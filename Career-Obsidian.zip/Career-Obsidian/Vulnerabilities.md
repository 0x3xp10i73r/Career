---
title: "Vulnerabilities"
kind: moc
tags:
  - vulnerabilities
  - status/not-started
  - moc
status: "Not started"
database: "Career"
area: "Vulnerabilities"
up: "[[Career]]"
notion-id: 394759b9275183dd90c701d8111c6b26
---

# Vulnerabilities

In: [[Career]]

## Contents

[[Authentication Vulnerabilities]]

[[Access Control Vulnerabilities]]

[[Business Logic Vulnerabilities]]

[[Command Injection]]

[[CORS - Cross Origin Resource Sharing]]

[[Cross Site Scripting]]

[[CSRF]]

[[File Upload]]

[[HTTP Host Header Attacks]]

**[[Information disclosure]]**

[[Vulnerabilities/Insecure Deserialization|Insecure Deserialization]]

[[JWT]]

[[NoSQL Injection]]

[[OAuth Vulnerabilities]]

[[Path Traversal]]

[[Prototype Pollution]]

[[Race Conditions]]

[[SSRF]]

[[Server Side Template Injection]]

[[SQL Injection]]

[[XXE - XML External Entity Injection]]

[[Vulnerabilities/HTTP Request Smuggling|HTTP Request Smuggling]]

[[DOM Based Vulnerabilities]]
