---
title: "Local Privilege Escaltion"
aliases:
  - "Local Privilege Escalation"
kind: moc
tags:
  - local-privilege-escaltion
  - status/not-started
  - moc
status: "Not started"
database: "Career"
area: "Local Privilege Escaltion"
up: "[[Career]]"
notion-id: 37e759b9275180358216e8752eba09b9
---

# Local Privilege Escaltion

In: [[Career]]

```bash
# Check for exposed inspector ports
ss -tunlp

# check sudo -
sudo -l

uname -r

ls -la /opt

getcap -r / 2>/dev/null

sudo /bin/nice /notes/../home/webadmin/root.sh

find /home -name "key" 2>/dev/null

```

[[Privilege Esc via Insecure debug interface ( Exposed Debugger )]]

[[Privilege Esc using Facter]]

**[[Privilege Esc via cap_setuid Capability on Python Interpreter]]**

**[[Privilege Esc Passwordless Sudo Misconfiguration]]**

[[Privilege Esc via Sudo Path Traversal via Incomplete Canonicalisation]]

**[[Privilege Esc via Sudo Misconfiguration and Writable Script Abuse]]**

[[Privilege Esc via Sudo Misconfiguration (Vim Abuse)]]

[[Privilege Esc via SUID Python Binary]]

[[Privilege Esc via Docker Group Membership]]

[[Privilege Esc via Exposed Backup SSH Key]]

[[Privilege Esc via Wildcard Injection (Tar Checkpoint Abuse)]]
