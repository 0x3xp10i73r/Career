---
title: "Lab: Stored DOM XSS"
aliases:
  - "Lab Stored DOM XSS"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "PRACTITIONER"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 398759b92751805bb013fec96d792b6b
---

# Lab: Stored DOM XSS

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab demonstrates a stored DOM vulnerability in the blog comment functionality. To solve this lab, exploit this vulnerability to call the alert() function.

![[attachments/PortSwigger Academy Labs/Lab - Stored DOM XSS/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - Stored DOM XSS/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - Stored DOM XSS/image 2.png]]
