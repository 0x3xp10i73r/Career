---
title: "Lab: Reflected XSS into HTML context with most tags and attributes blocked"
aliases:
  - "Lab Reflected XSS into HTML context with most tags"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "PRACTITIONER"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 398759b9275180359b89e09b3d1e3871
---

# Lab: Reflected XSS into HTML context with most tags and attributes blocked

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab contains a reflected XSS vulnerability in the search functionality but uses a web application firewall (WAF) to protect against common XSS vectors.

To solve the lab, perform a cross-site scripting attack that bypasses the WAF and calls the print() function.

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with most tags and attributes blocked/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with most tags and attributes blocked/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with most tags and attributes blocked/image 2.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with most tags and attributes blocked/image 3.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with most tags and attributes blocked/image 4.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with most tags and attributes blocked/image 5.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with most tags and attributes blocked/image 6.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with most tags and attributes blocked/image 7.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with most tags and attributes blocked/image 8.png]]
