---
title: "Lab: DOM XSS in jQuery anchor href attribute sink using location.search source"
aliases:
  - "PortSwigger Academy Labs - Lab: DOM XSS in jQuery anchor href attribute sink using location.search source"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "APPRENTICE"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 381759b9275180628cffef2cb5bd56f7
---

# Lab: DOM XSS in jQuery anchor href attribute sink using location.search source

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab contains a DOM-based cross-site scripting vulnerability in the submit feedback page. It uses the jQuery library's `$` selector function to find an anchor element, and changes its `href` attribute using data from `location.search`.

To solve this lab, make the "back" link alert `document.cookie`.

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in jQuery anchor href attribute sink using location.search source/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in jQuery anchor href attribute sink using location.search source/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in jQuery anchor href attribute sink using location.search source/image 2.png]]
