---
title: "Lab: Reflected XSS into a JavaScript string with angle brackets HTML encoded"
aliases:
  - "PortSwigger Academy Labs - Lab: Reflected XSS into a JavaScript string with angle brackets HTML encoded"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "APPRENTICE"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 398759b9275180b68790ca2425bdaa33
---

# Lab: Reflected XSS into a JavaScript string with angle brackets HTML encoded

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab contains a reflected cross-site scripting vulnerability in the search query tracking functionality where angle brackets are encoded. The reflection occurs inside a JavaScript string. To solve this lab, perform a cross-site scripting attack that breaks out of the JavaScript string and calls the alert function.

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into a JavaScript string with angle brackets HTML encoded/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into a JavaScript string with angle brackets HTML encoded/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into a JavaScript string with angle brackets HTML encoded/image 2.png]]
