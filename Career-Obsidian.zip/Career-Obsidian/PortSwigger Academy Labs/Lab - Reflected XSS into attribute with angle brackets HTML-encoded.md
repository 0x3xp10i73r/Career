---
title: "Lab: Reflected XSS into attribute with angle brackets HTML-encoded"
aliases:
  - "PortSwigger Academy Labs - Lab: Reflected XSS into attribute with angle brackets HTML-encoded"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "APPRENTICE"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 398759b9275180ac8377cb9ad0de433b
---

# Lab: Reflected XSS into attribute with angle brackets HTML-encoded

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab contains a reflected cross-site scripting vulnerability in the search blog functionality where angle brackets are HTML-encoded. To solve this lab, perform a cross-site scripting attack that injects an attribute and calls the alert function.

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into attribute with angle brackets HTML-encoded/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into attribute with angle brackets HTML-encoded/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into attribute with angle brackets HTML-encoded/image 2.png]]
