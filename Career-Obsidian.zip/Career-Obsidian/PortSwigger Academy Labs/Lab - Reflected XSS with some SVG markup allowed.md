---
title: "Lab: Reflected XSS with some SVG markup allowed"
aliases:
  - "Lab Reflected XSS with some SVG markup allowed"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "PRACTITIONER"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 3d6759b927518010aa11d78b8b281b93
---

# Lab: Reflected XSS with some SVG markup allowed

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab has a simple reflected XSS vulnerability. The site is blocking common tags but misses some SVG tags and events.

To solve the lab, perform a cross-site scripting attack that calls the alert() function.

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS with some SVG markup allowed/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS with some SVG markup allowed/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS with some SVG markup allowed/image 2.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS with some SVG markup allowed/image 3.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS with some SVG markup allowed/image 4.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS with some SVG markup allowed/image 5.png]]
