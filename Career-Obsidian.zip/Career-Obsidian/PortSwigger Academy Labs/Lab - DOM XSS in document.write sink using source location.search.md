---
title: "Lab: DOM XSS in document.write sink using source location.search"
aliases:
  - "PortSwigger Academy Labs - Lab: DOM XSS in document.write sink using source location.search"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "APPRENTICE"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 340759b92751800a9eb6f8414ca17c01
---

# Lab: DOM XSS in document.write sink using source location.search

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab contains a DOM-based cross-site scripting  vulnerability in the search query tracking functionality. It uses the  JavaScript `document.write` function, which writes data out to the page. The `document.write` function is called with data from `location.search`, which you can control using the website URL.

To solve this lab, perform a cross-site scripting attack that calls the `alert` function.

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in document.write sink using source location.search/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in document.write sink using source location.search/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in document.write sink using source location.search/image 2.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in document.write sink using source location.search/image 3.png]]
