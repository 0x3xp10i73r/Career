---
title: "Lab: File path traversal, simple case"
aliases:
  - "Lab File path traversal, simple case"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - path-traversal
status: "Done"
level: "APPRENTICE"
vulnerability: "Path Traversal"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 380759b9275180a98a5dc0813be95185
---

# Lab: File path traversal, simple case

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab contains a path traversal vulnerability in the display of product images.

To solve the lab, retrieve the contents of the `/etc/passwd` file.
