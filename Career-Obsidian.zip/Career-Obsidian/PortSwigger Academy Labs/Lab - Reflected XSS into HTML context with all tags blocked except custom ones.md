---
title: "Lab: Reflected XSS into HTML context with all tags blocked except custom ones"
aliases:
  - "Lab Reflected XSS into HTML context with all tags"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "PRACTITIONER"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 3d6759b927518096abd6d7f957f08ffc
---

# Lab: Reflected XSS into HTML context with all tags blocked except custom ones

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab blocks all HTML tags except custom ones.

To solve the lab, perform a cross-site scripting attack that injects a custom tag and automatically alerts document.cookie.

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with all tags blocked except custom ones/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with all tags blocked except custom ones/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with all tags blocked except custom ones/image 2.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with all tags blocked except custom ones/image 3.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with all tags blocked except custom ones/image 4.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with all tags blocked except custom ones/image 5.png]]
