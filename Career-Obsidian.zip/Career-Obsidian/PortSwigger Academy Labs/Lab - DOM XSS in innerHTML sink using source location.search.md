---
title: "Lab: DOM XSS in innerHTML sink using source location.search"
aliases:
  - "PortSwigger Academy Labs - Lab: DOM XSS in innerHTML sink using source location.search"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "APPRENTICE"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 340759b92751808d9205c7742e9bb32f
---

# Lab: DOM XSS in innerHTML sink using source location.search

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab contains a DOM-based cross-site scripting vulnerability in the search blog functionality. It uses an `innerHTML` assignment, which changes the HTML contents of a `div` element, using data from `location.search`.

To solve this lab, perform a cross-site scripting attack that calls the `alert` function.

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in innerHTML sink using source location.search/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in innerHTML sink using source location.search/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in innerHTML sink using source location.search/image 2.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in innerHTML sink using source location.search/image 3.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in innerHTML sink using source location.search/image 4.png]]
