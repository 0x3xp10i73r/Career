---
title: "Lab: Reflected XSS into HTML context with nothing encoded"
aliases:
  - "PortSwigger Academy Labs - Lab: Reflected XSS into HTML context with nothing encoded"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "APPRENTICE"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 340759b92751804d9358f35fb4054d32
---

# Lab: Reflected XSS into HTML context with nothing encoded

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab contains a simple reflected cross-site scripting vulnerability in the search functionality.

To solve the lab, perform a cross-site scripting attack that calls the `alert` function.

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with nothing encoded/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with nothing encoded/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with nothing encoded/image 2.png]]
