---
title: "Lab: DOM XSS in jQuery selector sink using a hashchange event"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "APPRENTICE"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 381759b9275180f2a613c5328a45ea35
---

# Lab: DOM XSS in jQuery selector sink using a hashchange event

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab contains a DOM-based cross-site scripting vulnerability on the home page. It uses jQuery's `$()` selector function to auto-scroll to a given post, whose title is passed via the `location.hash` property.

To solve the lab, deliver an exploit to the victim that calls the `print()` function in their browser.
