---
title: "Lab: DOM-based open redirection"
aliases:
  - "Lab DOM-based open redirection"
kind: lab
tags:
  - portswigger-academy-labs
  - status/not-started
  - lab
  - open-redirection
status: "Not started"
level: "PRACTITIONER"
vulnerability: "Open redirection"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 370759b927518041b80bcbed1544fb3a
---

# Lab: DOM-based open redirection

In: [[Career]] / [[PortSwigger Academy Labs]]

![[attachments/PortSwigger Academy Labs/Lab - DOM-based open redirection/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM-based open redirection/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM-based open redirection/image 2.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM-based open redirection/image 3.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM-based open redirection/image 4.png]]
