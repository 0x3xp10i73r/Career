---
title: "Lab: Stored XSS into anchor href attribute with double quotes HTML-encoded"
aliases:
  - "PortSwigger Academy Labs - Lab: Stored XSS into anchor href attribute with double quotes HTML-encoded"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "APPRENTICE"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 398759b927518089a9c3ec2daeb7314b
---

# Lab: Stored XSS into anchor href attribute with double quotes HTML-encoded

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab contains a stored cross-site scripting vulnerability in the comment functionality. To solve this lab, submit a comment that calls the alert function when the comment author name is clicked.

![[attachments/PortSwigger Academy Labs/Lab - Stored XSS into anchor href attribute with double quotes HTML-encoded/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - Stored XSS into anchor href attribute with double quotes HTML-encoded/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - Stored XSS into anchor href attribute with double quotes HTML-encoded/image 2.png]]
