---
title: "Lab: Stored XSS into HTML context with nothing encoded"
aliases:
  - "PortSwigger Academy Labs - Lab: Stored XSS into HTML context with nothing encoded"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "APPRENTICE"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 340759b9275180ba97a4ce57ed129951
---

# Lab: Stored XSS into HTML context with nothing encoded

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab contains a stored cross-site scripting vulnerability in the comment functionality.

To solve this lab, submit a comment that calls the `alert` function when the blog post is viewed.

![[attachments/PortSwigger Academy Labs/Lab - Stored XSS into HTML context with nothing encoded/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - Stored XSS into HTML context with nothing encoded/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - Stored XSS into HTML context with nothing encoded/image 2.png]]

![[attachments/PortSwigger Academy Labs/Lab - Stored XSS into HTML context with nothing encoded/image 3.png]]
