---
title: "Lab: DOM XSS in document.write sink using source location.search inside a select element"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "PRACTITIONER"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 398759b9275180c484d4d45f0e33e96a
---

# Lab: DOM XSS in document.write sink using source location.search inside a select element

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab contains a DOM-based cross-site scripting vulnerability in the stock checker functionality. It uses the JavaScript `document.write` function, which writes data out to the page. The `document.write` function is called with data from `location.search` which you can control using the website URL. The data is enclosed within a select element.

To solve this lab, perform a cross-site scripting attack that breaks out of the select element and calls the alert function.

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in document.write sink using source location.search inside a select element/image.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in document.write sink using source location.search inside a select element/image 1.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in document.write sink using source location.search inside a select element/image 2.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in document.write sink using source location.search inside a select element/image 3.png]]

![[attachments/PortSwigger Academy Labs/Lab - DOM XSS in document.write sink using source location.search inside a select element/image 4.png]]
