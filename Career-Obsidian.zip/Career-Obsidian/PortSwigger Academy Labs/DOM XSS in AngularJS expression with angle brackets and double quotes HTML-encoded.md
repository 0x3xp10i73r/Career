---
title: "DOM XSS in AngularJS expression with angle brackets and double quotes HTML-encoded"
aliases:
  - "DOM XSS in AngularJS expression with angle bracket"
kind: lab
tags:
  - portswigger-academy-labs
  - status/done
  - lab
  - cross-site-scripting
status: "Done"
level: "PRACTITIONER"
vulnerability: "Cross-Site Scripting"
database: "PortSwigger Academy"
area: "PortSwigger Academy Labs"
up: "[[PortSwigger Academy Labs]]"
notion-id: 398759b927518054b702e025175c74fc
---

# DOM XSS in AngularJS expression with angle brackets and double quotes HTML-encoded

In: [[Career]] / [[PortSwigger Academy Labs]]

This lab contains a DOM-based cross-site scripting vulnerability in a AngularJS expression within the search functionality.

AngularJS is a popular JavaScript library, which scans the contents of HTML nodes containing the ng-app attribute (also known as an AngularJS directive). When a directive is added to the HTML code, you can execute JavaScript expressions within double curly braces. This technique is useful when angle brackets are being encoded.

To solve this lab, perform a cross-site scripting attack that executes an AngularJS expression and calls the alert function.

![[attachments/PortSwigger Academy Labs/DOM XSS in AngularJS expression with angle brackets and double quotes HTML-encoded/image.png]]
