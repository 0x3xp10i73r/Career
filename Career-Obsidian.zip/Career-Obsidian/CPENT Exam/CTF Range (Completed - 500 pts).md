---
title: "CTF Range (Completed - 500 pts)"
kind: exam
tags:
  - cpent-exam
  - exam
area: "CPENT Exam"
up: "[[CPENT Exam]]"
notion-id: 259759b92751833281bc018800c03d9e
---

# CTF Range (Completed - 500 pts)

In: [[Career]] / [[CPENT Exam]]

**Scope**:

**IP Address Range**: 192.168.200.0/24

**Exclusion**: 192.168.200.1, 192.168.200.100

**Description**: In this zone, you will target
Linux-based environments and their security misconfigurations. Identify
and exploit vulnerabilities to compromise the systems and locate the
secret keys hidden on the targets.

### **Challenge 35: (30 Points)**

The server at 192.168.200.106 hosts a ticketing portal accessible via
http://192.168.200.106/ticketing. Enumerate the application's database
and determine the specialty associated with the agent Alice Smith.
(Answer Format: Xxxxxxxxxx)

```python
Networking
```

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_21-44-17.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_21-45-13.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_21-45-42.png]]

### **Challenge 36: (30 Points)**

What is the decoded password of the user account which allows you to
log in to the ticketing portal? (Answer format: xXNxxNxNxx)

```python
uG0tm3b4ck
```

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_21-46-45.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_21-48-17.png]]

### **Challenge 37: (50 Points)**

Compromise 192.168.200.106 and enter the value of local.txt. (Answer format: xNxxxNNxx)

```python
b7oql50ih
```

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-07-59.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-08-39.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-09-45.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-10-21.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-11-04.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/image.png]]

### **Challenge 38: (30 Points)**

Identify the binary that helps in attaining escalated privileges on
192.168.200.106 and determine it's file size in bytes. (Answer format:
NNNNNNN)

```python
1396520
```

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-16-32.png]]

### **Challenge 39: (60 Points)**

Compromise 192.168.200.106 and enter the value of Admin.txt. (Answer format: xxxNNxxxNN)

```python
kcn86hln90
```

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-18-51.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-20-32.png]]

### **Challenge 40: (30 Points)**

The machine 192.168.200.106 contains an SSH private key. Identify the
key and submit the first six characters of its content, found between
the BEGIN and END key tags. (Answer Format: xNXxxx)

```python
b3Blbn
```

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/image 1.png]]

### **Challenge 41: (30 Points)**

Name the CMS with version that is running on port 80 on machine at 192.168.200.127? (Answer Format: Xxxxxx N.N.N)

```python
Joomla 4.1.0
```

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-27-19.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-27-46.png]]

### **Challenge 42: (30 Points)**

Determine the password  for the valid SSH user account on the target
system with the IP address 192.168.200.127. (Answer Format: XxxxNxxxN)

is afftected with **[CVE-2023-23752](https://github.com/Acceis/exploit-CVE-2023-23752)**

```python
Whit3lin3
```

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-33-39.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-37-44.png]]

logged in using admin creds

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-51-39.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-52-30.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-53-28.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_22-52-52.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_23-02-58.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_23-03-35.png]]

### **Challenge 43: (50 Points)**

Determine the last six characters of the contents of the root.txt file
on the target machine at 192.168.200.127 (Answer Format: xxNNNN)

```python
fa6775
```

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-09-03_at_17-44-00_(2).png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_23-10-01.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_23-09-10.png]]

### **Challenge 44: (30 Points)**

What is the version number of apache server running on the machine  with IP 192.168.200.232? (Answer Format: N.N.NN)

```python
2.4.41
```

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_23-11-34.png]]

### **Challenge 45: (50 Points)**

Determine the WordPress plugin identified on the machine with the IP
address 192.168.200.232. (Answer Format: xxxxxxxxx-xxxxxxx)

```python
slideshow-gallery
```

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_23-27-23.png]]

### **Challenge 46: (30 Points)**

Retrieve the password for the henry user account on the target system
with the IP address 192.168.200.232.(Answer Format: xxxxxN)

```python
brent3
```

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_23-49-50.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_23-55-36.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-22_at_23-57-19.png]]

### Challenge 47: (50 Points) Determine the first five characters of the contents of root.txt on the target system (192.168.200.232)? (Answer Format: XNxxx)

```python
M5qmm
```

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-08-23_at_00-01-26.png]]

![[attachments/CPENT Exam/CTF Range (Completed - 500 pts)/Screenshot_2026-09-03_at_17-48-02.png]]
