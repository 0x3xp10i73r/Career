---
title: "Web APP 1"
kind: exam
tags:
  - cpent-exam
  - exam
area: "CPENT Exam"
up: "[[Web Range - (Completed - 500 Points)]]"
notion-id: 258759b9275182fe997681731684d17b
---

# Web APP 1

In: [[Career]] / [[CPENT Exam]] / [[Web Range - (Completed - 500 Points)]]

![[attachments/CPENT Exam/Web Range - (Completed - 500 Points)/Web APP 1/Screenshot_2026-08-22_at_20-02-08.png]]
