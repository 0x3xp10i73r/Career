---
title: "Web App 2"
kind: exam
tags:
  - cpent-exam
  - exam
area: "CPENT Exam"
up: "[[Web Range - (Completed - 500 Points)]]"
notion-id: df5759b92751820b9bb3811d5636744d
---

# Web App 2

In: [[Career]] / [[CPENT Exam]] / [[Web Range - (Completed - 500 Points)]]

![[attachments/CPENT Exam/Web Range - (Completed - 500 Points)/Web App 2/Screenshot_2026-08-22_at_20-57-07.png]]
