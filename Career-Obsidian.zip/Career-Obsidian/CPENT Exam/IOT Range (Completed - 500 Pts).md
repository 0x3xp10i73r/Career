---
title: "IOT Range (Completed - 500 Pts)"
kind: exam
tags:
  - cpent-exam
  - exam
area: "CPENT Exam"
up: "[[CPENT Exam]]"
notion-id: 052759b927518381a4ae010da990200a
---

# IOT Range (Completed - 500 Pts)

In: [[Career]] / [[CPENT Exam]]

**Scope**:

**IP Address Range**: 172.25.120.0/24

**Exclusion**: 172.25.120.250

**Target machine 1**: 172.25.120.110

**Username**: ubuntu

**Password**: toor

**Target machine 2**: 172.25.120.100

**Username**: cpent

**Password**: cpentpw

**Description**: In this zone, you will need to identify  the target, map the attack surface, and then gain access; once you gain  access, you need to reverse engineer the firmware and answer the  questions. As you build your target database, make a note of any  hard-coded credentials. Once you find a firmware image, analyze the  extracted file system and look at the code, which in many cases will be  PHP, etc..

### **Challenge 13: (20 Points)**

What is the block size of IOT.bin file in bytes (Answer Format: NNNNN)

```text
6099215
```

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-09-59.png]]

### **Challenge 14: (20 Points)**

What is the CPU architecture of the iot2.bin file? (Answer Format: Xxxxxxxx)

```text
Blackfin
```

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-14-51.png]]

### **Challenge 15: (20 Points)**

Determine the Linux version compatible with the IOT2.bin file (Answer Format: Xxxxx N.N.NN.N)

```text
Linux 2.6.26.5
```

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/image.png]]

### **Challenge 16: (30 Points)**

Determine the file format of the extracted file 813682 from IOT3.bin (Answer Format: XXX)

```python
ELF
```

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/image 1.png]]

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-22-32.png]]

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-24-55.png]]

Sure — in short, you did **firmware extraction and identification**:

1. **`binwalk -e IOT3.bin`** → scanned the firmware and found embedded compressed files.
2. It found an **XZ-compressed file** at offset `0x813682`.
3. Binwalk extracted and decompressed it into:

    ```
    _IOT3.bin.extracted/813682
    ```

4. You ran:

    ```bash
    file ./_IOT3.bin.extracted/813682
    ```

5. `file` identified it as:

    ```
    ELF 32-bit LSB relocatable, ARM, EABI5
    ```

6. Therefore, the challenge answer was **`ELF`**.

**In one line:**

`IOT3.bin → Binwalk → find XZ → extract/decompress → file → identify as ELF.`

I can also give you a short cheat sheet for the firmware-analysis commands you've used in Challenges 13–16.

### **Challenge 17: (20 Points)**

Determine the offset value of the extracted file D8232C within IOT3.bin (Answer Format: NxNNxNNN)

```python
0xD8232C
```

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-27-29.png]]

In short, for **Challenge 17**:

1. We used `binwalk` to analyze `IOT3.bin`.
2. We searched its output for `D8232C`:

    ```bash
    binwalk IOT3.bin | grep -i 'D8232C'
    ```

3. Binwalk reported:

    ```
    14164780  0xD8232C  xz compressed data
    ```

4. `0xD8232C` is the **hexadecimal offset** where that extracted XZ file starts inside `IOT3.bin`.

### **Challenge 18: (20 Points)**

What is the IP address of the device named DSP-W215 found in the database file of IOT4.bin? (Answer Format: NNN.NNN.N.NN)

```python
192.168.0.60
```

1. **Extracted the firmware**

    ```bash
    binwalk -e IOT4.bin
    ```

    This extracted the SquashFS filesystem.

2. **Searched for the database**

    ```bash
    find _IOT4.bin.extracted -name 'config.sqlite' -type f
    ```

    This found:

    ```
    _IOT4.bin.extracted/squashfs-root/mnt/config.sqlite
    ```

3. **Identified the relevant database table**

    From the extracted strings/schema, we saw the `NetworkSettings` table contains:

    - `DeviceName`
    - `IPAddr`
4. **Queried the database**

    ```bash
    sqlite3 _IOT4.bin.extracted/squashfs-root/mnt/config.sqlite "SELECT DeviceName, IPAddr FROM NetworkSettings;"
    ```

5. We then look for the **DSP-W215** row and take its `IPAddr` as the answer.

So the basic process was:

**IOT4.bin → extract filesystem → find `config.sqlite` → query `NetworkSettings` → find DSP-W215 → get its IP address.**

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-34-28.png]]

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-33-52.png]]

### **Challenge 19: (30 Points)**

```python
v1.21.1
```

What is the version of BusyBox used in IOT4.bin? (Answer Format: xN.NN.N)

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-36-32.png]]

### **Challenge 20: (30 Points)**

What is the GCC version used to compile the file located at offset 464A28 in the IoT5.bin image? (Answer Format: N.N.N)

```python
4.3.1
```

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-40-14.png]]

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-40-49.png]]

Sure. For **Challenge 20**, the process was:

### 1. Understand what the challenge asks

The challenge asks:

> [!question]
> What is the **GCC version** used to compile the file at offset `464A28` in `IoT5.bin`?
>

So we need to inspect the data located at that offset and look for compiler information.

### 2. Identify the extracted file

Binwalk had already extracted the data from `IoT5.bin`, giving us:

```
_IOT5.bin.extracted/464A28
```

Here, `464A28` represents the **hexadecimal offset** where the file/data was found inside the firmware.

### 3. Use `strings`

The extracted file is a binary, so running `cat` wouldn't give useful readable output.

We used:

```bash
strings _IOT5.bin.extracted/464A28
```

`strings` scans a binary and extracts sequences of printable characters.

This is useful because compiled binaries often contain metadata such as:

- Linux kernel version
- GCC/compiler version
- build date
- architecture information
- library names
- error messages

### 4. Search specifically for GCC

Instead of looking through everything, we piped the output into:

```bash
grep -i 'GCC'
```

So the complete command was:

```bash
strings _IOT5.bin.extracted/464A28 | grep -i 'GCC' | head
```

Breakdown:

```
strings
   ↓
Extract readable text from binary

|
   ↓
Pass that text to grep

grep -i 'GCC'
   ↓
Search for "GCC", ignoring case

head
   ↓
Show only the first few matching lines
```

### 5. We found the compiler information

The output contained:

```
gcc version 4.3.1 20080521 (prerelease)
...
(GCC 4.3.1 Axis release R11/1.1)
```

The important part is:

```
gcc version 4.3.1
```

Therefore:

### ✅ Challenge 20 Answer: `4.3.1`

**In one sentence:** We extracted readable strings from the binary at offset `464A28`, searched those strings for GCC metadata, and found that the file was compiled using **GCC 4.3.1**.

### **Challenge 21: (20 Points)**

Analyze the file IOT5.bin in 172.25.120.110 and determine its file system. (Answer format: XXXXN)

```python
JFFS2
```

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-43-04.png]]

### **Challenge 22: (40 Points)**

On the Machine 172.25.120.100, analyze IOT firmware image FileOne.bin and determine the image size. (Answer format: NNNNNNN)

```python
7754752
```

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-47-21.png]]

### **Challenge 23: (100 Points)**

What is the starting address of the file system in FileTwo.bin on 172.25.120.100? (Answer format: NxXNNNN)

```python
0xE0080
```

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-50-12.png]]

### **Challenge 24: (50 Points)**

On the machine 172.25.120.110, in IOT6.bin, which file contains the root user’s password? (Answer format: xxxxxx)

```python
passwd
```

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-52-42.png]]

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_00-53-14.png]]

### **Challenge 25: (100 Points)**

On IP address 172.25.120.110, what is the firmware device for the IOT6.bin firmware? (Answer format: XXXXNNNN)

```python
NETG0100
```

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_01-13-28.png]]

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/Screenshot_2026-08-23_at_01-14-52.png]]

![[attachments/CPENT Exam/IOT Range (Completed - 500 Pts)/image 2.png]]

Here's the full command sequence to reproduce the finding from scratch, in order:

```bash
# 1. Extract the firmware filesystem
binwalk -e IOT6.bin

# 2. Move into the extraction directory
cd _IOT6.bin-0.extracted

# 3. Confirm the extracted squashfs root exists
ls

# 4. Identify the board/model config baked into the build
cat squashfs-root/userfs/profile.cfg | grep -i "AYECOM_"
```

This confirms the model:

```
AYECOM_MODELNAME="D6000"
AYECOM_HWID="NETG01"
```

```bash
# 5. Find the script that maps product name -> real runtime HWID
find squashfs-root -iname "*presetting*"

# 6. Read it to get the actual HWID mapping table
cat squashfs-root/usr/script/product_presetting.sh
```

That last command reveals the mapping block:

```bash
elif [ "$1" = "D6000" ] ; then
        $SYSCMD hwid NETG0100
```

**Answer for D6000: `NETG0100`**

One-liner version if you just want to jump straight to the payoff on a similar future challenge:

```bash
binwalk -e IOT6.bin && cd _IOT6.bin-0.extracted && grep -A1 'D6000\|D3600\|D3610\|D6010' squashfs-root/usr/script/product_presetting.sh
```
