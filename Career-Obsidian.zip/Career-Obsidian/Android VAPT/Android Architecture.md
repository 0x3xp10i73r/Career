---
title: "Android Architecture"
kind: topic
tags:
  - android-vapt
area: "Android VAPT"
up: "[[Android VAPT]]"
notion-id: bba759b9275183a6aa79813b9e5607fa
---

# Android Architecture

In: [[Career]] / [[Android VAPT]]

![[attachments/Android VAPT/Android Architecture/image.png]]
