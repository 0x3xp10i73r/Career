---
title: "Mobile OWASP Top 10"
kind: topic
tags:
  - android-vapt
area: "Android VAPT"
up: "[[Android VAPT]]"
notion-id: cc8759b9275183cb82da8143a383541c
---

# Mobile OWASP Top 10

In: [[Career]] / [[Android VAPT]]

![[attachments/Android VAPT/Mobile OWASP Top 10/image.png]]
