---
title: "Intro"
aliases:
  - "Android VAPT - Intro"
kind: topic
tags:
  - android-vapt
area: "Android VAPT"
up: "[[Android VAPT]]"
notion-id: 6e3759b927518277b9e701549df8d4a2
---

# Intro

In: [[Career]] / [[Android VAPT]]

## Android APK Structure

**Definition**

- APK files contain compiled application code, resources, metadata, and optional native libraries.

#### How It Works

- APK packages contain multiple components used by Android during application execution.

#### Common APK Components

| Component | Purpose |
| --- | --- |
| `AndroidManifest.xml` | Defines application metadata, permissions, and components |
| `classes.dex` | Contains Dalvik bytecode |
| `resources.arsc` | Precompiled application resources |
| `res/` | Application resource files |
| `assets/` | Raw application assets |
| `lib/` | Native compiled libraries |
| `META-INF/` | APK signature and metadata |

#### Detection / Mitigation

- Review APK contents during static analysis.
- Verify APK signature integrity.
- Inspect native libraries for vulnerabilities.

---

## AndroidManifest.xml

**Definition**

- Core configuration file inside an APK that defines application metadata, permissions, and application components.

#### How It Works

- Declares:
    - Package name
    - Application version
    - Activities
    - Services
    - Receivers
    - Providers
    - Permissions

#### Common Manifest Attributes

| Attribute | Purpose |
| --- | --- |
| `manifest` | Defines package name and build information |
| `permissions` | Declares custom permissions |
| `uses-permission` | Requests Android permissions |
| `uses-feature` | Declares hardware/software dependencies |
| `application` | Defines application-level configuration |
| `activity` | Declares UI activities |
| `intent-filter` | Specifies accepted intents |
| `service` | Declares background services |
| `receiver` | Declares broadcast receivers |
| `provider` | Declares content providers |

#### Detection / Mitigation

- Review exported components.
- Identify excessive permissions.
- Check for insecure intent filters and exposed providers.
