---
title: "CheckList"
aliases:
  - "Android VAPT - CheckList"
kind: topic
tags:
  - android-vapt
area: "Android VAPT"
up: "[[Android VAPT]]"
notion-id: 3e4759b92751803fa511e6029d9c44ae
---

# CheckList

In: [[Career]] / [[Android VAPT]]

## Testing Categories Overview

```
Static Analysis → Dynamic Analysis → Network Analysis → Permission Analysis → Cryptographic Analysis → Data Storage Analysis
```

---

## Checklist by Category

### C01 — SSL Pinning

- Missing SSL pinning altogether
- Test if bypassable via Frida/Objection
- Check if code manipulation is possible

**Bypass commands:**

```bash
# Frida
frida --codeshare pcipolloni/universal-android-ssl-pinning-bypass-with-frida -f <package>

# Objection
android sslpinning disable --quiet
```

---

### C02 — Root Detection

- Missing root detection
- Test if bypassable via Frida/Objection
- Check if internal logic flow can be modified

```bash
# Frida
frida --codeshare dzonerzy/fridantiroot -f <package>

# Objection
android root disable --quiet
```

---

### C03 — Emulator Detection

- Missing emulator detection
- Test bypass via Frida script

---

### C04 — Sensitive Data in Logcat

- Check logs for passwords, tokens, PII
- Check for unencrypted request/data in logs

```bash
adb logcat | grep -i "password\|token\|secret\|key"
```

---

### C05 — Sensitive Data in Local Storage

- SharedPreferences — stored unencrypted?
- Temporary files
- Local database using strong encryption?
- Other files on device storage

---

### C06 — Sensitive Data in App Memory

- Use Fridump to dump app memory

```bash
python3 fridump.py -U -s <package_name>
strings dump_file | grep -i "password\|token"
```

---

### C07 — Weak Signer Certificate

- Signed with weak algorithm (e.g., `SHA1withRSA`)?
- Check for **Janus Vulnerability** (CVE-2017-13156)
- Signed with debug certificate?

---

### C08 — Vulnerable Android Activities

- **Authentication bypass** via direct ADB activity launch
- Exported activities accessible by other apps
- Activity hijacking
- Activity causing DoS/crash

```bash
# Launch activity directly bypassing auth
adb shell am start -n <package>/<activity>
```

---

### C09 — WebView Vulnerabilities

- XSS via WebView
- Local File Inclusion (LFI) via WebView
- JavaScript enabled insecurely (`setJavaScriptEnabled(true)`)

---

### C10 — Intent Filters

- Intent spoofing or sniffing (like OpenRedirect but for Android)
- Check if intent data is validated/filtered

---

### C11 — Broadcast Receivers

- Check manifest for `<receiver android:exported="true">` with no permissions set

---

### C12 — Content Providers

- SQL injection via content provider
- Path traversal via content provider
- Internal data access via unprotected provider

```bash
# Drozer
run scanner.provider.injection <package>
run scanner.provider.traversal <package>
run scanner.provider.finduris <package>
```

---

### C13 — Source Code Obfuscation

- ProGuard implemented?
- Sensitive code properly obfuscated?

---

### C14 — Hardcoded Sensitive Info

- Hardcoded API keys, tokens, passwords in source code
- Use MobSF or grep decompiled code

```bash
grep -r "api_key\|password\|secret\|token" decompiled_source/
```

---

### C15 — Insecure Coding Practices

- Insecure random number generators (guessable OTPs)
- Insecure function calls
- Weak crypto: MD5 hash, Base64 "encoding" used as encryption
- Other coding weaknesses

---

### C16 — Insecure Deeplinks

- Explicit deeplinks with PendingIntent to sensitive areas
- Implicit deeplinks not properly validated

---

### C17 — Missing Integrity Checks

- Decompile → modify → recompile → sign → check if app still works
- No tamper detection = vulnerable to repackaging attacks

---

### C18 — Insecure AndroidManifest.xml

Check for:

- `android:usesCleartextTraffic="true"` — allows HTTP
- `android:debuggable="true"` — debug mode enabled
- `android:allowBackup="true"` — backup enabled
- `dataExtractionRules` not properly defined
- Unnecessary permissions

---

### C19 — Background Screen Caching

- Screenshots taken when app goes to background
- Check with `FLAG_SECURE`

---

### C20 — Insecure Firebase Database

```bash
# Append .json to Firebase URL
https://<project>.firebaseio.com/.json

# Try appspot variant
https://<project>.appspot.com/.json
```

---

### C21 — Biometric/Lock Bypass

- Runtime hook biometric authentication
- Modify return value via Frida/Objection

---

### C22 — Dynamic Analysis API Checks

- Test API endpoints with comprehensive API checklist
- Broken Access Control
- Server-side injection
- Security misconfigurations
- Sensitive data exposure
- Fuzzing

---

## Essential ADB Commands

```bash
# Device management
adb devices
adb start-server / adb kill-server
adb reboot

# App management
adb shell pm list packages -3          # list 3rd party apps
adb shell pm list packages 'keyword'   # find app
adb install <app.apk>
adb uninstall <package>
adb shell monkey -p <package> -c 1     # launch app
adb shell am start -n <package>/.<activity>  # launch specific activity

# File operations
adb push <file> /storage/emulated/0/
adb pull /storage/emulated/0/<file> ./
adb exec-out run-as <package> cat <file> > local_file  # bypass permission denied

# Shell access
adb shell
adb shell su   # root shell

# Logcat
adb logcat

# ADB over WiFi
adb tcpip 5555
adb connect <device_ip>:5555
```

---

## Essential Frida Commands

```bash
# List apps
frida-ps -Uai
frida-ps -Uai | grep -i 'keyword'

# Run bypass scripts
frida --codeshare dzonerzy/fridantiroot -f <package>
frida --codeshare pcipolloni/universal-android-ssl-pinning-bypass-with-frida -f <package>
frida --codeshare fdciabdul/frida-multiple-bypass -f <package>  # all-in-one

# Combine scripts
frida --codeshare dzonerzy/fridantiroot --codeshare pcipolloni/universal-android-ssl-pinning-bypass-with-frida -f <package>
```

---

## Essential Objection Commands

```bash
# Connect
objection --gadget <package> explore

# SSL pinning bypass
android sslpinning disable --quiet

# Root bypass
android root disable --quiet

# Enumerate
android hooking list activities <package>
android hooking list services <package>
android hooking list receivers <package>
android hooking get current_activity

# Memory
memory dump all 'dump.dmp'
memory search 'password' --string

# Hook a method
android hooking watch class_method <package>.<class>.<method> --dump-args --dump-backtrace --dump-return

# Alter return value
android hooking set return_value <package>.<class>.<method> false

# SQLite
sqlite connect <db_file>
sqlite execute query "select * from users"
```

---

## Key Tools Summary

| Tool | Purpose |
| --- | --- |
| **MobSF** | Static + dynamic analysis, automated scanning |
| **JADX** | Decompile APK → readable Java |
| **Apktool** | Decompile/recompile APK (smali) |
| **Frida** | Runtime instrumentation + hook/modify methods |
| **Objection** | Frida-based CLI for runtime analysis |
| **Drozer** | Attack surface enumeration via ADB |
| **Burp Suite** | Intercept/modify HTTP/S traffic |
| **APKLeaks** | Find secrets/endpoints in APK |
| **Fridump** | Dump app memory via Frida |
| **DB Browser (SQLite)** | View app SQLite databases |
| **ADB** | Device communication and shell access |

---

## Practice Apps

- DIVA (Damn Insecure Vulnerable App)
- InsecureBankv2
- OVAA (Oversecured Vulnerable Android App)
- VyAPI (Cloud + Android hybrid)
- WaTF Bank
- Vuldroid
