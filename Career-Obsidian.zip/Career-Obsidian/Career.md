---
title: "Career"
aliases:
  - "Home"
  - "Index"
  - "Start here"
kind: home
notion-id: 36c759b927518058a7fbdf1bbb746a0d
---

# Career

Pentest notes, labs, machines, and exam writeups converted from the Notion export into an Obsidian vault.

> [!info] Open this vault
> Unzip the folder, then in Obsidian choose **Open folder as vault** and select `Career-Obsidian`. This note is the map. Wikilinks, properties, aliases, and backlinks are already filled in.

> [!warning] Screenshots are linked, not included
> The Notion export had 875 screenshot embeds and zero image files (872 unique files; a few notes reuse one). Every embed already points at its final path under `attachments/`. Send a directory listing that keeps the folders — `image.png` is not unique — and a mover script can copy each file onto that path. Map: [[image manifest]] (`Meta/image-manifest.json`). Notes: [[conversion report]].

## Tracker

The areas below were the Notion database on this page. Status, date, and the other fields are also stored on each note.

| Area | Status |
| --- | --- |
| [[Nmap Study]] | ⬜ Not started |
| [[PortSwigger Academy Labs]] | ⬜ Not started |
| [[TryHackMe Rooms]] | ⬜ Not started |
| [[Vulnerabilities]] | ⬜ Not started |
| [[Android VAPT]] | ⬜ Not started |
| [[CPTS HackTheBox]] | ⬜ Not started |
| [[Hack The Box Labs]] | ⬜ Not started |
| [[Local Privilege Escaltion]] | ⬜ Not started |
| [[Bandit]] | ⬜ Not started |
| [[Offsec PG Play]] | ⬜ Not started |
| [[Bug Thive Labs]] | ⬜ Not started |
| [[Active Directory]] | ⬜ Not started |
| [[HTB Modules]] | ⬜ Not started |
| [[CPENT Exam]] | ⬜ Not started |
| [[Windows]] | ⬜ Not started |

## Outside the tracker

- [[Linux Privilege Escaltion]]

## Live query

%% Install Dataview if you want this block to become a live table. The tracker above does not need it. %%

```dataview
TABLE kind AS Kind, status AS Status, difficulty AS Difficulty, date AS Date, area AS Area
WHERE kind = "writeup" OR kind = "lab" OR kind = "exam"
SORT area ASC, file.name ASC
```
