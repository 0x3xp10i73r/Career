---
title: "Summary"
aliases:
  - "Nmap Advanced Port Scans - Summary"
kind: topic
tags:
  - nmap-study
area: "Nmap Study"
up: "[[Nmap Advanced Port Scans]]"
notion-id: 232759b927518067aef5e40a80581f3d
---

# Summary

In: [[Career]] / [[Nmap Study]] / [[Nmap Advanced Port Scans]]

## **🔍 Nmap Advanced Scan Types – Summary**

### **🚩 TCP Flag-Based Scans**

| **Scan Type** | **Command Example** | **Purpose** |
| --- | --- | --- |
| **Null Scan** | sudo nmap -sN 10.10.130.41 | Sends no TCP flags. Closed ports reply with RST. |
| **FIN Scan** | sudo nmap -sF 10.10.130.41 | Sends TCP FIN flag. Closed ports reply with RST. |
| **Xmas Scan** | sudo nmap -sX 10.10.130.41 | Sends FIN, PSH, URG flags. Closed ports reply with RST. |
| **Maimon Scan** | sudo nmap -sM 10.10.130.41 | FIN + ACK flags. May bypass some filters, rarely useful today. |
| **ACK Scan** | sudo nmap -sA 10.10.130.41 | Used to map firewall rules, not port state. |
| **Window Scan** | sudo nmap -sW 10.10.130.41 | Like ACK scan, but uses TCP window size to infer port state. |
| **Custom TCP Scan** | sudo nmap --scanflags URGACKPSHRSTSYNFIN 10.10.130.41 | Sets custom TCP flags manually for testing behavior. |

---

### **🎭 Spoofing & Evasion Techniques**

| **Technique** | **Command/Option** | **Purpose** |
| --- | --- | --- |
| **Spoofed Source IP** | sudo nmap -S SPOOFED_IP 10.10.130.41 | Makes scan appear from another IP. Must sniff replies separately. |
| **Spoofed MAC Address** | --spoof-mac SPOOFED_MAC | Hides real MAC address. Must be on same network. |
| **Decoy Scan** | nmap -D DECOY1_IP,ME 10.10.130.41 | Hides real source among fake IPs. |
| **Idle Scan** | sudo nmap -sI ZOMBIE_IP 10.10.130.41 | Fully stealthy. Uses a predictable idle host for scanning. |
| **Fragmented Scan** | -f or -ff | Splits IP packets into 8 or 16 bytes to avoid detection. |

---

### **🧪 Customization & Obfuscation**

| **Option** | **Purpose** |
| --- | --- |
| --source-port <PORT> | Sets custom source port for probes. Can trick poorly configured firewalls. |
| --data-length <NUM> | Appends random data to packets to reach specific length. |

---

### **🗣️ Output & Verbosity**

| **Option** | **Purpose** |
| --- | --- |
| --reason | Explains why Nmap determined a port as open/closed/etc. |
| -v | Verbose output |
| -vv | Very verbose output |
| -d | Debugging mode |
| -dd | Extended debugging output |
