---
title: "Idle/Zombie Scan"
aliases:
  - "Idle Zombie Scan"
kind: topic
tags:
  - nmap-study
area: "Nmap Study"
up: "[[Nmap Advanced Port Scans]]"
notion-id: 231759b9275180849217d85041ed6042
---

# Idle/Zombie Scan

In: [[Career]] / [[Nmap Study]] / [[Nmap Advanced Port Scans]]

## **🧟 Idle (Zombie) Scan – Nmap**

### **📌 What is an Idle Scan?**

An **Idle Scan** (also known as a **Zombie Scan**) is a **stealthy port scanning technique** in which the **attacker uses an idle (non-active) system** to send spoofed probes to the target. The attacker’s system **never directly interacts** with the target, making it difficult to detect.

---

### **🛠️ Command Format**

```
nmap -sI ZOMBIE_IP TARGET_IP
```

- ZOMBIE_IP: IP address of the idle machine (a quiet host with predictable IP IDs)
- TARGET_IP: IP address of the target system

---

### **📊 How It Works – 3 Steps**

#### **1. 🧠 Baseline IP ID Check**

- Attacker sends a SYN/ACK to the zombie.
- Zombie replies with RST, and attacker records its current **IP ID**.

#### **2. 🎯 Spoofed Probe**

- Attacker sends a SYN to the **target**, **spoofing the zombie’s IP** as the source.
- Target responds based on port state:
    - **Open** → sends SYN/ACK to zombie → zombie replies with RST → **IP ID increases by 1**
    - **Closed** → sends RST to zombie → no response → **IP ID stays the same**
    - **Filtered** → no response → **IP ID stays the same**

#### **3. 📈 Check IP ID Again**

- Attacker sends another SYN/ACK to zombie.
- Zombie responds with RST → attacker reads new **IP ID**.

---

### **🧠 IP ID Difference Interpretation**

| **IP ID Difference** | **Conclusion** |
| --- | --- |
| 1 | Port is **closed** or **filtered** |
| 2 | Port is **open** |
| >2 or inconsistent | Zombie is **not idle** (unreliable) |

---

### **✅ Requirements**

- **Idle zombie host**: Must have predictable, incrementing IP ID behavior.
- **Same subnet** or ability to **monitor zombie’s responses**.
- Works best on **quiet machines** (e.g., old printers, IoT devices).

---

### **🎯 Advantages**

- **Completely stealthy** — no traffic between **attacker and target**.
- Difficult for firewalls and IDS to trace back to attacker.

### **⚠️ Limitations**

- Depends on **predictable IP ID behavior**.
- Useless if zombie is **not idle** or **high-traffic**.
- **Firewall filtering** can disrupt scan accuracy.
