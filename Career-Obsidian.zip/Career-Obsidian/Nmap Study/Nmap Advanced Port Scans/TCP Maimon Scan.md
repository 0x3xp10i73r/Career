---
title: "TCP Maimon Scan"
kind: topic
tags:
  - nmap-study
area: "Nmap Study"
up: "[[Nmap Advanced Port Scans]]"
notion-id: 231759b927518067b14fcb8e5888702e
---

# TCP Maimon Scan

In: [[Career]] / [[Nmap Study]] / [[Nmap Advanced Port Scans]]

Here’s a **concise markdown summary** of the **Maimon Scan** as described:

---

## **🔎 TCP Maimon Scan (Nmap -sM)**

### **📜 Origin**

- Described by **Uriel Maimon** in **1996**
- Designed to **bypass some firewall rules and detect open ports** on certain systems (especially **BSD-derived**)

---

### **⚙️ Scan Characteristics**

- **Flags Set:** FIN + ACK
- **Command:**

```bash
sudo nmap -sM TARGET_IP
```

---

### **🧠 Scan Logic**

- **Closed ports:** Send back an **RST**
- **Open ports (on vulnerable systems):** **Drop** the packet (no response)

This allows Nmap to **infer open|filtered** status when **no RST is received**, but **only works on specific systems**.

---

### **📉 Effectiveness**

- 🔹 **Modern systems:** Usually respond with RST for *both open and closed ports*, making the scan **ineffective**
- 🔹 **Limited use cases:** Can help evade detection or firewalls on **legacy or poorly configured systems**
- 🔹 **Primarily educational** to understand scanning mechanisms and bypass logic

---

### **🖥️ Example Output**

```
pentester@TryHackMe$ sudo nmap -sM 10.10.252.27

Starting Nmap 7.60 ( https://nmap.org ) at ...
All 1000 scanned ports on 10.10.252.27 are closed
```

> [!important]
> Indicates
>
>
> **no open ports detected**
>

---

### **🛠️ When to Use**

- As a **fallback** method during **stealthy recon**
- On **older systems**, especially **BSD or misconfigured firewalls**

Let me know if you’d like a comparison with other stealth scans like Null, FIN, or Xmas.
