---
title: "Summary"
aliases:
  - "Nmap Basic Port Scans - Summary"
kind: topic
tags:
  - nmap-study
area: "Nmap Study"
up: "[[Nmap Basic Port Scans]]"
notion-id: 231759b92751806ba3eac39565a835b0
---

# Summary

In: [[Career]] / [[Nmap Study]] / [[Nmap Basic Port Scans]]

## **🔍 Nmap Scan Types and Options**

### **📌Port Scan Types**

| **Scan Type** | **Example Command** | **Description** |
| --- | --- | --- |
| **TCP Connect Scan** | nmap -sT 10.10.12.15 | Used when not running as root; completes full 3-way handshake |
| **TCP SYN Scan** | sudo nmap -sS 10.10.12.15 | Most common and stealthy; only sends SYN packets |
| **UDP Scan** | sudo nmap -sU 10.10.12.15 | Probes UDP ports; slower and less reliable than TCP |

---

### **⚙️**

### **Useful Nmap Options**

| **Option** | **Purpose** |
| --- | --- |
| -p- | Scan **all** 65535 ports |
| -p1-1023 | Scan **well-known** ports (1 to 1023) |
| -F | Scan **100 most common** ports |
| -r | Scan ports in **sequential** order |
| -T<0-5> | Timing template (0=slowest, 5=fastest) |
| --max-rate 50 | Limit scan to **≤ 50 packets/sec** |
| --min-rate 15 | Ensure scan sends **≥ 15 packets/sec** |
| --min-parallelism 100 | Use at least **100 probes in parallel** |
