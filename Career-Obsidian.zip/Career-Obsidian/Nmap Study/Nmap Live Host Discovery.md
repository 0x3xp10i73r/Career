---
title: "Nmap Live Host Discovery"
kind: moc
tags:
  - nmap-study
  - moc
area: "Nmap Study"
up: "[[Nmap Study]]"
notion-id: 231759b9275180398ad5de89176f9539
---

# Nmap Live Host Discovery

In: [[Career]] / [[Nmap Study]]

#### **🚀 Nmap Default Behavior**

| **User Type** | **Network Type** | **Method Used** |
| --- | --- | --- |
| **Privileged** | Local (Ethernet) | ARP requests |
| **Privileged** | External | ICMP Echo, ICMP Timestamp, TCP ACK (port 80), TCP SYN (port 443) |
| **Unprivileged** | External | TCP SYN to port 80 & 443 (3-way handshake) |

[[Nmap Host discovery using ARP]]

[[Nmap Host Discovery using ICMP]]

[[Nmap Host Discovery Using TCP and UDP]]

## **🧭 Nmap Host Discovery Summary (No Port Scanning)**

Any response = target is **online** ✅

### **🔍 Command Summary**

| **Scan Type** | **Example Command** | **Notes** |
| --- | --- | --- |
| **ARP Scan** | sudo nmap -PR -sn MACHINE_IP/24 | Local subnet only |
| **ICMP Echo Scan** | sudo nmap -PE -sn MACHINE_IP/24 | May be blocked by firewalls |
| **ICMP Timestamp Scan** | sudo nmap -PP -sn MACHINE_IP/24 | Alternative to Echo, less common |
| **ICMP Address Mask Scan** | sudo nmap -PM -sn MACHINE_IP/24 | Rarely used, often blocked |
| **TCP SYN Ping Scan** | sudo nmap -PS22,80,443 -sn MACHINE_IP/30 | SYN to known ports, root required |
| **TCP ACK Ping Scan** | sudo nmap -PA22,80,443 -sn MACHINE_IP/30 | Sends ACKs, expects RST |
| **UDP Ping Scan** | sudo nmap -PU53,161,162 -sn MACHINE_IP/30 | Expects ICMP Port Unreachable response |

---

### **⚙️ Key Nmap Options**

| **Option** | **Purpose** |
| --- | --- |
| -n | Skip DNS resolution (faster) |
| -R | Force reverse DNS lookup for all targets |
| -sn | Ping scan only (no port scan) |

> [!success]
> Use -sn to
>
>
> **only detect live hosts**
>
