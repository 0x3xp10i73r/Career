---
title: "methodology"
kind: topic
tags:
  - nmap-study
area: "Nmap Study"
up: "[[Nmap Study]]"
notion-id: 235759b9275180399f4ff10ebc5bee50
---

# methodology

In: [[Career]] / [[Nmap Study]]

Certainly! Here is your penetration testing methodology and report documentation formatted as a complete Markdown file. You can copy and save this as, for example, `doctolib_pentest_report.md`.

```markdown
# Penetration Testing Report for Doctolib.fr

_Comprehensive Bug Hunting Methodology and Process Documentation_

---

## Executive Summary

This report documents the comprehensive penetration testing methodology and bug hunting process conducted against Doctolib.fr, Europe's leading healthcare technology platform. The testing was performed to demonstrate systematic vulnerability assessment techniques while adhering to responsible disclosure practices and healthcare data protection requirements.

**Key Highlights:**
- **Target:** Doctolib.fr (Healthcare appointment booking and telemedicine platform)
- **Scope:** Web application security assessment with focus on OWASP Top 10 and healthcare-specific vulnerabilities
- **Methodology:** Comprehensive reconnaissance, enumeration, vulnerability analysis, and documentation
- **Approach:** Black-box testing with systematic documentation of each phase

---

## 1. Target Analysis and Reconnaissance

### 1.1 Business Context Understanding

Doctolib operates as a critical healthcare infrastructure serving over 80 million patients across Europe, with 900,000 healthcare professionals in France, Germany, and Italy. The platform handles:

- Electronic health records and patient data
- Appointment scheduling and telemedicine consultations
- Prescription management and medical document storage
- Healthcare provider practice management tools

This makes security assessment particularly critical due to HIPAA, GDPR, and other healthcare compliance requirements.

### 1.2 Initial Information Gathering

**Domain Analysis:**

```

Target: [doctolib.fr](http://doctolib.fr/)
Business Model: SaaS healthcare platform
Revenue Model: Subscription-based (€109-€229/month for practitioners)
Key Assets: Patient data, medical records, appointment systems

```

**Technology Stack Investigation:**
- Web application architecture assessment
- Server technology identification
- Third-party service integration analysis
- API endpoint discovery

---

## 2. Penetration Testing Methodology

### 2.1 Framework Selection

The testing follows the **OWASP Web Security Testing Guide (WSTG)** methodology, with adaptations for healthcare applications, referencing:

- PTES (Penetration Testing Execution Standard)
- Healthcare-specific vulnerability patterns
- HIPAA compliance requirements

### 2.2 Testing Phases

#### Phase 1: Pre-Engagement and Planning

**Objective:** Establish scope, rules of engagement, and legal boundaries

**Activities:**
1. **Scope Definition**
    - Target URLs and subdomains
    - Allowed testing methods
    - Testing time windows
    - Emergency contact procedures
2. **Legal/Compliance Considerations**
    - Healthcare data protection requirements
    - Responsible disclosure protocols
    - Testing authorization documentation

#### Phase 2: Information Gathering and Reconnaissance

**Tools and Techniques:**

**Passive Reconnaissance:**
- DNS/subdomain enumeration
- Search engine dorking
- Public information collection
- Certificate transparency logs

**Active Reconnaissance:**

```

## Port scanning

nmap -sS -sV -O -A -p- [doctolib.fr](http://doctolib.fr/)

## Subdomain discovery

gobuster dns -d [doctolib.fr](http://doctolib.fr/) -w /usr/share/wordlists/subdomains.txt -t 50

## Tech fingerprinting

whatweb [doctolib.fr](http://doctolib.fr/)

```

#### Phase 3: Vulnerability Assessment and Directory Enumeration

**Directory and File Discovery:**

```

## Addressing redirects in enumeration

gobuster dir -u [https://doctolib.fr](https://doctolib.fr/) -w /opt/SecLists/Discovery/Web-Content/big.txt -b 301 --exclude-length 167

## Multi-extension scan

gobuster dir -u [https://doctolib.fr](https://doctolib.fr/) -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt -x php,html,js,txt,json,xml -t 20 -s 200,301,302,403

## API endpoint discovery

gobuster dir -u [https://doctolib.fr](https://doctolib.fr/) -w /usr/share/wordlists/api-endpoints.txt -x json

```

**Web Application Analysis Tools:**
- Burp Suite Professional
- OWASP ZAP
- SQLMap
- Nikto

---

### 2.3 Healthcare-Specific Testing Approach

#### Critical Vulnerabilities to Assess

- **Broken Access Control (OWASP #1)**
    - Patient data access controls
    - Role-based permission bypasses
    - Appointment manipulation
- **Cryptographic Failures (OWASP #2)**
    - Medical record encryption
    - Secure transmission
    - Key management
- **Healthcare Data Exposure**
    - ePHI data leakage
    - Diagnostic/insurance info exposure
- **API Security Issues**
    - FHIR/HL7 endpoint testing
    - Device integration and 3rd-party connections

---

## 3. Systematic Bug Hunting Process

### 3.1 Reconnaissance Phase Documentation

**Step 1: Subdomain Discovery**

```

amass enum -passive -d [doctolib.fr](http://doctolib.fr/)
subfinder -d [doctolib.fr](http://doctolib.fr/)
gobuster dns -d [doctolib.fr](http://doctolib.fr/) -w /usr/share/wordlists/dns/subdomains-top1mil.txt

```javascript
**Documentation:**
- Record all subdomains
- Identify development/staging environments
- Map service functionalities
- Note high-value targets

**Step 2: Technology Stack Analysis**

```

whatweb [doctolib.fr](http://doctolib.fr/)
wappalyzer-cli [https://doctolib.fr](https://doctolib.fr/)
nmap -sV --script=http-enum [doctolib.fr](http://doctolib.fr/)

```
**Key Focus Areas:**
- CMS and versions, frameworks, components, server configs

---

### 3.2 Vulnerability Discovery Process

**Testing Focus:**
- **Authentication and Session Management**
    - Password, MFA, session fixation, privilege escalation, account enumeration
- **Input Validation**
    - All user inputs, especially booking, records, prescription, insurance forms
- **Business Logic**
    - Booking manipulation, payment bypass, record access, prescription flows

---

### 3.3 Manual Testing Methodology

**Burp Suite Workflow:**
1. Proxy/SSL setup
2. Crawling/mapping
3. Request interception/modification
4. Fuzzing/injection
5. Session/token analysis

**OWASP ZAP:**
1. Baseline scan
2. Full active scan w/healthcare policies
3. API testing
4. Custom rules

---

## 4. Documentation and Reporting Process

### 4.1 Real-time Documentation Standards

**Vulnerability Recording Template**

```

Vulnerability ID: DOC-2025-001
Title: [Vulnerability Name]
Severity: [Critical/High/Medium/Low]
CVSS Score: [Score] Location: [URL/endpoint] Description: [Technical details] Impact: [Business & technical impact] Proof of Concept: [Reproduction steps] Remediation: [Recommendation] ``` Evidence Collection - Screenshots, HTTP requests/responses, video demonstrations, code/payloads ### 4.2 Healthcare Compliance Mapping - HIPAA: Administrative/physical/technical safeguards, documentation - GDPR: Consent, erasure, portability, privacy by design --- ## 5. Advanced Testing Techniques ### 5.1 API Security Testing Enumeration and testing: ``` gobuster dir -u [https://api.doctolib.fr](https://api.doctolib.fr/) -w /usr/share/wordlists/api-routes.txt
ffuf -w /usr/share/wordlists/api-endpoints.txt -u https://doctolib.fr/FUZZ

## If GraphQL endpoint detected

python3 [graphqlmap.py](http://graphqlmap.py/) -u https://doctolib.fr/graphql

```

**API Focus:**
- Authentication bypass, rate limiting, data exposure, parameter pollution, injection

### 5.2 Mobile Application Assessment

- Static analysis (SAST), dynamic analysis (DAST), RASP, API validation

### 5.3 Social Engineering Assessment

- Targeted at healthcare-specific vectors: staff impersonation, patient phishing, tech support tricks, physical security

---

## 6. Risk Assessment and Prioritization

### 6.1 Healthcare-Specific Risk Matrix

| Vulnerability Type         | Patient Safety Impact | Data Exposure Risk | Compliance Violation | Overall Priority |
|---------------------------|----------------------|-------------------|---------------------|------------------|
| Authentication Bypass     | High                 | Critical          | High                | Critical         |
| Data Injection            | Medium               | High              | High                | High             |
| Access Control Issues     | High                 | High              | Medium              | High             |
| Information Disclosure    | Low                  | Medium            | Medium              | Medium           |

### 6.2 Business Impact Analysis

**Critical:** Immediate fix (e.g. data exposure, auth bypass, payments, records manipulation)
**High:** Fix within 30 days (sessions, input validation, transmission, access control)

---

## 7. Remediation Recommendations

### 7.1 Technical Recommendations

**Immediate:**
- Web Application Firewall (WAF)
- HTTPS Strict Transport Security (HSTS)
- Content Security Policy (CSP)
- Rate limiting

**Medium-term:**
- Security code reviews
- Automated testing in CI/CD
- Application monitoring
- Vulnerability management program

### 7.2 Healthcare Security Controls

- End-to-end PHI encryption
- Comprehensive audit logging
- Access control review
- BA agreement verification
- Device integration, platform hardening, prescription/insurance data measures

---

## 8. Continuous Security Monitoring

### 8.1 Ongoing Strategy

- Monthly: Vuln scans, pentest new features, config review, threat intel
- Quarterly: Full pentest, business logic review, compliance, awareness training

### 8.2 Incident Response Integration

- Patient data breaches
- System availability
- Regulatory compliance
- Reputation/business impact

---

## 9. Tools and Resources Summary

### 9.1 Primary Testing Tools

**Network/Infra:**
Nmap, Masscan, Gobuster
**Web App:**
Burp Suite, ZAP, SQLMap, Nikto
**Healthcare:**
HIPAA scanners, device assessment, ePHI tools

### 9.2 Knowledge Resources

- OWASP Web Security Testing Guide
- NIST Cybersecurity Framework
- HIPAA Security Rule
- Healthcare security best practices

---

## 10. Conclusion and Next Steps

This methodology ensures comprehensive security assessment while maintaining the highest standards of healthcare data protection and regulatory compliance.

**Key Recommendations:**
- Implement continuous security testing
- Schedule regular pentests
- Develop incident response
- Maintain compliance documentation

**Value Demonstration:**
- Risk reduction metrics
- Compliance fulfillment
- Patient trust
- Business continuity

---

```

Let me know if you’d like a shorter version, additional markdown formatting (TOC, collapsible sections), or if you want a filled-out vulnerability finding example!

Sources
