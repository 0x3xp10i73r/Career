---
title: "Offsec PG Play"
kind: database
tags:
  - offsec-pg-play
  - status/not-started
  - database
status: "Not started"
database: "Career"
area: "Offsec PG Play"
up: "[[Career]]"
notion-id: 387759b9275180efac6cc5509f8968b5
---

# Offsec PG Play

In: [[Career]]

## All notes

11 notes. Properties are on each note, so the table stays in sync with the files.

| Name | Status | Difficulty | Type | Date |
| --- | --- | --- | --- | --- |
| [[Blogger]] | ✅ Done | Medium | Linux, Web | 2026-06-22 |
| [[Potato]] | ✅ Done | Easy | Linux, Web | 2026-06-24 |
| [[Katana]] | ✅ Done | Medium | Linux, Web | 2026-06-24 |
| [[Gaara]] | ✅ Done | Easy | Linux, Web | 2026-06-27 |
| [[Stapler]] | 🔄 In progress | Medium |  | 2026-07-09 |
| [[Election1]] | ✅ Done | Medium |  | 2026-07-13 |
| [[InsanityHosting]] | ⬜ Not started | Intermediate |  | 2026-07-14 |
| [[So Simple]] | ✅ Done | Intermediate | Linux, Web | 2026-08-19 |
| [[Tre]] | ✅ Done | Intermediate | Linux, Web | 2026-08-20 |
| [[DC-9]] | ✅ Done | Intermediate | Linux, Web | 2026-08-26 |
| [[Funbox]] | ✅ Done | Intermediate | Linux | 2026-09-23 |

%% Install the Dataview community plugin to turn the block below into a live, sortable table. The markdown table above works without it. %%

```dataview
TABLE status AS Status, difficulty AS Difficulty, date AS Date, tags AS Tags
WHERE database = "Offsec PG Play"
SORT file.name ASC
```
