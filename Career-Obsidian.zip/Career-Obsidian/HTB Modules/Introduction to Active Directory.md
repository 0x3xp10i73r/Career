---
title: "Introduction to Active Directory"
kind: moc
tags:
  - htb-modules
  - moc
area: "HTB Modules"
up: "[[HTB Modules]]"
notion-id: 3ea759b9275180969c66d91e645ae286
---

# Introduction to Active Directory

In: [[Career]] / [[HTB Modules]]

## Contents

**[[Why Active Directory|Why Active Directory?]]**

**[[Active Directory Research Over the Years]]**

[[Active Directory Structure]]

[[Active Directory Terminologies]]

[[Active Directory Objects]]

**[[Active Directory Functionality]]**

[[Kerberos, DNS, LDAP, MSRPC]]

**[[NTLM Authentication - Read this]]**
