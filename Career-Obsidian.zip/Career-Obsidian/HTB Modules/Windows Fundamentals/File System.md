---
title: "File System"
kind: topic
tags:
  - htb-modules
area: "HTB Modules"
up: "[[Windows Fundamentals]]"
notion-id: 3b6759b927518063bc29fd3d3b421fe5
---

# File System

In: [[Career]] / [[HTB Modules]] / [[Windows Fundamentals]]

## File System Types

| FS | Used On | Max File Size | Key Notes |
| --- | --- | --- | --- |
| FAT12/FAT16 | Legacy only | Small | Not used on modern Windows |
| **FAT32** | USB, SD cards, drives | **4GB max** | Cross-compatible (Windows/Mac/Linux/consoles) |
| **NTFS** | Windows default (NT 3.1+) | Very large | Journaling, permissions, encryption, metadata |
| exFAT | Flash drives, SD cards | Large | Bridge between FAT32 and NTFS |

### FAT32 vs NTFS

| Feature | FAT32 | NTFS |
| --- | --- | --- |
| Max file size | 4GB | 16TB+ |
| Permissions | ❌ | ✅ Granular |
| Journaling | ❌ | ✅ |
| Encryption | ❌ (3rd party) | ✅ Built-in (EFS) |
| Compression | ❌ | ✅ |
| Cross-OS compat | ✅ Wide | Limited mobile support |
| Failure recovery | ❌ | ✅ |

---

## NTFS Permission Types

| Permission | What it Allows |
| --- | --- |
| **Full Control (F)** | Read, write, change, delete |
| **Modify (M)** | Read, write, delete (no permission changes) |
| **List Folder Contents** | View/list folders + subfolders, execute files (folders only) |
| **Read & Execute (RX)** | View, list, execute (files + folders inherit) |
| **Write (W)** | Add files/subfolders, write to files |
| **Read (R)** | View contents and listing only |
| **Traverse Folder** | Move through folders even without list permission |

> [!note]
> Permissions **inherit from parent folder** by default — admins can disable inheritance per object
>

---

## icacls — Command Line Permission Management

### View Permissions

```bash
icacls c:\windows
icacls c:\Users
```

### Grant Permissions

```bash
# Grant full control to user joe (current folder only)
icacls c:\users /grant joe:f

# Grant full control including subfolders and files
icacls c:\users /grant joe:(OI)(CI)(F)
```

### Remove Permissions

```bash
icacls c:\users /remove joe
```

---

## icacls Output — Reading the Symbols

### Permission Codes

| Code | Meaning |
| --- | --- |
| `F` | Full access |
| `M` | Modify |
| `RX` | Read & Execute |
| `R` | Read only |
| `W` | Write only |
| `D` | Delete |
| `N` | No access |

### Inheritance Flags

| Flag | Meaning |
| --- | --- |
| `(CI)` | Container Inherit — subfolders inherit |
| `(OI)` | Object Inherit — files inherit |
| `(IO)` | Inherit Only — doesn't apply to current object |
| `(NP)` | No Propagate — don't pass to child objects |
| `(I)` | Inherited from parent |

### Example Reading

```
NT AUTHORITY\SYSTEM:(OI)(CI)(IO)(F)
```

SYSTEM has Full access (F), inherited by all objects (OI) and containers (CI), inherit only (IO) — full control over all files and subfolders

---

## Pentesting Relevance

| Scenario | Use |
| --- | --- |
| Check if you can write to a directory | `icacls <path>` → look for `W` or `M` or `F` on your user/group |
| Find writable directories for payload staging | `icacls` across Program Files, System32 |
| DLL hijacking | Find directories where your user has write access that are in the DLL search path |
| Escalate via misconfigured permissions | Writable service binary or service directory → replace binary → escalate |
| Grant access to a file during engagement | `icacls file /grant user:F` |

---

## Key Takeaways

- **NTFS** = the only file system that matters for Windows security — it's where all permission controls live
- **FAT32** has no security features — any file on FAT32 is accessible by anyone
- `icacls` = the go-to tool for reading and modifying Windows file permissions from CMD
- `(OI)(CI)(F)` = full control over a directory AND all contents (the dangerous one)
- **Traverse Folder** permission = sneaky — lets users navigate past directories they can't list
- Always check `icacls` on directories where services run — misconfigured permissions = privilege escalation path
