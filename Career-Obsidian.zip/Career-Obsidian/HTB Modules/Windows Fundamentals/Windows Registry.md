---
title: "Windows Registry"
kind: topic
tags:
  - htb-modules
area: "HTB Modules"
up: "[[Windows Fundamentals]]"
notion-id: 3bf759b9275180949c22c95bc136114c
---

# Windows Registry

In: [[Career]] / [[HTB Modules]] / [[Windows Fundamentals]]

## What is the Registry

A **hierarchical database** storing configuration for Windows OS, hardware, software, services, security policies, and user profiles. Critical — mistakes can break Windows components.

---

## Registry Structure

```
Hive → Key → Subkey → Value
(like: Drive → Folder → Subfolder → File)
```

Example path: `HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion`

- `HKEY_LOCAL_MACHINE` = Hive
- `SOFTWARE` = Key
- `Microsoft\Windows\CurrentVersion` = Subkeys

---

## Primary Hives

| Hive | Abbreviation | Purpose |
| --- | --- | --- |
| `HKEY_CURRENT_USER` | **HKCU** | Settings for current logged-on user only |
| `HKEY_LOCAL_MACHINE` | **HKLM** | System-wide settings (requires admin to edit) |
| `HKEY_CLASSES_ROOT` | HKCR | File associations, app registration |
| `HKEY_USERS` | HKU | All loaded user profiles |
| `HKEY_CURRENT_CONFIG` | HKCC | Current hardware configuration |

---

## Value Data Types

| Type | Description |
| --- | --- |
| `REG_SZ` | Standard text string |
| `REG_DWORD` | 32-bit number (used for enabled/disabled settings) |
| `REG_QWORD` | 64-bit number |
| `REG_MULTI_SZ` | **Multiple text strings** |
| `REG_BINARY` | Raw binary data |

---

## Tools

### GUI: `regedit.exe`

```
Win + R → type regedit → OK
```

- Left pane = hierarchy
- Right pane = values in selected key
- Address bar = full key path

### CLI: `reg.exe`

```bash
# View all operations
reg /?

# Query all values in a key
reg query "HKCU\Software\HTB-Academy"

# Query specific value
reg query "HKCU\Software\HTB-Academy" /v CourseName

# Query recursively (all subkeys)
reg query "HKCU\Software" /s

# Add/create a value
reg add "HKCU\Software\HTB-Academy" /v CreatedBy /t REG_SZ /d "reg.exe" /f

# Modify existing value
reg add "HKCU\Software\HTB-Academy" /v LabComplete /t REG_DWORD /d 0 /f

# Delete a specific value
reg delete "HKCU\Software\HTB-Academy" /v CreatedBy /f

# Delete entire key + all values
reg delete "HKCU\Software\HTB-Academy" /f

# Query remote machine (HKLM and HKU only)
reg query \\<machine>\HKLM\Software\...
```

**reg add parameters:**

| Parameter | Purpose |
| --- | --- |
| `/v` | Value name |
| `/t` | Data type |
| `/d` | Data to store |
| `/f` | Force (no confirmation) |

---

## Important Registry Locations (Pentesting)

| Path | Purpose |
| --- | --- |
| `HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System` | UAC settings (`EnableLUA`) |
| `HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon` | AutoLogon credentials sometimes stored here |
| `HKCU\Software\Microsoft\Windows\CurrentVersion\Run` | Programs that run at user login |
| `HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run` | Programs that run at system boot |
| `HKLM\SYSTEM\CurrentControlSet\Services` | Service configurations + binary paths |
| `HKLM\SAM` | Local account hashes (needs SYSTEM to read) |
| `HKLM\SECURITY` | Security policy data |

---

## UAC — DisablingEnabling

```bash
# Check UAC status
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA

# Disable UAC (requires admin, needs reboot)
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 0 /f

# After setting to 0:
# reg query returns → EnableLUA  REG_DWORD  0x0
```

---

## Question Answers

| Question | Answer |
| --- | --- |
| After disabling UAC, what hex value does reg query return? | `0x0` |
| Which hive stores settings for currently logged-on user? | `HKEY_CURRENT_USER` |
| What data type does EnableLUA use? | `REG_DWORD` |
| Data type for multiple text strings? | `REG_MULTI_SZ` |

---

## Pentesting Relevance

| Action | Why |
| --- | --- |
| Check `Run` keys | Find persistence mechanisms |
| Read service binary paths from registry | DLL hijacking, service misconfiguration |
| Query SAM/SECURITY hives | Credential extraction (needs SYSTEM) |
| Modify `EnableLUA` | Disable UAC for easier exploitation |
| `Get-ACL -Path HKLM:\...` | Check registry key permissions for privesc |

---

## Key Takeaways

- Registry = **central config database** — modifying wrong keys breaks Windows
- `HKCU` = no admin needed; `HKLM` = admin required
- `reg.exe` = scriptable, remote-capable, faster than GUI for automation
- `REG_DWORD` = most common type for on/off settings (1=on, 0=off)
- **Run keys** = primary persistence location — always check during investigation
- `/f` flag on `reg delete` = no confirmation → be very careful with the path
