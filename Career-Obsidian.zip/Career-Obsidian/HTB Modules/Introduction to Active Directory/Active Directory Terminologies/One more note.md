---
title: "One more note"
aliases:
  - "Active Directory Terminologies - One more note"
kind: topic
tags:
  - htb-modules
area: "HTB Modules"
up: "[[Active Directory Terminologies]]"
notion-id: 3ec759b92751807e925eeb5a16d0b904
---

# One more note

In: [[Career]] / [[HTB Modules]] / [[Introduction to Active Directory]] / [[Active Directory Terminologies]]

## Active Directory Terminology

> [!abstract] Overview
>
>
> Active Directory (AD) uses a large number of specific terms to describe its directory structure, objects, authentication, authorization, replication, and security mechanisms.
>
> This note covers the core terminology used when working with Active Directory.
>

---

### 1. Active Directory Structure

#### Object

An **Object** is any resource present within an Active Directory environment.

Examples:

- Users
- Computers
- Domain Controllers
- Organizational Units (OUs)
- Printers
- Groups

---

#### Attributes

Every AD object has a set of **attributes** that define its characteristics.

For example, a computer object may contain:

- Hostname
- DNS name

Attributes have associated **LDAP names**, which are used when querying Active Directory.

Examples:

| AD Attribute | LDAP Name |
| --- | --- |
| Full Name | `displayName` |
| First Name | `givenName` |

---

#### Schema

The **Active Directory Schema** is the blueprint that defines:

- What types of objects can exist
- Which attributes those objects can have
- Required and optional attributes
- Object classes

Examples:

```
user     → User objects
computer → Computer objects
```

When an object is created from a class, it is called an **instance** of that class.

Example:

```
Computer Class
      ↓
   RDS01
      ↓
Instance of the "computer" class
```

> [!important]
>
>
> Think of the **Schema** as the definition/template for objects, while an **Object** is an actual instance created from that definition.
>

---

#### Domain

A **Domain** is a logical group of AD objects.

It can contain:

- Users
- Computers
- Groups
- OUs
- Other AD resources

Domains can operate independently or be connected through **trust relationships**.

Example:

```
inlanefreight.local
```

---

#### Forest

A **Forest** is a collection of one or more Active Directory domains.

It is the top-level AD container and can contain:

- Domains
- Users
- Groups
- Computers
- GPOs
- OUs

Example:

```
Forest
│
├── Domain A
│   ├── Users
│   ├── Computers
│   └── Groups
│
└── Domain B
    ├── Users
    ├── Computers
    └── Groups
```

> [!tip]
>
>
> **Forest → Tree → Domain → Objects**
>

---

#### Tree

A **Tree** is a collection of AD domains beginning with a single root domain.

Example:

```
inlanefreight.local
│
└── corp.inlanefreight.local
```

Another tree within the same forest could be:

```
ilfreight.local
│
└── corp.ilfreight.local
```

Important characteristics:

- Domains within a tree share a namespace.
- Parent-child trust relationships exist between domains.
- Domains in a tree share a standard **Global Catalog**.
- Two trees in the same forest cannot share the same namespace.

---

#### Container

A **Container** is an AD object that can contain other objects.

It has a defined location within the directory subtree hierarchy.

Example:

```
Domain
└── OU
    ├── User
    ├── Computer
    └── Group
```

---

#### Leaf

A **Leaf** object does **not** contain other objects.

It appears at the end of the directory hierarchy.

---

### 2. Object Identification

#### Global Unique Identifier — GUID

A **GUID** is a unique 128-bit value assigned to an AD object.

Stored in:

```
ObjectGUID
```

Every object created in AD receives a GUID.

Examples of objects with GUIDs:

- Users
- Groups
- Computers
- Domain Controllers
- OUs

#### Important Properties

- Unique across the enterprise
- Used internally by AD to identify objects
- Remains associated with the object for its lifetime
- Provides a reliable way to identify an exact object

Objects can be searched using:

```
GUID
Distinguished Name (DN)
SID
sAMAccountName
```

> [!tip] Pentesting Note
>
>
> Searching by `ObjectGUID` can provide a more precise result than searching by a potentially duplicated object name.
>

---

#### Security Principals

A **Security Principal** is something that the operating system can authenticate.

Examples:

- User accounts
- Computer accounts
- Processes
- Threads
- Service accounts

In AD, security principals can manage access to resources.

There are also local users and groups controlled by the local **Security Accounts Manager (SAM)** rather than AD.

---

#### Security Identifier — SID

A **SID** uniquely identifies a security principal or security group.

Examples:

```
User SID
Group SID
Computer SID
```

When a user logs in, Windows creates an **access token** containing:

- User SID
- User's assigned rights
- SIDs of groups the user belongs to

The access token is used when Windows determines whether the user is authorized to perform an action.

> [!important]
>
>
> A SID is unique within its environment and is not reused for another security principal after deletion.
>

---

### 3. Distinguished Names

#### Distinguished Name — DN

A **Distinguished Name (DN)** describes the complete path to an object within AD.

Example:

```
CN=bjones,OU=IT,OU=Employees,DC=inlanefreight,DC=local
```

Breakdown:

```
CN=bjones
    ↓
OU=IT
    ↓
OU=Employees
    ↓
DC=inlanefreight
    ↓
DC=local
```

Where:

- `CN` = Common Name
- `OU` = Organizational Unit
- `DC` = Domain Component

> [!important]
>
>
> The DN identifies the object's complete location in the AD hierarchy.
>

---

#### Relative Distinguished Name — RDN

An **RDN** is a single component of a Distinguished Name that identifies an object at its current hierarchy level.

Example:

```
CN=bjones,OU=IT,OU=Employees,DC=inlanefreight,DC=local
```

The RDN is:

```
CN=bjones
```

AD does not allow two objects with the same name under the same parent container.

However, the same RDN can exist elsewhere if the complete DN is different.

Example:

```
CN=bjones,DC=dev,DC=inlanefreight,DC=local

CN=bjones,DC=inlanefreight,DC=local
```

These are different objects because their complete DNs differ.

---

### 4. Account Names

#### sAMAccountName

The **sAMAccountName** is the user's logon name.

Example:

```
bjones
```

Characteristics:

- Used for user logon
- Must be unique
- Maximum of 20 characters

---

#### userPrincipalName — UPN

The **userPrincipalName (UPN)** is another way to identify a user.

Format:

```
username@domain
```

Example:

```
bjones@inlanefreight.local
```

The UPN consists of:

```
Prefix = User account name
Suffix = Domain name
```

The UPN is not mandatory.

---

## 5. FSMO Roles

### Flexible Single Master Operations — FSMO

**FSMO roles** distribute specific AD responsibilities among Domain Controllers.

There are **five FSMO roles**.

| Role | Scope | Count |
| --- | --- | --- |
| Schema Master | Forest | 1 |
| Domain Naming Master | Forest | 1 |
| RID Master | Domain | 1 per domain |
| PDC Emulator | Domain | 1 per domain |
| Infrastructure Master | Domain | 1 per domain |

#### Forest-Wide Roles

```
Schema Master
Domain Naming Master
```

There is one of each per forest.

#### Domain-Wide Roles

```
RID Master
PDC Emulator
Infrastructure Master
```

There is one of each per domain.

#### Assignment

When a new AD forest is created, all five roles are initially assigned to the first Domain Controller in the forest root domain.

When a new domain is added:

```
RID Master
PDC Emulator
Infrastructure Master
```

are assigned to the new domain.

> [!note]
>
>
> FSMO roles can be transferred by administrators when required.
>

---

## 6. Global Catalog

A **Global Catalog (GC)** is a Domain Controller that stores information about objects across the entire AD forest.

It contains:

- A full copy of objects in its own domain
- A partial copy of objects from other domains

#### Functions

##### Authentication

The GC helps provide authorization information for groups that a user belongs to when an access token is generated.

##### Object Search

It allows users and applications to search for objects across domains in the forest.

```
Forest
├── Domain A
├── Domain B
└── Domain C
       ↓
Global Catalog
       ↓
Search across domains
```

> [!tip]
>
>
> The Global Catalog makes the directory structure of the forest searchable without requiring knowledge of the specific domain containing an object.
>

---

## 7. Read-Only Domain Controller — RODC

A **Read-Only Domain Controller (RODC)** contains a read-only copy of the Active Directory database.

#### Characteristics

- AD database is read-only
- Does not push AD database changes
- Does not push SYSVOL changes
- Provides read-only DNS
- Supports administrator role separation
- Reduces replication traffic

#### Password Caching

RODCs do not cache AD account passwords except:

- RODC computer account password
- RODC `KRBTGT` password

---

## 8. Active Directory Replication

**Replication** occurs when AD objects are updated and those changes are transferred between Domain Controllers.

When a Domain Controller is added:

```
Domain Controller
        ↓
Connection Objects
        ↓
Replication
```

The **Knowledge Consistency Checker (KCC)** creates and manages replication connections.

#### Purpose

Replication ensures that:

- Changes are synchronized
- Domain Controllers have updated information
- AD continues operating if a Domain Controller fails

---

## 9. Service Principal Name — SPN

A **Service Principal Name (SPN)** uniquely identifies a service instance.

SPNs are used by **Kerberos authentication** to associate a service instance with a logon account.

Conceptually:

```
Service Instance
       ↓
      SPN
       ↓
Logon Account
       ↓
Kerberos Authentication
```

The client can request authentication for the service without needing to know the account name directly.

---

## 10. Group Policy Object — GPO

A **Group Policy Object (GPO)** is a collection of policy settings.

Each GPO has a unique GUID.

GPOs can contain:

- Local file system settings
- Active Directory settings
- User settings
- Computer settings

They can be applied:

- Across a domain
- To specific users
- To specific computers
- At the OU level

Example:

```
Domain
│
├── OU: Employees
│      └── GPO
│
└── OU: IT
       └── GPO
```

---

## 11. Access Control

### Access Control List — ACL

An **ACL** is an ordered collection of **Access Control Entries (ACEs)** associated with an object.

```
ACL
│
├── ACE
├── ACE
├── ACE
└── ACE
```

---

### Access Control Entry — ACE

An **ACE** specifies:

- A trustee
- Allowed rights
- Denied rights
- Auditing information where applicable

A trustee may be:

- User
- Group
- Logon session

---

### Discretionary Access Control List — DACL

A **DACL** determines which security principals are allowed or denied access to an object.

Example:

```
Object
  ↓
DACL
  ├── User A → Allow
  ├── Group B → Deny
  └── User C → Allow
```

When a process attempts to access an object, Windows checks the DACL.

ACE entries are evaluated in sequence until:

- A matching entry allows the requested rights, or
- Access is denied.

#### Important Edge Cases

If an object has **no DACL**:

```
→ Full access is granted to everyone
```

If a DACL has **no ACE entries**:

```
→ Access is denied
```

---

### System Access Control List — SACL

A **SACL** controls which access attempts should be logged.

It allows administrators to audit access to secured objects.

```
Access Attempt
      ↓
    SACL
      ↓
Security Event Log
```

---

## 12. Fully Qualified Domain Name — FQDN

An **FQDN** is the complete name of a host.

Format:

```
hostname.domain.tld
```

Example:

```
DC01.INLANEFREIGHT.LOCAL
```

FQDNs are used to locate hosts through DNS without requiring their IP address.

---

## 13. Tombstone

A **Tombstone** is an AD object that represents a deleted object.

When an AD object is deleted:

```
Object Deleted
      ↓
isDeleted = TRUE
      ↓
Tombstone
      ↓
Deleted Objects
      ↓
Tombstone Lifetime
      ↓
Permanent Removal
```

The deleted object remains for a defined period called the **Tombstone Lifetime**.

The material notes that Microsoft recommends a lifetime of **180 days**, although the default can vary depending on the Domain Controller operating system version.

Without AD Recycle Bin:

- Most attributes are stripped
- The object remains in the Deleted Objects container
- Some information cannot be recovered

---

## 14. Active Directory Recycle Bin

The **AD Recycle Bin** was introduced with Windows Server 2008 R2.

Its purpose is to make recovery of deleted AD objects easier.

When enabled:

- Deleted objects remain recoverable
- Most object attributes are preserved
- Objects can be restored more completely

The material states that if no other value is specified, the default recoverable period is **60 days**.

#### Tombstone vs Recycle Bin

| Feature | Tombstone | AD Recycle Bin |
| --- | --- | --- |
| Represents deleted objects | Yes | Yes |
| Object attributes preserved | Mostly stripped | Most preserved |
| Easier restoration | No | Yes |
| Recovery capability | Limited | Better |

---

## 15. SYSVOL

**SYSVOL** is a folder/share used to store public domain files.

It can contain:

- Group Policy settings
- System policies
- Logon scripts
- Logoff scripts
- Other scripts executed within the AD environment

SYSVOL contents are replicated across Domain Controllers.

```
Domain Controller 1
        │
        │ Replication
        ▼
Domain Controller 2
        │
        ▼
Domain Controller 3
```

> [!tip] Pentesting Relevance
>
>
> SYSVOL can contain scripts and policy-related files, so it is an important location to understand during AD enumeration.
>

---

## 16. AdminSDHolder

**AdminSDHolder** manages ACLs for members of privileged built-in AD groups.

It contains the security descriptor that should be applied to protected accounts.

The **SDProp** process periodically checks protected accounts and ensures that their ACLs match the expected security descriptor.

#### Default Behavior

The material states that SDProp runs:

```
Every hour by default
```

#### Security Relevance

Suppose an attacker modifies an ACL on a protected account.

```
Malicious ACL Change
        ↓
Protected Account
        ↓
SDProp runs
        ↓
ACL restored
```

Unless additional settings are changed, the unauthorized ACL modification can be removed when SDProp runs.

---

## 17. dsHeuristics

`dsHeuristics` is an attribute on the Directory Service object.

It controls multiple forest-wide configuration settings.

One setting can exclude built-in groups from the **Protected Groups** list.

Normally:

```
Protected Group
      ↓
AdminSDHolder
      ↓
SDProp
      ↓
ACL Protection
```

If a group is excluded through `dsHeuristics`, changes affecting it may not be reverted by SDProp.

---

## 18. adminCount

The `adminCount` attribute indicates whether an account is protected by the security protection mechanisms associated with privileged groups.

Values:

```
adminCount = 0
```

or not specified:

```
→ User is not protected
```

```
adminCount = 1
```

```
→ User is protected
```

#### Pentesting Relevance

Accounts with:

```
adminCount = 1
```

may indicate privileged or historically privileged accounts and can therefore be interesting during internal AD enumeration.

---

## 19. Active Directory Users and Computers — ADUC

**ADUC** is a graphical management console used to manage:

- Users
- Groups
- Computers
- Contacts

Many actions performed through ADUC can also be performed using PowerShell.

---

## 20. ADSI Edit

**ADSI Edit** is a GUI tool for directly managing AD objects and attributes.

Compared with ADUC, ADSI Edit provides much deeper access.

It can be used to:

- Modify attributes
- Delete attributes
- Add objects
- Remove objects
- Move objects

> [!warning]
>
>
> ADSI Edit is powerful and changes made through it can cause significant problems in an AD environment.
>

---

## 21. sIDHistory

The `sIDHistory` attribute stores SIDs previously assigned to an object.

It is commonly used during domain migrations so that a migrated account can maintain its previous access.

Example:

```
Old Domain
   ↓
Old SID
   ↓
Migration
   ↓
New Account
   ↓
sIDHistory
```

#### Security Relevance

If improperly configured, `sIDHistory` can potentially be abused to obtain access associated with a previous SID.

The material specifically notes the importance of **SID Filtering** when dealing with SIDs from another domain.

---

## 22. NTDS.DIT

`NTDS.DIT` is the primary Active Directory database.

Location:

```
C:\Windows\NTDS\
```

It contains AD information such as:

- User objects
- Group objects
- Group membership
- Password hashes

#### Security / Pentesting Relevance

After full domain compromise, an attacker may attempt to obtain the database and extract password hashes.

Those hashes can potentially be:

- Used in pass-the-hash attacks
- Cracked offline with tools such as Hashcat

#### Reversible Encryption

If the policy:

```
Store password with reversible encryption
```

is enabled, the database can also contain cleartext-equivalent password information for users created or whose passwords were changed after the policy was enabled.

> [!warning]
>
>
> The material describes this configuration as rare.
>

---

## 23. MSBROWSE

**MSBROWSE** was a Microsoft networking protocol used by older Windows LAN environments.

Its purpose included:

- Maintaining lists of network resources
- Browsing shared printers
- Browsing shared files
- Identifying the Master Browser

Older Windows systems could use:

```bash
nbtstat -A <IP>
```

to search for the Master Browser.

If `MSBROWSE` appeared, it indicated the Master Browser.

The `nltest` utility could also be used to query a Windows Master Browser for Domain Controller names.

#### Modern Relevance

MSBROWSE is largely obsolete.

Modern Windows environments primarily use:

```
SMB
CIFS
```

for file and printer sharing/browsing.

---

## 24. Important AD Relationships

### AD Hierarchy

```
Forest
│
├── Tree
│   │
│   ├── Domain
│   │   │
│   │   ├── OU
│   │   │   ├── Users
│   │   │   ├── Computers
│   │   │   └── Groups
│   │   │
│   │   └── GPOs
│   │
│   └── Child Domain
│
└── Another Tree
```

---

### Object Identification

```
Object
├── ObjectGUID
├── SID
├── DN
├── RDN
├── sAMAccountName
└── userPrincipalName
```

---

### Access Control

```
Object
  │
  └── ACL
       │
       ├── DACL
       │    └── ACEs
       │
       └── SACL
            └── Auditing
```

---

### Privileged Account Protection

```
Privileged Account
        │
        ├── adminCount = 1
        │
        ↓
Protected Group
        │
        ↓
AdminSDHolder
        │
        ↓
SDProp
        │
        ↓
ACL Protection
```

---

## 25. Quick Reference Table

| Term | Meaning |
| --- | --- |
| **Object** | Any resource in AD |
| **Attribute** | Property describing an AD object |
| **Schema** | Blueprint defining AD object classes and attributes |
| **Domain** | Logical group of AD objects |
| **Forest** | Collection of AD domains |
| **Tree** | Collection of domains sharing a namespace |
| **Container** | Object capable of containing other objects |
| **Leaf** | Object that cannot contain other objects |
| **GUID** | Unique 128-bit identifier for an AD object |
| **Security Principal** | Entity that can be authenticated |
| **SID** | Unique identifier for a security principal/group |
| **DN** | Complete path to an AD object |
| **RDN** | Single identifying component of a DN |
| **sAMAccountName** | User logon name |
| **UPN** | `username@domain` user identifier |
| **FSMO** | Five specialized AD operational roles |
| **Global Catalog** | Provides forest-wide object information/search |
| **RODC** | Read-only Domain Controller |
| **Replication** | Synchronization of AD changes between DCs |
| **SPN** | Identifier for a service instance used by Kerberos |
| **GPO** | Collection of Group Policy settings |
| **ACL** | Collection of ACEs controlling access |
| **ACE** | Individual access-control rule |
| **DACL** | Controls allowed/denied access |
| **SACL** | Controls auditing of access |
| **FQDN** | Complete hostname + domain name |
| **Tombstone** | Representation of a deleted AD object |
| **AD Recycle Bin** | Mechanism for recovering deleted AD objects |
| **SYSVOL** | Share containing domain policy/scripts |
| **AdminSDHolder** | Protects ACLs of privileged accounts |
| **dsHeuristics** | Forest-wide directory configuration attribute |
| **adminCount** | Indicates protected account status |
| **ADUC** | GUI for managing AD users/groups/computers |
| **ADSI Edit** | Deep-level AD object/attribute management tool |
| **sIDHistory** | Stores previously assigned SIDs |
| **NTDS.DIT** | Main AD database |
| **MSBROWSE** | Legacy Windows network browsing protocol |

---

## 26. High-Value Pentesting Takeaways

> [!important]
>
>
> When enumerating an AD environment, these are particularly useful concepts to remember.
>

#### Object Identification

Know the difference between:

```
GUID
SID
DN
RDN
sAMAccountName
UPN
```

#### Privileged Accounts

Pay attention to:

```
adminCount = 1
```

and understand the relationship between:

```
Protected Groups
        ↓
AdminSDHolder
        ↓
SDProp
```

#### Access Control

Understand:

```
ACL
 ├── DACL
 │    └── ACE
 │
 └── SACL
```

#### Domain Infrastructure

Know:

```
Forest
 ↓
Tree
 ↓
Domain
 ↓
OU
 ↓
Objects
```

#### Authentication / Services

Important concepts:

```
Kerberos
   ↓
SPN
   ↓
Service Account
```

#### Domain Controllers

Understand:

```
Domain Controller
├── Global Catalog
├── Replication
├── SYSVOL
├── FSMO roles
└── NTDS.DIT
```

#### High-Value Files / Locations

```
C:\Windows\NTDS\NTDS.DIT
```

and:

```
SYSVOL
```

are particularly important concepts for AD security assessments.

---

## 27. Exam Memory Sheet

### Remember These

```
FOREST
    ↓
TREE
    ↓
DOMAIN
    ↓
OU
    ↓
OBJECT
```

```
OBJECT
├── GUID
├── SID
├── DN
├── RDN
├── sAMAccountName
└── UPN
```

```
ACL
├── DACL → Allow/Deny
└── SACL → Audit
```

```
FSMO = 5 ROLES

Forest:
- Schema Master
- Domain Naming Master

Domain:
- RID Master
- PDC Emulator
- Infrastructure Master
```

```
DC
├── Global Catalog
├── Replication
├── SYSVOL
├── FSMO
└── NTDS.DIT
```

```
Privileged Account
       ↓
adminCount = 1
       ↓
AdminSDHolder
       ↓
SDProp
```

---

### One-Line Definitions

> [!note]
> **Object** → A resource in AD.
>

> [!note]
> **Attribute** → A property of an AD object.
>

> [!note]
> **Schema** → Defines what objects and attributes can exist.
>

> [!note]
> **Domain** → Logical collection of AD objects.
>

> [!note]
> **Forest** → Collection of AD domains.
>

> [!note]
> **Tree** → Collection of domains sharing a namespace.
>

> [!note]
> **GUID** → Unique identifier for an AD object.
>

> [!note]
> **SID** → Unique identifier for a security principal.
>

> [!note]
> **DN** → Full path of an object in AD.
>

> [!note]
> **RDN** → Object's identifying component at its current hierarchy level.
>

> [!note]
> **SPN** → Identifier for a service instance used by Kerberos.
>

> [!note]
> **GPO** → Collection of policy settings.
>

> [!note]
> **ACL** → Collection of access-control rules.
>

> [!note]
> **DACL** → Controls access.
>

> [!note]
> **SACL** → Controls auditing.
>

> [!note]
> **SYSVOL** → Stores domain policy and scripts.
>

> [!note]
> **NTDS.DIT** → Core Active Directory database.
>

> [!note]
> **AdminSDHolder** → Protects ACLs of privileged accounts.
>

> [!note]
> **SDProp** → Periodically enforces AdminSDHolder permissions.
>

> [!note]
> **adminCount** → Indicates whether an account is protected.
>

> [!note]
> **sIDHistory** → Stores previously assigned SIDs.
>

> [!note]
> **RODC** → Read-only Domain Controller.
>

> [!note]
> **Global Catalog** → Provides forest-wide object information/search.
>

> [!note]
> **Replication** → Synchronizes AD changes between DCs.
>
