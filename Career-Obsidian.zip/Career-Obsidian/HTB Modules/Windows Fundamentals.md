---
title: "Windows Fundamentals"
kind: moc
tags:
  - htb-modules
  - moc
area: "HTB Modules"
up: "[[HTB Modules]]"
notion-id: 3b6759b927518003acced91cc32cfcb4
---

# Windows Fundamentals

In: [[Career]] / [[HTB Modules]]

## Contents

[[Introduction to Windows]]

[[Operating System Structure]]

[[File System]]

[[NTFS vs Share Permissions]]

[[Windows Registry]]

[[Windows Services & Processes]]

**[[Service Permissions]]**

[[Windows Sessions]]

**[[Interacting with the Windows Operating System]]**

[[Windows Management Instrumentation (WMI)]]

[[Microsoft Management Console]]

[[Desktop Experience vs. Server Core]]

[[Windows Security]]
