---
title: "Business Logic Vulnerabilities"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: e77759b9275182b99a6e81cdd7349fca
---

# Business Logic Vulnerabilities

In: [[Career]] / [[Vulnerabilities]]

## Contents

**[[Lab - Excessive trust in client-side controls|Lab: Excessive trust in client-side controls]]**

**[[Lab - 2FA broken logic (Incomplete)|Lab: 2FA broken logic (Incomplete)]]**

**[[Lab - High-level logic vulnerability|Lab: High-level logic vulnerability]]**

**[[Lab - Low-level logic flaw|Lab: Low-level logic flaw]]**
