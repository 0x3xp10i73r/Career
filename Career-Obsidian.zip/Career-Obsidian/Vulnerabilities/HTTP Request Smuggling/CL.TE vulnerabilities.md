---
title: "CL.TE vulnerabilities"
aliases:
  - "CL TE vulnerabilities"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Vulnerabilities/HTTP Request Smuggling|HTTP Request Smuggling]]"
notion-id: 964759b92751820985de81324e5716ea
---

# CL.TE vulnerabilities

In: [[Career]] / [[Vulnerabilities]] / [[Vulnerabilities/HTTP Request Smuggling|HTTP Request Smuggling]]

### Definition

- **CL.TE** occurs when:
    - **Front-end server uses `Content-Length`**
    - **Back-end server uses `Transfer-Encoding`**
- Different interpretation causes **request boundary desynchronizaltion**, allowing an attacker to **smuggle a hidden request**.

---

### Example Payload

```
POST / HTTP/1.1
Host: vulnerable-website.com
Content-Length: 13
Transfer-Encoding: chunked

0

SMUGGLED
```

---

### How the Attack Works

**1. Front-end Processing**

- Uses **Content-Length: 13**
- Reads entire body:

```
0

SMUGGLED
```

- Forwards it as **one request** to backend.

**2. Back-end Processing**

- Uses **Transfer-Encoding: chunked**
- Reads:

```
0
```

- `0` means **end of request body**.

**3. Smuggled Data**

- Remaining data:

```
SMUGGLED
```

- Treated as **start of the next request**.

---
