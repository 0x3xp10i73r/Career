---
title: "TE.CL Request Smuggling"
aliases:
  - "TE CL Request Smuggling"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Vulnerabilities/HTTP Request Smuggling|HTTP Request Smuggling]]"
notion-id: 414759b92751822faa07011790127813
---

# TE.CL Request Smuggling

In: [[Career]] / [[Vulnerabilities]] / [[Vulnerabilities/HTTP Request Smuggling|HTTP Request Smuggling]]

## TE.CL Request Smuggling (Short Notes)

### Definition

- **TE.CL** occurs when:
    - **Front-end server uses `Transfer-Encoding`**
    - **Back-end server uses `Content-Length`**
- Different parsing causes **request desynchronization**, allowing **hidden requests to be injected**.

---

### Example Payload

```
POST / HTTP/1.1
Host: vulnerable-website.com
Content-Length: 3
Transfer-Encoding: chunked

8
SMUGGLED
0
```

**Burp Note**

- Disable **“Update Content-Length”** in Repeater.
- Ensure the request ends with **`\r\n\r\n` after `0`**.

---

### How the Attack Works

**1. Front-end Processing**

- Uses **Transfer-Encoding: chunked**
- Reads:
    - `8` → chunk size (8 bytes)
    - `SMUGGLED`
    - `0` → end of chunks
- Forwards the request to backend.

**2. Back-end Processing**

- Uses **Content-Length: 3**
- Reads only:

```
8\r\n
```

- Remaining data:

```
SMUGGLED
```

is treated as **the start of the next request**.

---

### Result

- Attacker **smuggles a request into backend queue**, which can lead to:
    - Authentication bypass
    - Session hijacking
    - Cache poisoning.
