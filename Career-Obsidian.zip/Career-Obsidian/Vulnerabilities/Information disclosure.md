---
title: "Information disclosure"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: acd759b9275183a5b28c81314fac1ce5
---

# Information disclosure

In: [[Career]] / [[Vulnerabilities]]

## Contents

**[[Lab - Information disclosure in error messages|Lab: Information disclosure in error messages]]**

**[[Lab - Information disclosure on debug page|Lab: Information disclosure on debug page]]**

**[[Lab - Source code disclosure via backup files|Lab: Source code disclosure via backup files]]**

**[[Lab - Authentication bypass via information disclosure|Lab: Authentication bypass via information disclosure]]**

**[[Information disclosure in version control history]]**
