---
title: "File Upload"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: e81759b9275183a786df018e152c4505
---

# File Upload

In: [[Career]] / [[Vulnerabilities]]

## Contents

[[Study - Flawed File Upload Validation]]

**[[Web shell upload via Content-Type restriction bypass]]**

[[Study - File Execution Prevention & Bypasses]]

**[[Web shell upload via path traversal]]**

[[Study - Insufficient blacklisting of dangerous file types|Study - Insufficient blacklisting of dangerous file types Blacklist Bypass Techniques]]

**[[Web shell upload via extension blacklist bypass]]**

[[Study - Obfuscating file extensions]]

[[Study - Content-Based Validation & Bypasses]]

**[[Web shell upload via obfuscated file extension(NullByte)]]**

**[[Remote code execution via polyglot web shell upload]]**

[[Exploiting file upload race conditions]]
