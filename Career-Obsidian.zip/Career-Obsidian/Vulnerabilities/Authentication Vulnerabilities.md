---
title: "Authentication Vulnerabilities"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: ad6759b92751821784308192b6c232fb
---

# Authentication Vulnerabilities

In: [[Career]] / [[Vulnerabilities]]

## Contents

[[What is Authentication]]

**[[Vulnerabilities in password-based login]]**

**[[Username enumeration via different responses]]**

**[[Lab - Username enumeration via subtly different responses|Lab: Username enumeration via subtly different responses]]**

**[[Lab - Username enumeration via response timing|Lab: Username enumeration via response timing]]**
