---
title: "Lab: Information disclosure in error messages"
aliases:
  - "Lab Information disclosure in error messages"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Information disclosure]]"
notion-id: 052759b9275182cfa3368102c7c8295c
---

# Lab: Information disclosure in error messages

In: [[Career]] / [[Vulnerabilities]] / [[Information disclosure]]

This lab's verbose error messages reveal that it is using a vulnerable version of a third-party framework. To solve the lab, obtain and submit the version number of this framework.

![[attachments/Vulnerabilities/Information disclosure/Lab - Information disclosure in error messages/image.png]]

![[attachments/Vulnerabilities/Information disclosure/Lab - Information disclosure in error messages/image 1.png]]
