---
title: "Lab: Source code disclosure via backup files"
aliases:
  - "Lab Source code disclosure via backup files"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Information disclosure]]"
notion-id: bce759b9275182b0bb3401796f248ec0
---

# Lab: Source code disclosure via backup files

In: [[Career]] / [[Vulnerabilities]] / [[Information disclosure]]

This lab leaks its source code via backup files in a hidden directory. To solve the lab, identify and submit the database password, which is hard-coded in the leaked source code.

![[attachments/Vulnerabilities/Information disclosure/Lab - Source code disclosure via backup files/image.png]]

![[attachments/Vulnerabilities/Information disclosure/Lab - Source code disclosure via backup files/image 1.png]]
