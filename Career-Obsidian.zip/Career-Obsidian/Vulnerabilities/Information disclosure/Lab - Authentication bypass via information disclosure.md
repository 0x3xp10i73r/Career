---
title: "Lab: Authentication bypass via information disclosure"
aliases:
  - "Lab Authentication bypass via information disclosu"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Information disclosure]]"
notion-id: 97f759b927518235a68401575208b4c8
---

# Lab: Authentication bypass via information disclosure

In: [[Career]] / [[Vulnerabilities]] / [[Information disclosure]]

This lab's administration interface has an authentication bypass vulnerability, but it is impractical to exploit without knowledge of a custom HTTP header used by the front-end.

To solve the lab, obtain the header name then use it to bypass the lab's authentication. Access the admin interface and delete the user `carlos`.

You can log in to your own account using the following credentials: `wiener:peter`

![[attachments/Vulnerabilities/Information disclosure/Lab - Authentication bypass via information disclosure/image.png]]

![[attachments/Vulnerabilities/Information disclosure/Lab - Authentication bypass via information disclosure/image 1.png]]

![[attachments/Vulnerabilities/Information disclosure/Lab - Authentication bypass via information disclosure/image 2.png]]

![[attachments/Vulnerabilities/Information disclosure/Lab - Authentication bypass via information disclosure/image 3.png]]
