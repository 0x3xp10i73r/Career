---
title: "Lab: Information disclosure on debug page"
aliases:
  - "Lab Information disclosure on debug page"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Information disclosure]]"
notion-id: 311759b92751835a9fb301880bb3a168
---

# Lab: Information disclosure on debug page

In: [[Career]] / [[Vulnerabilities]] / [[Information disclosure]]

This lab contains a debug page that discloses sensitive information
about the application. To solve the lab, obtain and submit the `SECRET_KEY` environment variable.


![[attachments/Vulnerabilities/Information disclosure/Lab - Information disclosure on debug page/image.png]]

![[attachments/Vulnerabilities/Information disclosure/Lab - Information disclosure on debug page/image 1.png]]
