---
title: "CSRF"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: 95c759b927518312b4428130459ff029
---

# CSRF

In: [[Career]] / [[Vulnerabilities]]

## Contents

[[What is CSRF|What is CSRF?]]

**[[Lab - CSRF vulnerability with no defenses|Lab: CSRF vulnerability with no defenses]]**

**[[CSRF Token Bypass - Request Method Dependency|CSRF Token Bypass: Request Method Dependency]]**

**[[Lab - CSRF where token validation depends on request method|Lab: CSRF where token validation depends on request method]]**

**[[CSRF Token Bypass - Token Presence Dependency|CSRF Token Bypass: Token Presence Dependency]]**

**[[Lab - CSRF where token validation depends on token being present|Lab: CSRF where token validation depends on token being present]]**

**[[CSRF Token Bypass - Session Independence|CSRF Token Bypass: Session Independence]]**

**[[Lab - CSRF where token is not tied to user session|Lab: CSRF where token is not tied to user session]]**

**[[CSRF Token Bypass - Token Bound to Wrong Cookie|CSRF Token Bypass: Token Bound to Wrong Cookie]]**

**[[CSRF where token is tied to non-session cookie]]**

**[[CSRF Token Bypass - “Double Submit Vulnerability|CSRF Token Bypass: “Double Submit" Vulnerability]]**

**[[Lab - CSRF where token is duplicated in cookie|Lab: CSRF where token is duplicated in cookie]]**

[[SameSite Flag Notes]]

**[[Bypassing SameSite Lax via GET Requests]]**

**[[Lab - SameSite Lax bypass via method override|Lab: SameSite Lax bypass via method override]]**

**[[Bypassing SameSite=Strict via On-Site Gadgets]]**

[[Lab - SameSite Strict bypass via client-side redirect|Lab: SameSite Strict bypass via client-side redirect]]

**[[Bypassing SameSite Lax via Newly Issued Cookies]]**

**[[Lab - SameSite Lax bypass via cookie refresh|Lab: SameSite Lax bypass via cookie refresh]]**

**[[Bypassing SameSite via Sibling Domains]]**

**[[Lab - SameSite Strict bypass via sibling domain|Lab: SameSite Strict bypass via sibling domain]]**
