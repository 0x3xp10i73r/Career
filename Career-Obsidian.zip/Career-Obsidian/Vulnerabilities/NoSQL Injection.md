---
title: "NoSQL Injection"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: 6cf759b92751825f91a581b5deff9cc3
---

# NoSQL Injection

In: [[Career]] / [[Vulnerabilities]]

## Contents

[[NoSQL Injection notes]]

[[NoSQL Injection – Syntax Injection]]

**[[Lab - Detecting NoSQL injection|Lab: Detecting NoSQL injection]]**

[[NoSQL Injection – Operator Injection]]

**[[Lab - Exploiting NoSQL operator injection to bypass authentication|Lab: Exploiting NoSQL operator injection to bypass authentication]]**

[[Data Exfiltration via NoSQL Injection]]

**[[Lab - Exploiting NoSQL injection to extract data|Lab: Exploiting NoSQL injection to extract data]]**
