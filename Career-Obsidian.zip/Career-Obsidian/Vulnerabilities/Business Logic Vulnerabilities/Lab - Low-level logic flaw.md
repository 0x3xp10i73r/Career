---
title: "Lab: Low-level logic flaw"
aliases:
  - "Lab Low-level logic flaw"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Business Logic Vulnerabilities]]"
notion-id: 7dd759b927518304a87081fa1a13ceaa
---

# Lab: Low-level logic flaw

In: [[Career]] / [[Vulnerabilities]] / [[Business Logic Vulnerabilities]]

This lab doesn't adequately validate user input. You can exploit a logic flaw in its purchasing workflow to buy items for an unintended price. To solve the lab, buy a "Lightweight l33t leather jacket".

You can log in to your own account using the following credentials: `wiener:peter`

![[attachments/Vulnerabilities/Business Logic Vulnerabilities/Lab - Low-level logic flaw/image.png]]
