---
title: "Lab: 2FA broken logic (Incomplete)"
aliases:
  - "Lab 2FA broken logic (Incomplete)"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Business Logic Vulnerabilities]]"
notion-id: 12f759b92751839db78d01f2825474d1
---

# Lab: 2FA broken logic (Incomplete)

In: [[Career]] / [[Vulnerabilities]] / [[Business Logic Vulnerabilities]]

This lab's two-factor authentication is vulnerable due to its flawed logic. To solve the lab, access Carlos's account page.

- Your credentials: `wiener:peter`
- Victim's username: `carlos`

You also have access to the email server to receive your 2FA verification code

![[attachments/Vulnerabilities/Business Logic Vulnerabilities/Lab - 2FA broken logic (Incomplete)/image.png]]

![[attachments/Vulnerabilities/Business Logic Vulnerabilities/Lab - 2FA broken logic (Incomplete)/image 1.png]]
