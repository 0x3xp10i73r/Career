---
title: "Lab: Excessive trust in client-side controls"
aliases:
  - "Lab Excessive trust in client-side controls"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Business Logic Vulnerabilities]]"
notion-id: 99d759b927518314868881e4d0c2d32f
---

# Lab: Excessive trust in client-side controls

In: [[Career]] / [[Vulnerabilities]] / [[Business Logic Vulnerabilities]]

This lab doesn't adequately validate user input. You can exploit a logic flaw in its purchasing workflow to buy items for an unintended price. To solve the lab, buy a "Lightweight l33t leather jacket".

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/Business Logic Vulnerabilities/Lab - Excessive trust in client-side controls/image.png]]

![[attachments/Vulnerabilities/Business Logic Vulnerabilities/Lab - Excessive trust in client-side controls/image 1.png]]

![[attachments/Vulnerabilities/Business Logic Vulnerabilities/Lab - Excessive trust in client-side controls/image 2.png]]

![[attachments/Vulnerabilities/Business Logic Vulnerabilities/Lab - Excessive trust in client-side controls/image 3.png]]

![[attachments/Vulnerabilities/Business Logic Vulnerabilities/Lab - Excessive trust in client-side controls/image 4.png]]

![[attachments/Vulnerabilities/Business Logic Vulnerabilities/Lab - Excessive trust in client-side controls/image 5.png]]
