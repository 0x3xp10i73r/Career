---
title: "HTTP Host Header Attacks"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: 143759b9275182d7898e81bc24aec946
---

# HTTP Host Header Attacks

In: [[Career]] / [[Vulnerabilities]]

## Contents

[[HTTP Host Header Notes]]

[[HTTP Host Header Attack]]

[[Testing for HTTP Host Header Vulnerabilities]]

**[[Lab - Basic password reset poisoning|Lab: Basic password reset poisoning]]**

**[[Lab - Host header authentication bypass|Lab: Host header authentication bypass]]**

[[HTTP Host Header Attacks - Internal Host Discovery & SSRF Techniques|HTTP Host Header Attacks: Internal Host Discovery & SSRF Techniques]]

**[[Lab - Routing-based SSRF|Lab: Routing-based SSRF]]**

**[[Lab - SSRF via flawed request parsing|Lab: SSRF via flawed request parsing]]**

**[[Lab - Host validation bypass via connection state attack|Lab: Host validation bypass via connection state attack]]**
