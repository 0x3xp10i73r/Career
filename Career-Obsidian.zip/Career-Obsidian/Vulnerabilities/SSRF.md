---
title: "SSRF"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: 46a759b927518381895a815938baff5a
---

# SSRF

In: [[Career]] / [[Vulnerabilities]]

## Contents

[[Server-Side Request Forgery (SSRF) - Notes]]

[[Lab - Basic SSRF against the local server - Easy|Lab: Basic SSRF against the local server - Easy]]

**[[SSRF Attacks Against Other Back-End Systems]]**

**[[Lab - Basic SSRF against another back-end system - Easy|Lab: Basic SSRF against another back-end system - Easy]]**

[[SSRF with Blacklist-Based Input Filters]]

**[[SSRF with blacklist-based input filter]]**

**[[Lab - Blind SSRF with out-of-band detection|Lab: Blind SSRF with out-of-band detection]]**

**[[Lab - SSRF with filter bypass via open redirection vulnerability|Lab: SSRF with filter bypass via open redirection vulnerability]]**
