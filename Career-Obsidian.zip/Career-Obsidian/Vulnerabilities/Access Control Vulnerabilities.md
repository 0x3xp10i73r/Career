---
title: "Access Control Vulnerabilities"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: e70759b9275182ba8f57818a1426f190
---

# Access Control Vulnerabilities

In: [[Career]] / [[Vulnerabilities]]

## Contents

**[[Lab - Unprotected admin functionality|Lab: Unprotected admin functionality]]**

**[[Lab - Unprotected admin functionality with unpredictable URL|Lab: Unprotected admin functionality with unpredictable URL]]**

**[[Lab - User role controlled by request parameter|Lab: User role controlled by request parameter]]**

**[[Lab - User role can be modified in user profile|Lab: User role can be modified in user profile]]**

**[[Lab - User ID controlled by request parameter|Lab: User ID controlled by request parameter]]**

**[[Lab - User ID controlled by request parameter, with unpredictable user IDs|Lab: User ID controlled by request parameter, with unpredictable user IDs]]**

**[[Lab - User ID controlled by request parameter with data leakage in redirect|Lab: User ID controlled by request parameter with data leakage in redirect]]**

**[[Lab - User ID controlled by request parameter with password disclosure|Lab: User ID controlled by request parameter with password disclosure]]**

[[Lab - IDOR|Lab: IDOR]]

**[[Lab - URL-based access control can be circumvented|Lab: URL-based access control can be circumvented]]**

**[[Lab - Method-based access control can be circumvented|Lab: Method-based access control can be circumvented]]**

[[Lab - Multi-step process with no access control on one step (Pending)|Lab: Multi-step process with no access control on one step (Pending)]]

**[[Lab - Referer-based access control|Lab: Referer-based access control]]**
