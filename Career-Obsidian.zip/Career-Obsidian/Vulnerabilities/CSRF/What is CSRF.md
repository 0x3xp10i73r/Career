---
title: "What is CSRF?"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[CSRF]]"
notion-id: 611759b9275182538cde015eaf70fdd7
---

# What is CSRF?

In: [[Career]] / [[Vulnerabilities]] / [[CSRF]]

## Cross-Site Request Forgery (CSRF) - Security Notes

### 1. Definition

**Cross-Site Request Forgery (CSRF)** is a web security vulnerability that allows attackers to induce users to perform unintended actions. It circumvents the Same Origin Policy designed to prevent websites from interfering with each other.

### 2. Impact of CSRF Attacks

- **Account compromise**: Email/password changes, funds transfers
- **Privilege escalation**: If victim has administrative access
- **Full application control** in worst-case scenarios
- **Data manipulation**: Unauthorized modifications to user data

### 3. Prerequisites for CSRF

Three key conditions must be present:

1. **Relevant Action** - Action worth attacking (privileged or user-specific)
2. **Cookie-Based Session Handling** - Reliance solely on session cookies for authentication
3. **No Unpredictable Parameters** - All request parameters must be guessable/determinable

### 4. Attack Mechanism

#### Example Attack Flow:

```bash
POST /email/change HTTP/1.1
Host: vulnerable-website.com
Cookie: session=yvthwsztyeQkAPzeQ5gHgTvlyxHfsAfE
email=attacker@evil.net
```

#### Attack Vector HTML:

```html
<html>
<body>
    <form action="<https://vulnerable-website.com/email/change>" method="POST">
        <input type="hidden" name="email" value="pwned@evil-user.net"/>
    </form>
    <script>document.forms[0].submit();</script>
</body>
</html>

```

### 5. Attack Delivery Methods

- **External websites** controlled by attacker
- **Social engineering**: Links via email/social media
- **Self-contained attacks** (GET-based):

    ```html
    <img src="<https://vulnerable.com/change-email?email=attacker@evil.net>">
    ```


### 6. Common Defense Mechanisms

#### A. CSRF Tokens

- **Implementation**: Unique, secret, unpredictable server-generated values
- **Requirement**: Client must include valid token in sensitive requests
- **Effectiveness**: High when properly implemented

#### B. SameSite Cookies

- **Browser mechanism**: Controls cookie inclusion in cross-site requests
- **Chrome default**: Lax restrictions (since 2021)
- **Standardization**: Expected adoption across major browsers

#### C. Referer-Based Validation

- **Method**: Verifies request originated from own domain
- **Limitation**: Generally less effective than CSRF tokens
- **Vulnerable**: To Referer header stripping or spoofing

### 7. Exploitation Tools & Techniques

#### Burp Suite Professional Features:

- Built-in CSRF PoC generator
- **Access**: Right-click → Engagement tools → Generate CSRF PoC
- **Customization**: Adjust options for unusual request quirks

### 8. Testing Methodology

1. Identify sensitive actions without unpredictable parameters
2. Verify cookie-based authentication
3. Generate CSRF PoC using tools
4. Test with authenticated sessions
5. Attempt defense bypasses

### 9. Prevention Best Practices

- Implement **CSRF tokens** for state-changing operations
- Use **SameSite cookie attributes**
- Consider **double-submit cookie patterns**
- Implement **custom request headers** for AJAX
- Educate developers about CSRF risks
