---
title: "Lab: CSRF where token validation depends on token being present"
aliases:
  - "Lab CSRF where token validation depends on token b"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[CSRF]]"
notion-id: d78759b9275182ac88f481c082aff51d
---

# Lab: CSRF where token validation depends on token being present

In: [[Career]] / [[Vulnerabilities]] / [[CSRF]]

This lab's email change functionality is vulnerable to CSRF.

To solve the lab, use your exploit server to host an HTML page that uses a CSRF attack to change the viewer's email address.

You can log in to your own account using the following credentials: wiener:peter

1. Login with the given credentials

![[attachments/Vulnerabilities/CSRF/Lab - CSRF where token validation depends on token being present/image.png]]

1. Use the login functionality

![[attachments/Vulnerabilities/CSRF/Lab - CSRF where token validation depends on token being present/image 1.png]]

1. Intercept the corresponding request in the Proxy


![[attachments/Vulnerabilities/CSRF/Lab - CSRF where token validation depends on token being present/image 2.png]]

1. Send the request with the csrf token

![[attachments/Vulnerabilities/CSRF/Lab - CSRF where token validation depends on token being present/image 3.png]]

1. Send the request without the token (confirms csrf)

![[attachments/Vulnerabilities/CSRF/Lab - CSRF where token validation depends on token being present/image 4.png]]

1. Send the csrf payload through the exploit server

![[attachments/Vulnerabilities/CSRF/Lab - CSRF where token validation depends on token being present/image 5.png]]
