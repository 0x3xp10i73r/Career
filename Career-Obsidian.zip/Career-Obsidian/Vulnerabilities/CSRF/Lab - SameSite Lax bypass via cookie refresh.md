---
title: "Lab: SameSite Lax bypass via cookie refresh"
aliases:
  - "Lab SameSite Lax bypass via cookie refresh"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[CSRF]]"
notion-id: 4f1759b9275182cf98e801d7f6e9773e
---

# Lab: SameSite Lax bypass via cookie refresh

In: [[Career]] / [[Vulnerabilities]] / [[CSRF]]

This lab's change email function is vulnerable to CSRF. To solve the lab, perform a CSRF attack that changes the victim's email address. You should use the provided exploit server to host your attack.

The lab supports OAuth-based login. You can log in via your social media account with the following credentials: wiener:peter
