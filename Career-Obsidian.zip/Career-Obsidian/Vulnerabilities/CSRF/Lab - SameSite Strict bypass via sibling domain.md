---
title: "Lab: SameSite Strict bypass via sibling domain"
aliases:
  - "Lab SameSite Strict bypass via sibling domain"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[CSRF]]"
notion-id: 1db759b9275183399ad101d2f5fd6779
---

# Lab: SameSite Strict bypass via sibling domain

In: [[Career]] / [[Vulnerabilities]] / [[CSRF]]

0Cg3OGw3jfXUgn4VXOXwv0AMnQMT/JZfnkhoBBb/ACivYAn2zh0uJm1F0wzsNfeYTktyBt891LhF6pmoFbDAWt9ICdt+sZrUzr7Aq3OGYjnmSrLjEjg9QzbM4kXoZ8zmrgTngf66VM3QGTzLCRiUWUkAQAYzo+mRdlNnz5dVIXaInWg5G14cI79d2CL1CmtPjDPGWoOYPrMcXvKbK4k/JMIiQm2UPj54HR6Jn8mkpGGonS6ZouRqo8yYkuwlt7PdoU5hciAdqqKJrxuHEZ0dfUmbKQiksudb+pM1b5TIcoTmhMNUcOeVDRAAoSIDqreYk9BnD2CLHnzzbmXHNnTZyZ7IEUSOrCmVrUAGxDLFqcAwWJwsRzOs1jZXhnlaNFn/Am7ITF+LOdy+umJg1I0r6oEPg8dG/RTXPz773uJZfHY15Mpn4PdLvwJ2TKIMBVCxs+TUofwcxp8hfT/8PbxkJFxy5wDmiAitqqhJ1ORND06P6iTkIzBLBVAf8kQGko0A3FoaV/DdXo4hBedbT6nA1tDLKy3+Tj583/nQQwGBsZywVq52XrMAOpJlCxByJbmkHnhYJA8/nNEVgNK8f4PG/YCtAufKsbejB+M6kvLrwLsOwaUc6xWcymJU9u8uPTnBtLKcxIfIhCBM+JxtmVJRNFzWOtE066ezBUc4Y5tPmEqhIeO6Qkewt8wJuMMwtw8v9lUo6Y7lnH7DvcPtzxWoe2nIkqfAKZmHmhGa6K5EjPWeiW2N/TrHHyFbynwz/0LQJhBKDLXSIjsBu/lyAwZeIA==
