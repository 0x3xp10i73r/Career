---
title: "Lab: Basic SSRF against another back-end system | Easy"
aliases:
  - "Lab Basic SSRF against another back-end system Eas"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[SSRF]]"
notion-id: b09759b9275183adbed5815ccae6c782
---

# Lab: Basic SSRF against another back-end system | Easy

In: [[Career]] / [[Vulnerabilities]] / [[SSRF]]

This lab has a stock check feature which fetches data from an internal system.

To solve the lab, use the stock check functionality to scan the internal `192.168.0.X` range for an admin interface on port
`8080`, then use it to delete the user `carlos`.

1. Visit the lab and click on any product and view details

![[attachments/Vulnerabilities/SSRF/Lab - Basic SSRF against another back-end system - Easy/image.png]]

1. Click on check stock button and intercept the request in the proxy

![[attachments/Vulnerabilities/SSRF/Lab - Basic SSRF against another back-end system - Easy/image 1.png]]

1. Intercept the request in burpsuite

![[attachments/Vulnerabilities/SSRF/Lab - Basic SSRF against another back-end system - Easy/image-2.png]]

1. Send the request in the intruder by and setup payload for the IP using /admin

![[attachments/Vulnerabilities/SSRF/Lab - Basic SSRF against another back-end system - Easy/image 1-2.png]]

![[attachments/Vulnerabilities/SSRF/Lab - Basic SSRF against another back-end system - Easy/image 2.png]]

![[attachments/Vulnerabilities/SSRF/Lab - Basic SSRF against another back-end system - Easy/image 3.png]]

![[attachments/Vulnerabilities/SSRF/Lab - Basic SSRF against another back-end system - Easy/image 4.png]]
