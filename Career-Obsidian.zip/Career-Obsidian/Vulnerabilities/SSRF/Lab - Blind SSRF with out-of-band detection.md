---
title: "Lab: Blind SSRF with out-of-band detection"
aliases:
  - "Lab Blind SSRF with out-of-band detection"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[SSRF]]"
notion-id: 6d9759b927518201a0ef81ccaa5ab30c
---

# Lab: Blind SSRF with out-of-band detection

In: [[Career]] / [[Vulnerabilities]] / [[SSRF]]

This site uses analytics software which fetches the URL specified in the Referer header when a product page is loaded.

To solve the lab, use this functionality to cause an HTTP request to the public Burp Collaborator server.

![[attachments/Vulnerabilities/SSRF/Lab - Blind SSRF with out-of-band detection/image.png]]

![[attachments/Vulnerabilities/SSRF/Lab - Blind SSRF with out-of-band detection/image 1.png]]

![[attachments/Vulnerabilities/SSRF/Lab - Blind SSRF with out-of-band detection/image 2.png]]

![[attachments/Vulnerabilities/SSRF/Lab - Blind SSRF with out-of-band detection/image 3.png]]

![[attachments/Vulnerabilities/SSRF/Lab - Blind SSRF with out-of-band detection/image 4.png]]

![[attachments/Vulnerabilities/SSRF/Lab - Blind SSRF with out-of-band detection/image 5.png]]
