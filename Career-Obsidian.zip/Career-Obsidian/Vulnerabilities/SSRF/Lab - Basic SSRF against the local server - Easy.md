---
title: "Lab: Basic SSRF against the local server | Easy"
aliases:
  - "Lab Basic SSRF against the local server Easy"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[SSRF]]"
notion-id: 54f759b9275183899452810f77d6298f
---

# Lab: Basic SSRF against the local server | Easy

In: [[Career]] / [[Vulnerabilities]] / [[SSRF]]

This lab has a stock check feature which fetches data from an internal system.

To solve the lab, change the stock check URL to access the admin interface at `http://localhost/admin` and delete the user `carlos`.

1. Visit the lab and click on any product and view details

![[attachments/Vulnerabilities/SSRF/Lab - Basic SSRF against another back-end system - Easy/image.png]]

1. Click on check stocke button and intercept the request in the proxy

![[attachments/Vulnerabilities/SSRF/Lab - Basic SSRF against another back-end system - Easy/image 1.png]]

1. Craft the SSRF payload on the stockApi parameter & get the delete function

![[attachments/Vulnerabilities/SSRF/Lab - Basic SSRF against the local server - Easy/image 2.png]]

1. Call that function

![[attachments/Vulnerabilities/SSRF/Lab - Basic SSRF against the local server - Easy/image 3.png]]

![[attachments/Vulnerabilities/SSRF/Lab - Basic SSRF against the local server - Easy/image 4.png]]
