---
title: "Lab: Authentication bypass via OAuth implicit flow"
aliases:
  - "Lab Authentication bypass via OAuth implicit flow"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[OAuth Vulnerabilities]]"
notion-id: 8e8759b927518303b9a6012fb230e113
---

# Lab: Authentication bypass via OAuth implicit flow

In: [[Career]] / [[Vulnerabilities]] / [[OAuth Vulnerabilities]]

This lab uses an OAuth service to allow users to log in with their social media account. Flawed validation by the client application makes it possible for an attacker to log in to other users' accounts without knowing their password.

To solve the lab, log in to Carlos's account. His email address is `carlos@carlos-montoya.net`.

You can log in with your own social media account using the following credentials: `wiener:peter`.

![[attachments/Vulnerabilities/OAuth Vulnerabilities/Lab - Authentication bypass via OAuth implicit flow/image.png]]

![[attachments/Vulnerabilities/OAuth Vulnerabilities/Lab - Authentication bypass via OAuth implicit flow/image 1.png]]
