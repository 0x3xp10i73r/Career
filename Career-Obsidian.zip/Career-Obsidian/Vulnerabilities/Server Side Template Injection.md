---
title: "Server Side Template Injection"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: d94759b9275182839d558171a7b02501
---

# Server Side Template Injection

In: [[Career]] / [[Vulnerabilities]]

## Contents

[[Notes]]

**[[Lab - Basic server-side template injection|Lab: Basic server-side template injection]]**

**[[Lab - Basic server-side template injection (code context)|Lab: Basic server-side template injection (code context)]]**
