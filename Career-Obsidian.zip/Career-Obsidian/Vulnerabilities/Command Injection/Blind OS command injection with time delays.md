---
title: "Blind OS command injection with time delays"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Command Injection]]"
notion-id: 814759b92751821987f6012d86e9c821
---

# Blind OS command injection with time delays

In: [[Career]] / [[Vulnerabilities]] / [[Command Injection]]

1. Use Burp Suite to intercept and modify the request that submits feedback.
2. Modify the `email` parameter, changing it to:`email=x||ping+-c+10+127.0.0.1||`
3. Observe that the response takes 10 seconds to return.

- x → harmless command that always fails (exit code ≠ 0)
- || → “run the next command only if the previous one failed”
- `ping -c 10 127.0.0.1` → takes ~10 seconds to finish
- final || → ignored (nothing after it)

![[attachments/Vulnerabilities/Command Injection/Blind OS command injection with time delays/image.png]]

![[attachments/Vulnerabilities/Command Injection/Blind OS command injection with time delays/image 1.png]]
