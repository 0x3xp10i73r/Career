---
title: "Lab: Blind OS command injection with out-of-band interaction"
aliases:
  - "Lab Blind OS command injection with out-of-band in"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Command Injection]]"
notion-id: 01f759b927518201bbf3019c28fdc12d
---

# Lab: Blind OS command injection with out-of-band interaction

In: [[Career]] / [[Vulnerabilities]] / [[Command Injection]]

This lab contains a blind OS command injection vulnerability in the feedback function.

The application executes a shell command containing the user-supplied details. The command is executed asynchronously and has no effect on the application's response. It is not possible to redirect output into a location that you can access. However, you can trigger out-of-band interactions with an external domain.

To solve the lab, exploit the blind OS command injection vulnerability to issue a DNS lookup to Burp Collaborator.

![[attachments/Vulnerabilities/Command Injection/Lab - Blind OS command injection with out-of-band interaction/image.png]]

![[attachments/Vulnerabilities/Command Injection/Lab - Blind OS command injection with out-of-band interaction/image 1.png]]

![[attachments/Vulnerabilities/Command Injection/Lab - Blind OS command injection with out-of-band interaction/image 2.png]]
