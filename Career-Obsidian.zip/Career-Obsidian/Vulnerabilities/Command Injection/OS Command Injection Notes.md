---
title: "OS Command Injection Notes"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Command Injection]]"
notion-id: 661759b9275183118358017f140d98f1
---

# OS Command Injection Notes

In: [[Career]] / [[Vulnerabilities]] / [[Command Injection]]

## OS Command Injection (Shell Injection)

- Allows an attacker to **execute OS commands** on the server running the application
- Can lead to **full compromise** of the app and its data
- Attackers can pivot to **other internal systems** by exploiting trust relationships

---

## How It Works — Example

- A shopping app checks stock via URL:

```
https://insecure-website.com/stockStatus?productID=381&storeID=29
```

- Internally, the app runs a shell command:

```bash
stockreport.pl 381 29
```

- Attacker injects into `productID`:

```bash
& echo aiwefwlguh &
```

- The resulting command becomes:

```bash
stockreport.pl & echo aiwefwlguh & 29
```

- Output returned:

```
Error - productID was not provided
aiwefwlguh
29: command not found
```

- This confirms **3 separate commands executed** — injection was successful

---

### Why `&` is Used

- `&` is a **shell command separator** — splits one line into multiple commands
- Placing `&` **after** the injected command separates it from whatever follows, reducing the chance of it being blocked or broken

---

## Useful Recon Commands Post-Exploitation

| Purpose | Linux | Windows |
| --- | --- | --- |
| Current user | `whoami` | `whoami` |
| OS info | `uname -a` | `ver` |
| Network config | `ifconfig` | `ipconfig /all` |
| Network connections | `netstat -an` | `netstat -an` |
| Running processes | `ps -ef` | `tasklist` |
