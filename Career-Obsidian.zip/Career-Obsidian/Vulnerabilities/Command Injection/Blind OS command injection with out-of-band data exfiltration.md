---
title: "Blind OS command injection with out-of-band data exfiltration"
aliases:
  - "Blind OS command injection with out-of-band data e"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Command Injection]]"
notion-id: 169759b9275183c682170120a099d3f9
---

# Blind OS command injection with out-of-band data exfiltration

In: [[Career]] / [[Vulnerabilities]] / [[Command Injection]]

This lab contains a blind OS command injection vulnerability in the feedback function.

The application executes a shell command containing the user-supplied details. The command is executed asynchronously and has no effect on the application's response. It is not possible to redirect output into a location that you can access. However, you can trigger out-of-band interactions with an external domain.

To solve the lab, execute the whoami command and exfiltrate the output via a DNS query to Burp Collaborator. You will need to enter the name of the current user to complete the lab.

![[attachments/Vulnerabilities/Command Injection/Blind OS command injection with out-of-band data exfiltration/image.png]]

![[attachments/Vulnerabilities/Command Injection/Blind OS command injection with out-of-band data exfiltration/image 1.png]]

![[attachments/Vulnerabilities/Command Injection/Blind OS command injection with out-of-band data exfiltration/image 2.png]]

![[attachments/Vulnerabilities/Command Injection/Blind OS command injection with out-of-band data exfiltration/image 3.png]]
