---
title: "Lab: JWT authentication bypass via unverified signature"
aliases:
  - "Lab JWT authentication bypass via unverified signa"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[JWT]]"
notion-id: 951759b927518294afa98198cb022852
---

# Lab: JWT authentication bypass via unverified signature

In: [[Career]] / [[Vulnerabilities]] / [[JWT]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via unverified signature/image.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via unverified signature/image 1.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via unverified signature/image 2.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via unverified signature/image 3.png]]
