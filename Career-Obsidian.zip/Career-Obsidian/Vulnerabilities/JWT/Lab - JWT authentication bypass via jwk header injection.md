---
title: "Lab: JWT authentication bypass via jwk header injection"
aliases:
  - "Lab JWT authentication bypass via jwk header injec"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[JWT]]"
notion-id: 262759b927518204855b81f34daaf7f6
---

# Lab: JWT authentication bypass via jwk header injection

In: [[Career]] / [[Vulnerabilities]] / [[JWT]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via jwk header injection/image.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via jwk header injection/image 1.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via jwk header injection/image 2.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via jwk header injection/image 3.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via jwk header injection/image 4.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via jwk header injection/image 5.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via jwk header injection/image 6.png]]
