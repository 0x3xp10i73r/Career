---
title: "JWT Header Injection"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[JWT]]"
notion-id: 21a759b92751822e83a381b346a3e854
---

# JWT Header Injection

In: [[Career]] / [[Vulnerabilities]] / [[JWT]]

## JWT Header Parameter Injections

- JWT headers contain parameters that tell the server **which key to use for verification**
- These are user-controllable → attackers can abuse them to **inject their own key**

---

## Key Header Parameters to Know

| Parameter | What it Does |
| --- | --- |
| `jwk` | Embeds the public key **directly in the token** as a JSON object |
| `jku` | Provides a **URL** where the server fetches the verification key from |
| `kid` | An **ID** to identify which key to use when multiple keys exist |

> [!warning]
> All three are attacker-controllable — if the server blindly trusts them, you can make it verify the token using **your own key**
>

---

## JWT Header Injection Attacks — Comparison

---

### Quick Reference

|  | `jwk` Injection | `jku` Injection | `kid` Injection |
| --- | --- | --- | --- |
| **What it abuses** | Embedded key in token header | URL that points to attacker's key server | File path used as verification key |
| **Where attacker's key lives** | Inside the JWT header itself | On attacker's hosted server | On the target's own filesystem |
| **Algorithm** | RS256 (asymmetric) | RS256 (asymmetric) | HS256 (symmetric) |
| **What attacker needs** | Their own RSA key pair | Their own RSA key pair + hosted JWK Set | Knowledge of a predictable file (e.g. `/dev/null`) |
| **Server mistake** | Trusts any key embedded in the token | Fetches keys from any URL without whitelist | Uses `kid` value as a file path without sanitization |
| **Difficulty** | Easy — Burp does it automatically | Medium — need to host a JWK endpoint | Easy — `/dev/null` always works on Linux |

---

### One Line Each

- **`jwk`** → *"Trust my key, I put it right here in the token"*
- **`jku`** → *"Trust my key, go fetch it from my server"*
- **`kid`** → *"Use this file as your key — I know what's in it"*

---

### Key Differences Visually

```
jwk attack:
  JWT header contains → attacker's public key (embedded)
  Signed with         → attacker's private key
  Server verifies with → the embedded key ✅

jku attack:
	  JWT header contains → URL pointing to attacker's server
  Attacker hosts      → JWK Set with their public key
  Server fetches key from attacker's URL → verifies ✅

kid attack:
  JWT header contains → ../../dev/null (path traversal)
  Server reads file   → empty string
  Attacker signs with → empty string as secret ✅
```

---
