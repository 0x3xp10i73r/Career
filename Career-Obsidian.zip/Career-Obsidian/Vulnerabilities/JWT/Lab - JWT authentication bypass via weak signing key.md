---
title: "Lab: JWT authentication bypass via weak signing key"
aliases:
  - "Lab JWT authentication bypass via weak signing key"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[JWT]]"
notion-id: 280759b9275183d9892981c2d8636850
---

# Lab: JWT authentication bypass via weak signing key

In: [[Career]] / [[Vulnerabilities]] / [[JWT]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via weak signing key/image.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via weak signing key/image 1.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via weak signing key/image 2.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via weak signing key/image 3.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via weak signing key/image 4.png]]
