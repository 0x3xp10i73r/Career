---
title: "Lab: JWT authentication bypass via kid header path traversal"
aliases:
  - "Lab JWT authentication bypass via kid header path"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[JWT]]"
notion-id: de3759b92751832fa12201b04074b998
---

# Lab: JWT authentication bypass via kid header path traversal

In: [[Career]] / [[Vulnerabilities]] / [[JWT]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via kid header path traversal/image.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via kid header path traversal/image 1.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via kid header path traversal/image 2.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via kid header path traversal/image 3.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via kid header path traversal/image 4.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via kid header path traversal/image 5.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via kid header path traversal/image 6.png]]

![[attachments/Vulnerabilities/JWT/Lab - JWT authentication bypass via kid header path traversal/image 7.png]]
