---
title: "Prototype Pollution"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: 6c7759b9275183d49f9901941a258bcb
---

# Prototype Pollution

In: [[Career]] / [[Vulnerabilities]]

## Contents

[[JavaScript Objects, Prototypes & Prototype Pollution]]

[[Prototype Pollution Sources]]

[[Prototype Pollution Gadgets]]

[[Finding Client Side Prototype-Pollution]]
