---
title: "Lab: Limit overrun race conditions"
aliases:
  - "Lab Limit overrun race conditions"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Race Conditions]]"
notion-id: 014759b9275183299dd501e045f757ad
---

# Lab: Limit overrun race conditions

In: [[Career]] / [[Vulnerabilities]] / [[Race Conditions]]

This lab's purchasing flow contains a race condition that enables you to purchase items for an unintended price.

To solve the lab, successfully purchase a **Lightweight L33t Leather Jacket**.

You can log in to your account with the following credentials: `wiener:peter`.

For a faster and more convenient way to trigger the race condition, we recommend that you solve this lab using the [Trigger race conditions](https://github.com/PortSwigger/bambdas/blob/main/CustomAction/ProbeForRaceCondition.bambda) custom action. This is only available in Burp Suite Professional.

![[attachments/Vulnerabilities/Race Conditions/Lab - Limit overrun race conditions/image.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Limit overrun race conditions/image 1.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Limit overrun race conditions/image 2.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Limit overrun race conditions/image 3.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Limit overrun race conditions/image 4.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Limit overrun race conditions/image 5.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Limit overrun race conditions/image 6.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Limit overrun race conditions/image 7.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Limit overrun race conditions/image 8.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Limit overrun race conditions/image 9.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Limit overrun race conditions/image 10.png]]
