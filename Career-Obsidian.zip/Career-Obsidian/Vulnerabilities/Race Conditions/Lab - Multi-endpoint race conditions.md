---
title: "Lab: Multi-endpoint race conditions"
aliases:
  - "Lab Multi-endpoint race conditions"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Race Conditions]]"
notion-id: 40f759b9275182f99d68019847350334
---

# Lab: Multi-endpoint race conditions

In: [[Career]] / [[Vulnerabilities]] / [[Race Conditions]]

This lab's purchasing flow contains a race condition that enables you to purchase items for an unintended price.

To solve the lab, successfully purchase a **Lightweight L33t Leather Jacket**. You can log into your account with the following credentials: `wiener:peter`.

### Note

Solving this lab requires Burp Suite 2023.9 or higher.

### Tip

When experimenting, we recommend purchasing the gift card as you can later redeem this to avoid running out of store credit.

![[attachments/Vulnerabilities/Race Conditions/Lab - Multi-endpoint race conditions/image.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Multi-endpoint race conditions/image 1.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Multi-endpoint race conditions/image 2.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Multi-endpoint race conditions/image 3.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Multi-endpoint race conditions/image 4.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Multi-endpoint race conditions/image 5.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Multi-endpoint race conditions/image 6.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Multi-endpoint race conditions/image 7.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Multi-endpoint race conditions/image 8.png]]
