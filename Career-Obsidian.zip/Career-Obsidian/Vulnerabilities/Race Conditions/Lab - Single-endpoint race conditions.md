---
title: "Lab: Single-endpoint race conditions"
aliases:
  - "Lab Single-endpoint race conditions"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Race Conditions]]"
notion-id: 22e759b92751836e96bc814313a7a892
---

# Lab: Single-endpoint race conditions

In: [[Career]] / [[Vulnerabilities]] / [[Race Conditions]]

This lab's email change feature contains a race condition that enables you to associate an arbitrary email address with your account.

Someone with the address `carlos@ginandjuice.shop` has a pending invite to be an administrator for the site, but they have not yet created an account. Therefore, any user who successfully claims this address will automatically inherit admin privileges.

To solve the lab:

1. Identify a race condition that lets you claim an arbitrary email address.
2. Change your email address to `carlos@ginandjuice.shop`.
3. Access the admin panel.
4. Delete the user `carlos`

You can log in to your own account with the following credentials: `wiener:peter`.

You also have access to an email client, where you can view all emails sent to `@exploit-<YOUR-EXPLOIT-SERVER-ID>.exploit-server.net` addresses.

![[attachments/Vulnerabilities/Race Conditions/Lab - Single-endpoint race conditions/image.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Single-endpoint race conditions/image 1.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Single-endpoint race conditions/image 2.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Single-endpoint race conditions/image 3.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Single-endpoint race conditions/image 4.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Single-endpoint race conditions/image 5.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Single-endpoint race conditions/image 6.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Single-endpoint race conditions/image 7.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Single-endpoint race conditions/image 8.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Single-endpoint race conditions/image 9.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Single-endpoint race conditions/image 10.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Single-endpoint race conditions/image 11.png]]

![[attachments/Vulnerabilities/Race Conditions/Lab - Single-endpoint race conditions/image 12.png]]
