---
title: "Gadget Chains"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Vulnerabilities/Insecure Deserialization|Insecure Deserialization]]"
notion-id: ceb759b92751828cb323817a817335ba
---

# Gadget Chains

In: [[Career]] / [[Vulnerabilities]] / [[Vulnerabilities/Insecure Deserialization|Insecure Deserialization]]

## Gadget Chains

- A **gadget** = a snippet of existing app code that an attacker can leverage to achieve a goal
- A single gadget may seem harmless — but chained together they can cause serious damage
- The chain ends at a **"sink gadget"** — where the attacker's input causes maximum damage (e.g. RCE)

---

### Key Concept

> [!warning]
> The attacker does **not** write the code — all gadgets already exist in the app. The attacker only controls the **data** passed into the chain.
>
- The chain is typically kicked off by a **magic method** triggered during deserialization (the **"kick-off gadget"**)
- Can be a simple 1–2 step chain or a complex sequence of object instantiations and method calls

---

## Working with Pre-Built Gadget Chains

- Manually finding gadget chains is **very difficult** — nearly impossible without source code
- Better approach: use **pre-built tools** with known, tested chains
- Works because many apps share the **same libraries** — if a chain works on one site using Apache Commons Collections, it likely works on any site using the same library

---

### Tool: ysoserial (Java)

- Popular tool for exploiting **Java deserialization**
- Workflow:
    1. Identify which library the target app uses
    2. Select the matching gadget chain in ysoserial
    3. Pass in your command to execute
    4. Tool outputs a ready-to-use serialized object
- Still requires some **trial and error** but far faster than manual chain building
- Java 16+ requires extra flags to run:

```bash
java -jar ysoserial-all.jar \
  --add-opens=java.xml/com.sun.org.apache.xalan.internal.xsltc.trax=ALL-UNNAMED \
  --add-opens=java.xml/com.sun.org.apache.xalan.internal.xsltc.runtime=ALL-UNNAMED \
  --add-opens=java.base/java.net=ALL-UNNAMED \
  --add-opens=java.base/java.util=ALL-UNNAMED \
  [payload] '[command]'
```

---

### Key Takeaway

- Gadget chains are what make insecure deserialization escalate from **low-impact to critical**
- Mastering gadget chains is essential for successfully exploiting deserialization vulnerabilities in real engagements
