---
title: "Lab: Modifying serialized data types"
aliases:
  - "Lab Modifying serialized data types"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Vulnerabilities/Insecure Deserialization|Insecure Deserialization]]"
notion-id: ca8759b9275182c0b440810003d9b0b1
---

# Lab: Modifying serialized data types

In: [[Career]] / [[Vulnerabilities]] / [[Vulnerabilities/Insecure Deserialization|Insecure Deserialization]]

This lab uses a serialization-based session mechanism and is vulnerable to authentication bypass as a result. To solve the lab, edit the serialized object in the session cookie to access the administrator account. Then, delete the user carlos.

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized data types/image.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized data types/image 1.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized data types/image 2.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized data types/image 3.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized data types/image 4.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized data types/image 5.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized data types/image 6.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized data types/image 7.png]]
