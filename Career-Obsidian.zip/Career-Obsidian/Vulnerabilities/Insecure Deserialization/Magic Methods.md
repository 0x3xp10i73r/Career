---
title: "Magic Methods"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Vulnerabilities/Insecure Deserialization|Insecure Deserialization]]"
notion-id: 563759b92751828faac381ea62e223f0
---

# Magic Methods

In: [[Career]] / [[Vulnerabilities]] / [[Vulnerabilities/Insecure Deserialization|Insecure Deserialization]]

## Magic Methods

- Special methods that are **invoked automatically** when a particular event occurs — not called manually
- Often indicated by **double underscores** e.g. `__construct()`, `__wakeup()`, `__init__`
- Developers use them to predefine what code runs when certain scenarios happen
- Not a vulnerability on their own — **dangerous only when they handle attacker-controllable data**

---

### Key Magic Methods to Know

| Language | Method | When Invoked |
| --- | --- | --- |
| PHP | `__construct()` | Object is instantiated |
| PHP | `__wakeup()` | Object is deserialized via `unserialize()` |
| Python | `__init__` | Object is instantiated |
| Java | `readObject()` | Object is deserialized via `ObjectInputStream.readObject()` |

---

### Why They Matter in Deserialization

- Some magic methods are **automatically triggered during deserialization**
- PHP's `unserialize()` automatically calls `__wakeup()` on the object
- Java's `ObjectInputStream.readObject()` acts like a constructor — re-initializes the object on deserialization
- Java classes can also declare their **own** `readObject()`:

```java
private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
    // custom deserialization logic
}
```

- This gives the class control over its own deserialization — and gives attackers a **hook to exploit**

> [!tip]
> Magic methods allow data from a serialized object to enter the app's code **before the object is fully deserialized** — this is the starting point for advanced exploits.
>

---

## Injecting Arbitrary Objects

- You're not limited to modifying the object the website gives you — you can **inject a completely different class**
- Deserialization methods **don't check what they're deserializing** — any serializable class available to the app can be passed in
- The unexpected object type may cause an exception — but **the malicious object is already instantiated** by then

---

### How an Attacker Constructs an Exploit

1. Get access to the app's source code
2. Study all available classes
3. Find classes with **deserialization magic methods** (`__wakeup()`, `readObject()`, etc.)
4. Check if those methods **perform dangerous operations on controllable data**
5. Serialize an object of that class and pass it in → magic method fires automatically

---

### Key Takeaway

- The power of object injection is that it lets attackers **influence what code runs** — both during and after deserialization
- The more classes and dependencies an app has, the **bigger the pool of exploitable magic methods**
