---
title: "Lab: Modifying serialized objects"
aliases:
  - "Lab Modifying serialized objects"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Vulnerabilities/Insecure Deserialization|Insecure Deserialization]]"
notion-id: 9b6759b92751834cbc498155693dfd26
---

# Lab: Modifying serialized objects

In: [[Career]] / [[Vulnerabilities]] / [[Vulnerabilities/Insecure Deserialization|Insecure Deserialization]]

This lab uses a serialization-based session mechanism and is vulnerable to privilege escalation as a result. To solve the lab, edit the serialized object in the session cookie to exploit this vulnerability and gain administrative privileges. Then, delete the user carlos.

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized objects/image.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized objects/image 1.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized objects/image 2.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized objects/image 3.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized objects/image 4.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized objects/image 5.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Modifying serialized objects/image 6.png]]
