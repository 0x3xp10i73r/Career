---
title: "Lab: Arbitrary object injection in PHP"
aliases:
  - "Lab Arbitrary object injection in PHP"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Vulnerabilities/Insecure Deserialization|Insecure Deserialization]]"
notion-id: 5b1759b92751837b881b012a7537faef
---

# Lab: Arbitrary object injection in PHP

In: [[Career]] / [[Vulnerabilities]] / [[Vulnerabilities/Insecure Deserialization|Insecure Deserialization]]

This lab uses a serialization-based session mechanism and is vulnerable to arbitrary object injection as a result. To solve the lab, create and inject a malicious serialized object to delete the morale.txt file from Carlos's home directory. You will need to obtain source code access to solve this lab.

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Arbitrary object injection in PHP/image.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Arbitrary object injection in PHP/image 1.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Arbitrary object injection in PHP/image 2.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Arbitrary object injection in PHP/image 3.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Arbitrary object injection in PHP/image 4.png]]

![[attachments/Vulnerabilities/Insecure Deserialization/Lab - Arbitrary object injection in PHP/image 5.png]]
