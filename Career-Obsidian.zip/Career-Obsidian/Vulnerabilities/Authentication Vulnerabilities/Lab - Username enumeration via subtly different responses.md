---
title: "Lab: Username enumeration via subtly different responses"
aliases:
  - "Lab Username enumeration via subtly different resp"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Authentication Vulnerabilities]]"
notion-id: 160759b9275182ee97040180f63e5f70
---

# Lab: Username enumeration via subtly different responses

In: [[Career]] / [[Vulnerabilities]] / [[Authentication Vulnerabilities]]

This lab is subtly vulnerable to username enumeration and password
brute-force attacks. It has an account with a predictable username and
password, which can be found in the following wordlists:

- [Candidate usernames](https://portswigger.net/web-security/authentication/auth-lab-usernames)
- [Candidate passwords](https://portswigger.net/web-security/authentication/auth-lab-passwords)

To solve the lab, enumerate a valid username, brute-force this user's password, then access their account page.

1. Start the sniper attack from the intruder and observe the response

![[attachments/Vulnerabilities/Authentication Vulnerabilities/Lab - Username enumeration via subtly different responses/image.png]]

1. Perform the negative search of the responses for error response `“Invalid username or password.”` from the intruder attack. You’ll see the valid username

![[attachments/Vulnerabilities/Authentication Vulnerabilities/Lab - Username enumeration via subtly different responses/image 1.png]]

1. With valid username start the intruder sniper attack for the password parameter.

![[attachments/Vulnerabilities/Authentication Vulnerabilities/Lab - Username enumeration via subtly different responses/image 2.png]]

![[attachments/Vulnerabilities/Authentication Vulnerabilities/Lab - Username enumeration via subtly different responses/image 3.png]]
