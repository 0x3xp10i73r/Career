---
title: "Username enumeration via different responses"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Authentication Vulnerabilities]]"
notion-id: f98759b927518386b22a8150833aeb76
---

# Username enumeration via different responses

In: [[Career]] / [[Vulnerabilities]] / [[Authentication Vulnerabilities]]

This lab is vulnerable to username enumeration and password
brute-force attacks. It has an account with a predictable username and
password, which can be found in the following wordlists:

- [Candidate usernames](https://portswigger.net/web-security/authentication/auth-lab-usernames)
- [Candidate passwords](https://portswigger.net/web-security/authentication/auth-lab-passwords)

To solve the lab, enumerate a valid username, brute-force this user's password, then access their account page.

1. Brute-force the username with the Sniper attack in the intruder & get the valid Username

![[attachments/Vulnerabilities/Authentication Vulnerabilities/Username enumeration via different responses/image.png]]

1. Now after valid username, brute-force the passwords using the sniper attack.

![[attachments/Vulnerabilities/Authentication Vulnerabilities/Username enumeration via different responses/image 1.png]]

![[attachments/Vulnerabilities/Authentication Vulnerabilities/Username enumeration via different responses/image 2.png]]

![[attachments/Vulnerabilities/Authentication Vulnerabilities/Username enumeration via different responses/image 3.png]]
