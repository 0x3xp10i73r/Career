---
title: "Lab: Username enumeration via response timing"
aliases:
  - "Lab Username enumeration via response timing"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Authentication Vulnerabilities]]"
notion-id: c99759b92751823b804a01455b9e4c9c
---

# Lab: Username enumeration via response timing

In: [[Career]] / [[Vulnerabilities]] / [[Authentication Vulnerabilities]]

This lab is vulnerable to username enumeration using its response times. To solve the lab, enumerate a valid username, brute-force this user's password, then access their account page.

- Your credentials: `wiener:peter`
- [Candidate usernames](https://portswigger.net/web-security/authentication/auth-lab-usernames)
- [Candidate passwords](https://portswigger.net/web-security/authentication/auth-lab-passwords)
