---
title: "Lab: Host header authentication bypass"
aliases:
  - "Lab Host header authentication bypass"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[HTTP Host Header Attacks]]"
notion-id: 531759b927518346a3ac0115a5b60573
---

# Lab: Host header authentication bypass

In: [[Career]] / [[Vulnerabilities]] / [[HTTP Host Header Attacks]]

This lab makes an assumption about the privilege level of the user based on the HTTP Host header.

To solve the lab, access the admin panel and delete the user `carlos`.

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Host header authentication bypass/image.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Host header authentication bypass/image 1.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Host header authentication bypass/image 2.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Host header authentication bypass/image 3.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Host header authentication bypass/image 4.png]]
