---
title: "Lab: Host validation bypass via connection state attack"
aliases:
  - "Lab Host validation bypass via connection state at"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[HTTP Host Header Attacks]]"
notion-id: 11f759b9275183dab4dd01c678c506ee
---

# Lab: Host validation bypass via connection state attack

In: [[Career]] / [[Vulnerabilities]] / [[HTTP Host Header Attacks]]

This lab is vulnerable to routing-based SSRF via the Host header. Although the front-end server may initially appear to perform robust validation of the Host header, it makes assumptions about all requests on a connection based on the first request it receives.

To solve the lab, exploit this behavior to access an internal admin panel located at `192.168.0.1/admin`, then delete the user `carlos`.

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Host validation bypass via connection state attack/image.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Host validation bypass via connection state attack/image 1.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Host validation bypass via connection state attack/image 2.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Host validation bypass via connection state attack/image 3.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Host validation bypass via connection state attack/image 4.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Host validation bypass via connection state attack/image 5.png]]
