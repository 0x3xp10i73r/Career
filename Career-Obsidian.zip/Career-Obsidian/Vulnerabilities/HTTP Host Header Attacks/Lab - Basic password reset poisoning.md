---
title: "Lab: Basic password reset poisoning"
aliases:
  - "Lab Basic password reset poisoning"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[HTTP Host Header Attacks]]"
notion-id: 88c759b927518253a49201a2dbe2ef0a
---

# Lab: Basic password reset poisoning

In: [[Career]] / [[Vulnerabilities]] / [[HTTP Host Header Attacks]]

This lab is vulnerable to password reset poisoning. The user `carlos` will carelessly click on any links in emails that he receives. To solve the lab, log in to Carlos's account.

You can log in to your own account using the following credentials: `wiener:peter`. Any emails sent to this account can be read via the email client on the exploit server.

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Basic password reset poisoning/image.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Basic password reset poisoning/image 1.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Basic password reset poisoning/image 2.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Basic password reset poisoning/image 3.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Basic password reset poisoning/image 4.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Basic password reset poisoning/image 5.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Basic password reset poisoning/image 6.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Basic password reset poisoning/image 7.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Basic password reset poisoning/image 8.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Basic password reset poisoning/image 9.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Basic password reset poisoning/image 10.png]]
