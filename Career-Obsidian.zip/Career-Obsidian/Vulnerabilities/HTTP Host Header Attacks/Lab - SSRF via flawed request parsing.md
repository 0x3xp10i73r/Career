---
title: "Lab: SSRF via flawed request parsing"
aliases:
  - "Lab SSRF via flawed request parsing"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[HTTP Host Header Attacks]]"
notion-id: feb759b927518376b2f70167be896e32
---

# Lab: SSRF via flawed request parsing

In: [[Career]] / [[Vulnerabilities]] / [[HTTP Host Header Attacks]]

This lab is vulnerable to routing-based SSRF due to its flawed parsing of the request's intended host. You can exploit this to access an insecure intranet admin panel located at an internal IP address.

To solve the lab, access the internal admin panel located in the `192.168.0.0/24` range, then delete the user `carlos`.

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - SSRF via flawed request parsing/image.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - SSRF via flawed request parsing/image 1.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - SSRF via flawed request parsing/image 2.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - SSRF via flawed request parsing/image 3.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - SSRF via flawed request parsing/image 4.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - SSRF via flawed request parsing/image 5.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - SSRF via flawed request parsing/image 6.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - SSRF via flawed request parsing/image 7.png]]
