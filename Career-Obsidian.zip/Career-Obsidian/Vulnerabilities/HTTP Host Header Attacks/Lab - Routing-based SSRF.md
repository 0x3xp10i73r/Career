---
title: "Lab: Routing-based SSRF"
aliases:
  - "Lab Routing-based SSRF"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[HTTP Host Header Attacks]]"
notion-id: aa7759b9275183bf987581033ebe2991
---

# Lab: Routing-based SSRF

In: [[Career]] / [[Vulnerabilities]] / [[HTTP Host Header Attacks]]

This lab is vulnerable to routing-based SSRF via the Host header. You can exploit this to access an insecure intranet admin panel located on an internal IP address.

To solve the lab, access the internal admin panel located in the `192.168.0.0/24` range, then delete the user `carlos`.

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Routing-based SSRF/image.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Routing-based SSRF/image 1.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Routing-based SSRF/image 2.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Routing-based SSRF/image 3.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Routing-based SSRF/image 4.png]]

![[attachments/Vulnerabilities/HTTP Host Header Attacks/Lab - Routing-based SSRF/image 5.png]]
