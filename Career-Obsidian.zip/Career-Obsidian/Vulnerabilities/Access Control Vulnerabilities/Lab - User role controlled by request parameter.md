---
title: "Lab: User role controlled by request parameter"
aliases:
  - "Lab User role controlled by request parameter"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Access Control Vulnerabilities]]"
notion-id: 522759b92751831b841b815e614b41d0
---

# Lab: User role controlled by request parameter

In: [[Career]] / [[Vulnerabilities]] / [[Access Control Vulnerabilities]]

This lab has an admin panel at /admin, which identifies administrators using a forgeable cookie.

Solve the lab by accessing the admin panel and using it to delete the user carlos.

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User role controlled by request parameter/image.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User role controlled by request parameter/image 1.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User role controlled by request parameter/image 2.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User role controlled by request parameter/image 3.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User role controlled by request parameter/image 4.png]]
