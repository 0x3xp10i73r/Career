---
title: "Lab: User ID controlled by request parameter with data leakage in redirect"
aliases:
  - "Lab User ID controlled by request parameter with d"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Access Control Vulnerabilities]]"
notion-id: 8ba759b92751822387ea8117f89cdc5e
---

# Lab: User ID controlled by request parameter with data leakage in redirect

In: [[Career]] / [[Vulnerabilities]] / [[Access Control Vulnerabilities]]

This lab contains an access control vulnerability where sensitive information is leaked in the body of a redirect response.

To solve the lab, obtain the API key for the user carlos and submit it as the solution.

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter with data leakage in redirect/image.png]]
