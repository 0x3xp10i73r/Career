---
title: "Lab: Multi-step process with no access control on one step (Pending)"
aliases:
  - "Lab Multi-step process with no access control on o"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Access Control Vulnerabilities]]"
notion-id: 9ae759b927518224b4a6016414c184a1
---

# Lab: Multi-step process with no access control on one step (Pending)

In: [[Career]] / [[Vulnerabilities]] / [[Access Control Vulnerabilities]]

This lab has an admin panel with a flawed multi-step process for changing a user's role. You can familiarize yourself with the admin panel by logging in using the credentials administrator: admin.

To solve the lab, log in using the credentials wiener: peter and exploit the flawed access controls to promote yourself to become an administrator.

1. Log in using the admin credentials.
2. Browse to the admin panel, promote `carlos`, and send the confirmation HTTP request to Burp Repeater.
3. Open a private/incognito browser window, and log in with the non-admin credentials.
4. Copy the non-admin user's session cookie into
the existing Repeater request, change the username to yours, and replay
it.
