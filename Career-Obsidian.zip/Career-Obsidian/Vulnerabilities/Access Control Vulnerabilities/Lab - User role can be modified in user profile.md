---
title: "Lab: User role can be modified in user profile"
aliases:
  - "Lab User role can be modified in user profile"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Access Control Vulnerabilities]]"
notion-id: 8d8759b92751834984f80112396d2d7e
---

# Lab: User role can be modified in user profile

In: [[Career]] / [[Vulnerabilities]] / [[Access Control Vulnerabilities]]

This lab has an admin panel at /admin. It's only accessible to logged-in users with a roleid of 2.

Solve the lab by accessing the admin panel and using it to delete the user carlos.

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User role can be modified in user profile/image.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User role can be modified in user profile/image 1.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User role can be modified in user profile/image 2.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User role can be modified in user profile/image 3.png]]
