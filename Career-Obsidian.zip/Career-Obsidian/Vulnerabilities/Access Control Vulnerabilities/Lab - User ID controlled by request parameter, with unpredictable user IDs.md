---
title: "Lab: User ID controlled by request parameter, with unpredictable user IDs"
aliases:
  - "Lab User ID controlled by request parameter, with"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Access Control Vulnerabilities]]"
notion-id: 926759b9275182c4b56281a897ae4e0d
---

# Lab: User ID controlled by request parameter, with unpredictable user IDs

In: [[Career]] / [[Vulnerabilities]] / [[Access Control Vulnerabilities]]

This lab has a horizontal privilege escalation vulnerability on the user account page, but identifies users with GUIDs.

To solve the lab, find the GUID for carlos, then submit his API key as the solution.

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter, with unpredictable user IDs/image.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter, with unpredictable user IDs/image 1.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter, with unpredictable user IDs/image 2.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter, with unpredictable user IDs/image 3.png]]
