---
title: "Lab: User ID controlled by request parameter with password disclosure"
aliases:
  - "Lab User ID controlled by request parameter with p"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Access Control Vulnerabilities]]"
notion-id: da6759b9275183519c2281836eed90ed
---

# Lab: User ID controlled by request parameter with password disclosure

In: [[Career]] / [[Vulnerabilities]] / [[Access Control Vulnerabilities]]

This lab has user account page that contains the current user's existing password, prefilled in a masked input.

To solve the lab, retrieve the administrator's password, then use it to delete the user carlos.

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter with password disclosure/image.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter with password disclosure/image 1.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter with password disclosure/image 2.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter with password disclosure/image 3.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter with password disclosure/image 4.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter with password disclosure/image 5.png]]
