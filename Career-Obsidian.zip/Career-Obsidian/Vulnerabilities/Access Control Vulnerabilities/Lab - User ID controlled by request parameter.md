---
title: "Lab: User ID controlled by request parameter"
aliases:
  - "Lab User ID controlled by request parameter"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Access Control Vulnerabilities]]"
notion-id: ff8759b927518279b5fc8139d81c2224
---

# Lab: User ID controlled by request parameter

In: [[Career]] / [[Vulnerabilities]] / [[Access Control Vulnerabilities]]

This lab has a horizontal privilege escalation vulnerability on the user account page.

To solve the lab, obtain the API key for the user carlos and submit it as the solution.

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter/image.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter/image 1.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - User ID controlled by request parameter/image 2.png]]
