---
title: "Lab: URL-based access control can be circumvented"
aliases:
  - "Lab URL-based access control can be circumvented"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Access Control Vulnerabilities]]"
notion-id: 180759b92751823886ff812822fc4b0d
---

# Lab: URL-based access control can be circumvented

In: [[Career]] / [[Vulnerabilities]] / [[Access Control Vulnerabilities]]

This website has an unauthenticated admin panel at /admin, but a front-end system has been configured to block external access to that path. However, the back-end application is built on a framework that supports the X-Original-URL header.

To solve the lab, access the admin panel and delete the user carlos.

## Some Notes

#### X-Original-URL in VAPT (Vulnerability Assessment & Penetration Testing)

- **Vulnerability Class**: Improper Access Control / Request Smuggling / Header Injection
- **Testing Methodology**:
    1. Intercept legitimate request using proxy (Burp Suite, ZAP)
    2. Add/inject header: `X-Original-URL: /restricted/path`
    3. Keep original request path benign (e.g., GET /)
    4. Send and observe if response corresponds to the injected path
    5. Test variations: relative paths, encoded values (%2fadmin), full URLs
- **Example Exploit Request**:

    ```
    GET / HTTP/1.1
    Host: target.com
    X-Original-URL: /admin/dashboard
    
    ```


![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - URL-based access control can be circumvented/image.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - URL-based access control can be circumvented/image 1.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - URL-based access control can be circumvented/image 2.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - URL-based access control can be circumvented/image 3.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - URL-based access control can be circumvented/image 4.png]]
