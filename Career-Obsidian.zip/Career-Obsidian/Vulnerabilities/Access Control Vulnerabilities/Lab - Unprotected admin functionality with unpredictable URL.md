---
title: "Lab: Unprotected admin functionality with unpredictable URL"
aliases:
  - "Lab Unprotected admin functionality with unpredict"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Access Control Vulnerabilities]]"
notion-id: 829759b92751838aad1f019fdfcfd6a8
---

# Lab: Unprotected admin functionality with unpredictable URL

In: [[Career]] / [[Vulnerabilities]] / [[Access Control Vulnerabilities]]

This lab has an unprotected admin panel. It's located at an unpredictable location, but the location is disclosed somewhere in the application.

Solve the lab by accessing the admin panel, and using it to delete the user carlos.

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - Unprotected admin functionality with unpredictable URL/image.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - Unprotected admin functionality with unpredictable URL/image 1.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - Unprotected admin functionality with unpredictable URL/image 2.png]]
