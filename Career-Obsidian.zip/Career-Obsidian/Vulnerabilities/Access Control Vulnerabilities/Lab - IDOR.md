---
title: "Lab: IDOR"
aliases:
  - "Lab IDOR"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Access Control Vulnerabilities]]"
notion-id: 622759b927518221bdbb01262c25c76d
---

# Lab: IDOR

In: [[Career]] / [[Vulnerabilities]] / [[Access Control Vulnerabilities]]

This lab stores user chat logs directly on the server's file system, and retrieves them using static URLs.

Solve the lab by finding the password for the user carlos, and logging into their account.

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - IDOR/image.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - IDOR/image 1.png]]

![[attachments/Vulnerabilities/Access Control Vulnerabilities/Lab - IDOR/image 2.png]]
