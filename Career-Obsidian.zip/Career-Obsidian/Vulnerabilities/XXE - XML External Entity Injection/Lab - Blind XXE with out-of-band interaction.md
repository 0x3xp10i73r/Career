---
title: "Lab: Blind XXE with out-of-band interaction"
aliases:
  - "Lab Blind XXE with out-of-band interaction"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[XXE - XML External Entity Injection]]"
notion-id: e32759b92751837683b3811bab8f4930
---

# Lab: Blind XXE with out-of-band interaction

In: [[Career]] / [[Vulnerabilities]] / [[XXE - XML External Entity Injection]]

This lab has a "Check stock" feature that parses XML input but does not display the result.

You can detect the blind XXE vulnerability by triggering out-of-band interactions with an external domain.

To solve the lab, use an external entity to make the XML parser issue a DNS lookup and HTTP request to Burp Collaborator.

### Note

To prevent the Academy platform being used to attack third parties, our firewall blocks interactions between the labs and arbitrary external systems. To solve the lab, you must use Burp Collaborator's default public server.

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction/image.png]]

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction/image 1.png]]

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction/image 2.png]]

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction/image 3.png]]

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction/image 4.png]]

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction/image 5.png]]

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction/image 6.png]]
