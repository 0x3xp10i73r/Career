---
title: "Lab: Blind XXE with out-of-band interaction via XML parameter entities"
aliases:
  - "Lab Blind XXE with out-of-band interaction via XML"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[XXE - XML External Entity Injection]]"
notion-id: c29759b92751827b862e01b42cd3f94b
---

# Lab: Blind XXE with out-of-band interaction via XML parameter entities

In: [[Career]] / [[Vulnerabilities]] / [[XXE - XML External Entity Injection]]

This lab has a "Check stock" feature that parses XML input, but does not display any unexpected values, and blocks requests containing regular external entities. To solve the lab, use a parameter entity to make the XML parser issue a DNS lookup and HTTP request to Burp Collaborator.

`Note`

To prevent the Academy platform being used to attack third parties, our firewall blocks interactions between the labs and arbitrary external systems. To solve the lab, you must use Burp Collaborator's default public server.

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction via XML parameter entities/image.png]]

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction via XML parameter entities/image 1.png]]

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction via XML parameter entities/image 2.png]]

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction via XML parameter entities/image 3.png]]

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction via XML parameter entities/image 4.png]]

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction via XML parameter entities/image 5.png]]

![[attachments/Vulnerabilities/XXE - XML External Entity Injection/Lab - Blind XXE with out-of-band interaction via XML parameter entities/image 6.png]]
