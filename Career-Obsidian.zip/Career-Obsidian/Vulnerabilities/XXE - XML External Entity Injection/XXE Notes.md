---
title: "XXE Notes"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[XXE - XML External Entity Injection]]"
notion-id: fe6759b92751821f84d9812c7735ef9c
---

# XXE Notes

In: [[Career]] / [[Vulnerabilities]] / [[XXE - XML External Entity Injection]]

**XML & XXE Key Concepts**

- **XML (Extensible Markup Language)**
    - Designed for storing/transporting data.
    - Uses a custom tree structure of tags (unlike HTML's fixed tags).
    - Was popular for data transport, now largely replaced by JSON.
- **XML Entities**
    - Represent data without using the data itself directly.
    - **Built-in entities** exist for special characters (e.g., `&lt;` for `<`, `&gt;` for `>`).
- **Document Type Definition (DTD)**
    - Defines an XML document’s structure, data types, and other rules.
    - Located within the `<!DOCTYPE>` element.
    - Can be:
        - **Internal:** Fully within the XML document.
        - **External:** Loaded from an outside source.
        - **Hybrid:** A mix of internal and external.
- **Custom XML Entities**
    - Defined by users inside the DTD.
    - Example:

        ```xml
        <!DOCTYPE example [ <!ENTITY myentity "Some value" > ]>
        ```

    - Using `&myentity;` in the document replaces it with `"Some value"`.
- **XML External Entities (XXE)**
    - A custom entity that loads its value from an **external source**.
    - Uses the `SYSTEM` keyword and a URL.
    - Example:

        ```xml
        <!DOCTYPE example [ <!ENTITY ext SYSTEM "<http://example.com/file>" > ]>
        ```

    - Can read local files using `file://` (e.g., `file:///etc/passwd`).
    - **Primary mechanism for XXE attacks**—when external entity input is parsed, it can lead to data exposure, SSRF, or DoS.


**Types of XXE Attacks**

- **File Retrieval**

    An external entity is defined to read a local file (e.g., `/etc/passwd`), and the content is returned in the application’s response.

- **SSRF (Server-Side Request Forgery)**

    An external entity is defined with a URL pointing to an internal system, forcing the XML parser to make requests to internal or back-end services.

- **Blind XXE – Out-of-Band Data Exfiltration**

    Sensitive data is sent from the application server to an external system controlled by the attacker, often using parameter entities and external DTDs.

- **Blind XXE – Data Retrieval via Error Messages**

    An attacker triggers an XML parsing error that includes sensitive data within the error message returned by the application.
