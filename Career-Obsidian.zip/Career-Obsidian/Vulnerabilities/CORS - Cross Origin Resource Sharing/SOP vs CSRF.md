---
title: "SOP vs CSRF"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[CORS - Cross Origin Resource Sharing]]"
notion-id: 70b759b927518331bc370155624b6810
---

# SOP vs CSRF

In: [[Career]] / [[Vulnerabilities]] / [[CORS - Cross Origin Resource Sharing]]

## SOP vs CSRF: Understanding Why Same-Origin Policy Does Not Prevent Cross-Site Request Forgery

### Executive Summary

The Same-Origin Policy (SOP) provides **no protection** against Cross-Site Request Forgery (CSRF) attacks. This fundamental misunderstanding persists because both mechanisms involve cross-origin interactions, but they address fundamentally different security concerns: **data confidentiality** (SOP) versus **request authenticity** (CSRF).

### Core Distinction

| Dimension | Same-Origin Policy (SOP) | Cross-Site Request Forgery (CSRF) |
| --- | --- | --- |
| **Primary Concern** | Data confidentiality | Request authenticity |
| **Protection Scope** | Prevents reading cross-origin responses | Prevents unauthorized actions |
| **Attack Objective** | Information theft | Action execution |
| **Defense Timing** | Post-response validation | Pre-request authentication |
| **Browser Role** | Enforces access control | Merely follows HTTP standards |

### Technical Analysis: Why SOP Fails Against CSRF

#### 1. **Fundamental Design Purpose**

- **SOP**: Created to prevent one origin from **reading** another origin's data
- **CSRF**: Exploits the browser's automatic credential transmission
- **Critical Insight**: SOP regulates **data access**, not **request transmission**

#### 2. **Cookie Transmission Exception**

Cookies operate under special rules that bypass SOP's restrictions:

```text
// Browser automatically includes cookies for same-site requests
GET /api/user-data HTTP/1.1
Host: bank.com
Cookie: session_id=abc123; user_token=xyz789  // Auto-included
Origin: <https://evil.com>

```

#### 3. **Request/Response Lifecycle Mismatch**

```
CSRF Attack Timeline:
[evil.com] --(1) Forged Request--> [bank.com] --(2) Processes--> [Action Executed]
                                      |
                                      V
                             [Sends Response] --(3)--> [evil.com]
                                                           |
                                                           V
                                                (4) SOP Blocks Reading

```

**Key Observation**: The attack succeeds at step 2, while SOP only intervenes at step 4.

#### 4. **Simple Request Vulnerability**

Simple HTTP requests bypass CORS preflight checks and SOP doesn't restrict their transmission:

```html
// These trigger CSRF without SOP interference:
<img src="<https://bank.com/logout>">
<form action="<https://bank.com/transfer>" method="POST">
<iframe src="<https://bank.com/action>">

```

### Practical Demonstration

#### Browser Console Test Cases

```javascript
// Test 1: SOP blocks cross-origin data reading
fetch('<https://api.bank.com/balance>')
  .then(response => response.json())  // ❌ Blocked by SOP
  .catch(error => console.log('SOP enforced:', error));

// Test 2: CSRF action succeeds despite SOP
const form = document.createElement('form');
form.method = 'POST';
form.action = '<https://bank.com/transfer>';
form.innerHTML = `
  <input type="hidden" name="amount" value="10000">
  <input type="hidden" name="account" value="attacker">
`;
document.body.appendChild(form);
form.submit();  // ✅ Executes despite SOP

```

### Security Boundary Analysis

#### SOP Security Boundary

```bash
┌─────────────────────────────────────┐
│         Client-Side Boundary        │
│  Prevents: Cross-origin data access │
│  Allows: Cross-origin requests      │
└─────────────────────────────────────┘

```

#### CSRF Security Boundary

```bash
┌─────────────────────────────────────┐
│         Server-Side Boundary        │
│  Prevents: Unauthenticated actions  │
│  Requires: Request validation       │
└─────────────────────────────────────┘

```

### Real-World Attack Vector

**Scenario**: Banking application CSRF exploit

```html
<!-- Malicious page hosted on evil.com -->
<!DOCTYPE html>
<html>
<body onload="document.forms[0].submit()">
  <form action="<https://bank.com/api/transfer>" method="POST">
    <input type="hidden" name="from" value="user_account">
    <input type="hidden" name="to" value="attacker_account">
    <input type="hidden" name="amount" value="5000">
    <input type="hidden" name="currency" value="USD">
  </form>
</body>
</html>

```

**Attack Flow Analysis**:

1. ✅ User authenticated with [bank.com](http://bank.com/) (session cookie present)
2. ✅ User visits [evil.com](http://evil.com/) (malicious page loads)
3. ✅ Form auto-submits to [bank.com](http://bank.com/)
4. ✅ Browser automatically includes session cookies
5. ✅ Bank processes request (no CSRF protection)
6. ❌ SOP irrelevant: Attack succeeds before response phase

### Conclusion

The Same-Origin Policy and CSRF protection address orthogonal security concerns. Understanding this distinction is crucial for implementing effective web application security. While SOP protects user data from unauthorized reading, CSRF protections ensure that actions are performed only with user intent. Both are essential components of a comprehensive security strategy, but neither can substitute for the other.

**Key Takeaway**: SOP ≠ CSRF protection. Always implement explicit CSRF defenses regardless of your CORS or SOP configuration.
