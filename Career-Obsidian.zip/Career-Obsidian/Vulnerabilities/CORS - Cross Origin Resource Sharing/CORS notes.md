---
title: "CORS notes"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[CORS - Cross Origin Resource Sharing]]"
notion-id: 7cf759b927518319a905013e2fc3067f
---

# CORS notes

In: [[Career]] / [[Vulnerabilities]] / [[CORS - Cross Origin Resource Sharing]]

## CORS & Same-Origin Policy Notes

### **Same-Origin Policy (SOP)**

- **What it is**: Browser security rule that blocks websites from accessing resources from *different* domains
- **Why it exists**: Prevents malicious sites from stealing your data from other websites
- **What it allows**: You can *send* requests to other domains, but can't *read* the responses
- **Example**: `example.com` cannot read data from `bank.com`

### **CORS (Cross-Origin Resource Sharing)**

- **What it is**: A way to *safely relax* the Same-Origin Policy
- **How it works**: Uses special HTTP headers to tell browsers which external domains are allowed
- **Why needed**: Modern websites often need to work with subdomains or trusted partners

### **Key Points**

✅ **CORS is NOT security against CSRF attacks**

✅ **CORS = Controlled way to allow cross-origin access**

✅ **Uses HTTP headers to define trusted websites**

⚠️ **Bad CORS setup = Security vulnerabilities**

### **Common Problems**

- Websites being **too lenient** with CORS rules
- Mistakes in configuration
- "Allow everything" policies that hackers can exploit

### **Simple Analogy**

- **SOP**: "You can't talk to strangers"
- **CORS**: "Here's a list of approved strangers you can talk to"
- **Bad CORS**: "You can talk to anyone" ← Dangerous!

### **Takeaway**

CORS is necessary for modern web apps but must be configured carefully. Poor setup can let attackers steal data across domains.
