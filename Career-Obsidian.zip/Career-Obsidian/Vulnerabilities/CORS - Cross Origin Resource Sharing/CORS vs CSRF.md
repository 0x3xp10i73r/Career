---
title: "CORS vs CSRF"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[CORS - Cross Origin Resource Sharing]]"
notion-id: b8a759b9275182229bf001edff59bc22
---

# CORS vs CSRF

In: [[Career]] / [[Vulnerabilities]] / [[CORS - Cross Origin Resource Sharing]]

## **The ONE-SENTENCE Difference:**

**CORS is about READING data you shouldn't see. CSRF is about DOING things you shouldn't do.**

---

## **Think of Them as Different Security Guards:**

### **CORS Guard (At the Data Door)**

- **Job:** "Who can READ the response from our server?"
- **Question:** "Can Site A read data from Site B?"
- **Analogy:** A museum guard checking if you have permission to **read/see** the exhibits

### **CSRF Guard (At the Action Door)**

- **Job:** "Who can PERFORM actions on our server?"
- **Question:** "Can Site A make users do things on Site B?"
- **Analogy:** A bank teller verifying if a transaction request is actually **from you**

---

## **Real-Life Examples to End Confusion:**

### **Example 1: Social Media**

**CORS Scenario:**

- You're on `evil.com`
- It tries to fetch your Facebook messages from `facebook.com/api/messages`
- **CORS says:** "No, [evil.com](http://evil.com/) can't READ Facebook's response"

**CSRF Scenario:**

- You're on `evil.com`
- It has a hidden form that posts "Delete all posts" to `facebook.com/delete`
- **CSRF happens:** Your browser sends your Facebook cookie, Facebook deletes posts
- **CORS doesn't help here** because Facebook received a valid request!

---

## **The Request/Response Cycle:**

```
YOU on evil.com
     │
     ▼
evil.com → [REQUEST to bank.com] → Bank Server
     │         (with your cookies)        │
     │                                    ▼
     │                            [PROCESSES request]
     │                                    │
     │                                    ▼
     └──── [RESPONSE from bank.com] ←── [SEND response]
              CORS checks here!           │
                                            │
                                   CSRF checks here!
                                    (when request arrived)

```

**Notice:**

- **CSRF** checked when request **ARRIVES** at bank
- **CORS** checked when response **LEAVES** bank

---

## **Key Memory Tricks:**

### **1. Direction Matters:**

- **CORS:** About the **response** (outgoing from server)
- **CSRF:** About the **request** (incoming to server)

### **2. Think "Steal" vs "Forge":**

- **CORS prevents:** "I'll steal their data"
- **CSRF prevents:** "I'll forge their signature"

### **3. Simple Questions:**

**Ask: "Who can see this data?"** → That's **CORSAsk: "Who can make this request?"** → That's **CSRF**

---

## **Quick Test for Understanding:**

**Scenario:** `evil.com` wants to transfer money from your bank account

**What happens:**

1. `evil.com` makes request to `bank.com/transfer-money`
2. Your browser automatically includes your bank cookie ✅
3. Bank receives request with valid cookie
4. **CSRF check:** Is this a legit request? (Needs token!)
5. Bank processes transfer (if no CSRF protection)
6. Bank sends back "Transfer successful" response
7. **CORS check:** Can `evil.com` read this response? (Probably not)

**Key insight:** The **damage is done at step 5** (before CORS even matters)!

---

## **Why People Get Confused:**

### **Common Mix-up:**

"Wait, if CORS blocks cross-origin requests, doesn't it block CSRF?"
**NO!** CORS only blocks reading responses, not sending requests.

### **The Trap:**

People think: `evil.com → bank.com` = CORS blocks it

Reality: `evil.com → [request] → bank.com` = CORS doesn't block sending

Only: `bank.com → [response] → evil.com` = CORS blocks reading

---

## **Easy-to-Remember Chart:**

| Think about... | CORS | CSRF |
| --- | --- | --- |
| **Problem** | Data theft | Unauthorized actions |
| **When** | Reading response | Making request |
| **Who decides** | Server (with headers) | Server (with tokens) |
| **Browser's role** | Enforces CORS headers | Just follows rules |
| **Analogy** | Can't read someone's diary | Can't sign someone's name |
| **Without it...** | Data leaks | Actions happen |
| **With it...** | Safe APIs | Safe actions |

---

## **Final Clear Explanation:**

Imagine you have a **house (website)**:

**CORS** is like:

- Rules about who can **look into your windows** (read your data)
- You put signs: "Only family can look inside"
- Strangers can still knock on your door (send requests)

**CSRF** is like:

- Rules about who can **use your keys** (perform actions)
- You verify signatures before accepting any delivery orders
- Prevents someone from using your key without permission

**The confusion happens because:**

- Both involve "cross-site" something
- Both are about security
- But one is about **seeing**, the other is about **doing**

---

## **Your Cheat Sheet:**

When confused, ask:

1. **"Is this about SEEING/READING data?"** → **CORS**
2. **"Is this about MAKING/DOING something?"** → **CSRF**

**Example:**

- "Can `evil.com` read my Gmail?" → **CORS**
- "Can `evil.com` send email from my Gmail?" → **CSRF**

You'll never mix them up again!
