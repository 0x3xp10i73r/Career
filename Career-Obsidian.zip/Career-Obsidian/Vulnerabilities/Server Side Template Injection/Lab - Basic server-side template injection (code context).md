---
title: "Lab: Basic server-side template injection (code context)"
aliases:
  - "Lab Basic server-side template injection (code con"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Server Side Template Injection]]"
notion-id: 40f759b9275183ee876d81bfe616c8a8
---

# Lab: Basic server-side template injection (code context)

In: [[Career]] / [[Vulnerabilities]] / [[Server Side Template Injection]]

This lab is vulnerable to server-side template injection due to the way it unsafely uses a Tornado template. To solve the lab, review the Tornado documentation to discover how to execute arbitrary code, then delete the morale.txt file from Carlos's home directory.

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/Server Side Template Injection/Lab - Basic server-side template injection (code context)/image.png]]

![[attachments/Vulnerabilities/Server Side Template Injection/Lab - Basic server-side template injection (code context)/image 1.png]]

![[attachments/Vulnerabilities/Server Side Template Injection/Lab - Basic server-side template injection (code context)/image 2.png]]
