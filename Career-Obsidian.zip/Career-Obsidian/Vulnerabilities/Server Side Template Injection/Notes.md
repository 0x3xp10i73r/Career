---
title: "Notes"
aliases:
  - "Server Side Template Injection - Notes"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Server Side Template Injection]]"
notion-id: 75a759b9275182aca3c5812b097133cc
---

# Notes

In: [[Career]] / [[Vulnerabilities]] / [[Server Side Template Injection]]

## Server-Side Template Injection (SSTI)

### What is Server-Side Template Injection?

- **Server-Side Template Injection (SSTI)** occurs when **user input is inserted directly into a template** and executed by the **template engine on the server**.
- Attackers inject **template syntax** that gets **evaluated server-side**.
- This allows attackers to **execute template directives or code**.

#### Key Idea

Instead of passing user input **as data**, the application inserts it **into the template itself**.

---

## How Template Engines Work

Template engines generate dynamic web pages by combining:

- **Static templates** (HTML structure)
- **Dynamic data** (user or application data)

Example template:

```
Hello {{username}}
```

The template engine replaces `{{username}}` with actual user data.

---

## Safe Template Example

```
$output = $twig->render(
"Dear {first_name},",
array("first_name" => $user.first_name)
);
```

Why this is safe:

- User input is passed **as data**
- It **does not modify the template structure**

---

## Vulnerable Template Example

```
$output = $twig->render("Dear " . $_GET['name']);
```

Here:

- User input becomes **part of the template**
- Template syntax can be injected

Example attack:

```
http://vulnerable-website.com/?name={{malicious-code}}
```

The injected template syntax gets **executed by the server**.

---

## Why SSTI is Dangerous

SSTI is often **more severe than client-side injection**.

Possible impacts include:

- **Remote Code Execution (RCE)**
- **Access to server files**
- **Sensitive data exposure**
- **Internal network access**
- **Complete server takeover**

---

## How SSTI Vulnerabilities Arise

SSTI occurs when:

- User input is **concatenated into templates**
- Instead of being **passed as data**

Common causes:

- Poor template design
- Developer misunderstanding of template security
- Allowing users to **edit templates directly**

---

## 1. Detect SSTI

SSTI vulnerabilities are often **not obvious**.

Initial testing involves **template fuzzing**.

#### Common SSTI Fuzz Payload

```
${{<%[%'"}}%\
```

If the server throws an **exception or unusual response**, it may indicate **template evaluation**.

---

## SSTI Contexts

SSTI can occur in **two contexts**:

1. Plaintext context
2. Code context

Each requires **different detection techniques**.

---

## Plaintext Context

User input is inserted **directly into template output**.

Example template:

```
render('Hello ' + username)
```

Example request:

```
http://vulnerable-website.com/?username=Carlos
```

Output:

```
Hello Carlos
```

---

## Detecting SSTI in Plaintext Context

Inject **mathematical expressions**.

Example payload:

```
${7*7}
```

Request:

```
http://vulnerable-website.com/?username=${7*7}
```

If the response is:

```
Hello 49
```

This confirms:

- The template engine **executed the expression**
- **SSTI vulnerability exists**

---

## Code Context

Sometimes user input is inserted **inside a template expression**.

Example:

```
greeting = getQueryParameter('greeting')
engine.render("Hello {{"+greeting+"}}", data)
```

Example request:

```
http://vulnerable-website.com/?greeting=data.username
```

Output:

```
Hello Carlos
```

---

## Detecting SSTI in Code Context

#### Step 1: Test for XSS

Inject HTML:

```
http://vulnerable-website.com/?greeti*ng=data*.username<tag>
```

Possible results:

- Encoded HTML
- Blank output
- Error

---

#### Step 2: Break Template Expression

Payload:

```
http://vulnerable-website.com/?greeting=data.username}}<tag>
```

If output becomes:

```
Hello Carlos<tag>
```

This indicates:

- Template expression was **broken**
- SSTI vulnerability exists

---

## 2. Identify the Template Engine

After detecting SSTI, determine **which template engine is used**.

Examples of engines:

- Jinja2
- Twig
- Freemarker
- ERB
- Velocity
- Smarty

---

## Using Error Messages

Submitting invalid syntax may reveal the engine.

Example payload:

```
<%=foobar%>
```

Example error:

```
undefined local variable or method `foobar'
```

This indicates **Ruby ERB template engine**.

---

## Using Mathematical Expressions

Test payloads from different template engines.

Example payloads:

```
{{7*7}}
${7*7}
<%= 7*7 %>
```

Observe which syntax evaluates correctly.

---

## Example Engine Difference

Payload:

```
{{7*'7'}}
```

Different engines behave differently:

| Engine | Result |
| --- | --- |
| Twig | 49 |
| Jinja2 | 7777777 |

This helps identify the engine.

---

## 3. Exploit the Vulnerability

Once the engine is identified, attackers can attempt:

- File access
- Command execution
- Server enumeration
- Data extraction

In many cases SSTI can lead to:

- **Remote Code Execution**

---
