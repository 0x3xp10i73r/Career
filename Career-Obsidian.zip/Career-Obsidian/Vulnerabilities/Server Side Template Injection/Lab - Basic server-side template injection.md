---
title: "Lab: Basic server-side template injection"
aliases:
  - "Lab Basic server-side template injection"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Server Side Template Injection]]"
notion-id: 9a3759b92751823cbf0a0160f1b49ff9
---

# Lab: Basic server-side template injection

In: [[Career]] / [[Vulnerabilities]] / [[Server Side Template Injection]]

This lab is vulnerable to server-side template injection due to the way it unsafely uses a Tornado template. To solve the lab, review the Tornado documentation to discover how to execute arbitrary code, then delete the morale.txt file from Carlos's home directory.

You can log in to your own account using the following credentials: wiener:peter

![[attachments/Vulnerabilities/Server Side Template Injection/Lab - Basic server-side template injection/image.png]]

![[attachments/Vulnerabilities/Server Side Template Injection/Lab - Basic server-side template injection/image 1.png]]

![[attachments/Vulnerabilities/Server Side Template Injection/Lab - Basic server-side template injection/image 2.png]]

![[attachments/Vulnerabilities/Server Side Template Injection/Lab - Basic server-side template injection/image 3.png]]
