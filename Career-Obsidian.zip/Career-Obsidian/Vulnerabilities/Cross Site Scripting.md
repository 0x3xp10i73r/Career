---
title: "Cross Site Scripting"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: d02759b9275182cf9973016b283a3106
---

# Cross Site Scripting

In: [[Career]] / [[Vulnerabilities]]

## Contents

**[[Cross Site Scripting/Lab - Reflected XSS into HTML context with nothing encoded|Lab: Reflected XSS into HTML context with nothing encoded]]**

**[[Cross Site Scripting/Lab - Stored XSS into HTML context with nothing encoded|Lab: Stored XSS into HTML context with nothing encoded]]**

[[Cross Site Scripting/Lab - DOM XSS in document.write sink using source location.search|Lab: DOM XSS in document.write sink using source location.search]]

**[[Cross Site Scripting/Lab - DOM XSS in innerHTML sink using source location.search|Lab: DOM XSS in `innerHTML` sink using source `location.search`]]**

**[[Cross Site Scripting/Lab - DOM XSS in jQuery anchor href attribute sink using location.search source|Lab: DOM XSS in jQuery anchor `href` attribute sink using `location.search` source]]**

**[[Lab - DOM XSS in jQuery selector sink using a hashchange event (pending)|Lab: DOM XSS in jQuery selector sink using a hashchange event (pending)]]**

**[[Cross Site Scripting/Lab - Reflected XSS into attribute with angle brackets HTML-encoded|Lab: Reflected XSS into attribute with angle brackets HTML-encoded]]**

**[[Cross Site Scripting/Lab - Stored XSS into anchor href attribute with double quotes HTML-encoded|Lab: Stored XSS into anchor `href` attribute with double quotes HTML-encoded]]**

**[[Cross Site Scripting/Lab - Reflected XSS into a JavaScript string with angle brackets HTML encoded|Lab: Reflected XSS into a JavaScript string with angle brackets HTML encoded]]**

**[[Lab - DOM XSS in AngularJS expression with angle brackets and double quotes HTML-encoded|Lab: DOM XSS in AngularJS expression with angle brackets and double quotes HTML-encoded]]**
