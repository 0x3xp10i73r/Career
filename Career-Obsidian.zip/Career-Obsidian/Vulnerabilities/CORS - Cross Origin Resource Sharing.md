---
title: "CORS - Cross Origin Resource Sharing"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: 63a759b9275182499525815d877a87df
---

# CORS - Cross Origin Resource Sharing

In: [[Career]] / [[Vulnerabilities]]

## Contents

[[CORS notes]]

[[CORS vs CSRF]]

[[SOP vs CSRF]]

**[[Lab - CORS vulnerability with basic origin reflection|Lab: CORS vulnerability with basic origin reflection]]**

**[[Lab - CORS vulnerability with trusted null origin|Lab: CORS vulnerability with trusted null origin]]**

**[[Lab - CORS vulnerability with trusted insecure protocols (pending)|Lab: CORS vulnerability with trusted insecure protocols (pending)]]**

[[CORS Prevention]]
