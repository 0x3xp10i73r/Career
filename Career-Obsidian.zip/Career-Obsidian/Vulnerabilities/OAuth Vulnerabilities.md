---
title: "OAuth Vulnerabilities"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: c3d759b927518213a67a81927da75b86
---

# OAuth Vulnerabilities

In: [[Career]] / [[Vulnerabilities]]

## Contents

[[A Little about Oauth]]

[[OAuth Grant Types]]

[[OAuth Authentication]]

**[[Lab - Authentication bypass via OAuth implicit flow|Lab: Authentication bypass via OAuth implicit flow]]**

**[[Lab - SSRF via OpenID dynamic client registration (Incomplete)|Lab: SSRF via OpenID dynamic client registration (Incomplete)]]**
