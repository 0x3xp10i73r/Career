---
title: "Lab: Detecting NoSQL injection"
aliases:
  - "Lab Detecting NoSQL injection"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[NoSQL Injection]]"
notion-id: 4ac759b92751824397ac819af4d9b60c
---

# Lab: Detecting NoSQL injection

In: [[Career]] / [[Vulnerabilities]] / [[NoSQL Injection]]

The product category filter for this lab is powered by a
MongoDB NoSQL database. It is vulnerable to NoSQL injection.

To solve the lab, perform a NoSQL injection attack that causes the application to display unreleased products.

![[attachments/Vulnerabilities/NoSQL Injection/Lab - Detecting NoSQL injection/image.png]]

![[attachments/Vulnerabilities/NoSQL Injection/Lab - Detecting NoSQL injection/image 1.png]]

![[attachments/Vulnerabilities/NoSQL Injection/Lab - Detecting NoSQL injection/image 2.png]]
