---
title: "NoSQL Injection notes"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[NoSQL Injection]]"
notion-id: 256759b927518285a799015bb4a426d0
---

# NoSQL Injection notes

In: [[Career]] / [[Vulnerabilities]] / [[NoSQL Injection]]

## NoSQL Injection

- A vulnerability where an attacker **interferes with queries** made to a NoSQL database
- Similar concept to SQL injection but targets **NoSQL databases** (e.g. MongoDB)

---

## What an Attacker Can Do

- **Bypass authentication** or other protection mechanisms
- **Extract or edit data** from the database
- **Cause denial of service (DoS)**
- **Execute code** on the server

---

## What is a NoSQL Database?

- Stores and retrieves data in a format **other than traditional SQL relational tables**
- Uses a **wide range of query languages** — no universal standard like SQL
- Has **fewer relational constraints** than traditional databases
- Examples: **MongoDB, Redis, CouchDB, DynamoDB**

---

## Types of NoSQL Injection

### 1. Syntax Injection

- Break the **NoSQL query syntax** to inject your own payload
- Similar methodology to SQL injection
- More complex because NoSQL databases use **different query languages, syntax, and data structures** — no one-size-fits-all payload

### 2. Operator Injection

- Abuse **NoSQL query operators** to manipulate how queries behave
- Example: MongoDB operators like `$where`, `$gt`, `$ne`, `$regex`
- Can change query logic without breaking syntax

---

## NoSQL vs SQL Injection - Key Differences

|  | SQL Injection | NoSQL Injection |
| --- | --- | --- |
| Target | Relational DB (MySQL, MSSQL) | Non-relational DB (MongoDB etc.) |
| Query language | Universal — SQL | Varies per database |
| Syntax | Standardized | Database-specific |
| Operators abused | `OR`, `AND`, `UNION` | `$gt`, `$ne`, `$where`, `$regex` |

---

## Most Common Target

> [!tip]
> **MongoDB** is the most widely used NoSQL database and the most commonly tested for NoSQL injection in real engagements and CTFs.
>
