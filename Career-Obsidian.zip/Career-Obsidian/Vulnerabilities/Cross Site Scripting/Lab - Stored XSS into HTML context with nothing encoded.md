---
title: "Lab: Stored XSS into HTML context with nothing encoded"
aliases:
  - "Cross Site Scripting - Lab: Stored XSS into HTML context with nothing encoded"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Cross Site Scripting]]"
notion-id: cab759b9275183c2864a8199f185d788
---

# Lab: Stored XSS into HTML context with nothing encoded

In: [[Career]] / [[Vulnerabilities]] / [[Cross Site Scripting]]

This lab contains a stored cross-site scripting vulnerability in the comment functionality.

To solve this lab, submit a comment that calls the alert function when the blog post is viewed.

1. Visit the lab & click on any blog post

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - Stored XSS into HTML context with nothing encoded/image.png]]

1. Fill the comment section with XSS payload and fill other details

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - Stored XSS into HTML context with nothing encoded/image 1.png]]

1. XSS will execure

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - Stored XSS into HTML context with nothing encoded/image 2.png]]

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - Stored XSS into HTML context with nothing encoded/image 3.png]]
