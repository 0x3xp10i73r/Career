---
title: "Lab: DOM XSS in AngularJS expression with angle brackets and double quotes HTML-encoded"
aliases:
  - "Lab DOM XSS in AngularJS expression with angle bra"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Cross Site Scripting]]"
notion-id: 570759b9275182b5bb50810e893c8822
---

# Lab: DOM XSS in AngularJS expression with angle brackets and double quotes HTML-encoded

In: [[Career]] / [[Vulnerabilities]] / [[Cross Site Scripting]]

This lab contains a DOM-based cross-site scripting vulnerability in a AngularJS expression within the search functionality.

AngularJS is a popular JavaScript library, which scans the contents of HTML nodes containing the ng-app attribute (also known as an AngularJS directive). When a directive is added to the HTML code, you can execute JavaScript expressions within double curly braces. This technique is useful when angle brackets are being encoded.

To solve this lab, perform a cross-site scripting attack that executes an AngularJS expression and calls the `alert` function.

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - DOM XSS in AngularJS expression with angle brackets and double quotes HTML-encoded/image.png]]
