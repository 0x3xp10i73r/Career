---
title: "Lab: Reflected XSS into HTML context with nothing encoded"
aliases:
  - "Cross Site Scripting - Lab: Reflected XSS into HTML context with nothing encoded"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Cross Site Scripting]]"
notion-id: 30a759b9275183458b3581a9e27ab688
---

# Lab: Reflected XSS into HTML context with nothing encoded

In: [[Career]] / [[Vulnerabilities]] / [[Cross Site Scripting]]

This lab contains a simple reflected cross-site scripting vulnerability in the search functionality.

To solve the lab, perform a cross-site scripting attack that calls the alert function.

1. Enter XSS payload in the inputBox & click on search button

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - Reflected XSS into HTML context with nothing encoded/image.png]]

1. XSS will execute

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - Reflected XSS into HTML context with nothing encoded/image 1.png]]
