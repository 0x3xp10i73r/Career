---
title: "Lab: DOM XSS in jQuery selector sink using a hashchange event (pending)"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Cross Site Scripting]]"
notion-id: fcc759b92751838a8e4d81d5c977b34c
---

# Lab: DOM XSS in jQuery selector sink using a hashchange event (pending)

In: [[Career]] / [[Vulnerabilities]] / [[Cross Site Scripting]]

x
