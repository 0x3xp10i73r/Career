---
title: "Lab: Reflected XSS into attribute with angle brackets HTML-encoded"
aliases:
  - "Cross Site Scripting - Lab: Reflected XSS into attribute with angle brackets HTML-encoded"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Cross Site Scripting]]"
notion-id: bc7759b9275182809f1b8141c6533f7c
---

# Lab: Reflected XSS into attribute with angle brackets HTML-encoded

In: [[Career]] / [[Vulnerabilities]] / [[Cross Site Scripting]]

## Notes

- The application reflects user input inside an HTML attribute (e.g., `value=""`, `src=""`, `title=""`).
- `<` and `>` characters are HTML-encoded (e.g., `&lt;` and `&gt;`), so injecting full `<script>` tags is blocked.
- Even though tags cannot be injected, the attribute context is still controllable.
- The payload can break out of the existing attribute value using a quote (`"`) or (`'`), depending on how the attribute is wrapped.
- Once outside the attribute value, new attributes can be added — especially event-handler attributes such as:
    - `onmouseover=...`
    - `onclick=...`
    - `onfocus=...`
- Example reflection pattern (simplified):

    ```html
    <input value="REFLECTED-HERE">
    ```

    Payload pattern:

    ```text
    " autofocus onfocus=alert(1) "
    ```

- Because `<` and `>` are encoded, this does not rely on creating new tags — only on modifying attributes.
- Execution occurs when the event is triggered (e.g., focus, click, mouse movement).
- This is considered reflected DOM XSS because the value is reflected immediately in the HTML response.
- Key testing strategy:
    - Identify the attribute context.
    - Determine the quote used (`"` vs `'`).
    - Inject a closing quote, then add an event handler.
- Key lesson: encoding angle brackets alone is insufficient — attribute context still requires proper output encoding and validation.

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - Reflected XSS into attribute with angle brackets HTML-encoded/image.png]]

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - Reflected XSS into attribute with angle brackets HTML-encoded/image 1.png]]

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - Reflected XSS into attribute with angle brackets HTML-encoded/image 2.png]]

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - Reflected XSS into attribute with angle brackets HTML-encoded/image 3.png]]

```javascript
" autofocus onfocus=alert(document.domain) x="
```

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - Reflected XSS into attribute with angle brackets HTML-encoded/image 4.png]]
