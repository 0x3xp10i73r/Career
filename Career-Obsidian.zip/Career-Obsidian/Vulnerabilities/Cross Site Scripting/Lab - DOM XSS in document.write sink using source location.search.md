---
title: "Lab: DOM XSS in document.write sink using source location.search"
aliases:
  - "Cross Site Scripting - Lab: DOM XSS in document.write sink using source location.search"
kind: lab
tags:
  - vulnerabilities
  - lab
area: "Vulnerabilities"
up: "[[Cross Site Scripting]]"
notion-id: e72759b92751822c8a7d018a798a8f4a
---

# Lab: DOM XSS in document.write sink using source location.search

In: [[Career]] / [[Vulnerabilities]] / [[Cross Site Scripting]]

- Source and Sink in JavaScript

    # Source & Sink in JavaScript

    ## Overview

    In JavaScript, **Source** and **Sink** describe how data **enters** and **leaves** a program. These concepts are especially important in **data flow analysis** and **web security**.

    ---

    ## Source

    ### Definition

    A **Source** is any place where data **originates**.

    This data often comes from **users**, **browsers**, or **external systems**, and should be treated as **untrusted** unless validated.

    ### Common JavaScript Sources

    ```javascript
    prompt("Enter value");          // User input
    location.href                  // URL
    document.cookie                // Cookies
    localStorage.getItem("key")     // Browser storage
    ```

    ### Key Point

    > A source is the starting point of data.
> [!note]
>

    ---

    ## Sink

    ### Definition

    A **Sink** is any place where data is **used, executed, or displayed**.

    Improper handling of data at sinks can cause **security vulnerabilities**.

    ### Common JavaScript Sinks

    ```javascript
    document.write(data);
    element.innerHTML = data;
    eval(data);
    console.log(data);
    
    ```

    ### Key Point

    > A sink is the endpoint where data is consumed.
> [!note]
>

    ---

    ## Data Flow Example

    ```javascript
    let userInput = prompt("Enter your name"); // Source
    document.getElementById("output").innerHTML = userInput; // Sink
    
    ```

    - `prompt()` → Source
    - `innerHTML` → Sink

    ---


1. Visit the webpage

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - DOM XSS in document.write sink using source location.search/image.png]]

1. Use the XSS payload to exploit the vulneriblity

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - DOM XSS in document.write sink using source location.search/image 1.png]]

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - DOM XSS in document.write sink using source location.search/image 2.png]]

![[attachments/Vulnerabilities/Cross Site Scripting/Lab - DOM XSS in document.write sink using source location.search/image 3.png]]
