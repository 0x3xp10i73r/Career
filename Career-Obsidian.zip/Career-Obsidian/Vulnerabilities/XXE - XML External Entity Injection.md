---
title: "XXE - XML External Entity Injection"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: f31759b92751839a9b568116dd0ba1a6
---

# XXE - XML External Entity Injection

In: [[Career]] / [[Vulnerabilities]]

## Contents

[[XXE Notes]]

**[[Exploiting XXE to retrieve files]]**

**[[Lab - Exploiting XXE using external entities to retrieve files|Lab: Exploiting XXE using external entities to retrieve files]]**

**[[Exploiting XXE to perform SSRF attacks]]**

**[[Lab - Exploiting XXE to perform SSRF attacks|Lab: Exploiting XXE to perform SSRF attacks]]**

**[[Detecting blind XXE using out-of-band (OAST) techniques]]**

**[[Lab - Blind XXE with out-of-band interaction|Lab: Blind XXE with out-of-band interaction]]**

**[[XML Parameter Entities for Bypassing Defenses]]**

**[[Lab - Blind XXE with out-of-band interaction via XML parameter entities|Lab: Blind XXE with out-of-band interaction via XML parameter entities]]**

**[[Exploiting Blind XXE to Exfiltrate Data Out-of-Band]]**

**[[Lab - Exploiting blind XXE to exfiltrate data using a malicious external DTD|Lab: Exploiting blind XXE to exfiltrate data using a malicious external DTD]]**

**[[Exploiting blind XXE to retrieve data via error messages]]**

**[[Lab - Exploiting blind XXE to retrieve data via error messages|Lab: Exploiting blind XXE to retrieve data via error messages]]**

**[[Finding hidden attack surface for XXE injection]]**

**[[Lab - Exploiting XInclude to retrieve files|Lab: Exploiting XInclude to retrieve files]]**

**[[XXE attacks via modified content type]]**

**[[Lab - Exploiting XXE via image file upload|Lab: Exploiting XXE via image file upload]]**
