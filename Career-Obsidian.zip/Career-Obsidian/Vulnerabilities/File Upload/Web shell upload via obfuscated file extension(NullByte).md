---
title: "Web shell upload via obfuscated file extension(NullByte)"
aliases:
  - "Web shell upload via obfuscated file extension(Nul"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[File Upload]]"
notion-id: f3a759b927518224925d01c4ddc84bab
---

# Web shell upload via obfuscated file extension(NullByte)

In: [[Career]] / [[Vulnerabilities]] / [[File Upload]]

1. Upload a normal .php file and see the response

![[attachments/Vulnerabilities/File Upload/Web shell upload via obfuscated file extension(NullByte)/image.png]]

2. Change the file name with Null-Byte Payload %00.jpg

![[attachments/Vulnerabilities/File Upload/Web shell upload via obfuscated file extension(NullByte)/image 1.png]]

1. You will just able to access the .php file as .jpg gets ignores byte the Null_Byte Injection

![[attachments/Vulnerabilities/File Upload/Web shell upload via obfuscated file extension(NullByte)/image 2.png]]
