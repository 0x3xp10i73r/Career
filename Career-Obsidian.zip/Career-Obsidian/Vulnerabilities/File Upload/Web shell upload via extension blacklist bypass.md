---
title: "Web shell upload via extension blacklist bypass"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[File Upload]]"
notion-id: 9d3759b927518318928d01a64cea46b4
---

# Web shell upload via extension blacklist bypass

In: [[Career]] / [[Vulnerabilities]] / [[File Upload]]

1. Upload .htacess file in the server to update the MIME type restrictions

Giving the permissions .htaccess file to accept & execute the .133t as PHP

![[attachments/Vulnerabilities/File Upload/Web shell upload via extension blacklist bypass/image.png]]

1. Rename the .php web-shell payload file to .133t extension & upload it to the server

![[attachments/Vulnerabilities/File Upload/Web shell upload via extension blacklist bypass/image 1.png]]

1. Access the rev2.133t file & get the `/home/carlos/secret`

![[attachments/Vulnerabilities/File Upload/Web shell upload via extension blacklist bypass/image 2.png]]
