---
title: "Remote code execution via polyglot web shell upload"
aliases:
  - "Remote code execution via polyglot web shell uploa"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[File Upload]]"
notion-id: e4c759b92751830483ef810fb352cc00
---

# Remote code execution via polyglot web shell upload

In: [[Career]] / [[Vulnerabilities]] / [[File Upload]]

1. Create a .php file using exiftool using image

![[attachments/Vulnerabilities/File Upload/Remote code execution via polyglot web shell upload/image.png]]

1. Upload this .php file in the image section and intercept the request

![[attachments/Vulnerabilities/File Upload/Remote code execution via polyglot web shell upload/image 1.png]]

1. GET that file and read contents of the `/home/carlos/secret`

![[attachments/Vulnerabilities/File Upload/Remote code execution via polyglot web shell upload/image 2.png]]
