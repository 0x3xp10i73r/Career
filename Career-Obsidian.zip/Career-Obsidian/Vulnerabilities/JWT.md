---
title: "JWT"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: 93d759b92751837dad90017eb35d7a68
---

# JWT

In: [[Career]] / [[Vulnerabilities]]

## Contents

[[JWT Security Notes]]

**[[Lab - JWT authentication bypass via unverified signature|Lab: JWT authentication bypass via unverified signature]]**

**[[Lab - JWT authentication bypass via flawed signature verification|Lab: JWT authentication bypass via flawed signature verification]]**

[[Weak JWT Secrets]]

**[[Lab - JWT authentication bypass via weak signing key|Lab: JWT authentication bypass via weak signing key]]**

[[JWT Header Injection]]

**[[Injecting self-signed JWTs via the jwk parameter]]**

**[[Lab - JWT authentication bypass via jwk header injection|Lab: JWT authentication bypass via jwk header injection]]**

**[[Injecting self-signed JWTs via the kid parameter]]**

**[[Lab - JWT authentication bypass via kid header path traversal|Lab: JWT authentication bypass via kid header path traversal]]**

**[[Injecting self-signed JWTs via the jku parameter]]**

[[Untitled]]
