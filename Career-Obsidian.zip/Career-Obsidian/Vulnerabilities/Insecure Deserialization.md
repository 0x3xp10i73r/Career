---
title: "Insecure Deserialization"
aliases:
  - "Vulnerabilities - Insecure Deserialization"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: 630759b927518284af9501ec0ceab54a
---

# Insecure Deserialization

In: [[Career]] / [[Vulnerabilities]]

## Contents

[[Serialization vs Deserialization]]

[[Insecure Deserialization/Insecure Deserialization|Insecure Deserialization]]

[[Identifying Insecure Deserialization]]

**[[Lab - Modifying serialized objects|Lab: Modifying serialized objects]]**

[[Modifying Serialized DataTypes]]

**[[Lab - Modifying serialized data types|Lab: Modifying serialized data types]]**

**[[Lab - Using application functionality to exploit insecure deserialization|Lab: Using application functionality to exploit insecure deserialization]]**

[[Magic Methods]]

**[[Lab - Arbitrary object injection in PHP|Lab: Arbitrary object injection in PHP]]**

[[Gadget Chains]]

**[[Lab - Exploiting Java deserialization with Apache Commons|Lab: Exploiting Java deserialization with Apache Commons]]**
