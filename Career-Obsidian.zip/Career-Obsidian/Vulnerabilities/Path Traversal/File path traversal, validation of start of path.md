---
title: "File path traversal, validation of start of path"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Path Traversal]]"
notion-id: 6ab759b927518202951201d5e7561ef1
---

# File path traversal, validation of start of path

In: [[Career]] / [[Vulnerabilities]] / [[Path Traversal]]

1. Use Burp Suite to intercept and modify a request that fetches a product image.
2. Modify the `filename` parameter, giving it the value:`/var/www/images/../../../etc/passwd`
3. Observe that the response contains the contents of the `/etc/passwd` file.
