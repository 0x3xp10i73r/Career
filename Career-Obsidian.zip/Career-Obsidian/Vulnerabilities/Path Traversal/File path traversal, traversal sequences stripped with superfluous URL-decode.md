---
title: "File path traversal, traversal sequences stripped with superfluous URL-decode"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Path Traversal]]"
notion-id: 9f6759b9275183b3b2bf01963060c74b
---

# File path traversal, traversal sequences stripped with superfluous URL-decode

In: [[Career]] / [[Vulnerabilities]] / [[Path Traversal]]

1. Use Burp Suite to intercept and modify a request that fetches a product image.
2. Modify the `filename` parameter, giving it the value:`..%252f..%252f..%252fetc/passwd`
3. Observe that the response contains the contents of the `/etc/passwd` file.
