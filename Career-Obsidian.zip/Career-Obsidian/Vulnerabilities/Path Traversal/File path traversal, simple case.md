---
title: "File path traversal, simple case"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Path Traversal]]"
notion-id: cb3759b927518374acc701762421f6fb
---

# File path traversal, simple case

In: [[Career]] / [[Vulnerabilities]] / [[Path Traversal]]

1. Use Burp Suite to intercept and modify a request that fetches a product image.
2. Modify the `filename` parameter, giving it the value:`../../../etc/passwd`
3. Observe that the response contains the contents of the `/etc/passwd` file.
