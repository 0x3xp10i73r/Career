---
title: "File path traversal, traversal sequences stripped non-recursively"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Path Traversal]]"
notion-id: 62a759b9275182168b81812c61c84de2
---

# File path traversal, traversal sequences stripped non-recursively

In: [[Career]] / [[Vulnerabilities]] / [[Path Traversal]]

1. Use Burp Suite to intercept and modify a request that fetches a product image.
2. Modify the `filename` parameter, giving it the value:`....//....//....//etc/passwd`
3. Observe that the response contains the contents of the `/etc/passwd` file.
