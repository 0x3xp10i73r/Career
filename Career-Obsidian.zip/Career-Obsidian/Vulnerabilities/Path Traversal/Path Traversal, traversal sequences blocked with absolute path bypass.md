---
title: "Path Traversal, traversal sequences blocked with absolute path bypass"
aliases:
  - "Path Traversal, traversal sequences blocked with a"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Path Traversal]]"
notion-id: a18759b9275183688e6d0189c49f87b9
---

# Path Traversal, traversal sequences blocked with absolute path bypass

In: [[Career]] / [[Vulnerabilities]] / [[Path Traversal]]

1. Use Burp Suite to intercept and modify a request that fetches a product image.
2. Modify the `filename` parameter, giving it the value `/etc/passwd`.
3. Observe that the response contains the contents of the `/etc/passwd` file.
