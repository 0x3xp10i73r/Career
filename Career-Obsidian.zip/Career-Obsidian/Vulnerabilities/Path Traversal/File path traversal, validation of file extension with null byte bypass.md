---
title: "File path traversal, validation of file extension with null byte bypass"
aliases:
  - "File path traversal, validation of file extension"
kind: topic
tags:
  - vulnerabilities
area: "Vulnerabilities"
up: "[[Path Traversal]]"
notion-id: 0e6759b92751820781990104b195f6bb
---

# File path traversal, validation of file extension with null byte bypass

In: [[Career]] / [[Vulnerabilities]] / [[Path Traversal]]

1. Use Burp Suite to intercept and modify a request that fetches a product image.
2. Modify the `filename` parameter, giving it the value:`../../../etc/passwd%00.png`
3. Observe that the response contains the contents of the `/etc/passwd` file.
