---
title: "Path Traversal"
kind: moc
tags:
  - vulnerabilities
  - moc
area: "Vulnerabilities"
up: "[[Vulnerabilities]]"
notion-id: 858759b92751833484b18151f8b68fc2
---

# Path Traversal

In: [[Career]] / [[Vulnerabilities]]

## Contents

**[[File path traversal, simple case]]**

**[[Path Traversal, traversal sequences blocked with absolute path bypass]]**

**[[File path traversal, traversal sequences stripped non-recursively]]**

**[[File path traversal, traversal sequences stripped with superfluous URL-decode]]**

**[[File path traversal, validation of start of path]]**

**[[File path traversal, validation of file extension with null byte bypass]]**
