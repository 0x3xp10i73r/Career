---
title: "Introduction"
kind: topic
tags:
  - linux-privilege-escaltion
area: "Linux Privilege Escaltion"
up: "[[Windows Privilege Escaltion]]"
notion-id: 242759b927518067b79ef84eb854bc51
---

# Introduction

In: [[Career]] / [[Linux Privilege Escaltion]] / [[Privilege Escalation]] / [[Windows Privilege Escaltion]]

## **🔐Windows Privilege Escalation – Summary & Notes**

### **📌Definition**

Privilege escalation is the process of using access from **user A** to gain access to **user B** by exploiting weaknesses in the system.

- Goal: Typically to reach **Administrator** or **SYSTEM** level.
- Sometimes, stepwise escalation through **multiple non-admin users** may be needed.

---

### **🔍Common Weaknesses Used**

- 🛠 **Misconfigured Windows services or scheduled tasks**
- 🔐 **Excessive privileges** granted to user accounts
- 🐞 **Vulnerable software**
- ❌ **Missing security patches**

---

### **👥User Types in Windows**

### **1. Administrators**

- Full system access
- Can modify any configuration or access any file
- Members of the **Administrators group**

### **2. Standard Users**

- Limited capabilities
- Can only modify/access their own files
- Members of the **Users group**

---

### **🧬Special Built-in Accounts (Service Accounts)**

> [!note]
> These accounts are not interactively usable like normal users but can be
>
>
> **targeted**
>
> **privilege escalation**
>

| **Account** | **Description** | **Network Behavior** |
| --- | --- | --- |
| **SYSTEM / LocalSystem** | Used by Windows for internal operations. **Highest privilege** (even above Admin). | Full local access |
| **Local Service** | Runs services with **minimal** privileges. Uses **anonymous** connections. | Anonymous on the network |
| **Network Service** | Runs services with **minimal** privileges. Uses **computer’s credentials**. | Authenticates using machine account |

---

### **✅ Key Takeaways**

- Escalation doesn’t always mean going straight to Administrator or SYSTEM.
- Misconfigurations, oversights, and unpatched software are common targets.
- Knowing user types and privilege levels is essential for assessing next steps.
- SYSTEM is the **most privileged** and can sometimes be gained by abusing misconfigured services running as SYSTEM.
