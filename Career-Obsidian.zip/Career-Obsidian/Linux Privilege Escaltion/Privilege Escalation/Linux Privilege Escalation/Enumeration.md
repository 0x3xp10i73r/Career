---
title: "Enumeration"
kind: topic
tags:
  - linux-privilege-escaltion
area: "Linux Privilege Escaltion"
up: "[[Privilege Escalation/Linux Privilege Escalation|Linux Privilege Escalation]]"
notion-id: 241759b927518007a02aee38df4c1383
---

# Enumeration

In: [[Career]] / [[Linux Privilege Escaltion]] / [[Privilege Escalation]] / [[Privilege Escalation/Linux Privilege Escalation|Linux Privilege Escalation]]

### **Basic System Identification**

- `hostname`: Reveals the system’s hostname (e.g. role in the network like SQL-PROD-01).
- `uname -a`: Displays kernel and system info (useful for kernel exploit research).
- cat /proc/version: Kernel version + compiler info (e.g. GCC).
- cat /etc/issue: May show OS version, but can be customized/fake.

---

### **Process & User Info**

- ps, ps -A, ps axjf, ps aux: Show current/running processes, their tree, owners, etc.
- id: Shows user ID, group ID, and groups (useful to check privileges).
- sudo -l: Shows commands the current user can run as sudo.
- history: Reveals previously run commands (sometimes credentials).
- cat /etc/passwd: Lists system users; real users usually have /home directories.

---

### **Environment Variables**

- env: Lists all environment variables. Look out for PATH, SHELL, etc. Can help locate compilers or scripting languages.

---

### **File and Directory Enumeration**

- ls -la: Shows hidden files and permissions.
- find: Very powerful for locating specific files, permissions, or attributes:
    - Files by name: find / -name flag.txt
    - Executables: find / -perm a=x
    - World-writable/executable dirs: find / -perm -222 -type d
    - SUID files: find / -perm -u=s -type f 2>/dev/null

---

### **Network Enumeration**

- ifconfig: Displays active network interfaces.
- ip route: Shows routing table (potential pivoting points).
- netstat: Reveals open ports and connections:
    - netstat -a, -at, -au, -l, -tp, -ano, -i, -s

---

### **Tips**

- Use 2>/dev/null to suppress errors from commands like find.
- Real privilege escalation begins **after access** — thorough enumeration is essential.
- Pay attention to file permissions, hidden files, user-owned files, and development tools (e.g. Python, GCC).

---
