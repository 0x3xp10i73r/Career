---
title: "Hack The Box"
kind: database
tags:
  - hack-the-box-labs
  - database
area: "Hack The Box Labs"
up: "[[Hack The Box Labs]]"
notion-id: 7c4759b92751831d9c1d8142a53e0252
---

# Hack The Box

In: [[Career]] / [[Hack The Box Labs]]

## All notes

14 notes. Properties are on each note, so the table stays in sync with the files.

| Name | Status | Difficulty | For me | Tags | Date | URL |
| --- | --- | --- | --- | --- | --- | --- |
| [[Cap]] | ✅ Done | Easy | Easy | Linux, Web |  | [open](https://app.hackthebox.com/machines/Cap) |
| [[CCTV]] | 🔄 In progress | Easy |  | Web |  | [open](https://app.hackthebox.com/machines/CCTV) |
| [[Facts]] | ✅ Done | Easy |  | AWS, Linux, Web | 2026-05-02 | [open](https://app.hackthebox.com/machines/Facts?sort_by=created_at&sort_type=desc) |
| [[Kobold]] | 🔄 In progress | Easy |  | Linux, Web | 2026-05-02 | [open](https://app.hackthebox.com/machines/Kobold) |
| [[WingData]] | ✅ Done | Easy | Medium | Linux | 2026-05-08 | [open](https://app.hackthebox.com/machines/WingData?sort_by=created_at&sort_type=desc) |
| [[Interceptor]] | 🔄 In progress | Medium |  | Linux | 2026-05-21 |  |
| [[Reactor]] | ✅ Done | Easy | Medium | Linux | 2026-05-26 | [open](https://app.hackthebox.com/machines/Reactor?sort_by=created_at&sort_type=desc) |
| [[SmartHire]] | 🔄 In progress | Easy |  | Linux | 2026-05-28 |  |
| [[Two Million]] | 🔄 In progress | Easy |  | API, Linux | 2026-06-07 | [open](https://app.hackthebox.com/machines/TwoMillion?sort_by=created_at&sort_type=desc) |
| [[Connected]] | ✅ Done | Easy | Medium | Linux | 2026-06-08 | [open](https://app.hackthebox.com/machines/Connected?sort_by=created_at&sort_type=desc) |
| [[DevHub]] | 🔄 In progress | Easy |  | Linux | 2026-06-14 | DevHub |
| [[Enigma]] | 🔄 In progress | Easy |  | Linux, Web | 2026-06-28 |  |
| [[Paperwork]] | 🔄 In progress | Easy |  | Linux, Web | 2026-07-12 |  |
| [[Cohort]] | 🔄 In progress | Easy |  | Linux | 2026-08-08 | [open](https://app.hackthebox.com/machines/Cohort?sort_by=created_at&sort_type=desc) |

%% Install the Dataview community plugin to turn the block below into a live, sortable table. The markdown table above works without it. %%

```dataview
TABLE status AS Status, difficulty AS Difficulty, date AS Date, tags AS Tags
FROM "Hack The Box Labs/Hack The Box"
WHERE database = "Hack The Box"
SORT file.name ASC
```
