---
title: "Enigma"
kind: writeup
tags:
  - hack-the-box-labs
  - status/in-progress
  - writeup
  - linux
  - web
status: "In progress"
difficulty: "Easy"
date: 2026-06-28
database: "Hack The Box"
area: "Hack The Box Labs"
up: "[[Hack The Box]]"
notion-id: 38d759b9275180f085e5e1e42720b605
---

# Enigma

In: [[Career]] / [[Hack The Box Labs]] / [[Hack The Box]]

## Nmap Scan

```bash
                                                                                                                                         
┌──(root㉿kali)-[~]
└─# nmap -sC -sV -p- -Pn --min-rate=1000 -oA nmap/enigma 10.129.225.110
Starting Nmap 7.99 ( https://nmap.org ) at 2026-06-28 16:42 +0530
Nmap scan report for 10.129.225.110
Host is up (0.39s latency).
Not shown: 65522 closed tcp ports (reset)
PORT      STATE SERVICE  VERSION
22/tcp    open  ssh      OpenSSH 9.6p1 Ubuntu 3ubuntu13.16 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   256 0c:4b:d2:76:ab:10:06:92:05:dc:f7:55:94:7f:18:df (ECDSA)
|_  256 2d:6d:4a:4c:ee:2e:11:b6:c8:90:e6:83:e9:df:38:b0 (ED25519)
80/tcp    open  http     nginx 1.24.0 (Ubuntu)
|_http-title: Did not follow redirect to http://enigma.htb/
|_http-server-header: nginx/1.24.0 (Ubuntu)
110/tcp   open  pop3     Dovecot pop3d
| ssl-cert: Subject: commonName=enigma
| Subject Alternative Name: DNS:enigma
| Not valid before: 2026-02-18T20:33:33
|_Not valid after:  2036-02-16T20:33:33
|_pop3-capabilities: CAPA UIDL AUTH-RESP-CODE SASL PIPELINING RESP-CODES STLS TOP
|_ssl-date: TLS randomness does not represent time
111/tcp   open  rpcbind  2-4 (RPC #100000)
| rpcinfo: 
|   program version    port/proto  service
|   100000  2,3,4        111/tcp   rpcbind
|   100000  2,3,4        111/udp   rpcbind
|   100000  3,4          111/tcp6  rpcbind
|   100000  3,4          111/udp6  rpcbind
|   100003  3,4         2049/tcp   nfs
|   100003  3,4         2049/tcp6  nfs
|   100005  1,2,3      36317/tcp6  mountd
|   100005  1,2,3      45347/udp6  mountd
|   100005  1,2,3      46837/udp   mountd
|   100005  1,2,3      52335/tcp   mountd
|   100021  1,3,4      41953/tcp   nlockmgr
|   100021  1,3,4      43460/udp   nlockmgr
|   100021  1,3,4      43887/udp6  nlockmgr
|   100021  1,3,4      46135/tcp6  nlockmgr
|   100024  1          40071/tcp   status
|   100024  1          49763/udp6  status
|   100024  1          50959/tcp6  status
|   100024  1          56497/udp   status
|   100227  3           2049/tcp   nfs_acl
|_  100227  3           2049/tcp6  nfs_acl
143/tcp   open  imap     Dovecot imapd (Ubuntu)
|_imap-capabilities: OK have ENABLE LOGIN-REFERRALS ID LITERAL+ post-login listed STARTTLS IMAP4rev1 SASL-IR Pre-login IDLE more LOGINDISABLEDA0001 capabilities
|_ssl-date: TLS randomness does not represent time
| ssl-cert: Subject: commonName=enigma
| Subject Alternative Name: DNS:enigma
| Not valid before: 2026-02-18T20:33:33
|_Not valid after:  2036-02-16T20:33:33
993/tcp   open  ssl/imap Dovecot imapd (Ubuntu)
|_ssl-date: TLS randomness does not represent time
| ssl-cert: Subject: commonName=enigma
| Subject Alternative Name: DNS:enigma
| Not valid before: 2026-02-18T20:33:33
|_Not valid after:  2036-02-16T20:33:33
995/tcp   open  ssl/pop3 Dovecot pop3d
| ssl-cert: Subject: commonName=enigma
| Subject Alternative Name: DNS:enigma
| Not valid before: 2026-02-18T20:33:33
|_Not valid after:  2036-02-16T20:33:33
|_ssl-date: TLS randomness does not represent time
2049/tcp  open  nfs_acl  3 (RPC #100227)
40071/tcp open  status   1 (RPC #100024)
41953/tcp open  nlockmgr 1-4 (RPC #100021)
43817/tcp open  mountd   1-3 (RPC #100005)
52335/tcp open  mountd   1-3 (RPC #100005)
53025/tcp open  mountd   1-3 (RPC #100005)
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 155.29 seconds

```

## Checking Mounted Directory

```bash
┌──(root㉿kali)-[~]
└─# showmount -e 10.129.225.110

Export list for 10.129.225.110:
/srv/nfs/onboarding *
                                                                                                                                         
┌──(root㉿kali)-[~]
└─# mkdir -p ~/NFS/var_nfs 
                                                                                                                                         
┌──(root㉿kali)-[~]
└─# sudo mount -t nfs -o nolock 10.129.225.110:/srv/nfs/onboarding ~/NFS/var_nfs
                                                                                                                                         
┌──(root㉿kali)-[~]
└─# mount | grep nfs
10.129.225.110:/srv/nfs/onboarding on /root/NFS/var_nfs type nfs4 (rw,relatime,vers=4.2,rsize=524288,wsize=524288,namlen=255,hard,fatal_neterrors=none,proto=tcp,timeo=600,retrans=2,sec=sys,clientaddr=10.10.16.78,local_lock=none,addr=10.129.225.110)
                                                                                                                                         
┌──(root㉿kali)-[~]
└─# cd NFS/var_nfs 
ls                                                                                                                                         
┌──(root㉿kali)-[~/NFS/var_nfs]
└─# tree .
.
└── New_Employee_Access.pdf

1 directory, 1 file
                                                                                                                                         
┌──(root㉿kali)-[~/NFS/var_nfs]
└─# ls            
New_Employee_Access.pdf
                                                                                                                                         
┌──(root㉿kali)-[~/NFS/var_nfs]
└─# cp New_Employee_Access.pdf ~/
                                                                                                                                         
┌──(root㉿kali)-[~/NFS/var_nfs]
└─# cd
                                                                                                                                         
┌──(root㉿kali)-[~]
└─# ls                                                                          
Desktop    Downloads                      jetbrains-toolbox.tar.gz  New_Employee_Access.pdf  nmap      Projects  Templates
Documents  jetbrains-toolbox-3.5.0.84344  Music                     NFS                      Pictures  Public    Videos
                                                                                                                                         
┌──(root㉿kali)-[~]
└─# open New_Employee_Access.pdf 

```

![[attachments/Hack The Box Labs/Hack The Box/Enigma/Screenshot_2026-06-28_at_16-57-21.png]]

## Checking Email using POP3 and OpenSSL

#### Tried using openSSL and before telnet but got errors

```bash
┌──(root㉿kali)-[~]
└─# openssl s_client -connect 10.129.225.110:995
Connecting to 10.129.225.110
CONNECTED(00000003)
Can't use SSL_get_servername
depth=0 CN=enigma
verify error:num=18:self-signed certificate
verify return:1
depth=0 CN=enigma
verify return:1
---
Certificate chain
 0 s:CN=enigma
   i:CN=enigma
   a:PKEY: RSA, 2048 (bit); sigalg: sha256WithRSAEncryption
   v:NotBefore: Feb 18 20:33:33 2026 GMT; NotAfter: Feb 16 20:33:33 2036 GMT
---
Server certificate
-----BEGIN CERTIFICATE-----
MIIC7zCCAdegAwIBAgIUDIVPMnvnZ7MqOX9P3XD6FaMUGLYwDQYJKoZIhvcNAQEL
BQAwETEPMA0GA1UEAwwGZW5pZ21hMB4XDTI2MDIxODIwMzMzM1oXDTM2MDIxNjIw
MzMzM1owETEPMA0GA1UEAwwGZW5pZ21hMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A
MIIBCgKCAQEAkSnxU+24XgWM3KXxLy4mCk7AclfQyAQlcr8Gm7L3E3gdkF74wSZy
i00pixUHKlKqrPQwSpNqsWMqi1ggBZQzd2jBRKzpQQflMUzI8uoUjkBlaFqKCli5
cJgyL/WcOylWDTdBXeIyBUBDN1duzVa/BDTV83inPH+Fs5rpesSJ/Jwsv4432dtb
SGAe6YuR4PIpgI33GvPoW3uSfE/yMGffwRf0RONTcsbsNC8reb3XKqa9eNfrmYb3
S9/L/3dK04fZRU1gk4vRt0xY60VSgQXJqQwfsTUxcNqwYL0bZ0u5bEfV6ITwNO5F
DZ11EkqkJCFx6pVgWRmnfC0XNMi5IHW3mwIDAQABoz8wPTAJBgNVHRMEAjAAMBEG
A1UdEQQKMAiCBmVuaWdtYTAdBgNVHQ4EFgQUHA8z2wPX5Qj2TV6SafL8f2LRoDsw
DQYJKoZIhvcNAQELBQADggEBADr3VEq/+YzDltVRbBvjGeCCm2A2+5nAniEJE/oA
CkQDVHgYrMH/7L0z0kocq0e54Mk+iRRPKjP4bF4FhG2syeaE2o1aqH6C3GIoBvRZ
79XCkgxf5XDlECId1en+KS+iX2ssSmFWEU7l9+OnIRY1QA91OekD2OznIfAeXjaw
O4SWzae1MrGM0venQ1RugTWa9JoL6G2BUtqIGDyw3QRxmx3HKStMtfHqdq2vzFjA
LsK4A5j7mMDujaq55Nsc4/Su0ShQKPW3A1X7C1Y9c492g9Z0R5GL17CrmYJIVPX2
+LC3TWgrRUQ6i5qZ7/9jU198FGNUlRGQi304f+XlxhVqTHI=
-----END CERTIFICATE-----
subject=CN=enigma
issuer=CN=enigma
---
No client certificate CA names sent
Peer signing digest: SHA256
Peer signature type: rsa_pss_rsae_sha256
Peer Temp Key: X25519, 253 bits
---
SSL handshake has read 1311 bytes and written 1738 bytes
Verification error: self-signed certificate
---
New, TLSv1.3, Cipher is TLS_AES_256_GCM_SHA384
Protocol: TLSv1.3
Server public key is 2048 bit
This TLS version forbids renegotiation.
Compression: NONE
Expansion: NONE
No ALPN negotiated
Early data was not sent
Verify return code: 18 (self-signed certificate)
---
---
Post-Handshake New Session Ticket arrived:
SSL-Session:
    Protocol  : TLSv1.3
    Cipher    : TLS_AES_256_GCM_SHA384
    Session-ID: 83A87E52DA0C9252378AF9521C43DB24D19A78C62D058D1CECE456770F190770
    Session-ID-ctx: 
    Resumption PSK: 290C34AC0398DF03ECA128219AD7D970D6D93AC4D2A44CA5376060AA157D0BEA852742FDB54378E8B3138D18D6C73CBF
    PSK identity: None
    PSK identity hint: None
    SRP username: None
    TLS session ticket lifetime hint: 7200 (seconds)
    TLS session ticket:
    0000 - 7d 13 9d eb b5 1d 00 d5-96 d3 88 15 c2 26 74 08   }............&t.
    0010 - 37 9f c5 66 6c d7 8c a1-57 42 b6 44 80 ba 22 3c   7..fl...WB.D.."<
    0020 - a3 cc b1 98 63 32 8f 14-ff 5a 15 1e 26 be c9 84   ....c2...Z..&...
    0030 - 0a 39 ee d3 8e 64 1f f6-b6 1a 45 d8 7f 51 67 e4   .9...d....E..Qg.
    0040 - fa d5 3a 2c 70 cc 13 db-fe f1 15 86 dc f2 01 dc   ..:,p...........
    0050 - 6e ce 5a 4c b6 dc 8e 23-c2 ea d9 56 b4 8f 9c b2   n.ZL...#...V....
    0060 - b7 d2 69 45 2a 42 81 1b-38 ae 7c 7c a1 ca 28 00   ..iE*B..8.||..(.
    0070 - dd d0 ff 15 5a 72 af 9d-7a e8 ea 53 d9 36 f7 f3   ....Zr..z..S.6..
    0080 - d7 fb 2f fd 6f b5 8f 09-be 8e 43 a2 c9 21 6e c0   ../.o.....C..!n.
    0090 - e4 d8 79 6e 62 8d f0 60-95 c5 23 1b 65 14 2e 59   ..ynb..`..#.e..Y
    00a0 - 89 f9 77 e9 10 7d 03 93-2c 6e 20 04 a5 d5 3b 77   ..w..}..,n ...;w
    00b0 - 7c 26 e1 b7 5b 36 92 e6-17 b3 d7 64 22 de 4c da   |&..[6.....d".L.
    00c0 - 6d f4 6b 50 6a 5b da c6-57 fa b6 a8 f7 08 44 75   m.kPj[..W.....Du

    Start Time: 1782646255
    Timeout   : 7200 (sec)
    Verify return code: 18 (self-signed certificate)
    Extended master secret: no
    Max Early Data: 0
---
read R BLOCK
---
Post-Handshake New Session Ticket arrived:
SSL-Session:
    Protocol  : TLSv1.3
    Cipher    : TLS_AES_256_GCM_SHA384
    Session-ID: EA1188C931BCFCE3179B05A35D9E954D0ABB6E018783151A858E04F1174834A1
    Session-ID-ctx: 
    Resumption PSK: 1896DF9A148FE73428CCC1A3C3F4B225B940B514027A92908F30CEE668849347D4E506B41534FAE86F65BFEBB7D4C7DF
    PSK identity: None
    PSK identity hint: None
    SRP username: None
    TLS session ticket lifetime hint: 7200 (seconds)
    TLS session ticket:
    0000 - 7d 13 9d eb b5 1d 00 d5-96 d3 88 15 c2 26 74 08   }............&t.
    0010 - b8 9c 1b 45 00 6d a0 ef-0b e0 da 98 9d ac ce 81   ...E.m..........
    0020 - 81 45 4f e8 13 5d c2 8c-40 c1 24 29 37 b7 63 f3   .EO..]..@.$)7.c.
    0030 - c4 01 8e b3 b0 28 b2 ea-cc d1 1d 50 02 48 17 ea   .....(.....P.H..
    0040 - 1b 29 f8 02 b2 82 51 b4-0f bc 96 c7 7e e9 27 02   .)....Q.....~.'.
    0050 - ca d1 68 f9 5b 23 52 c1-0c 1e 7a 67 46 e9 58 df   ..h.[#R...zgF.X.
    0060 - 47 cf 7b 28 64 71 ec bd-e8 3d 5a 8f 88 99 b0 d1   G.{(dq...=Z.....
    0070 - 19 f3 c8 b9 5c c0 f4 a3-00 16 59 1d 02 1c 66 47   ....\.....Y...fG
    0080 - cc ed fb db 2b 9c 53 41-8c 0c f8 eb 08 9a fe c8   ....+.SA........
    0090 - d1 34 f2 00 30 6f 06 4a-a7 e8 d9 b5 ad 57 93 50   .4..0o.J.....W.P
    00a0 - 17 d6 c3 3e e9 40 18 5b-da 2a 2e 10 45 a6 c7 f7   ...>.@.[.*..E...
    00b0 - d3 83 1a 50 91 c8 a6 b7-ff 72 8f 0a fb 53 93 4c   ...P.....r...S.L
    00c0 - 77 bf 14 e9 fb c1 e9 04-ce f5 ac d4 e4 67 4d 2f   w............gM/

    Start Time: 1782646255
    Timeout   : 7200 (sec)
    Verify return code: 18 (self-signed certificate)
    Extended master secret: no
    Max Early Data: 0
---
read R BLOCK
+OK Dovecot (Ubuntu) ready.
USER kevin

+OK
-ERR Unknown command.
v
-ERR Unknown command.
PASS Enigma2024!
+OK Logged in.
LIST    
+OK 1 messages:
1 1473
.
RETR 1
RENEGOTIATING
ERROR

```

#### Then tried with curl

```bash
┌──(root㉿kali)-[~]
└─# curl -k pop3s://10.129.225.110/1 --user 'kevin:Enigma2024!'
Return-Path: <sarah@enigma.htb>
X-Original-To: kevin@localhost
Delivered-To: kevin@localhost
Received: from enigma (localhost [127.0.0.1])
        by enigma (Postfix) with ESMTP id 673F7211B9
        for <kevin@localhost>; Wed, 18 Feb 2026 21:29:13 +0000 (UTC)
Date: Wed, 18 Feb 2026 21:29:13 +0000
To: kevin@localhost
From: sarah@enigma.htb
Subject: Welcome to Enigma Corp, Kevin!
Message-Id: <20260218212913.010896@enigma>
X-Mailer: swaks v20240103.0 jetmore.org/john/code/swaks/

Hi Kevin,

Welcome to the team! We're thrilled to have you on board at Enigma Corp.

A little about us — Enigma Corp is a mid-sized technology and operations firm specializing in infrastructure management and enterprise solutions. We've been growing rapidly over the past few years and we're excited to have fresh talent joining us.

I'm Sarah from the Accounts department. I'll be your point of contact for any finance-related queries during your onboarding period.

We're still finalizing a few of your onboarding details — your system access, equipment setup, and department introductions are all being arranged by the IT team. You should be receiving your access credentials shortly via the company shared drive.

In the meantime, don't hesitate to reach out if you have any questions. We want to make sure your first few days are as smooth as possible.

Looking forward to working with you!

Best regards,
Sarah
Accounts Department
Enigma Corp
sarah@enigma.htb

```

#### Checking Sarah’s Mail

```bash
┌──(root㉿kali)-[~]
└─# curl -k pop3s://10.129.225.110/1 --user 'sarah:Enigma2024!'
Return-Path: <it@enigma.htb>
X-Original-To: sarah@localhost
Delivered-To: sarah@localhost
Received: from enigma (localhost [127.0.0.1])
        by enigma (Postfix) with ESMTP id C123C211B9
        for <sarah@localhost>; Wed, 18 Feb 2026 21:42:51 +0000 (UTC)
Date: Thu, 19 Feb 2026 10:22:00 +0000
Subject: Re: OpenSTAManager Access Request
From: it@enigma.htb
To: sarah@enigma.htb
Message-Id: <osm-reply-001@enigma.htb>
In-Reply-To: <osm-request-001@enigma.htb>
References: <osm-request-001@enigma.htb>

Hi Sarah,

Apologies for the delay. I have provisioned your access. Please find the details below:

URL: http://support_001.enigma.htb
Username: admin
Password: Ne3s4rtars78s

Note: I will create a dedicated account for you shortly, for now you can use the admin account to get started.

Regards,
IT Support
Enigma Corp

```

![[attachments/Hack The Box Labs/Hack The Box/Enigma/Screenshot_2026-06-28_at_17-10-49.png]]

#### Logged in using sarah’s creds

![[attachments/Hack The Box Labs/Hack The Box/Enigma/Screenshot_2026-06-28_at_17-12-36.png]]
