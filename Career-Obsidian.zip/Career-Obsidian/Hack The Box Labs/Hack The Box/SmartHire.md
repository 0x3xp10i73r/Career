---
title: "SmartHire"
kind: writeup
tags:
  - hack-the-box-labs
  - status/in-progress
  - writeup
  - linux
status: "In progress"
difficulty: "Easy"
date: 2026-05-28
database: "Hack The Box"
area: "Hack The Box Labs"
up: "[[Hack The Box]]"
notion-id: 376759b9275182b8af63817a0a23a501
---

# SmartHire

In: [[Career]] / [[Hack The Box Labs]] / [[Hack The Box]]

## Nmap Scan

```bash
nmap -p- --min-rate 1000 -T4 -sV -Pn -oA nmap_full_scan 10.129.100.186
Starting Nmap 7.98 ( https://nmap.org ) at 2026-05-28 16:20 +0530
Warning: 10.129.100.186 giving up on port because retransmission cap hit (6).
Stats: 0:01:04 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 70.15% done; ETC: 16:21 (0:00:27 remaining)
Nmap scan report for 10.129.100.186
Host is up (0.20s latency).
Not shown: 65533 closed tcp ports (reset)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 8.9p1 Ubuntu 3ubuntu0.15 (Ubuntu Linux; protocol 2.0)
80/tcp open  http    nginx 1.18.0 (Ubuntu)
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 112.49 seconds
```

## Fuzzing Directories

```bash
┌──[kali@Shieldbyte53]─[~]
└─❯ ffuf -u "http://smarthire.htb//FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt 

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://smarthire.htb//FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

dashboard               [Status: 302, Size: 199, Words: 18, Lines: 6, Duration: 684ms]
login                   [Status: 200, Size: 6160, Words: 1357, Lines: 128, Duration: 189ms]
logout                  [Status: 302, Size: 199, Words: 18, Lines: 6, Duration: 190ms]
predict                 [Status: 302, Size: 199, Words: 18, Lines: 6, Duration: 186ms]
register                [Status: 200, Size: 6499, Words: 1415, Lines: 132, Duration: 186ms]
:: Progress: [20481/20481] :: Job [1/1] :: 90 req/sec :: Duration: [0:02:56] :: Errors: 0 ::
```

## VHosts Fuzzing

```bash
──[kali@Shieldbyte53]─[/mnt/c/Users/shiel]
└─❯ ffuf -H "Host: FUZZ.smarthire.htb" -H "User-Agent: PENTEST" -c -w "/usr/share/wordlists/seclists/Discovery/DNS/bitquark-subdomains-top100000.txt" -u http://smarthire.htb -r -fl 216  

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://smarthire.htb
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/DNS/bitquark-subdomains-top100000.txt
 :: Header           : User-Agent: PENTEST
 :: Header           : Host: FUZZ.smarthire.htb
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
 :: Filter           : Response lines: 216
________________________________________________

models                  [Status: 401, Size: 137, Words: 11, Lines: 1, Duration: 323ms]
```
