---
title: "Kobold"
kind: writeup
tags:
  - hack-the-box-labs
  - status/in-progress
  - writeup
  - linux
  - web
status: "In progress"
difficulty: "Easy"
date: 2026-05-02
url: "https://app.hackthebox.com/machines/Kobold"
database: "Hack The Box"
area: "Hack The Box Labs"
up: "[[Hack The Box]]"
notion-id: f15759b92751837ea9210155eb0c7cae
---

# Kobold

In: [[Career]] / [[Hack The Box Labs]] / [[Hack The Box]]

## Nmap Scan

```bash
┌──[kali@Shieldbyte53]─[~/nmap]
└─❯ nmap -p- --min-rate 1000 -T4 -Pn -sV -oA nmap_full_scan 10.129.236.225
Starting Nmap 7.98 ( https://nmap.org ) at 2026-05-02 17:03 +0530
Nmap scan report for 10.129.236.225
Host is up (0.18s latency).
Not shown: 65531 closed tcp ports (reset)
PORT     STATE SERVICE  VERSION
22/tcp   open  ssh      OpenSSH 9.6p1 Ubuntu 3ubuntu13.15 (Ubuntu Linux; protocol 2.0)
80/tcp   open  http     nginx 1.24.0 (Ubuntu)
443/tcp  open  ssl/http nginx 1.24.0 (Ubuntu)
3552/tcp open  http     Golang net/http server
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port3552-TCP:V=7.98%I=7%D=5/2%Time=69F5E159%P=x86_64-pc-linux-gnu%r(Gen
SF:ericLines,67,"HTTP/1\.1\x20400\x20Bad\x20Request\r\nContent-Type:\x20te
SF:xt/plain;\x20charset=utf-8\r\nConnection:\x20close\r\n\r\n400\x20Bad\x2
SF:0Request")%r(GetRequest,8FF,"HTTP/1\.0\x20200\x20OK\r\nAccept-Ranges:\x
SF:20bytes\r\nCache-Control:\x20no-cache,\x20no-store,\x20must-revalidate\
SF:r\nContent-Length:\x202081\r\nContent-Type:\x20text/html;\x20charset=ut
SF:f-8\r\nExpires:\x200\r\nPragma:\x20no-cache\r\nDate:\x20Sat,\x2002\x20M
SF:ay\x202026\x2011:39:11\x20GMT\r\n\r\n<!doctype\x20html>\n<html\x20lang=
SF:\"%lang%\">\n\t<head>\n\t\t<meta\x20charset=\"utf-8\"\x20/>\n\t\t<meta\
SF:x20http-equiv=\"Cache-Control\"\x20content=\"no-cache,\x20no-store,\x20
SF:must-revalidate\"\x20/>\n\t\t<meta\x20http-equiv=\"Pragma\"\x20content=
SF:\"no-cache\"\x20/>\n\t\t<meta\x20http-equiv=\"Expires\"\x20content=\"0\
SF:"\x20/>\n\t\t<link\x20rel=\"icon\"\x20href=\"/api/app-images/favicon\"\
SF:x20/>\n\t\t<meta\x20name=\"viewport\"\x20content=\"width=device-width,\
SF:x20initial-scale=1,\x20maximum-scale=1,\x20viewport-fit=cover\"\x20/>\n
SF:\t\t<link\x20rel=\"manifest\"\x20href=\"/app\.webmanifest\"\x20/>\n\t\t
SF:<meta\x20name=\"theme-color\"\x20content=\"oklch\(1\x200\x200\)\"\x20me
SF:dia=\"\(prefers-color-scheme:\x20light\)\"\x20/>\n\t\t<meta\x20name=\"t
SF:heme-color\"\x20content=\"oklch\(0\.141\x200\.005\x20285\.823\)\"\x20me
SF:dia=\"\(prefers-color-scheme:\x20dark\)\"\x20/>\n\t\t\n\t\t<link\x20rel
SF:=\"modu")%r(HTTPOptions,8FF,"HTTP/1\.0\x20200\x20OK\r\nAccept-Ranges:\x
SF:20bytes\r\nCache-Control:\x20no-cache,\x20no-store,\x20must-revalidate\
SF:r\nContent-Length:\x202081\r\nContent-Type:\x20text/html;\x20charset=ut
SF:f-8\r\nExpires:\x200\r\nPragma:\x20no-cache\r\nDate:\x20Sat,\x2002\x20M
SF:ay\x202026\x2011:39:11\x20GMT\r\n\r\n<!doctype\x20html>\n<html\x20lang=
SF:\"%lang%\">\n\t<head>\n\t\t<meta\x20charset=\"utf-8\"\x20/>\n\t\t<meta\
SF:x20http-equiv=\"Cache-Control\"\x20content=\"no-cache,\x20no-store,\x20
SF:must-revalidate\"\x20/>\n\t\t<meta\x20http-equiv=\"Pragma\"\x20content=
SF:\"no-cache\"\x20/>\n\t\t<meta\x20http-equiv=\"Expires\"\x20content=\"0\
SF:"\x20/>\n\t\t<link\x20rel=\"icon\"\x20href=\"/api/app-images/favicon\"\
SF:x20/>\n\t\t<meta\x20name=\"viewport\"\x20content=\"width=device-width,\
SF:x20initial-scale=1,\x20maximum-scale=1,\x20viewport-fit=cover\"\x20/>\n
SF:\t\t<link\x20rel=\"manifest\"\x20href=\"/app\.webmanifest\"\x20/>\n\t\t
SF:<meta\x20name=\"theme-color\"\x20content=\"oklch\(1\x200\x200\)\"\x20me
SF:dia=\"\(prefers-color-scheme:\x20light\)\"\x20/>\n\t\t<meta\x20name=\"t
SF:heme-color\"\x20content=\"oklch\(0\.141\x200\.005\x20285\.823\)\"\x20me
SF:dia=\"\(prefers-color-scheme:\x20dark\)\"\x20/>\n\t\t\n\t\t<link\x20rel
SF:=\"modu");
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 110.56 seconds

```

## Visiting Open port 3552

![[attachments/Hack The Box Labs/Hack The Box/Kobold/SCR-20260328-uqji-2.jpeg]]
