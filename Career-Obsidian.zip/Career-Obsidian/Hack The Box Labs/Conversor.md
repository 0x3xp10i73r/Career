---
title: "Conversor"
kind: topic
tags:
  - hack-the-box-labs
area: "Hack The Box Labs"
up: "[[Hack The Box Labs]]"
notion-id: a2d759b9275183558747816931d170e2
---

# Conversor

In: [[Career]] / [[Hack The Box Labs]]

https://app.hackthebox.com/machines/Conversor

## Scanning Open Ports

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ rustscan -a 10.129.238.31 -u 5000 -- -sS -T4
.----. .-. .-. .----..---.  .----. .---.   .--.  .-. .-.
| {}  }| { } |{ {__ {_   _}{ {__  /  ___} / {} \ |  `| |
| .-. \| {_} |.-._} } | |  .-._} }\     }/  /\  \| |\  |
`-' `-'`-----'`----'  `-'  `----'  `---' `-'  `-'`-' `-'
The Modern Day Port Scanner.
________________________________________
: http://discord.skerritt.blog         :
: https://github.com/RustScan/RustScan :
 --------------------------------------
Port scanning: Making networking exciting since... whenever.

[~] The config file is expected to be at "/home/kali/.rustscan.toml"
[~] Automatically increasing ulimit value to 5000.
Open 10.129.238.31:22
Open 10.129.238.31:80
[~] Starting Script(s)
[>] Running script "nmap -vvv -p {{port}} -{{ipversion}} {{ip}} -sS -T4" on ip 10.129.238.31
Depending on the complexity of the script, results may take some time to appear.
[~] Starting Nmap 7.95 ( https://nmap.org ) at 2026-01-29 17:07 IST
Initiating Ping Scan at 17:07
Scanning 10.129.238.31 [4 ports]
Completed Ping Scan at 17:07, 0.35s elapsed (1 total hosts)
Initiating Parallel DNS resolution of 1 host. at 17:07
Completed Parallel DNS resolution of 1 host. at 17:07, 0.03s elapsed
DNS resolution of 1 IPs took 0.03s. Mode: Async [#: 1, OK: 0, NX: 1, DR: 0, SF: 0, TR: 1, CN: 0]
Initiating SYN Stealth Scan at 17:07
Scanning 10.129.238.31 [2 ports]
Discovered open port 80/tcp on 10.129.238.31
Discovered open port 22/tcp on 10.129.238.31
Completed SYN Stealth Scan at 17:07, 0.66s elapsed (2 total ports)
Nmap scan report for 10.129.238.31
Host is up, received reset ttl 62 (0.39s latency).
Scanned at 2026-01-29 17:07:27 IST for 1s

PORT   STATE SERVICE REASON
22/tcp open  ssh     syn-ack ttl 62
80/tcp open  http    syn-ack ttl 62

Read data files from: /usr/share/nmap
Nmap done: 1 IP address (1 host up) scanned in 1.17 seconds
           Raw packets sent: 6 (240B) | Rcvd: 5 (196B)
```

## Visiting port 80

![[attachments/Hack The Box Labs/Conversor/image.png]]
