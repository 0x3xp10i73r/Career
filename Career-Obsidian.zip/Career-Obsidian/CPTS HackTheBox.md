---
title: "CPTS HackTheBox"
kind: moc
tags:
  - cpts-hackthebox
  - status/not-started
  - moc
status: "Not started"
database: "Career"
area: "CPTS HackTheBox"
up: "[[Career]]"
notion-id: 378759b92751806ebf1bc27a4c0c8de4
---

# CPTS HackTheBox

In: [[Career]]

## Contents

**[[Penetration Testing Process]]**

[[Network Enumeration with Nmap]]

[[Foot Printing]]

[[File Transfers]]

[[Shells and Payloads]]

[[Active Directory Enumeration & Attacks]]
