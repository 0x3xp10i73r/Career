---
title: "CPENT Exam"
kind: moc
tags:
  - cpent-exam
  - status/not-started
  - moc
status: "Not started"
database: "Career"
area: "CPENT Exam"
up: "[[Career]]"
notion-id: 0b1759b92751837985b001ad6483aec2
---

# CPENT Exam

In: [[Career]]

## Contents

[[AD Range - 270 Points]]

[[IOT Range (Completed - 500 Pts)]]

[[Binary Range (Completed - 500 pts)]]

[[CTF Range (Completed - 500 pts)]]

[[Web Range - (Completed - 500 Points)]]
