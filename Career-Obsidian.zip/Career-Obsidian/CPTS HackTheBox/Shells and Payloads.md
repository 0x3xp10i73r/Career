---
title: "Shells and Payloads"
kind: moc
tags:
  - cpts-hackthebox
  - moc
area: "CPTS HackTheBox"
up: "[[CPTS HackTheBox]]"
notion-id: 385759b92751800d92beca0a82217ac7
---

# Shells and Payloads

In: [[Career]] / [[CPTS HackTheBox]]

## Contents

**[[Shells & Payloads - Intro]]**

[[Anatomy of a Shell]]

[[Bind Shells]]

[[Reverse Shells]]

[[Introduction to Payloads]]

[[Metasploit - Automating Payloads & Delivery]]

[[MSFvenom - Crafting Payloads]]

[[Infiltrating Windows]]

[[Infiltrating Unix - Linux|Infiltrating Unix/Linux]]

[[Spawning Interactive Shells]]

[[Laudanum Web Shells]]

[[Antak Web Shell]]

[[PHP Web Shells]]
