---
title: "Foot Printing"
kind: topic
tags:
  - cpts-hackthebox
area: "CPTS HackTheBox"
up: "[[CPTS HackTheBox]]"
notion-id: 37c759b92751806e8042d179b956fe2c
---

# Foot Printing

In: [[Career]] / [[CPTS HackTheBox]]

## Domain Information Gathering

## Methodology

```
Company Website → SSL Certs → crt.sh → DNS Records → Shodan → Third-party Analysis
```

---

## Techniques & Tools

### 1. SSL Certificate Inspection

- Check the company's main website SSL cert
- Certs often cover **multiple subdomains** → reveals active domains
- Look at DNS names listed in the cert

### 2. Certificate Transparency Logs — `crt.sh`

All SSL certs issued by CAs are logged publicly (RFC 6962). Use this to find subdomains.

```bash
# JSON output
curl -s "https://crt.sh/?q=target.com&output=json" | jq .

# Filter unique subdomains only
curl -s "https://crt.sh/?q=target.com&output=json" | jq . | grep name \
| cut -d":" -f2 | grep -v "CN=" | cut -d'"' -f2 \
| awk '{gsub(/\\n/,"\n");}1;' | sort -u
```

### 3. Resolving Subdomains to IPs

Find which subdomains are **company-hosted** (not third-party — you can't test those without permission).

```bash
for i in $(cat subdomainlist); do
  host $i | grep "has address" | grep target.com | cut -d" " -f1,4
done
```

### 4. Shodan Scan on IPs

- Finds **open ports, services, software versions** on those IPs
- Useful for: HTTP/S, SSH, FTP, SMTP, Telnet, etc.

```bash
# Collect IPs first
for i in $(cat subdomainlist); do
  host $i | grep "has address" | grep target.com | cut -d" " -f4 >> ips.txt
done

# Query Shodan
for i in $(cat ips.txt); do shodan host $i; done
```

### 5. DNS Records — `dig`

```bash
dig any target.com
```

| Record | What it reveals |
| --- | --- |
| **A** | IP addresses for (sub)domains |
| **MX** | Mail provider (e.g. Google = Gmail) |
| **NS** | Name servers → hints at hosting provider |
| **TXT** | Third-party verifications, SPF, DMARC, DKIM |
| **SOA** | Zone authority info |

## Reading TXT Records (Key Intel)

TXT records reveal **third-party services** in use:

| Entry Found | What it means |
| --- | --- |
| `atlassian-domain-verification` | Uses Jira/Confluence → dev/collab platform |
| `google-site-verification` | Google Workspace → possible open GDrive files |
| `logmein-verification-code` | Centralized remote access → high-value target |
| `mailgun` | Email API in use → test for IDOR, SSRF, PUT/POST |
| `spf.protection.outlook.com` | Office 365 → OneDrive, Azure Blob/File storage (SMB) |
| `MS=ms...` value | Likely INWX hosting login ID/username |

---

## Cloud Resources Foot Printing

Find misconfigured cloud storage (S3, Azure Blob, GCP) that is **publicly accessible without authentication**.

---

## Methodology

```
Subdomain/IP Enum → Google Dorks → Source Code Review → domain.glass → GrayHatWarfare → File Hunting
```

## Cloud Storage Types to Target

| Provider | Storage Type | Example URL Pattern |
| --- | --- | --- |
| AWS | S3 Bucket | s3-website-us-west-2.amazonaws.com |
| Azure | Blob Storage | blob.core.windows.net |
| GCP | Cloud Storage | storage.googleapis.com |

## Techniques

### 1. Subdomain → IP Lookup (spot cloud IPs)

```bash
for i in $(cat subdomainlist); do
  host $i | grep "has address" | grep target.com | cut -d" " -f1,4
done
# If output contains amazonaws.com / blob.core / googleapis → cloud storage found
```

### 2. Google Dorks

```
intext:"companyname" inurl:amazonaws.com
intext:"companyname" inurl:blob.core.windows.net
```

- Can return **PDFs, docs, presentations, code files** stored publicly
- Try company abbreviations too (e.g., `inlanefreight` → `ilf`, `ILF`)

### 3. Website Source Code Review

- Cloud storage URLs are often **hardcoded** in HTML source for loading images, JS, CSS
- Look for `dns-prefetch` / `preconnect` links pointing to blob/S3 domains
- Right-click → View Source or use browser dev tools

### 4. domain.glass

- Third-party recon tool → reveals infrastructure details
- Also shows **Cloudflare security status** → tells you if WAF/gateway is in place (note for later)

### 5. GrayHatWarfare

- Search and **filter exposed cloud buckets** by provider (AWS/Azure/GCP)
- Filter by **file type** (look for `.pdf`, `.docx`, `.pem`, `.key`, etc.)
- Can find buckets using company name or abbreviations

## What to Look For in Buckets

| File | Why it's critical |
| --- | --- |
| `id_rsa` | SSH **private key** → direct server login, no password needed |
| `id_rsa.pub` | SSH public key → confirms private key exists |
| `.env` files | API keys, DB credentials |
| PDFs / Docs | Internal data, infrastructure info |
| Source code | Hardcoded secrets, internal logic |

---

## FTP

## Key Concepts

- FTP = **File Transfer Protocol**, runs on **TCP port 21** (control) and **TCP port 20** (data)
- **Clear-text protocol** → credentials can be sniffed on the network  **UDP**, no authentication, local networks only

---

## Active vs Passive FTP

| Mode | Who initiates data channel | Firewall issue? |
| --- | --- | --- |
| **Active** | Server connects back to client | ❌ Blocked by client firewall |
| **Passive** | Client connects to server-announced port | ✅ Works through firewalls |

```
Nmap Scan → Anonymous Login Check → Directory Listing → Download Files → Upload Test → Banner/SSL Grab
```

---

## Enumeration Commands

### Nmap

```bash
# Full scan with scripts
sudo nmap -sV -p21 -sC -A 10.129.14.136

# With script trace (see raw traffic)
sudo nmap -sV -p21 -sC -A 10.129.14.136 --script-trace

# Update NSE script DB
sudo nmap --script-updatedb

# Find all FTP-related NSE scripts
find / -type f -name ftp* 2>/dev/null | grep scripts
```

**Useful NSE scripts found:**

- `ftp-anon.nse` → checks anonymous login
- `ftp-syst.nse` → grabs server status/version
- `ftp-brute.nse` → brute force
- `ftp-vsftpd-backdoor.nse` → checks backdoor vuln
- `ftp-bounce.nse` → bounce attack check

---

### Manual Interaction

```bash
# Direct connect
ftp 10.129.14.136          # then login as: anonymous

nc -nv 10.129.14.136 21    # raw netcat
telnet 10.129.14.136 21    # telnet

# For TLS/SSL encrypted FTP
openssl s_client -connect 10.129.14.136:21 -starttls ftp
# → also reveals SSL cert info (hostname, email, org)
```

---

### FTP Commands (Inside Session)

```bash
ls          # list files
ls -R       # recursive listing (if enabled) → see full dir tree
get file    # download single file
put file    # upload file
status      # show connection info
debug       # enable debug output
trace       # show packet-level trace
```

### Bulk Download

```bash
# Download everything at once (⚠️ noisy — may trigger alerts)
wget -m --no-passive ftp://anonymous:anonymous@10.129.14.136
```

---

## Dangerous Config Settings to Look For

| Setting | Risk |
| --- | --- |
| `anonymous_enable=YES` | Anyone can login |
| `anon_upload_enable=YES` | Anyone can upload files |
| `write_enable=YES` | Enables write commands |
| `no_anon_password=YES` | No password needed at all |
| `ls_recurse_enable=YES` | Full dir tree visible at once |
| `hide_ids=YES` | Hides real usernames (defensive) |

---

## Attack Paths

- Anonymous login + upload → upload web shell if FTP root = web root → RCE
- FTP logs → can be poisoned → Remote Code Execution
- LFI + FTP upload → upload malicious file, include via LFI → code execution
- SSL cert on FTP → reveals internal hostnames, emails, org structure
- Banner grabbing → reveals version → search for known CVEs

---

## Key Files (vsFTPd)

```
/etc/vsftpd.conf    → main config
/etc/ftpusers       → users DENIED FTP access
/usr/share/nmap/scripts/ftp-*  → NSE scripts
```

---

## Samba

- SMB = **Server Message Block** → file/printer/resource sharing protocol
- Runs on **TCP 445** (modern) or **TCP 139/137/138** (legacy NetBIOS)
- **Samba** = Linux/Unix implementation of SMB (cross-platform)
- ACLs control share permissions — **independent** of local file permissions

---

## SMB Versions

| Version | OS | Key Feature |
| --- | --- | --- |
| CIFS/SMB1 | Windows NT/2000 | Legacy, insecure |
| SMB 2.0 | Vista/2008 | Performance + signing |
| SMB 3.0 | Win8/2012 | Encryption, multichannel |
| SMB 3.1.1 | Win10/2016 | AES-128, integrity check |

---

## Methodology

```
Nmap Scan → Null Session → List Shares → RPC Enum → User/RID Brute → File Download
```

---

## Enumeration Commands

### 1. Nmap

```bash
sudo nmap -sV -sC -p139,445 10.129.14.128
# Reveals: Samba version, signing status, NetBIOS name, SMB dialect
```

---

### 2. smbclient (manual share browsing)

```bash
# List shares (null/anonymous session)
smbclient -N -L //10.129.14.128

# Connect to a share
smbclient //10.129.14.128/notes

# Inside session:
ls          # list files
ls -R       # recursive list
get file    # download file
put file    # upload file
!ls         # run local command without disconnecting
!cat file   # read file locally
```

---

### 3. rpcclient (deep enumeration via RPC)

```bash
# Null session login
rpcclient -U "" <IP>
```

| Command | What it returns |
| --- | --- |
| `srvinfo` | Server info + version |
| `enumdomains` | All domains on network |
| `querydominfo` | Domain/server/user count |
| `netshareenumall` | All shares + paths |
| `netsharegetinfo <share>` | Permissions on specific share |
| `enumdomusers` | All usernames + RIDs |
| `queryuser <RID>` | Full user details |
| `querygroup <RID>` | Group details |

---

### 4. RID Brute Force (find hidden users)

```bash
# RIDs are assigned sequentially — brute force to find all users
for i in $(seq 500 1100); do
  rpcclient -N -U "" 10.129.14.128 \
  -c "queryuser 0x$(printf '%x\n' $i)" \
  | grep "User Name\|user_rid\|group_rid" && echo ""
done
```

> [!note]
> RIDs start at 500 (Administrator), regular users typically from 1000+
>

---

### 5. smbmap (quick permissions overview)

```bash
smbmap -H 10.129.14.128
# Shows each share + READ/WRITE/NO ACCESS
```

---

### 6. CrackMapExec

```bash
crackmapexec smb 10.129.14.128 --shares -u '' -p ''
# Shows shares, permissions, SMB version, signing status
```

---

### 7. Impacket samrdump.py (automated user dump)

```bash
samrdump.py 10.129.14.128
# Dumps all users, UIDs, password policy, account status
```

---

### 8. enum4linux-ng (all-in-one)

```bash
./enum4linux-ng.py 10.129.14.128 -A
# Returns: OS, users, groups, shares, policies, NetBIOS, dialects
```

Install:

```bash
git clone https://github.com/cddmp/enum4linux-ng.git
cd enum4linux-ng && pip3 install -r requirements.txt
```

---

## Dangerous Config Settings

| Setting | Risk |
| --- | --- |
| `guest ok = yes` | No password needed |
| `browseable = yes` | Share visible to all |
| `writable = yes` / `read only = no` | Anyone can write |
| `create mask = 0777` | Files created with full permissions |
| `map to guest = bad user` | Failed logins → guest access |
| `logon script = script.sh` | Script runs on login → code execution |
| `magic script = script.sh` | Auto-executes script → RCE risk |

---

## What enum4linux-ng Reveals (Key Intel)

- OS version + SMB dialect supported
- Whether **null sessions** are allowed
- Domain name, workgroup, FQDN
- All **usernames + RIDs**
- Share names + **read/write access**
- **Password policy** (min length, lockout threshold, complexity)

---

## Key Takeaways

- Always try **null session** first (`N -U ""`) — very commonly misconfigured
- `enumdomusers` + `queryuser` via rpcclient = **full user recon without credentials**
- RID brute force finds users not listed in `enumdomusers`
- Writable share + web server = potential **shell upload**
- Password policy from enum4linux → informs brute force strategy (e.g., no lockout = go for it)
- **Never rely on one tool** — combine smbclient + rpcclient + enum4linux for complete picture

---

## Network File System [NFS]

## Key Concepts

- NFS = **Network File System** → Linux/Unix equivalent of SMB for file sharing
- Uses **TCP/UDP port 111** (RPC/portmapper) and **TCP/UDP port 2049** (NFS)
- Auth in NFSv3 = based on **client IP** (weak). NFSv4 = **Kerberos** (strong)
- No built-in auth/authz in NFS itself → delegated to **RPC + UID/GID**

---

## NFS Versions

| Version | Key Feature |
| --- | --- |
| NFSv2 | Old, UDP only |
| NFSv3 | Variable file size, better errors, no full auth |
| NFSv4 | Kerberos, ACLs, stateful, **single port 2049** only |

---

## Methodology

```
Nmap (port 111,2049) → showmount → Mount Share → ls -l/-n → UID Matching → File Access/Escalation
```

---

## Enumeration Commands

### 1. Nmap

```bash
# Basic scan
sudo nmap 10.129.14.128 -p111,2049 -sV -sC

# NFS-specific NSE scripts (lists shares, files, stats)
sudo nmap --script nfs* <IP> -sV -p111,2049
# Reveals: share paths, file names, permissions, UIDs, disk usage
```

---

### 2. showmount (list exported shares)

```bash
showmount -e 10.129.14.128
# Output: /mnt/nfs  10.129.14.0/24
```

---

### 3. Mount the Share

```bash
mkdir -p ~/NFS/var_nfs                                                                                                                                
mkdir -p ~/NFS/nfsshare
sudo mount -t nfs -o nolock 10.129.202.5:/var/nfs ~/NFS/var_nfs
sudo mount -t nfs -o nolock 10.129.202.5:/mnt/nfsshare ~/NFS/nfsshare
mount | grep nfs  # verify
cd target-NFS
tree .
```

---

### 4. Inspect Files + Ownership

```bash
ls -l mnt/nfs/    # shows usernames/group names
ls -n mnt/nfs/    # shows raw UID/GID numbers (critical for exploitation)
```

---

### 5. Unmount

```bash
cd ..
sudo umount ./target-NFS
```

---

## Dangerous Settings

| Option | Risk |
| --- | --- |
| `rw` | Read + write access to share |
| `insecure` | Allows ports >1024 (non-root users can interact) |
| `no_root_squash` | Root on client = root on server → **full file access** |
| `nohide` | Exposes nested mounted filesystems |

> [!note]
> **`root_squash`** (safe default) = maps root → anonymous user, limiting damage
**`no_root_squash`** (dangerous) = root keeps UID 0 → can read/write any file
> [!note]
>

---

## UID Matching Attack (Key Technique)

NFS trusts UID/GID numbers, not usernames. So:

```bash
# 1. Check UID of files on mounted share
ls -n mnt/nfs/        # e.g., file owned by UID 1000

# 2. Create same UID user on YOUR machine
sudo useradd -u 1000 attacker

# 3. Switch to that user
sudo -u attacker cat mnt/nfs/secret_file
# → NFS thinks you're the legitimate owner
```

---

## Privilege Escalation via NFS

If you have SSH access and find a writable NFS share:

1. Upload a shell binary to the NFS share
2. Set **SUID bit** matching target user's UID
3. Execute via SSH → runs as that user → **privilege escalation**

```bash
# Only works if no_root_squash is set
cp /bin/bash ./target-NFS/mnt/nfs/shell
chmod +s ./target-NFS/mnt/nfs/shell   # set SUID
```

---

## Config File

```
/etc/exports    → defines what is shared, to whom, with what options
```

Example entry:

```
/mnt/nfs  10.129.14.0/24(rw,sync,no_subtree_check)
```

---

## Key Takeaways

- NFS trusts **UID numbers not usernames** → create matching local user to access files
- `no_root_squash` = critical misconfiguration → root access to entire share
- Always run `ls -n` after mounting to see raw UIDs → plan your attack
- NFSv3 wide open on internal networks = **very common in real engagements**
- NFS share with SSH access = **easy privilege escalation path**

---

## DNS

## Key Concepts

- DNS = translates domain names → IP addresses, runs on **port 53** (TCP/UDP)
- DNS is **unencrypted by default** → can be sniffed (use DoT/DoH to encrypt)
- No central database — distributed across thousands of servers globally

---

## DNS Server Types

| Type | Role |
| --- | --- |
| Root Server | Top of hierarchy, 13 globally, managed by ICANN |
| Authoritative NS | Holds actual zone data, gives binding answers |
| Non-authoritative NS | Collects info via recursive/iterative queries |
| Caching Server | Stores results temporarily (TTL-based) |
| Forwarding Server | Just forwards queries to another server |
| Resolver | Local resolution (your PC/router) |

---

## DNS Record Types

| Record | Purpose |
| --- | --- |
| `A` | Domain → IPv4 |
| `AAAA` | Domain → IPv6 |
| `MX` | Mail server for domain |
| `NS` | Nameservers for domain |
| `TXT` | SPF, DMARC, verifications, misc info |
| `CNAME` | Alias → points to another domain |
| `PTR` | IP → Domain (reverse lookup) |
| `SOA` | Zone authority info + admin email |

---

## Methodology

```
NS Query → Version Query → ANY Query → AXFR Zone Transfer → Internal Zone Transfer → Subdomain Brute Force
```

---

## Enumeration Commands

### 1. NS Records (find nameservers)

```bash
dig ns inlanefreight.htb @10.129.14.128
# Reveals other DNS servers → query them too, may have different configs
```

### 2. DNS Version (CHAOS query)

```bash
dig CH TXT version.bind 10.129.14.128
# Returns BIND version → search for CVEs against that version
```

### 3. ANY Query (dump all records)

```bash
dig any inlanefreight.htb @10.129.14.128
# Returns all records server is willing to show
# Reveals: TXT (third-party services), NS, SOA, A records
```

### 4. SOA Record

```bash
dig soa www.inlanefreight.com
# Returns: primary NS, admin email (@ replaced by .), serial, TTL values
```

### 5. Zone Transfer — AXFR (critical attack)

```bash
# External zone
dig axfr inlanefreight.htb @10.129.14.128

# Internal zone (if discovered)
dig axfr internal.inlanefreight.htb @10.129.14.128
```

> [!note]
> If `allow-transfer` is misconfigured → dumps **entire zone** including internal hostnames and IPs
>

---

### 6. Subdomain Brute Force

```bash
# Manual bash loop
for sub in $(cat /opt/useful/seclists/Discovery/DNS/subdomains-top1million-110000.txt); do
  dig $sub.inlanefreight.htb @10.129.14.128 \
  | grep -v ';\|SOA' | sed -r '/^\s*$/d' \
  | grep $sub | tee -a subdomains.txt
done

# Automated with dnsenum
dnsenum --dnsserver 10.129.14.128 --enum -p 0 -s 0 \
-o subdomains.txt \
-f /opt/useful/seclists/Discovery/DNS/subdomains-top1million-110000.txt \
inlanefreight.htb
```

---

## Config Files (BIND9)

| File | Purpose |
| --- | --- |
| `/etc/bind/named.conf.local` | Zone definitions |
| `/etc/bind/named.conf.options` | Global server options |
| `/etc/bind/db.domain.com` | Forward zone file (name → IP) |
| `/etc/bind/db.10.129.14` | Reverse zone file (IP → name, PTR records) |

---

```bash
dig NS domain.com
dig ANY domain.com
dig AXFR domain.com @dns-server
dnsenum domain.com
```

---

## What AXFR Zone Transfer Reveals

From internal zone dump example:

```
dc1.internal.inlanefreight.htb  → 10.129.34.16   (Domain Controller!)
dc2.internal.inlanefreight.htb  → 10.129.34.11
mail1.internal...               → 10.129.18.200
vpn.internal...                 → 10.129.1.6
wsus.internal...                → 10.129.18.2    (Windows Update Server)
ws1/ws2.internal...             → workstations
```

---

## Key Takeaways

- **AXFR zone transfer** = most powerful DNS attack → reveals entire infrastructure if misconfigured
- Always try **internal subdomains** after finding them (separate zone, often more exposed)
- TXT records = goldmine for third-party service discovery
- DNS version via CHAOS query → direct CVE lookup
- Use **dnsenum** for automated NS, MX, AXFR + brute force in one tool
- SOA admin email format: `hostmaster.domain.com` → actual email is `hostmaster@domain.com`
