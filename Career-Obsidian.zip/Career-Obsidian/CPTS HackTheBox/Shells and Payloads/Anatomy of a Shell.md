---
title: "Anatomy of a Shell"
kind: topic
tags:
  - cpts-hackthebox
area: "CPTS HackTheBox"
up: "[[Shells and Payloads]]"
notion-id: 385759b92751802ba1a2dee368646195
---

# Anatomy of a Shell

In: [[Career]] / [[CPTS HackTheBox]] / [[Shells and Payloads]]

## Three Components of a "Command-Line Interface"

```
Operating System + Terminal Emulator + Command Language Interpreter = CLI
```

These three are **distinct and separable** — a terminal emulator doesn't lock you into one shell language.

---

## 1. Terminal Emulator

A program that lets you **interact** with a shell. It's just the window/interface — not the shell itself.

| Emulator | OS |
| --- | --- |
| Windows Terminal, cmder, PuTTY | Windows |
| kitty, Alacritty | Windows/Linux/macOS |
| xterm, GNOME Terminal, MATE Terminal, Konsole | Linux |
| Terminal, iTerm2 | macOS |

> [!note]
> Choice of emulator = personal/stylistic preference, not functionally critical
>

---

## 2. Command Language Interpreter

The actual program that **parses and executes** your typed commands (translates human input → OS instructions).

- Examples: Bash, Zsh, Ksh, PowerShell, cmd
- Also called: **shell scripting languages** or **Command and Scripting Interpreters** (MITRE ATT&CK Execution category)
- Each interpreter has its **own command set and syntax**

> [!note]
> Knowing which interpreter is running tells you exactly what commands/syntax will work
>

---

## How to Identify the Active Shell

### Visual Cue

- `$` prompt → typically Bash, Ksh, POSIX-compliant shells

### Method 1: `ps` command

```bash
ps
#   PID TTY    TIME CMD
#  4232 pts/1  00:00:00 bash   ← shows active shell process
```

### Method 2: `env` command

```bash
env
# SHELL=/bin/bash
```

---

## Key Insight: Terminal ≠ Shell Language

- Same terminal emulator (e.g., MATE Terminal) can run **different interpreters**:
    - One icon → Bash
    - Another icon → PowerShell (yes, PowerShell runs on Linux too — v7.1.3+)
- The shell language is **configurable/customizable** per user/workflow needs

---

## Why This Matters for Pentesting

- When you land a shell on a target, **identify the interpreter first** (`ps`, `env`, or prompt style)
- Wrong assumptions about shell type = broken commands, wasted time, or even alerting defenders
- Different interpreters = different built-in capabilities for file transfer, execution, evasion (ties back to LOLBins/GTFOBins)

---

## Key Takeaways

- CLI = OS + Terminal Emulator + Interpreter — **three separate, swappable layers**
- `$` prompt is a strong hint (but not proof) you're in a POSIX-style shell
- Always verify shell type on a new target using `ps` or `env` before running OS-specific commands
- PowerShell isn't Windows-exclusive — it runs cross-platform now
