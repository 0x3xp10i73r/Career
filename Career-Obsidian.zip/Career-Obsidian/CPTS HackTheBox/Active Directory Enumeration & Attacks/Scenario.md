---
title: "Scenario"
kind: topic
tags:
  - cpts-hackthebox
area: "CPTS HackTheBox"
up: "[[Active Directory Enumeration & Attacks]]"
notion-id: 3e9759b92751801e85cee531631c952a
---

# Scenario

In: [[Career]] / [[CPTS HackTheBox]] / [[Active Directory Enumeration & Attacks]]

## Engagement Scope — Inlanefreight

**Client:** Inlanefreight | **Firm:** CAT-5 Security

### In Scope

| Target | Notes |
| --- | --- |
| `INLANEFREIGHT.LOCAL` | Primary domain — AD + web services |
| `LOGISTICS.INLANEFREIGHT.LOCAL` | Subdomain |
| `FREIGHTLOGISTICS.LOCAL` | Subsidiary — **external forest trust** with primary |
| `172.16.5.0/23` | Internal subnet |

### Out of Scope

- Other subdomains not listed
- Phishing / social engineering
- Active attacks against real `inlanefreight.com`

### Starting Position

- **Anonymous** on internal network (no creds given)
- Goal: creds → enum → foothold → lateral movement → **Domain Admin**

### Authorized Methods

- Passive external OSINT (no active scanning of real-world IPs)
- Internal: full AD attack simulation from untrusted insider position
- Offline password cracking of captured hashes

---

## Assessment Task Checklist

```
☐ Domain enumeration
☐ Credential discovery
☐ Lateral movement
☐ Privilege escalation
☐ Domain Admin credentials acquired
☐ Compromise all in-scope domains
```

---

## Key Reminder for Real Engagements

Always verify before touching anything:

- Is this IP/domain explicitly in the scope document?
- Is this method listed as authorized?
- Do you have signed written approval?
