---
title: README
kind: meta
tags:
  - meta
aliases:
  - Read me
---

# README

Open this folder in Obsidian with **Open folder as vault**, then start at [[Career]].

Screenshots are not in this zip. Each note already embeds the path the file should have. The mapping is `Meta/image-manifest.json`.
