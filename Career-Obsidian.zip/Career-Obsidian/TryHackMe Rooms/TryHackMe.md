---
title: "TryHackMe"
kind: database
tags:
  - tryhackme-rooms
  - database
area: "TryHackMe Rooms"
up: "[[TryHackMe Rooms]]"
notion-id: 951759b9275182c2ac690111f52e1260
---

# TryHackMe

In: [[Career]] / [[TryHackMe Rooms]]

## All notes

21 notes. Properties are on each note, so the table stays in sync with the files.

| Name | Status | Difficulty | Type | Tags | Date | URL |
| --- | --- | --- | --- | --- | --- | --- |
| [[CyberHeroes]] | 🔄 In progress | Easy | Challenege | Web | 2026-04-06 | [open](https://tryhackme.com/room/cyberheroes) |
| [[Lazy Admin]] | ✅ Done | Easy | Challenege | Web | 2026-05-02 | [open](https://tryhackme.com/room/lazyadmin) |
| [[Ignite]] | ✅ Done | Easy | Challenege | Web | 2026-05-05 | [open](https://tryhackme.com/room/ignite) |
| [[RootMe]] | ✅ Done | Easy | Challenege | Linux, Web | 2026-05-05 | [open](https://tryhackme.com/room/rrootme) |
| [[Rabbit Store]] | 🔄 In progress | Medium | Challenege | Linux | 2026-05-12 |  |
| [[U.A. High School]] | ⬜ Not started | Easy | Challenege | Linux | 2026-05-21 |  |
| [[Oh My WebServer]] | 🔄 In progress | Medium | Challenege | Linux |  | [open](https://tryhackme.com/room/ohmyweb) |
| [[TryHack3M - Burg3r Bytes\|TryHack3M: Burg3r Bytes]] | 🔄 In progress | Hard | Challenege | Web |  | [open](https://tryhackme.com/room/burg3rbytes) |
| [[TryHackMe/Linux Privilege Escalation\|Linux Privilege Escalation]] | 🔄 In progress | Medium | Walkthrough + Challenge | Linux |  | [open](https://tryhackme.com/room/linuxprivescarena) |
| [[Include]] | 🔄 In progress | Medium | Challenege | Linux, Web |  | [open](https://tryhackme.com/room/include) |
| [[Corp Website (Done)]] | ✅ Done | Medium | Challenege | CVE, Web |  | [open](https://tryhackme.com/room/lafb2026e7) |
| [[Hammer]] | ✅ Done | Medium | Challenege | Web |  | [open](https://tryhackme.com/room/hammer) |
| [[Pickle Rick]] | ✅ Done | Easy | Challenege | Linux, Web |  | [open](https://tryhackme.com/room/picklerick) |
| [[UltraTech (Done)]] | ✅ Done | Medium | Challenege | Linux, Web |  | [open](https://tryhackme.com/room/ultratech1) |
| [[Watcher]] | ✅ Done | Medium | Challenege | Linux, Web |  | [open](https://tryhackme.com/room/watcher) |
| [[Simple CTF]] | ✅ Done | Easy | Challenege | Linux, Web |  | [open](https://tryhackme.com/room/easyctf) |
| [[Advance SQL Injection]] | ✅ Done | Medium | Walkthrough + Challenge | Web |  | [open](https://tryhackme.com/room/advancedsqlinjection) |
| [[Daily Bugle]] | ✅ Done | Hard | Challenege | Linux, Web |  | [open](https://tryhackme.com/room/dailybugle) |
| [[Skynet]] | ✅ Done | Easy | Challenege | Linux | 2026-06-03 | [open](https://tryhackme.com/room/skynet) |
| [[Anonymous]] | ⬜ Not started | Easy | Challenege | Linux | 2026-06-12 |  |
| [[Debug]] | ✅ Done | Medium | Challenege | Linux, Web | 2026-07-09 |  |

%% Install the Dataview community plugin to turn the block below into a live, sortable table. The markdown table above works without it. %%

```dataview
TABLE status AS Status, difficulty AS Difficulty, date AS Date, tags AS Tags
FROM "TryHackMe Rooms/TryHackMe"
WHERE database = "TryHackMe"
SORT file.name ASC
```
