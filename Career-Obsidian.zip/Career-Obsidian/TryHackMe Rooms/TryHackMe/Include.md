---
title: "Include"
kind: writeup
tags:
  - tryhackme-rooms
  - status/in-progress
  - writeup
  - linux
  - web
  - challenege
status: "In progress"
difficulty: "Medium"
url: "https://tryhackme.com/room/include"
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: 195759b92751829ba9c3816c14c82b9b
---

# Include

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

## Nmap Scan

```bash
╰─ nmap -p- --min-rate 1000 -T4 -sV -Pn -oA nmap_full_scan 10.48.148.60                                                                                                                  ─╯
Starting Nmap 7.95 ( https://nmap.org ) at 2026-03-16 11:42 IST
Nmap scan report for 10.48.148.60
Host is up (0.0088s latency).
Not shown: 65527 closed tcp ports (reset)
PORT      STATE SERVICE  VERSION
22/tcp    open  ssh      OpenSSH 8.2p1 Ubuntu 4ubuntu0.11 (Ubuntu Linux; protocol 2.0)
25/tcp    open  smtp     Postfix smtpd
110/tcp   open  pop3     Dovecot pop3d
143/tcp   open  imap     Dovecot imapd (Ubuntu)
993/tcp   open  ssl/imap Dovecot imapd (Ubuntu)
995/tcp   open  ssl/pop3 Dovecot pop3d
4000/tcp  open  http     Node.js (Express middleware)
50000/tcp open  http     Apache httpd 2.4.41 ((Ubuntu))
Service Info: Host:  mail.filepath.lab; OS: Linux; CPE: cpe:/o:linux:linux_kernel
```

## Fuzzing Port No - 50000

```bash
 ffuf -u "http://10.48.148.60:50000/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r                                                                            ─╯

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.48.148.60:50000/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 950ms]
.htpasswd               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 1941ms]
javascript              [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 107ms]
phpmyadmin              [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 91ms]
server-status           [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 34ms]
templates               [Status: 200, Size: 2206, Words: 132, Lines: 23, Duration: 10ms]
uploads                 [Status: 200, Size: 948, Words: 61, Lines: 17, Duration: 12ms]
:: Progress: [20481/20481] :: Job [1/1] :: 3846 req/sec :: Duration: [0:00:09] :: Errors: 0 ::
```

![[attachments/TryHackMe Rooms/TryHackMe/Include/image.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Include/image 1.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Include/image 2.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Include/image 3.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Include/image 4.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Include/image 5.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Include/image 6.png]]
