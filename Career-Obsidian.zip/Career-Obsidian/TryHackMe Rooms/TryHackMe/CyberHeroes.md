---
title: "CyberHeroes"
kind: writeup
tags:
  - tryhackme-rooms
  - status/in-progress
  - writeup
  - web
  - challenege
status: "In progress"
difficulty: "Easy"
date: 2026-04-06
url: "https://tryhackme.com/room/cyberheroes"
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: a70759b9275182138df901516f2cb9a2
---

# CyberHeroes

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

## Nmap Scan

```bash
┌──(0x3xp10i73r㉿hacker)-[~/nmap]
└─$ sudo nmap -p- --min-rate 1000 -T4 -sV -Pn -oA nmap_full_scan 10.48.134.196      
Password:
Starting Nmap 7.99 ( https://nmap.org ) at 2026-04-06 23:28 +0530
Stats: 0:00:07 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 18.02% done; ETC: 23:29 (0:00:32 remaining)
Nmap scan report for 10.48.134.196
Host is up (0.035s latency).
Not shown: 65533 closed tcp ports (reset)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.4 (Ubuntu Linux; protocol 2.0)
80/tcp open  http    Apache httpd 2.4.48 ((Ubuntu))
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 46.89 seconds
```

![[attachments/TryHackMe Rooms/TryHackMe/CyberHeroes/Screenshot_2026-04-06_at_11.31.20_PM.png]]
