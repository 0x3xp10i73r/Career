---
title: "Anonymous"
kind: writeup
tags:
  - tryhackme-rooms
  - status/not-started
  - writeup
  - linux
  - challenege
status: "Not started"
difficulty: "Easy"
date: 2026-06-12
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: 37d759b9275180f39902d035f54a9eeb
---

# Anonymous

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

## Nmap

```bash
┌──(kali㉿kali)-[~]
└─$ nmap -p- --min-rate 1000 -T4 -Pn -sV -oA nmap/nmap_full_scan 10.48.134.216
Starting Nmap 7.99 ( https://nmap.org ) at 2026-06-12 04:56 -0400
Nmap scan report for 10.48.134.216
Host is up (0.022s latency).
Not shown: 65531 closed tcp ports (reset)
PORT     STATE SERVICE    VERSION
22/tcp   open  ssh        OpenSSH 7.2p2 Ubuntu 4ubuntu2.8 (Ubuntu Linux; protocol 2.0)
53/tcp   open  tcpwrapped
8009/tcp open  ajp13      Apache Jserv (Protocol v1.3)
8080/tcp open  http       Apache Tomcat 9.0.30
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 22.50 seconds

```

![[attachments/TryHackMe Rooms/TryHackMe/Anonymous/image.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Anonymous/image 1.png]]
