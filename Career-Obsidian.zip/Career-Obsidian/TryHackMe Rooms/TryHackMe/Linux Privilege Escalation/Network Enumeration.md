---
title: "Network Enumeration"
kind: topic
tags:
  - tryhackme-rooms
area: "TryHackMe Rooms"
up: "[[TryHackMe/Linux Privilege Escalation|Linux Privilege Escalation]]"
notion-id: d74759b927518227956e01dff3c584c9
---

# Network Enumeration

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]] / [[TryHackMe/Linux Privilege Escalation|Linux Privilege Escalation]]

```bash
ip a
ip route
netstat -tulpn
netstat -antp
arp -a
cat /etc/resolv.conf
cat /etc/hosts
```
