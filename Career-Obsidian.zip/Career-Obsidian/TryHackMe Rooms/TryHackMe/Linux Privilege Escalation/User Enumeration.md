---
title: "User Enumeration"
kind: topic
tags:
  - tryhackme-rooms
area: "TryHackMe Rooms"
up: "[[TryHackMe/Linux Privilege Escalation|Linux Privilege Escalation]]"
notion-id: f6b759b9275182d5a09681323116499a
---

# User Enumeration

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]] / [[TryHackMe/Linux Privilege Escalation|Linux Privilege Escalation]]

| Command | What it does (one line) |
| --- | --- |
| `whoami` | Displays the username of the currently logged-in user. |
| `id` | Shows the current user's UID, GID, and group memberships. |
| `sudo -l` | Lists the commands the current user is allowed to run with sudo privileges. |
| `history` | Displays the list of previously executed shell commands. |
| `cat /etc/passwd` | Shows user account information such as usernames, UID, home directory, and shell. |
| `cat /etc/shadow` | Displays encrypted user password hashes and password policy info (usually requires root). |
| `cat /etc/group`  | Shows system groups and the users belonging to each group. |
