---
title: "Pickle Rick"
kind: writeup
tags:
  - tryhackme-rooms
  - status/done
  - writeup
  - linux
  - web
  - challenege
status: "Done"
difficulty: "Easy"
url: "https://tryhackme.com/room/picklerick"
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: aa2759b927518393b627815fc40acb38
---

# Pickle Rick

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

## Nmap Scan

```
nmap -p- --min-rate 1000 -T4 -sV -Pn -oA nmap_full_scan 10.48.160.230    
                                                                                                             ─╯
Starting Nmap 7.95 ( https://nmap.org ) at 2026-03-09 12:16 IST
Nmap scan report for 10.48.160.230
Host is up (0.022s latency).
Not shown: 65533 closed tcp ports (reset)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.11 (Ubuntu Linux; protocol 2.0)
80/tcp open  http    Apache httpd 2.4.41 ((Ubuntu))
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 15.81 seconds
```

## Fuzzing Directories

```
╰─ ffuf -u "http://10.48.160.230/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r                                                                                 ─╯

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.48.160.230/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 11ms]
.htaccess               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 2112ms]
assets                  [Status: 200, Size: 2192, Words: 125, Lines: 23, Duration: 9ms]
robots.txt              [Status: 200, Size: 17, Words: 1, Lines: 2, Duration: 8ms]
server-status           [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 28ms]
:: Progress: [20481/20481] :: Job [1/1] :: 3125 req/sec :: Duration: [0:00:09] :: Errors: 0 ::
```

## Username Enumeration

![[attachments/TryHackMe Rooms/TryHackMe/Pickle Rick/image.png]]

## Password Enumeration

![[attachments/TryHackMe Rooms/TryHackMe/Pickle Rick/image 1.png]]

## Basic Enumeration

![[attachments/TryHackMe Rooms/TryHackMe/Pickle Rick/image 2.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Pickle Rick/image 3.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Pickle Rick/image 4.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Pickle Rick/image 5.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Pickle Rick/image 6.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Pickle Rick/image 7.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Pickle Rick/image 8.png]]
