---
title: "Types of SQL Injection"
kind: topic
tags:
  - tryhackme-rooms
area: "TryHackMe Rooms"
up: "[[Advance SQL Injection]]"
notion-id: 08b759b927518363b9510196182ee8d0
---

# Types of SQL Injection

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]] / [[Advance SQL Injection]]

### In-Band SQL Injection

**Definition**

- SQL injection technique where the **same communication channel** is used to both **inject the payload and retrieve the results**.
- Considered the **most common and easiest SQL injection type** to exploit.

#### How It Works

- Attacker injects SQL code into a vulnerable input field.
- The database executes the manipulated query.
- Query results are returned **directly in the web application's response**.
- Attackers analyse the response to extract database information or sensitive data.

#### Commands / Payloads

**Error-Based SQL Injection Example**

```sql
SELECT * FROM users WHERE id = 1 AND 1=CONVERT(int, (SELECT @@version));
```

**Union-Based SQL Injection Example**

```sql
SELECT name, email FROM users WHERE id = 1
UNION ALL
SELECT username, password FROM admin;
```

#### Detection / Mitigation

- Use **parameterized queries or prepared statements**
- Disable **detailed database error messages**
- Implement **Web Application Firewalls (WAF)**
- Perform **input validation and output encoding**

---

## Error-Based SQL Injection

**Definition**

- SQL injection technique that forces the database to generate **error messages containing useful information** about the database structure.

#### How It Works

- Attacker manipulates a query to trigger a database error.
- The database returns detailed error information.
- Error messages may reveal:
    - Database version
    - Table names
    - Column names
    - Query structure
- The attacker uses this information to craft further exploitation payloads.

#### Commands / Payloads

```sql
SELECT * FROM users WHERE id = 1 AND 1=CONVERT(int, (SELECT @@version));
```

#### Detection / Mitigation

- Disable **verbose database errors**
- Use **custom application error handling**
- Use **prepared statements**
- Log abnormal query failures

---

## Union-Based SQL Injection

**Definition**

- SQL injection technique that uses the **UNION operator** to combine attacker-controlled queries with legitimate queries.

#### How It Works

- The attacker injects a **UNION SELECT statement**.
- The database merges results from the original query and the injected query.
- Sensitive information from other tables can be retrieved in the application response.

#### Commands / Payloads

```sql
SELECT name, email FROM users WHERE id = 1
UNION ALL
SELECT username, password FROM admin;
```

#### Detection / Mitigation

- Enforce **strict input validation**
- Use **prepared statements**
- Restrict database permissions
- Monitor unusual query patterns

---

## Inferential (Blind) SQL Injection

**Definition**

- SQL injection technique where **data is not directly returned**, and attackers infer database information by observing application behaviour.

#### How It Works

- Attacker injects conditional SQL queries.
- The application behaves differently depending on the result of the condition.
- Attackers analyse:
    - Page content changes
    - Response timing
    - Application behaviour
- Information about the database is extracted **bit by bit**.

#### Detection / Mitigation

- Monitor repeated conditional queries.
- Use **parameterized queries**
- Implement **rate limiting and WAF rules**

---

## Boolean-Based Blind SQL Injection

**Definition**

- Blind SQL injection technique where attackers determine database information by sending **true or false conditions**.

#### How It Works

- Inject a condition that evaluates to **true or false**.
- The application's response changes depending on the result.
- The attacker interprets these changes to extract information.

#### Commands / Payloads

**True Condition**

```sql
SELECT * FROM users WHERE id = 1 AND 1=1;
```

**False Condition**

```sql
SELECT * FROM users WHERE id = 1 AND 1=2;
```

#### Detection / Mitigation

- Detect repeated conditional queries.
- Implement strict input validation.
- Use prepared statements.
- Apply application behaviour monitoring.

---

## Time-Based Blind SQL Injection

**Definition**

- Blind SQL injection technique where attackers use **intentional database delays** to determine whether a condition is true or false.

#### How It Works

- A payload introduces a **time delay when a condition evaluates to true**.
- The attacker measures the server response time.
- A delayed response confirms the condition is true.

#### Commands / Payloads

```sql
SELECT * FROM users WHERE id = 1;
IF (1=1) WAITFOR DELAY '00:00:05'--;
```

#### Detection / Mitigation

- Monitor unusual query execution delays.
- Detect repeated timing-based requests.
- Use parameterized queries.
- Apply database query monitoring.

---

## Out-of-Band SQL Injection

**Definition**

- SQL injection technique used when **data cannot be retrieved through the normal application response channel**.
- Data is exfiltrated through **external communication channels** such as HTTP or DNS.

#### How It Works

- Attacker injects a SQL payload.
- The database triggers an **external network request**.
- Sensitive data is embedded in that request.
- The attacker receives the data on a controlled server.

#### Detection / Mitigation

- Monitor outbound **DNS or HTTP traffic** from database servers.
- Restrict outbound connections from database infrastructure.
- Disable database functions capable of external communication.
- Apply prepared statements and input validation.
