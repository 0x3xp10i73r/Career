---
title: "Rabbit Store"
kind: writeup
tags:
  - tryhackme-rooms
  - status/in-progress
  - writeup
  - linux
  - challenege
status: "In progress"
difficulty: "Medium"
date: 2026-05-12
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: 32b759b927518283ba87812650c376b5
---

# Rabbit Store

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

## Recon

## Nmap Scan

```bash
┌──(exp10i73r㉿kali)-[/mnt/hgfs/TryHackMe/Medium-RabbitStore]
└─$ nmap -p- --min-rate 1000 -T4 -Pn -sV -oA nmap_full_scan 10.49.170.71
Starting Nmap 7.99 ( https://nmap.org ) at 2026-05-12 17:16 +0530
Stats: 0:00:50 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 73.76% done; ETC: 17:17 (0:00:18 remaining)
Stats: 0:03:22 elapsed; 0 hosts completed (1 up), 1 undergoing Script Scan
NSE Timing: About 99.46% done; ETC: 17:19 (0:00:00 remaining)
Nmap scan report for 10.49.170.71
Host is up (0.064s latency).
Not shown: 65531 closed tcp ports (reset)
PORT      STATE SERVICE VERSION
22/tcp    open  ssh     OpenSSH 8.9p1 Ubuntu 3ubuntu0.10 (Ubuntu Linux; protocol 2.0)
80/tcp    open  http    Apache httpd 2.4.52
4369/tcp  open  epmd    Erlang Port Mapper Daemon
25672/tcp open  unknown
Service Info: Host: 127.0.1.1; OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 205.90 seconds

```

### Fuzzing the IP

```bash
                                                                                          
┌──(exp10i73r㉿kali)-[/mnt/hgfs/TryHackMe/Medium-RabbitStore]
└─$ ffuf -u "http://cloudsite.thm/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://cloudsite.thm/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 67ms]
.htaccess               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 67ms]
assets                  [Status: 301, Size: 315, Words: 20, Lines: 10, Duration: 67ms]
javascript              [Status: 301, Size: 319, Words: 20, Lines: 10, Duration: 67ms]
server-status           [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 70ms]
:: Progress: [20481/20481] :: Job [1/1] :: 355 req/sec :: Duration: [0:00:35] :: Errors: 0 ::
                                                                                                                    
┌──(exp10i73r㉿kali)-[/mnt/hgfs/TryHackMe/Medium-RabbitStore]
└─$ ffuf -u "http://storage.cloudsite.thm/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt

        /'___\  /'___\           /'___\       
       /\ \__/ /\ \__/  __  __  /\ \__/       
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\      
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/      
         \ \_\   \ \_\  \ \____/  \ \_\       
          \/_/    \/_/   \/___/    \/_/       

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://storage.cloudsite.thm/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htaccess               [Status: 403, Size: 286, Words: 20, Lines: 10, Duration: 73ms]
.htpasswd               [Status: 403, Size: 286, Words: 20, Lines: 10, Duration: 91ms]
assets                  [Status: 301, Size: 331, Words: 20, Lines: 10, Duration: 61ms]
css                     [Status: 301, Size: 328, Words: 20, Lines: 10, Duration: 64ms]
fonts                   [Status: 301, Size: 330, Words: 20, Lines: 10, Duration: 70ms]
images                  [Status: 301, Size: 331, Words: 20, Lines: 10, Duration: 78ms]
javascript              [Status: 301, Size: 335, Words: 20, Lines: 10, Duration: 77ms]
js                      [Status: 301, Size: 327, Words: 20, Lines: 10, Duration: 69ms]
server-status           [Status: 403, Size: 286, Words: 20, Lines: 10, Duration: 59ms]
:: Progress: [20481/20481] :: Job [1/1] :: 322 req/sec :: Duration: [0:00:36] :: Errors: 0 ::

```

## Account Registration

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/image.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/image 1.png]]

## Post Login Error

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/image 2.png]]

## Trying Diff Methods

### Manipulate inactive to active

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/image 3.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/image 4.png]]

## Tried JWT none algo, auth bypass, SQL Injection but nothing worked

## Exploiting Mass Assignment

## Did Mass assignment and user got registered successfully

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/image 5.png]]

## Login using same creds

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/image 6.png]]

## Finding Hidden API endpoints

## Uploading Via URL

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/Screenshot_2026-05-17_at_16-08-54.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/Screenshot_2026-05-17_at_16-07-50.png]]

## Visiting the uploaded file and gets downloaded

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/Screenshot_2026-05-17_at_16-10-38.png]]

## Exploiting Server Side Template Injection

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/Screenshot_2026-05-17_at_16-13-15.png]]

## SSTI confirmed

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/Screenshot_2026-05-17_at_16-15-13.png]]

## RCE

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/Screenshot_2026-05-17_at_16-37-14.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/image 7.png]]

## Obtaining the reverse shell

![[attachments/TryHackMe Rooms/TryHackMe/Rabbit Store/image 8.png]]

## After Spawning the Shell

```text
python3 -c 'import pty; pty.spawn("/bin/bash")'
ctrl+z

stty raw -echo; fg

export TERM=xterm
	reset
```
