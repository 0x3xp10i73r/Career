---
title: "BlackTop"
kind: topic
tags:
  - bug-thive-labs
area: "Bug Thive Labs"
up: "[[Bug Thive Labs]]"
notion-id: 38d759b92751801b9019d67af9dda1b1
---

# BlackTop

In: [[Career]] / [[Bug Thive Labs]]

## Nmap Scan

```bash
┌──(root㉿kali)-[~]
└─# nmap -sC -sV -p- -Pn --min-rate=1000 -oA nmap/blacktop 172.18.221.78
Starting Nmap 7.99 ( https://nmap.org ) at 2026-06-28 17:54 +0530
Stats: 0:00:50 elapsed; 0 hosts completed (1 up), 1 undergoing Script Scan
NSE Timing: About 99.30% done; ETC: 17:55 (0:00:00 remaining)
Nmap scan report for 172.18.221.78
Host is up (0.096s latency).
Not shown: 65532 closed tcp ports (reset)
PORT     STATE SERVICE VERSION
22/tcp   open  ssh     OpenSSH 8.2p1 (protocol 2.0)
| ssh-hostkey: 
|   3072 9f:35:6b:ad:65:e9:00:30:62:00:0b:69:9e:33:0e:2e (RSA)
|   256 5a:56:55:d3:fd:9c:af:b4:7c:69:0a:f8:cd:84:87:c1 (ECDSA)
|_  256 9c:f9:b3:7b:1d:7d:77:cb:65:6a:f7:d1:15:7f:90:cf (ED25519)
80/tcp   open  http    nginx 1.18.0 (Ubuntu)
|_http-title: Blacktop Portal
|_http-server-header: nginx/1.18.0 (Ubuntu)
6379/tcp open  redis   Redis key-value store 5.0.5
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 52.90 seconds
                                                                    
```

![[attachments/Bug Thive Labs/BlackTop/Screenshot_2026-06-28_at_17-57-54.png]]

![[attachments/Bug Thive Labs/BlackTop/Screenshot_2026-06-28_at_17-58-30.png]]
