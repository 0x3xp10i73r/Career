---
title: Image manifest
kind: meta
tags:
  - meta
aliases:
  - image manifest
---

# Image manifest

This note is only a pointer. The machine-readable map is `Meta/image-manifest.json` in the vault folder.

Each screenshot embed in the notes already uses its final Obsidian path. When the image files are available, copy each source file to the `target` path in that JSON. Do not rename the destination.

`filename_unique` is true only for names that occur once. `image.png` is not unique — match the folder as well.
