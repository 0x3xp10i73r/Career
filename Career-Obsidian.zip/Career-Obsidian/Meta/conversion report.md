---
title: Conversion report
kind: meta
tags:
  - meta
---

# Conversion report

- Notes written: 419
- Wikilinks created: 334
- External links kept: 53
- Image embeds: 872
- Notes with images: 169
- Unresolved internal links: 0
- Mid-word bold repairs: 2
- Children linked because Notion had not linked them: 0

## Code fence languages retagged

- `fence jsx→bash`: 33
- `fence jsx→html`: 1
- `fence jsx→javascript`: 30
- `fence jsx→json`: 2
- `fence jsx→python`: 1
- `fence jsx→sql`: 6
- `fence jsx→text`: 76
- `fence plain→bash`: 34
- `fence plain→html`: 6
- `fence plain→javascript`: 1
- `fence plain→sql`: 3

## Unresolved links

- None

## Images

Filenames like `image.png` repeat across notes, so a flat folder of images is not enough. Match on the parent folder plus filename, or on any `match_keys` suffix in `image-manifest.json`.

Most common filenames:

- `image.png` × 154
- `image 1.png` × 140
- `image 2.png` × 119
- `image 3.png` × 91
- `image 4.png` × 62
- `image 5.png` × 43
- `image 6.png` × 30
- `image 7.png` × 16
- `image 8.png` × 12
- `image 9.png` × 7
- `image 10.png` × 6
- `image 11.png` × 3
