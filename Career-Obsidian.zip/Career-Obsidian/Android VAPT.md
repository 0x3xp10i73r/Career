---
title: "Android VAPT"
kind: moc
tags:
  - android-vapt
  - status/not-started
  - moc
status: "Not started"
database: "Career"
area: "Android VAPT"
up: "[[Career]]"
notion-id: c0f759b9275183cb84020192164951a1
---

# Android VAPT

In: [[Career]]

## Contents

[[Intro]]

[[Android Architecture]]

[[Mobile OWASP Top 10]]

[[Android Pentesting Notes]]

[[CheckList]]
