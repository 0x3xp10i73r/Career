---
title: "PortSwigger Academy Labs"
kind: database
tags:
  - portswigger-academy-labs
  - status/not-started
  - database
status: "Not started"
database: "Career"
area: "PortSwigger Academy Labs"
up: "[[Career]]"
notion-id: 340759b9275180499532fb6fd0330b25
---

# PortSwigger Academy Labs

In: [[Career]]

## All notes

22 notes. Properties are on each note, so the table stays in sync with the files.

| Name | Status | Level | Vulnerability |
| --- | --- | --- | --- |
| [[PortSwigger Academy Labs/Lab - Reflected XSS into HTML context with nothing encoded\|Lab: Reflected XSS into HTML context with nothing encoded]] | ✅ Done | APPRENTICE | Cross-Site Scripting |
| [[PortSwigger Academy Labs/Lab - Stored XSS into HTML context with nothing encoded\|Lab: Stored XSS into HTML context with nothing encoded]] | ✅ Done | APPRENTICE | Cross-Site Scripting |
| [[PortSwigger Academy Labs/Lab - DOM XSS in document.write sink using source location.search\|Lab: DOM XSS in document.write sink using source location.search]] | ✅ Done | APPRENTICE | Cross-Site Scripting |
| [[PortSwigger Academy Labs/Lab - DOM XSS in innerHTML sink using source location.search\|Lab: DOM XSS in innerHTML sink using source location.search]] | ✅ Done | APPRENTICE | Cross-Site Scripting |
| [[Lab - DOM-based open redirection\|Lab: DOM-based open redirection]] | ⬜ Not started | PRACTITIONER | Open redirection |
| [[PortSwigger Academy Labs/Lab - SQL injection vulnerability in WHERE clause allowing retrieval of hidden data\|Lab: SQL injection vulnerability in WHERE clause allowing retrieval of hidden data]] | ✅ Done | APPRENTICE | SQL Injection |
| [[PortSwigger Academy Labs/Lab - SQL injection vulnerability allowing login bypass\|Lab: SQL injection vulnerability allowing login bypass]] | ✅ Done | PRACTITIONER | SQL Injection |
| [[Lab - File path traversal, simple case\|Lab: File path traversal, simple case]] | ✅ Done | APPRENTICE | Path Traversal |
| [[PortSwigger Academy Labs/Lab - DOM XSS in jQuery anchor href attribute sink using location.search source\|Lab: DOM XSS in jQuery anchor href attribute sink using location.search source]] | ✅ Done | APPRENTICE | Cross-Site Scripting |
| [[Lab - DOM XSS in jQuery selector sink using a hashchange event\|Lab: DOM XSS in jQuery selector sink using a hashchange event]] | ✅ Done | APPRENTICE | Cross-Site Scripting |
| [[Lab - Reflected DOM XSS\|Lab: Reflected DOM XSS]] | ✅ Done | PRACTITIONER | Cross-Site Scripting |
| [[PortSwigger Academy Labs/Lab - Reflected XSS into attribute with angle brackets HTML-encoded\|Lab: Reflected XSS into attribute with angle brackets HTML-encoded]] | ✅ Done | APPRENTICE | Cross-Site Scripting |
| [[PortSwigger Academy Labs/Lab - Stored XSS into anchor href attribute with double quotes HTML-encoded\|Lab: Stored XSS into anchor href attribute with double quotes HTML-encoded]] | ✅ Done | APPRENTICE | Cross-Site Scripting |
| [[PortSwigger Academy Labs/Lab - Reflected XSS into a JavaScript string with angle brackets HTML encoded\|Lab: Reflected XSS into a JavaScript string with angle brackets HTML encoded]] | ✅ Done | APPRENTICE | Cross-Site Scripting |
| [[Lab - DOM XSS in document.write sink using source location.search inside a select element\|Lab: DOM XSS in document.write sink using source location.search inside a select element]] | ✅ Done | PRACTITIONER | Cross-Site Scripting |
| [[DOM XSS in AngularJS expression with angle brackets and double quotes HTML-encoded]] | ✅ Done | PRACTITIONER | Cross-Site Scripting |
| [[Lab - Stored DOM XSS\|Lab: Stored DOM XSS]] | ✅ Done | PRACTITIONER | Cross-Site Scripting |
| [[Lab - Reflected XSS into HTML context with most tags and attributes blocked\|Lab: Reflected XSS into HTML context with most tags and attributes blocked]] | ✅ Done | PRACTITIONER | Cross-Site Scripting |
| [[Lab - Reflected XSS into HTML context with all tags blocked except custom ones\|Lab: Reflected XSS into HTML context with all tags blocked except custom ones]] | ✅ Done | PRACTITIONER | Cross-Site Scripting |
| [[Lab - Reflected XSS with some SVG markup allowed\|Lab: Reflected XSS with some SVG markup allowed]] | ✅ Done | PRACTITIONER | Cross-Site Scripting |
| [[Lab - Exploiting cross-site scripting to steal cookies\|Lab: Exploiting cross-site scripting to steal cookies]] | ✅ Done | PRACTITIONER | Cross-Site Scripting |
| [[Lab - Exploiting cross-site scripting to capture passwords\|Lab: Exploiting cross-site scripting to capture passwords]] | ⬜ Not started | PRACTITIONER | Cross-Site Scripting |

%% Install the Dataview community plugin to turn the block below into a live, sortable table. The markdown table above works without it. %%

```dataview
TABLE status AS Status, difficulty AS Difficulty, date AS Date, tags AS Tags
WHERE database = "PortSwigger Academy"
SORT file.name ASC
```
